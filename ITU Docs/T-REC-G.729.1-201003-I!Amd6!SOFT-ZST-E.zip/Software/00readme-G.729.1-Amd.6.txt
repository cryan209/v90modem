README file for the root directory - G.729.1 (2006) Amd.6 (2010)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

G.729.1 (2006) Amd.6 (2010) introduced new Annex E with the
superwideband (SWB) extension of G.729.1.

For completeness, this software distribution includes not only the
ANSI-C code for Annex E, but also that for the whole of G.729.1. This
distribution is labelled as "Release 1.6".

The ANSI-C code of G.729.1 main body (MB) and its Annexes B, C, and D is
the same as approved in G.729.1 (2006) Cor.1 (2009), *except* that the
Release number has been changed to 1.6 within the .c and .h files.

The folders contain the various elements of the G.729.1
(self-evident):

- G.729.1_V1.6_Part1_fixed_point_MB
- G.729.1_V1.6_Part2_floating_point_AnnexB
- G.729.1_V1.6_Part3_dtxcng_fixed-point_AnnexC
- G.729.1_V1.6_Part4_dtxcng_floating-point_AnnexD
- G.729.1_V1.6_Part5_swb_mono_AnnexE

Test vectors can be downloaded from the ITU-T Test Signal Database, see:
http://itu.int/net/ITU-T/sigdb/speaudio/Gseries.htm#G.729.1?

See Copyright_Notice.txt file.

