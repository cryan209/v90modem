/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include "G729EV_TDBWE_extract_time_envelope.h"

#include "G729EV_MAIN_defines.h"

#include <math.h>

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_extract_time_envelope()                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                     *
 *  TDBWE time envelope (segment energy) computation                        *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_extract_time_envelope(REAL * signal,        /* (i) original highband input signal              */
                                        int nls,              /* (i) normalization of input signal               */
                                        REAL * envelope,      /* (o) time envelope parameters                    */
                                        int number_subframes) /* (i) number of consecutive subframes in signal[] */
{
  int       i, k;
  REAL      sum;
  REAL     *ptr_signal;

  ptr_signal = signal;

  /* loop over all segments */
  for (i = 0; i < number_subframes; i++)
  {
    /* accumulate square sample values */
    sum = (REAL) 0.0;
    for (k = 0; k < G729EV_TDBWE_SUBFRAME_SIZE; k++)
    {
      sum += (*ptr_signal) * (*ptr_signal);
      ptr_signal++;
    }

    /* compute (1/2)log2 of segment energies */
    envelope[i] = (REAL) 0.5 *(REAL) log(sum / G729EV_TDBWE_SUBFRAME_SIZE + 1.0e-8) * ONE_OVER_LOG2;
  }
}
