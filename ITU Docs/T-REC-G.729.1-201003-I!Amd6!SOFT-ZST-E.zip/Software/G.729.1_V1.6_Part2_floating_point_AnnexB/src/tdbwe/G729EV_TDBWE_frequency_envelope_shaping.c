/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_frequency_envelope_shaping.h"

#include "G729EV_G729_ld8k.h"

#include <math.h>


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_frequency_envelope_shaping_initialize()          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~          *
 *  initialization of TDBWE frequency envelope shaping module               *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_frequency_envelope_shaping_initialize(G729EV_TDBWE_frequency_envelope_shaping_state * state)  /* (o) */
{
  G729EV_TDBWE_fir_initialize(&state->fir, state->filter_coeffs);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_frequency_envelope_shaping()                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                     *
 *  TDBWE frequency envelope shaping module                                 *
 *  shape frequency envelope of input[] according to desired_envelope[]     *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_frequency_envelope_shaping(G729EV_TDBWE_frequency_envelope_shaping_state * state, /* (i/o) frequency envelope shaping state */
                                             REAL * input,                                          /* (i)   input signal                     */
                                             REAL * output,                                         /* (o)   shaped signal                    */
                                             REAL * desired_envelope)                               /* (i)   envelope parameters              */
{
  int       i, k;
  REAL      actual_envelope[G729EV_TDBWE_NB_SUBBANDS];
  REAL      gain;
  const REAL *coeffs;
  REAL      filter_coeffs[G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH];

  /* get frequency envelope of input signal */
  G729EV_TDBWE_extract_frequency_envelope(input - G729EV_TDBWE_MEM_EXC, 0, actual_envelope);

  /* compute subband gains and filter coeffs */
  G729EV_G729_Set_zero(filter_coeffs, G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH);

  coeffs = G729EV_TDBWE_fes_coeffs_matrix;

  for (i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
  {
    /* gain computation */
    gain = desired_envelope[i] - actual_envelope[i];
    gain = (REAL) pow(2.0, gain);

    /* FIR filter design by weighted summation */
    for (k = 0; k < G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH; k++)
    {
      filter_coeffs[k] += gain * coeffs[k];
    }
    coeffs = &coeffs[G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH];
  }

  /* add highpass contribution */
  for (k = 0; k < G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH; k++)
  {
    state->filter_coeffs[k] = filter_coeffs[k] + G729EV_TDBWE_FREQ_ENV_SHAPING_GAIN_HIGHPASS * coeffs[k];
  }

  /* symmetrical extension (the filter has linear phase, i.e. even symmetry) */
  for (k = G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1; k >= G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH; k--)
  {
    state->filter_coeffs[k] = state->filter_coeffs[G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH - k - 1];
  }

  /* do the filtering */
  G729EV_TDBWE_fir(&state->fir, input, output, G729EV_TDBWE_L_FRAME2);
}
