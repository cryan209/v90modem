/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_DECODER_H__
#define __G729EV_TDBWE_DECODER_H__



#include "G729EV_MAIN_defines.h"
#include "G729EV_TDBWE_generate_excitation.h"
#include "G729EV_TDBWE_frequency_envelope_shaping.h"
#include "G729EV_CELP2S.h"


/* type definition TDBWE decoder state variable */
typedef struct
{

  G729EV_TDBWE_generate_excitation_state generate_excitation;
  G729EV_TDBWE_frequency_envelope_shaping_state frequency_envelope_shaping;
  REAL      old_excitation_1[G729EV_TDBWE_MEM_EXC];
  REAL      mem_freq_env[G729EV_TDBWE_NB_SUBBANDS];
  REAL      mem_time_env[2];
  REAL      prev_gain_time_envelope_shaping;
} G729EV_TDBWE_DECSTAT;


/* prototypes for exported functions */

void      G729EV_TDBWE_decoder_init(G729EV_TDBWE_DECSTAT * state);

void      G729EV_TDBWE_decoder(G729EV_TDBWE_DECSTAT * state,
                               G729EV_CELP2S_PARAM * nb_celp_param, REAL * signal_highband, REAL * parameters);

void      G729EV_TDBWE_dequantization(int *coder_parameters, REAL * parameters_tdbwe);

/* tables */

/* TDBWE table for mean time envelope quantization       */
extern const REAL G729EV_TDBWE_MEAN_TIME_ENV_cb[32];

/* TDBWE tables for time envelope quantization           */
extern const REAL G729EV_TDBWE_TIME_ENV_cb[1024];

/* TDBWE tables for frequecy envelope quantization       */
extern const int G729EV_TDBWE_FREQ_ENV_NUMBER_ENTRIES[3];
extern const int G729EV_TDBWE_FREQ_ENV_BITS[3];
extern const REAL *G729EV_TDBWE_FREQ_ENV_cb[3];
extern const REAL G729EV_TDBWE_FREQ_ENV_cb1[128];
extern const REAL G729EV_TDBWE_FREQ_ENV_cb2[128];
extern const REAL G729EV_TDBWE_FREQ_ENV_cb3[64];

#endif
