/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_VECTOR_QUANTIZATION_H__
#define __G729EV_TDBWE_VECTOR_QUANTIZATION_H__

#include "G729EV_MAIN_defines.h"


/* protoype for exported function */

void      G729EV_TDBWE_vector_quantization(REAL * input,
                                           const REAL * codebook, int *index, int vector_size, int codebook_size);

/* tables */

/* TDBWE table for mean time envelope quantization       */
extern const REAL G729EV_TDBWE_MEAN_TIME_ENV_cb[32];

/* TDBWE tables for time envelope quantization           */
extern const REAL G729EV_TDBWE_TIME_ENV_cb[1024];

/* TDBWE tables for frequecy envelope quantization       */
extern const int G729EV_TDBWE_FREQ_ENV_NUMBER_ENTRIES[3];
extern const int G729EV_TDBWE_FREQ_ENV_BITS[3];
extern const REAL *G729EV_TDBWE_FREQ_ENV_cb[3];
extern const REAL G729EV_TDBWE_FREQ_ENV_cb1[128];
extern const REAL G729EV_TDBWE_FREQ_ENV_cb2[128];
extern const REAL G729EV_TDBWE_FREQ_ENV_cb3[64];

#endif
