/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_envadaption.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_envAdapt()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Reduce pre/postecho in lower and higher band                            *
 *  Add CELP and TDAC synthesis in lower-band                               *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_envAdapt(REAL * sOut_low,      /* (o)   output samples lowband */
                          REAL * sBasic_low,    /* (i)   12k layer contribution (lowband)  */
                          REAL * sTdacAdd_low,  /* (i)   TDAC layer add-on for lowand  */
                          REAL * vmlold,        /* (i)   needed for lowband gain smoothing  */
                          REAL * sOut_hi,       /* (o)   output samples highband */
                          REAL * sBasic_hi,     /* (i)   14k layer contribution (highband) */
                          REAL * sTdacInc_hi,   /* (i)   highband signal TDBWE combinded with TDAC */
                          REAL * vmhold,        /* (i)   needed for highband gain smoothing */
                          int work,             /* (i)   if zero ->do not cancel echo (rate<=14000) */
                          int begin_index_low,  /* (i)   start index for false alarm zone in lower-band  */
                          int end_index_low,    /* (i)   stop index for false alarm zone in lower-band */
                          int begin_index_high, /* (i)   start index for false alarm zone in higher-band */
                          int end_index_high    /* (i)   stop index for false alarm zone in higher-band */
    )
{
  int       i, j;
  REAL      vl, vh;
  REAL      vml[G729EV_MAIN_L_FRAME2];
  REAL      vmh[G729EV_MAIN_L_FRAME2];
  REAL      sBasicLow_tilt[G729EV_MAIN_L_FRAME2];
  REAL      sTdacAddLow_tilt[G729EV_MAIN_L_FRAME2];
  REAL      EsBasicLow;
  REAL      EsTdacAddLow;
  REAL      EsBasicHi;
  REAL      EsTdacIncHi;


  /* apply tilt on lowband before comparing energies */
  for (j = 1; j < G729EV_MAIN_L_FRAME2; j++)
  {
    sBasicLow_tilt[j] = sBasic_low[j] - sBasic_low[j - 1];
    sTdacAddLow_tilt[j] = sTdacAdd_low[j] - sTdacAdd_low[j - 1];
  }
  sBasicLow_tilt[0] = 0;
  sTdacAddLow_tilt[0] = 0;

  /* compare energies, get scale factors */
  for (j = 0; j < G729EV_MAIN_L_FRAME2; j = j + G729EV_MAIN_PRE_SUBFRAME)
  {
    if (work)
    {
      /* get energies */
      EsBasicLow = 100;
      EsTdacAddLow = 100;
      EsBasicHi = 100;
      EsTdacIncHi = 100;

      for (i = 0; i < G729EV_MAIN_PRE_SUBFRAME; i++)
      {
        EsBasicLow += sBasicLow_tilt[i + j] * sBasicLow_tilt[i + j];
        EsTdacAddLow += sTdacAddLow_tilt[i + j] * sTdacAddLow_tilt[i + j];
        EsBasicHi += sBasic_hi[i + j] * sBasic_hi[i + j];
        EsTdacIncHi += sTdacInc_hi[i + j] * sTdacInc_hi[i + j];
      }

      /* find scaling factor for lowband */
      vl = (REAL) sqrt(EsBasicLow / EsTdacAddLow);
      if (vl > 1.0)
        vl = (REAL) 1.0;

      /* find scaling factor for highband */
      vh = (REAL) sqrt(EsBasicHi / EsTdacIncHi);
      if (vh > 0.9)
        vh = (REAL) 1.0;
    }
    else
    {
      vh = (REAL) 1.0;
      vl = (REAL) 1.0;
    }

    for (i = 0; i < G729EV_MAIN_PRE_SUBFRAME; i++)
    {
      vml[i + j] = vl;
      vmh[i + j] = vh;
    }
  }

/* begin_index_low = 0; end_index_low = 159; no preecho supression */

  for (i = begin_index_low; i <= end_index_low; i++)
  {
    vml[i] = 1;
  }

  for (i = begin_index_high; i <= end_index_high; i++)
  {
    vmh[i] = 1;
  }

  /* EnvAdaption - smoothing of gains */
  vmh[0] = (vmh[0] * (REAL) 0.15) + (*vmhold * (REAL) 0.85);
  vml[0] = (vml[0] * (REAL) 0.15) + (*vmlold * (REAL) 0.85);
  for (i = 1; i < G729EV_MAIN_L_FRAME2; i++)
  {
    vmh[i] = (vmh[i] * (REAL) 0.15) + (vmh[i - 1] * (REAL) 0.85);
    vml[i] = (vml[i] * (REAL) 0.15) + (vml[i - 1] * (REAL) 0.85);
  }

  /* update vmh vml memory */
  *vmlold = vml[(G729EV_MAIN_L_FRAME2) - 1];
  *vmhold = vmh[(G729EV_MAIN_L_FRAME2) - 1];

  for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
  {
    sOut_low[i] = sBasic_low[i] + sTdacAdd_low[i] * vml[i];
    sOut_hi[i] = sTdacInc_hi[i] * vmh[i];
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_PreechoFalseAlarm()                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Determine start/stop indices for false alarm zone in lower- and higher- *
 *  band                                                                    *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_PreechoFalseAlarm(REAL * rec_sig,    /* (i)   reconstructed signal, output of the imdct transform */
                                   REAL * imdct_mem,  /* (i)   memory of the imdct transform, used in the next frame */
                                   REAL * max_prev,   /* (i/o) maximum energy in the previous reconstructed frame */
                                   int *begin_ind,    /* (o)   starting index of the eventual false alarm zone */
                                   int *end_ind       /* (o)   ending index of the eventual false alarm zone */
    )
{
  int       i, j;
  REAL      es_tdac[6];         /* 0..3: energy of the 4 subframes, 4..5: energy of the future subframes */
  REAL      min_es, max_es, max_rec;
  REAL     *ptr;

  max_rec = (REAL) 0.0;
  /*energy of low bands 4 present and 2 future sub-frames */
  for (i = 0; i < 6; i++)
  {
    es_tdac[i] = 100;
  }
  ptr = rec_sig;
  for (j = 0; j < 4; j++)       /* 4 present subframes */
  {
    for (i = 0; i < G729EV_MAIN_PRE_SUBFRAME; i++)
    {
      es_tdac[j] += *ptr * *ptr;
      ptr++;
    }
  }

  ptr = imdct_mem;
  for (j = 4; j < 6; j++)       /* 2 future subframes */
  {
    for (i = 0; i < G729EV_MAIN_PRE_SUBFRAME; i++)
    {
      es_tdac[j] += *ptr * *ptr;
      ptr++;
    }
    es_tdac[j] *= 2;            /* *2 as the max of the synthesis window is sqrt(2) */
  }

  min_es = es_tdac[0];          /* for memorising the min energy */
  max_es = es_tdac[0];          /* for memorising the max energy */
  *begin_ind = 0;
  for (i = 1; i < 6; i++)
  {
    if (es_tdac[i] > max_es)
    {
      max_es = es_tdac[i];      /* max energy low band, 4 present and 2 future subframes */
      *begin_ind = i * G729EV_MAIN_PRE_SUBFRAME;
    }
    if (3 == i)
    {
      max_rec = max_es;         /* save partial max result for the 4 present subframes */
    }
  }

  if (*max_prev / max_rec > 32) /*post-echo situation, preecho false alarm detection desactivated */
  {
    *begin_ind = G729EV_MAIN_L_FRAME2;
    *end_ind = G729EV_MAIN_L_FRAME2 - 1;  /* begin > end --> nothing is done */
    *max_prev = max_rec;
  }
  else
  {
    *max_prev = max_rec;
    for (i = 1; i < 4; i++)
    {
      if (es_tdac[i] < min_es)
      {
        min_es = es_tdac[i];    /* min energy low band, 4 present subframes only */
      }
    }
    if (max_es / min_es < 16)   /* no big energy change --> no preecho ->false alarm zone:the whole frame */
    {
      *begin_ind = 0;
      *end_ind = G729EV_MAIN_L_FRAME2 - 1;
    }
    else
    {
      *end_ind = *begin_ind + 2 * G729EV_MAIN_PRE_SUBFRAME - 1; /*length of the false alarm zone is 2 subframes */
      if (*end_ind > G729EV_MAIN_L_FRAME2 - 1)
      {
        *end_ind = G729EV_MAIN_L_FRAME2 - 1;
      }
    }
  }
  return;
}
