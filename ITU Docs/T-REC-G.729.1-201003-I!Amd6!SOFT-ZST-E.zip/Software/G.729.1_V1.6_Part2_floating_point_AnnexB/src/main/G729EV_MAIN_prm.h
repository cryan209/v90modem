/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_PRM_H__
#define __G729EV_MAIN_PRM_H__

#include "G729EV_MAIN_decod.h"
#include "G729EV_MAIN_encod.h"

void      G729EV_MAIN_param2bit(int *coder_parameters,                  /* input */
                                int nb_bits, INT16 * itu_192_bitstream, /* output */
                                CODSTATMAIN * codstat);

void      G729EV_MAIN_bit2param(INT16 * itu_192_bitstream,  /* input */
                                int nb_bits,                /* input / number of bits in bitstream */
                                int *coder_parameters,      /* output */
                                int *ind_FER,               /* output */
                                DECSTATMAIN * decstat);


#endif /* __G729EV_MAIN_PRM_H__ */
