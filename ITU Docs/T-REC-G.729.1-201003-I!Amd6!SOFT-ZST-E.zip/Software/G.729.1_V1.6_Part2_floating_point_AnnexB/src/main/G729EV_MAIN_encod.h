/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/



#ifndef __G729EV_MAIN_ENCOD_H__
#define __G729EV_MAIN_ENCOD_H__

#include <stdio.h>
#include "CodecTypedef.h"

#include "G729EV_TDBWE_encoder.h"
#include "G729EV_G729_codstat.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_defines.h"

/* Types : */

typedef struct
{
  /* filter states */
  G729EV_MAIN_QMFCODSTAT qmf_ana;
  G729EV_MAIN_IIR2STAT mem_hp50;
  G729EV_MAIN_IIRN_STAT mem_lp3k;

  /* G.729 state variables */
  G729EV_G729_CODSTAT codStG729;
  G729EV_G729_DECSTAT decStG729;
  G729EV_TDBWE_CODSTAT tdbwe;

  /* states for perceptual weighting filtering of lower-band difference signal */
  REAL      mem_Wz_in[G729EV_G729_M];
  REAL      mem_wsp[G729EV_G729_M];

  /* memory of MDCT */
  REAL      mem_mdct_lo[G729EV_MAIN_L_FRAME2];
  REAL      mem_mdct_hi[G729EV_MAIN_L_FRAME2];

  /* states variables of FER encoder */
  INT16     oldferclass;
  REAL      lp_speech;
  REAL      relE_hist;
  REAL      relE_var;
  INT16     old_pulspos;

  /* encoder flags (8kHz sampled input, G729 bitstream mode) */
  int       f8;
  int       g729_bst;

} CODSTATMAIN;


/* Functions : */

void      G729EV_MAIN_InitEncoder(CODSTATMAIN * codstat, int rate, int f8, int g729_bst);

void      G729EV_MAIN_Encode(CODSTATMAIN * codstat, INT16 * samplesIn, INT16 * bitstream, int rate);


#endif  /*__G729EV_MAIN_ENCOD_H__ */
