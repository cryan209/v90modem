/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_CELP2S_qua_gain.h"


/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_qua_gain_Stage2()                *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                *
 *  gain codebook index                                      *
 *-----------------------------------------------------------*/

int G729EV_CELP2S_qua_gain_Stage2(                  /* (o)  : gain codebook index */
                                   REAL gain_code,  /* (i) : code gain of 1st stage                 */
                                   REAL xn[],       /* (i) : target vector for 2nd stage            */
                                   REAL y1[],       /* (i) : filtered fixed codeword for 2nd stage  */
                                   int l_subfr,     /* (i) : vector dimension                       */
                                   INT16 i_subfr    /* (i)  subframe number                         */
    )
{
  REAL      g_coeff[2];
                      /**< output: <y1,y1> and -2<xn,y1> */
  REAL      xy, yy;
  int       i, index;
  REAL      gain, dist, min_dist;
  REAL      gain_code_enh, ftmp;

  /* compute correlations */
  xy = (REAL) 0.0;
  for (i = 0; i < l_subfr; i++)
  {
    xy += xn[i] * y1[i];
  }
  yy = (REAL) 0.1;
  for (i = 0; i < l_subfr; i++)
  {
    yy += y1[i] * y1[i];        /* energy of filtered excitation */
  }
  g_coeff[0] = yy;
  g_coeff[1] = (REAL) - 2.0 * xy + (REAL) 0.01;


  /* quantize cb gain (relative value w.r.t gain_code) - 3 bits */
  if (i_subfr == 1 || i_subfr == 3)
  {

    gain_code_enh = xy / yy;
    ftmp = (REAL) (20.0f * log10(gain_code_enh / gain_code));
    index = (INT16) floor((0.333333f * (ftmp + 6.0f)) + 0.5f);
    if (index > 3)
      index = 3;
    if (index < 0)
      index = 0;
  }
  else
  {
    index = 0;
    gain = G729EV_MAIN_tab_gain_enha[0] * gain_code;
    min_dist = gain * (g_coeff[1] + gain * g_coeff[0]);
    for (i = 1; i < 8; i++)
    {
      gain = G729EV_MAIN_tab_gain_enha[i] * gain_code;

      dist = gain * (g_coeff[1] + gain * g_coeff[0]);
      if (dist < min_dist)
      {
        min_dist = dist;
        index = i;
      }
    }
  }

  return index;
}

/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_dec_gain_Stage2()                *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                *
 *  decode quantized gain                                    *
 *-----------------------------------------------------------*/

REAL G729EV_CELP2S_dec_gain_Stage2(                 /* (o)  : quantized gain (2nd stage) */
                                    REAL gain_code, /* (i) : 1 St stage code gain       */
                                    int index,      /* (i) : 2 nd stage code gain index */
                                    INT16 i_subfr   /* (i) : subframe number            */
    )
{
  REAL      gain_code_enh, ftmp;

  /*  decode quantized gain value from index */
  if (i_subfr == 1 || i_subfr == 3)
  {
    index &= 0x03;              /* Ensure there is no more than 2 bits read #### Should not be needed when TDAC will be present ### TV */
    ftmp = (((REAL) index) * 3.0f) - 6.0f;
    gain_code_enh = gain_code * (REAL) (pow(10, ftmp * 0.05f));
  }
  else
  {
    gain_code_enh = gain_code * G729EV_MAIN_tab_gain_enha[index];
  }

  return gain_code_enh;
}
