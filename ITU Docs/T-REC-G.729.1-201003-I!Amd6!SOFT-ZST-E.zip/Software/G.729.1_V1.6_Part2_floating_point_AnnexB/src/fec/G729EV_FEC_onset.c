/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <math.h>
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_FEC_tools.h"
#include "G729EV_G729_ld8k.h"

/************************************************************************************/
/* G729EV_FEC_mod_adapt_codebook :  Artificial reconstruction of the adaptive       */
/*                                  codebook memory after the lost of an ONSET      */
/* - Decode location and sign of the last pulse                                     */
/* - Reset adaptive codebook memory                                                 */
/* - Find LP filter impulse response energy                                         */
/* - Scale pulse "prototype" energy                                                 */
/* - Place pulse "prototype" at the right position in the adaptive codebooke memory */
/* - Update adaptive codebook memory                                                */
/* - Find signal classification                                                     */
/************************************************************************************/
void G729EV_FEC_mod_adapt_codebook(REAL * exc,        /* i/o : exc vector to modify                                             */
                                   int puls_pos,      /* i   : Last pulse position desired                                      */
                                   REAL * pitch_buf,  /* i   : containt pitch modified in function of bfi_pitch and new pitch   */
                                   REAL enr_q,        /* i   : energy provide by the encoder                                    */
                                   REAL * Aq          /* i   : Lsp coefficient                                                  */
    )
{
  INT16     T0, P0, onset_len, sign, i, len;
  REAL      h1[G729EV_G729_L_SUBFR], mem[G729EV_G729_M], exc_tmp[G729EV_FEC_L_MEM];
  REAL     *pt_end, *pt_exc, enr_LP, gain;
  REAL      H_low[5];

  sign = 0;
  T0 = (INT16) (pitch_buf[3]);


  if (T0 < 2 * G729EV_G729_L_SUBFR)
    onset_len = 2 * G729EV_G729_L_SUBFR;
  else
    onset_len = T0;


  P0 = puls_pos;

  if (P0 >= 64)
  {
    sign = 1;
    P0 = (P0 & 0x3F);
  }

  if (T0 >= 128)
  {
    P0 *= 4;
    P0 += 2;
  }
  else if (T0 >= 64)
  {
    P0 *= 2;
    P0 += 1;
  }

  if (P0 > 160)
  {
    P0 = 160;                   /* Should never be the case, however... */
  }

  G729EV_G729_Set_zero(exc_tmp, G729EV_FEC_L_MEM);  /* Reset excitation vector            */

 /*------------------------------------------------------------------------------------------*
  * Find LP filter impulse response energy   
  *------------------------------------------------------------------------------------------*/

  G729EV_G729_Set_zero(h1, G729EV_G729_L_SUBFR);  /* Find the impulse response          */
  G729EV_G729_Set_zero(mem, G729EV_G729_M);
  h1[0] = (REAL) 1.0;
  G729EV_G729_Syn_filt(Aq, h1, h1, G729EV_G729_L_SUBFR, mem, 0);
  enr_LP = G729EV_Dot_product(h1, h1, G729EV_G729_L_SUBFR) + (REAL) 0.01; /* Find the impulse response energy   */

  /* divide by LP filter E, scaled by transmitted E   */
  /* gain = (float)sqrt( enr_q / enr_LP ); */
  gain = (REAL) sqrt(1.5 * enr_q / enr_LP); /* divide by LP filter E, scale by transmitted E */
  gain *= 0.96f;

  /* Scale pulse "prototype" energy */
  /* Generate the scaled pulse */
  for (i = 0; i < G729EV_FEC_L_FIR_FER; i++)
  {
    H_low[i] = gain * G729EV_FEC_h_low[i];
  }

 /*------------------------------------------------------------------------------------------*
  * Place pulse "prototype" at the right position in the adaptive codebooke memory          
  *------------------------------------------------------------------------------------------*/
  len = G729EV_MAIN_L_FRAME2 - 1 - G729EV_FEC_L_FIR_FER / 2 - P0;
  pt_exc = exc_tmp + len;       /* beginning of the 1st pulse         */
  pt_end = exc_tmp + onset_len;
  len -= onset_len;
  if (len > G729EV_FEC_L_FIR_FER) /* untill the end of artificial onset */
  {
    len = G729EV_FEC_L_FIR_FER;
  }

  if (!sign)
  {
    for (i = 0; i < len; i++)
    {                           /* The filter response would have E=1 in full band. */
      pt_exc[i] += H_low[i];    /* As it is lp filtered, the E is somewhat lower */
    }
  }
  else
  {
    for (i = 0; i < len; i++)
    {                           /* The filter response would have E=1 in full band. */
      pt_exc[i] -= H_low[i];    /* As it is lp filtered, the E is somewhat lower */
    }
  }

  G729EV_G729_Copy(&exc_tmp[G729EV_MAIN_L_FRAME2 - G729EV_G729_PIT_MAX - G729EV_G729_L_INTERPOL],
                   exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
}
