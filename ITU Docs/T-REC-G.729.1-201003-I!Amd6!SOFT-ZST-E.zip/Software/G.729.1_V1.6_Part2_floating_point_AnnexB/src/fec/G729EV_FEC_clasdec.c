/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*----------------------------------------------------------------------------------*
 *  Signal classification at the decoder for FER concealment
 *----------------------------------------------------------------------------------*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_FEC_tools.h"
#include "G729EV_G729_ld8k.h"

/*---------------------------------------------------------------------*
 * - Prototypes
 *---------------------------------------------------------------------*/
static REAL G729EV_FEC_frame_energy(const REAL * pitch, const REAL * speech, const REAL lp_speech, REAL * frame_ener);
static void Corre(REAL * x, REAL * y, int l, REAL * gain);

/*---------------------------------------------------------------------*
 * Signal classification at the decoder for FER concealment
 * Function used only at 8kbps. When bit rate >= 12kbps, the classification 
 * is sent by the encoder. 
 *---------------------------------------------------------------------*/
void G729EV_FEC_clas_dec(INT16 * clas,          /* i/o: frame classification                    */
                         const REAL * pitch,    /* i:   pitch values for each subframe          */
                         const INT16 last_good, /* i:   type of the last correctly received fr. */
                         REAL * frame_synth,    /* i/o: synthesis buffer                        */
                         REAL * st_old_synth,   /* i/o: synthesis memory                        */
                         REAL * lp_speech       /* i/o: long term active speech energy average  */
    )
{
  REAL     *pt1, *pt2, zc_frame, frame_ener, s1, s2;
  REAL      tiltn, corn, zcn, pcn, fmerit1, tilt;
  REAL      voicing, enr1t, enr2t, enr1[3], enr2[3], ener, enern, cor_max[3], *synth;
  INT16     tmpS, i, j, zc[4], T0, pos, pc;
  REAL      old_synth[G729EV_G729_PIT_MAX + G729EV_MAIN_L_FRAME2];

  cor_max[0] = (REAL) 0.;
  cor_max[1] = (REAL) 0;
  cor_max[2] = (REAL) 0;
  /*-----------------------------------------------------------------*  
   * Copy synthesis into local buffer
   *-----------------------------------------------------------------*/
  synth = old_synth + G729EV_G729_PIT_MAX;  /* Pointer to the current frame     */
  for (i = 0; i < G729EV_G729_PIT_MAX; i++)
  {
    old_synth[i] = st_old_synth[i];
  }
  for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
  {
    synth[i] = frame_synth[i];
  }

   /*-----------------------------------------------------------------*  
    - Compute the zero crossing rate for all subframes
    *-----------------------------------------------------------------*/
  pt1 = (REAL *) synth;
  pt2 = (REAL *) synth - 1;
  for (i = 0; i < 4; i++)
  {
    tmpS = 0;

    for (j = 0; j < G729EV_G729_L_SUBFR; j++)
    {
      if ((*pt1 <= (REAL) 0.0) && (*pt2 > (REAL) 0.0))
      {
        tmpS++;
      }
      pt1++;
      pt2++;
    }
    zc[i] = tmpS;
  }
  zc_frame = (REAL) (zc[0] + zc[1] + zc[2] + zc[3]);

    /*-----------------------------------------------------------------*  
     * Compute the normalized correlation pitch-synch. at the end 
     * of the frame
     *-----------------------------------------------------------------*/
  T0 = (INT16) pitch[3];
  if (T0 > 3 * (G729EV_G729_L_SUBFR / 2))
  {
    T0 = (INT16) ((REAL) 0.5 * (pitch[2] + pitch[3]) + (REAL) 0.5);
  }
  pos = G729EV_MAIN_L_FRAME2;
  j = 0;
  pt1 = synth;
  while (pos > 3 * G729EV_G729_L_SUBFR) /* Can be entered maximally 3 times       */
  {
    pos -= T0;
    Corre(&pt1[pos], &pt1[pos - T0], T0, &cor_max[j]);
    if ((pos - T0) < 3 * G729EV_G729_L_SUBFR)
    {
      T0 = (INT16) ((REAL) 0.5 * (pitch[2] + pitch[3]) + (REAL) 0.5);
    }
    j++;
  }

  voicing = cor_max[0];
  for (i = 1; i < j; i++)
  {
    voicing += cor_max[i];
  }

  if (j == 3)
  {
    voicing *= (REAL) 0.33333;
  }
  else if (j == 2)
  {
    voicing *= (REAL) 0.5;
  }
  pc = (INT16) abs((int) (pitch[3] + pitch[2] - pitch[1] - pitch[0]));

   /*-----------------------------------------------------------------*  
    * Compute spectral tilt
    *-----------------------------------------------------------------*/
  enr1t = (REAL) 0.0;
  enr2t = (REAL) 0.0;
  pt1 = (REAL *) synth + G729EV_G729_L_SUBFR;
  pt2 = (REAL *) synth + G729EV_G729_L_SUBFR - 1;
  for (i = 0; i <= 2; i++)
  {
    s1 = (REAL) 0.0;
    s2 = (REAL) 0.0;
    for (j = 0; j < G729EV_G729_L_SUBFR; j++)
    {
      s1 += *pt1 * *pt1;
      s2 += *pt1 * *pt2;
      pt1++;
      pt2++;
    }
    enr1[i] = s1;
    enr2[i] = s2;
    enr1t += enr1[i];
    enr2t += enr2[i];
  }

  tilt = enr2t / (enr1t + (REAL) 0.1);

    /*-----------------------------------------------------------------*  
     * Compute pitch-synchronous energy at the frame end
     *-----------------------------------------------------------------*/
  ener = G729EV_FEC_frame_energy(pitch, synth, *lp_speech, &frame_ener);

    /*-----------------------------------------------------------------*  
     * transform parameters between 0 & 1    
     * find unique merit function            
     *-----------------------------------------------------------------*/
  enern = G729EV_FEC_K_ENR * ener + G729EV_FEC_C_ENR;
  tiltn = G729EV_FEC_K_TILT * tilt + G729EV_FEC_C_TILT;
  corn = G729EV_FEC_K_COR_DEC * voicing + G729EV_FEC_C_COR_DEC;
  zcn = G729EV_FEC_K_ZC_DEC * zc_frame + G729EV_FEC_C_ZC_DEC;
  pcn = G729EV_FEC_K_PC_DEC * pc + G729EV_FEC_C_PC_DEC;

  if (pcn > (REAL) 1.0)
  {
    pcn = (REAL) 1.0;
  }
  else if (pcn < (REAL) 0.0)
  {
    pcn = (REAL) 0.0;
  }

  if (corn > 0)
    corn *= (REAL) 2.;

  fmerit1 = (tiltn + (REAL) 2.0 * corn + zcn + pcn + enern) / (REAL) 6.;

 /*-----------------------------------------------------------------*  
  * frame classification                  
  *-----------------------------------------------------------------*/
  switch (last_good)
  {
    case G729EV_FEC_VOICED:
    case G729EV_FEC_ONSET:
    case G729EV_FEC_SIN_ONSET:
    case G729EV_FEC_V_TRANSITION:

      if (fmerit1 < (REAL) 0.39)
      {
        *clas = G729EV_FEC_UNVOICED;
      }
      else if (fmerit1 < (REAL) 0.63)
      {
        *clas = G729EV_FEC_V_TRANSITION;
      }
      else
      {
        *clas = G729EV_FEC_VOICED;
      }

      break;

    case G729EV_FEC_UNVOICED:
    case G729EV_FEC_UV_TRANSITION:

      if (fmerit1 > (REAL) 0.56)
      {
        *clas = G729EV_FEC_ONSET;
      }
      else if (fmerit1 > (REAL) 0.45)
      {
        *clas = G729EV_FEC_UV_TRANSITION;
      }
      else
      {
        *clas = G729EV_FEC_UNVOICED;
      }

      break;

    default:
      *clas = G729EV_FEC_UNVOICED;
      break;
  }

   /*-----------------------------------------------------------------*  
    * Measure average energy on good, active G729EV_FEC_VOICED frames for FER 
    * concealment classification
    *-----------------------------------------------------------------*/
  if (*clas == G729EV_FEC_VOICED)
  {
    *lp_speech = (REAL) 0.99 **lp_speech + (REAL) 0.01 *frame_ener; /* lp_speech update */
  }

   /*-----------------------------------------------------------------*  
    * Update synthesized speech memory
    *-----------------------------------------------------------------*/
  for (i = 0; i < G729EV_G729_PIT_MAX; i++)
  {
    st_old_synth[i] = old_synth[i + G729EV_MAIN_L_FRAME2];
  }

  return;
}


/*---------------------------------------------------------------------*  
 *  Compute pitch-synchronous energy at the frame end
 *---------------------------------------------------------------------*/

static REAL G729EV_FEC_frame_energy(                        /* o:   Pitch synchronus energy                    */
                                     const REAL * pitch,    /* i:   pitch values for each subframe             */
                                     const REAL * speech,   /* i:   pointer to speech signal for E computation */
                                     const REAL lp_speech,  /* i:   long term active speech energy average     */
                                     REAL * frame_ener      /* o:   pitch-synchronous energy at frame end      */
    )
{
  REAL      enern, *pt1;
  INT16     len;

  len = (INT16) ((REAL) 0.5 * (pitch[2] + pitch[3]) + (REAL) 0.5);

  if (len < G729EV_G729_L_SUBFR)
  {
    len *= 2;
  }

  pt1 = (REAL *) speech + G729EV_MAIN_L_FRAME2 - len;

  *frame_ener = (REAL) 10.0 *(REAL) log10(G729EV_Dot_product(pt1, pt1, len) / (REAL) len);

  enern = *frame_ener - lp_speech;

  return enern;
}

/*-----------------------------------------------------------------*
 * function Corre()
 *          ~~~~~~~~
 * Correlation function.  Signal x is compared to target signal y
 * Information about the similarity between vectors is returned in *gain
 *-----------------------------------------------------------------*/

static void Corre(REAL * x,     /* i:   vector 1                     */
                  REAL * y,     /* i:   vector 2                     */
                  int l,        /* i:   length of vectors            */
                  REAL * gain   /* o:   normalized correlation gain  */
    )
{
  REAL      cor, den, den2;

  cor = G729EV_Dot_product(x, y, l);
  den = G729EV_Dot_product(y, y, l);
  den2 = G729EV_Dot_product(x, x, l);

  *gain = cor / (REAL) sqrt(den * den2 + (REAL) 0.1);
  return;
}
