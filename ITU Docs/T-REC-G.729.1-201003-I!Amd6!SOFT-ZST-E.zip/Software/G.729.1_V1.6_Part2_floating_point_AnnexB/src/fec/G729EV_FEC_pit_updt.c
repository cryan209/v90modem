/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_FEC_fer.h"

/************************************************************************************/
/* G729EV_FEC_pit_updt :  Update last reliable pitch                                */
/************************************************************************************/

void G729EV_FEC_pit_updt(INT16 clas,        /* i:   frame classification           */
                         REAL * pitch_buf,  /* i:   fractionnal pitch buffer       */
                         INT16 last_good,   /* i:   Last good frame classification */
                         INT16 * upd_cnt,   /* i/o: update counter                 */
                         REAL * old_fpitch, /* i/o: old fractionnal pitch buffer   */
                         REAL * fpitch      /* i/o: fractionnal pitch              */
    )
{
  if ((clas == G729EV_FEC_VOICED) && (last_good >= G729EV_FEC_V_TRANSITION))
  {
    if ((pitch_buf[3] < (REAL) 1.4 * pitch_buf[1]) && (pitch_buf[3] > (REAL) 0.7 * pitch_buf[1]) && /* Check for pitch coherence */
        (pitch_buf[1] < (REAL) 1.4 * *old_fpitch) && (pitch_buf[3] > (REAL) 0.7 * *old_fpitch))
    {
      *upd_cnt = 0;
    }
  }

  if (clas == G729EV_FEC_UNVOICED)
  {
    *old_fpitch = (fpitch[0] + fpitch[1]) / (REAL) 2.0;
  }
  else
  {
    *old_fpitch = pitch_buf[3];
  }
  (*upd_cnt)++;                 /* counter of the age of the last update */
  if (*upd_cnt > G729EV_FEC_MAX_UPD_CNT)
  {
    *upd_cnt = G729EV_FEC_MAX_UPD_CNT;
  }

}
