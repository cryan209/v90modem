/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_FEC_H__
#define __G729EV_FEC_H__

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_ld8k.h"

/* fer prototype */
void      G729EV_FEC_encod(const INT16 old_clas,  /* i:   signal classification result from previous frames */
                           const REAL * voicing,  /* i:   normalized correlation for 3 half-frames          */
                           const REAL * speech,   /* i:   pointer to denoised speech signal                 */
                           const REAL * synth,    /* i:   pointer to synthesized speech for E computation   */
                           const INT16 * T_op,    /* i:   close loop pitch values for 3 half-frames         */
                           const REAL * ee,       /* i:   lf/hf E ration for 2 half-frames                  */
                           const REAL * sync_sp,  /* i:   time syncronised input speech                     */
                           INT16 * clas,          /* o:   signal clas for current frame                     */
                           int *coder_parameters, /* o:   coder_parameters                                  */
                           const INT16 T0,        /* i:   close loop integer pitch                          */
                           const INT16 T0_frac,   /* i:   close loop fractional part of the pitch           */
                           const REAL * res,      /* i:   LP residual signal frame                          */
                           REAL * lp_speech,      /* i/o: LP speech energu                                  */
                           REAL * rel_hist,       /* i/o: relative energy memory                            */
                           REAL * rel_var,        /* i/o: relative erergy variation                         */
                           INT16 * old_pos        /* i/o: Position of the last pulse                        */
    );

INT16     G729EV_FEC_dec(                       /* o:   frame class information           */
                          INT16 * last_good,    /* i:   last good received frame class    */
                          INT16 plast_good,     /* i:  previous last good received frame class    */
                          const INT16 prev_bfi, /* i:   BFI of the previous frame         */
                          int *indice,          /* i/o: Q indices (parameter vector)      */
                          REAL * enr_q,         /* o:   E information for FER protection  */
                          int Rate              /* i:   Bitrate decoded                   */
    );

void      G729EV_FEC_dec_bf(INT32 parm[],             /* (i)   : vector of synthesis parameters       */
                            REAL synth[],             /* (i/o) : synthesis speech                     */
                            REAL Az_dec[],            /* (o)   : decoded LP filter in 2 subframes     */
                            INT16 bfi,                /* (i)   : Bad Frame Indicator                  */
                            INT16 * last_good,        /* (i)   : last good frame classification       */
                            REAL * pitch_buf,         /* (i/o) : Pitch memory                         */
                            REAL old_enr,             /* (i)   : Energy at the end of the last frame  */
                            REAL * old_exc,           /* (i/o) : excitiation memory                   */
                            G729EV_G729_DECSTAT * st, /* (i)   : Decoder structure                    */
                            INT16 new_clas,           /* (i)   : present frame classification         */
                            INT16 puls_pos            /* (i)   : Position of the last pulse           */
    );

void      G729EV_FEC_energy(const INT16 clas,   /* i:   frame classification                     */
                            const REAL * synth, /* i:   synthesized speech                       */
                            const REAL pitch,   /* i:   pitch period                             */
                            REAL * enr_q,       /* o:   pitch-synchronous or half_frame energy   */
                            const INT16 offset  /* i:   speech pointer offset (0 or L_FRAME)     */
    );
void      G729EV_FEC_clas_dec(INT16 * clas,           /* i/o: frame classification                   */
                              const REAL * pitch,     /* i:   pitch values for each subframe         */
                              const INT16 last_good,  /* i:   type of the last correctly received fr.*/
                              REAL * frame_synth,     /* i/o: synthesis buffer                       */
                              REAL * st_old_synth,    /* i/o: synthesis memory                       */
                              REAL * lp_speech        /* i/o: long term active speech energy average */
    );

void      G729EV_FEC_pit_updt(INT16 clas,         /* i:   frame classification              */
                              REAL * pitch_buf,   /* i:   fractionnal pitch buffer QPIT     */
                              INT16 last_good,    /* i:   Last good frame classification    */
                              INT16 * upd_cnt,    /* i/o: update counter                    */
                              REAL * old_fpitch,  /* i/o: old fractionnal pitch buffer      */
                              REAL * fpitch       /* i/o: fractionnal pitch                 */
    );
void      G729EV_FEC_scale_syn(INT16 extrate,         /* i: indicate decoded bit rate                 */
                               INT16 clas,            /* i/o: frame classification                    */
                               const INT16 last_good, /* i:   last good frame classification          */
                               REAL * synth,          /* i/o: synthesized speech                      */
                               const REAL * pitch,    /* i:   pitch values for each subframe          */
                               REAL enr_q,            /* i:   transmitted energy for current frame    */
                               const INT16 prev_bfi,  /* i:   previous frame BFI                      */
                               REAL Aq[],             /* i/o: LP filter coefs (can be modified if BR) */
                               REAL * old_enr_LP,     /* i/o: LP filter E of last good G729EV_FEC_VOICED frame   */
                               REAL * mem_tmp,        /* i/o: temporary synthesis memory              */
                               REAL * exc_tmp,        /* i/o: temporary excitation                    */
                               REAL enr_old,          /* i  : energy at the end of the last frame     */
                               REAL * old_exc,        /* i/o: excitation buffer                       */
                               REAL * mem_syn,        /* i/o: synthesis memory                        */
                               INT16 bfi_cnt          /* i  : Number of bad frame                     */
    );
INT16     G729EV_FEC_findpulse(                   /* o:   pulse position        */
                                const REAL res[], /* i:   residual signal       */
                                INT16 T0,         /* i:   integer pitch         */
                                const INT16 enc   /* i:  enc = 1 -> encoder side; enc = 0 -> decoder side */
    );
void      G729EV_FEC_mod_adapt_codebook(REAL * exc,       /* i/o : exc vector to modify                                               */
                                        int puls_pos,     /* i   : Last pulse position desired                                        */
                                        REAL * pitch_buf, /* i   : containt pitch modified in function of bfi_pitch and new pitch     */
                                        REAL enr_q,       /* i   : energy provide by the encoder                                      */
                                        REAL * Aq         /* i   : Lsp coefficient                                                    */
    );
void      G729EV_FEC_pitch_pred(INT16 bfi,      /* i: Bad frame ?                     */
                                int *T,         /* i/o: Pitch                         */
                                int *T_fr,      /* i/o: fractionnal pitch             */
                                REAL * pit_mem, /* i/o: Pitch memories                */
                                INT16 * bfi_mem /* i/o: Memory of bad frame indicator */
    );
#endif /* __G729EV_FEC_H__ */
