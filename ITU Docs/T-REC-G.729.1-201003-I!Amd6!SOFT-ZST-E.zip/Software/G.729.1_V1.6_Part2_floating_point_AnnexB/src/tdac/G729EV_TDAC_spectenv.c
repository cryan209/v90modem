/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <assert.h>
#include <stdlib.h>
#include <math.h>

#include "G729EV_G729_defines.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_spectenv.h"
#include "G729EV_TDAC_util.h"
#include "G729EV_TDAC_lib_vq.h"
#include "G729EV_TDAC_vq.h"

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_calc_specEnv()                                    *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      *
*  Compute log2 rms for each subband                                       *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_calc_specEnv(REAL * y,       /* (i)    transform coefficients of the difference           */
                              REAL * log_rms, /* (o)    log2 of the spectrum envelope                      */
                              int n           /* (i)    number of subbands                                 */
    )
{
  int       i, j;
  REAL      ener;

  for (j = 0; j < n; j++)
  {
    /* compute subband energy */
    ener = (REAL) 0.0;
    for (i = G729EV_TDAC_sb_bound[j]; i < G729EV_TDAC_sb_bound[j + 1]; i++)
      ener += y[i] * y[i];      /*sum of squared coef */

    /* derive subband log-rms */
    log_rms[j] = (REAL) 0.5 *(REAL) log(ener / (REAL) G729EV_TDAC_nb_coef[j] + G729EV_TDAC_EPS1) * G729EV_TDAC_LOG2_INV;
  }

  return;
}

/*--------------------------------------------------------------------------*
* cod_specEnv : encoding of the spectrum envelope                          *
*--------------------------------------------------------------------------*/

/* subroutines:
   - G729EV_TDAC_quant_3dB
   - G729EV_TDAC_compute_diff_index
   - G729EV_TDAC_encode_spenv
   - G729EV_TDAC_writ_specEnv
 */

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_quant_3dB()                                       *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
*  Quantize with 3dB step                                                  *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_quant_3dB(int *index,      /* (o)    code words number              */
                           REAL * log_rms,  /* (i)    log2 of the spectrum envelope  */
                           int norm_MDCT    /* (i)    MDCT norm value                */
    )
{
  REAL      v;
  int       min_RMS, max_RMS;

  if (norm_MDCT < G729EV_TDAC_NORM_MDCT_TRESH)
  {
    min_RMS = G729EV_TDAC_MIN_RMS + norm_MDCT * 2;
    max_RMS = G729EV_TDAC_MAX_RMS + norm_MDCT * 2;
  }
  else
  {
    min_RMS = G729EV_TDAC_MIN_RMS + G729EV_TDAC_RMS_OFFSET;
    max_RMS = G729EV_TDAC_MAX_RMS + G729EV_TDAC_RMS_OFFSET;
  }


  /* rounding */
  v = *log_rms;
  *index = G729EV_MAIN_c_REAL_INT16(v * G729EV_TDAC_Q3db_INV);

  /* overload (<5 bits) */
  if (*index < min_RMS)
    *index = min_RMS;
  if (*index > max_RMS)
    *index = max_RMS;

  return;
}


/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_compute_diff_index()                              *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                *
*  Compute differential indices and detect saturation                      *
*--------------------------------------------------------------------------*/
int G729EV_TDAC_compute_diff_index(int *rms_index,  /* (i)    indices of quantized rms */
                                   int n,           /* (i)    number of subbands */
                                   int *diff_index  /* (o)    differential indices */
    )
{
  int       j, tmp;

  for (j = 0; j < n; j++)
  {
    tmp = rms_index[j] - rms_index[j - 1];
    if ((tmp < -12) || (tmp > 12))
    {
      return (1);
    }
    diff_index[j] = tmp;

    /* update index to take into account overload in difference */
    rms_index[j] = rms_index[j - 1] + tmp;
  }
  return (0);
}


/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_encode_spenv()                                    *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      *
*  encode spectral envelope                                                *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_encode_spenv(int *rms_index,     /* (i)    indices of quantized rms */
                              int *diff_index,    /* (i)    differential indices */
                              INT16 * bitstream,  /* (o)    bitstream */
                              int *nbit_env,      /* (o)    number of bits used for spectral envelope */
                              int n,              /* (i)    number of subbands */
                              int satur,          /* (i)    saturation flag */
                              int norm_MDCT       /* (i)    MDCT normalization factor */
    )
{
  INT16     bitstream_eq[1 + G729EV_TDAC_NB_SB_NB * 5];
  INT16    *pBit, *pBit_eq;
  int       nbit_eq, nbit, j, k, i, nbit_env_eq[G729EV_TDAC_NB_SB_NB];
  int       len;
  int       min_RMS;

  if (norm_MDCT < G729EV_TDAC_NORM_MDCT_TRESH)
  {
    min_RMS = G729EV_TDAC_MIN_RMS + norm_MDCT * 2;
  }
  else
  {
    min_RMS = G729EV_TDAC_MIN_RMS + G729EV_TDAC_RMS_OFFSET;
  }

  /* mode 1: equiprobable */
  pBit_eq = bitstream_eq;
  G729EV_TDAC_pushBit(1, &pBit_eq, 1);
  nbit_eq = 1;
  for (j = 0; j < n; j++)
  {
    /* write equiprobable code (mode 1) */
    G729EV_TDAC_pushBit((INT16) (rms_index[j] - min_RMS), &pBit_eq, 5);
    nbit_eq += 5;
    nbit_env_eq[j] = 5;
  }

  /* bypass mode 0 in case of overload in difference coding */
  if ((satur - 1) != 0)
  {
    /* mode 0: differential Huffman */
    pBit = bitstream;

    /* first band */
    G729EV_TDAC_pushBit(0, &pBit, 1);
    G729EV_TDAC_pushBit((INT16) (rms_index[0] - min_RMS), &pBit, 5);
    nbit = 5 + 1;
    nbit_env[0] = 5;

    /* next bands */
    for (j = 1; j < n; j++)
    {
      k = diff_index[j];
      len = G729EV_TDAC_len_huff_diff[k + 12];
      G729EV_TDAC_pushBit(G729EV_TDAC_code_huff_diff[k + 12], &pBit, len);
      nbit += len;
      nbit_env[j] = len;
    }
  }
  else
    nbit = 0;

  /* select best sequence */
  if ((satur == 1) || (nbit_eq < nbit))
  {

    pBit = bitstream;
    for (i = 0; i < nbit_eq; i++)
    {
      *pBit++ = bitstream_eq[i];
    }

    for (j = 0; j < n; j++)
    {
      nbit_env[j] = nbit_env_eq[j];
    }
  }

  return;
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_writ_specEnv()                                    *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      *
*  Write spectral envelope to bitstream                                    *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_writ_specEnv(INT16 * bits_env,   /* (i)    encoded spectral envelope (per subband) */
                              int *nb_bits_env,   /* (i)    number of bits per subbands */
                              int n,              /* (i)    dimension */
                              int nbit,           /* (i)    maximal number of bits for TDAC */
                              INT16 ** bitstream, /* (o)    bistream */
                              int *bit_cnt        /* (o)    number of bits written to bitstream */
    )
{
  int       ki, j, ii, i;
  INT16    *pBit;
  int       tmp;

  pBit = *bitstream;
  ki = 0;
  *pBit++ = bits_env[ki++];     /* eq_switch bit */
  *bit_cnt = *bit_cnt + 1;

  /* write encoded spectral envelope to bitstream */
  for (j = 0; j < n; j++)
  {
    tmp = *bit_cnt + nb_bits_env[j];
    if (tmp <= nbit)
    {
      *bit_cnt = tmp;
      for (i = 0; i < nb_bits_env[j]; i++)  /* save the whole huffman code  */
      {
        *pBit++ = bits_env[ki++];
      }
    }
    else
    {
      ii = nbit - *bit_cnt;     /* remaining bits */
      *bit_cnt = *bit_cnt + ii; /* bit_cnt = bits4vq *//* bit_cnt = bits4vq */
      for (i = 0; i < ii; i++)  /* save the beginning of the huffman code, to complete bitstream */
      {
        *pBit++ = bits_env[ki++];
      }
    }
  }

  *bitstream = pBit;

  return;
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_cod_spenv()                                       *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
*  Encode spectral envelope                                                *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_cod_spenv(REAL * log_rms,      /* (i)     log2 of the spectrum envelope */
                           int *rms_index,      /* (o)     decoded spectrum enveloppe */
                           INT16 ** pBit,       /* (i/o)   bitstream  */
                           int *bit_cnt,        /* (o)     number of bits written to bitstream  */
                           int nbit_to_encode,  /* (i)     maximal number of bits for TDAC */
                           int norm_MDCT        /* (i)     MDCT normalization factor */
    )
{

  int       j, satur;
  int       diff_index[G729EV_TDAC_NB_SB];
  INT16     bit_nb[1 + 10 * 14], bit_wb[1 + 8 * 14];  /* 1+max. length of Huffman code * nb subbands */
  int       nbit_env[G729EV_TDAC_NB_SB];

  /* initialize the number of bits used to encode each spectral factor (subband gain)  */
  for (j = 0; j < G729EV_TDAC_NB_SB; j++)
    nbit_env[j] = 0;

  /* round with 3dB step */
  for (j = 0; j < G729EV_TDAC_NB_SB; j++)
    G729EV_TDAC_quant_3dB(&rms_index[j], &log_rms[j], norm_MDCT);

  /* compute spectral envelope parameters in lower band */
  satur = G729EV_TDAC_compute_diff_index(&rms_index[1], G729EV_TDAC_NB_SB_NB - 1, &diff_index[1]);
  G729EV_TDAC_encode_spenv(rms_index, diff_index, bit_nb, nbit_env, G729EV_TDAC_NB_SB_NB, satur, norm_MDCT);

  /* compute spectral envelope parameters in higher band */
  satur = G729EV_TDAC_compute_diff_index(&rms_index[G729EV_TDAC_NB_SB_NB + 1], G729EV_TDAC_NB_SB_WB - 1,
                                         &diff_index[G729EV_TDAC_NB_SB_NB + 1]);
  G729EV_TDAC_encode_spenv(rms_index + G729EV_TDAC_NB_SB_NB, diff_index + G729EV_TDAC_NB_SB_NB,
                           bit_wb, nbit_env + G729EV_TDAC_NB_SB_NB, G729EV_TDAC_NB_SB_WB, satur, norm_MDCT);

  /* write higher band parameters to bitstream */
  G729EV_TDAC_writ_specEnv(bit_wb, nbit_env + G729EV_TDAC_NB_SB_NB,
                           G729EV_TDAC_NB_SB_WB, nbit_to_encode, pBit, bit_cnt);
  /* write lower band parameters to bitstream */
  G729EV_TDAC_writ_specEnv(bit_nb, nbit_env, G729EV_TDAC_NB_SB_NB, nbit_to_encode, pBit, bit_cnt);

  return;
}




/*-------------------------------------------------------------------------*
* dec_specEnv : decoding of the spectrum envelope                          *
*--------------------------------------------------------------------------*/

/* subroutines:
   - G729EV_TDAC_read_bits
   - G729EV_TDAC_dec
   - G729EV_TDAC_find_huffman
   - G729EV_TDAC_flush_buffer
   - G729EV_TDAC_decode_rms_index
   - G729EV_TDAC_calc_rms_q
   - G729EV_TDAC_dec_specEnv
 */

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_read_bits()                                       *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      *
*  Read bits from bitstream                                                *
*--------------------------------------------------------------------------*/
UINT16 G729EV_TDAC_read_bits(UINT16 * buffer,     /* (i/o)   bit buffer */
                             int len,             /* (i)     number of bits to read */
                             INT16 ** bitstream,  /* (i/o)   bitstream pointer */
                             int *bit_cnt         /* (i/o)   total number of bits read from bitstream */
    )
{
  int       i;
  UINT16    temp;

  i = (G729EV_TDAC_MAX_LONG_HUFF - len);
  temp = (*buffer) >> i;
  temp &= G729EV_MAIN_maskBit[len]; /* clean MSBs */
  *bit_cnt += len;
  *buffer <<= len;
  *buffer |= G729EV_TDAC_getBit(bitstream, len);

  return temp;
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_dec()                                             *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~                                               *
*  Decode rms index (natural binary coding)                                *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_dec(UINT16 * buffer,     /* (i/o)   bit buffer */
                     INT16 ** bitstream,  /* (i/o)   bitstream pointer */
                     int *bit_cnt,        /* (i/o)   total number of bits read from bitstream */
                     int *rms_index,      /* (o)     decoded rms index */
                     int norm_MDCT        /* (i)     MDCT normalization factor */
    )
{
  UINT16    temp;
  int       min_RMS;

  if (norm_MDCT < G729EV_TDAC_NORM_MDCT_TRESH)
  {
    min_RMS = G729EV_TDAC_MIN_RMS + norm_MDCT * 2;
  }
  else
  {
    min_RMS = G729EV_TDAC_MIN_RMS + G729EV_TDAC_RMS_OFFSET;
  }

  /* read 5 bits */
  temp = G729EV_TDAC_read_bits(buffer, 5, bitstream, bit_cnt);

  /* set index defined in interval [G729EV_TDAC_MIN_RMS, G729EV_TDAC_MAX_RMS] */
  *rms_index = (int) temp + min_RMS;
}


/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_find_huffman()                                    *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      *
*  Read and decode Huffman code                                            *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_find_huffman(UINT16 * buffer,      /* (i/o)   bit buffer */
                              const INT16 * len,    /* (i)     table of code lengths */
                              const UINT16 * code,  /* (i)     code table */
                              int nb_code,          /* (i)     number of Huffman codes */
                              int *k                /* (o)     index of Huffman code */
    )
{
  int       i, j;
  UINT16    temp;

  *k = -1;
  for (j = 0; j < nb_code; j++)
  {
    /* read the number of bits corresponding to the length of the k-th codevector */
    i = G729EV_TDAC_MAX_LONG_HUFF - len[j];
    temp = *buffer >> i;
    temp &= G729EV_MAIN_maskBit[len[j]];

    /* check if these bits match the codevector */
    if (temp == code[j])
    {
      *k = j;
      break;
    }
  }
  return;
}


/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_flush_buffer()                                    *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      *
*  Flush bit buffer                                                        *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_flush_buffer(UINT16 * buffer,    /* (i/o)   bit buffer */
                              int len,            /* (i)     number of bits to flush */
                              INT16 ** bitstream, /* (i/o)   bitstream pointer */
                              int *bit_cnt        /* (i/o)   total number of bits read from bitstream */
    )
{
  *bit_cnt += len;
  *buffer <<= len;
  *buffer |= G729EV_TDAC_getBit(bitstream, len);
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_decode_rms_index()                                *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                  *
*  Decode rms indices                                                     *
*--------------------------------------------------------------------------*/
int G729EV_TDAC_decode_rms_index(INT16 ** bitstream,  /* (i/o)   bitstream pointer */
                                 int *rms_index,      /* (o)     decoded rms indices */
                                 int *bit_cnt,        /* (o)     total number of bits read from bitstream */
                                 int nbit_to_decode,  /* (i)     maximal number of bits for TDAC */
                                 int n,               /* (i)     number of subbands */
                                 UINT16 * buffer,     /* (i/o)   bit buffer */
                                 int norm_MDCT        /* (i)     MDCT normalization factor */
    )
{
  int       eq_switch, j, k, nb_dec;

  nb_dec = 0;

  /* read switch between normal and equiprobable mode (1 bit) and first subband */
  if ((*bit_cnt + 6) <= nbit_to_decode)
  {
    eq_switch = G729EV_TDAC_read_bits(buffer, 1, bitstream, bit_cnt);
    G729EV_TDAC_dec(buffer, bitstream, bit_cnt, &rms_index[0], norm_MDCT);
    nb_dec++;
  }
  else
    return (nb_dec);

  /* switch between normal and equiprobable decoding */
  if (eq_switch == 0)           /*0: normal; 1: equiprobrable */
  {
    /* decode other subbands */
    for (j = 1; j < n; j++)
    {
      /* try to find a Huffman codevector */
      G729EV_TDAC_find_huffman(buffer, G729EV_TDAC_len_huff_diff, G729EV_TDAC_code_huff_diff, 25, &k);

      /* Test if word recovered */
      if ((k == -1) || ((*bit_cnt + G729EV_TDAC_len_huff_diff[k]) > nbit_to_decode))
        return (nb_dec);
      else
      {
        /* flush buffer */
        G729EV_TDAC_flush_buffer(buffer, G729EV_TDAC_len_huff_diff[k], bitstream, bit_cnt);

        /* add diff_rms defined in interval [-12,12] to previous rms_index */
        rms_index[j] = rms_index[j - 1] + (k - 12);
        nb_dec++;
      }
    }
  }
  else                          /* if (eq_switch == 0) */
  {
    for (j = 1; j < n; j++)
    {
      if ((*bit_cnt + 5) <= nbit_to_decode)
      {
        G729EV_TDAC_dec(buffer, bitstream, bit_cnt, &rms_index[j], norm_MDCT);
        nb_dec++;
      }
      else
      {
        return (nb_dec);
      }
    }
  }
  return (nb_dec);
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_calc_rms_q()                                      *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
*  Compute rms_q(j) = 2^(rms_index(j)/2)                                   *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_calc_rms_q(int *rms_index, /* (i)   decoded rms indices */
                            REAL * rmsq,    /* (o)   decoded rms */
                            int norm_MDCT,  /* (i)   MDCT normalization factor */
                            int *ndec       /* (i)   number of spectral envelope parameters */
    )
{
  REAL      v;

  int       min_RMS, max_RMS;
  int       bad_rms, j;

  if (norm_MDCT < G729EV_TDAC_NORM_MDCT_TRESH)
  {
    min_RMS = G729EV_TDAC_MIN_RMS + norm_MDCT * 2;
    max_RMS = G729EV_TDAC_MAX_RMS + norm_MDCT * 2;
  }
  else
  {
    min_RMS = G729EV_TDAC_MIN_RMS + G729EV_TDAC_RMS_OFFSET;
    max_RMS = G729EV_TDAC_MAX_RMS + G729EV_TDAC_RMS_OFFSET;
  }

  /* verify that rms_index is in [G729EV_TDAC_MIN_RMS,G729EV_TDAC_MAX_RMS] interval */
  bad_rms = 0;
  for (j = 0; j < *ndec; j++)
  {
    if (rms_index[j] < min_RMS)
    {
      bad_rms = 1;
    }
    if (rms_index[j] > max_RMS)
    {
      bad_rms = 1;
    }
  }

  /* reconstruct rms */
  if (bad_rms)
  {
    *ndec = 0;
  }
  else
  {
    for (j = 0; j < *ndec; j++)
    {
      v = (REAL) (rms_index[j]) * (REAL) G729EV_TDAC_Q3db;
      rmsq[j] = (REAL) pow((REAL_DOUBLE) 2.0, (REAL_DOUBLE) v);
    }
  }
}



/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_dec_specEnv()                                     *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
*  Decode spectral envelope                                                *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_dec_specEnv(INT16 ** bitstream,  /* (i/o)   bitstream pointer */
                             int *rms_index,      /* (o)     decoded rms indices */
                             REAL * rmsq,         /* (o)     decoded rms */
                             int *bit_cnt,        /* (o)     total number of bits read from bitstream */
                             int nbit_to_decode,  /* (i)     maximal number of bits for TDAC */
                             int *ndec_nb,        /* (i)     number of lower-band spectral envelope parameters */
                             int *ndec_wb,        /* (i)     number of higher-band spectral envelope parameters */
                             int norm_MDCT        /* (i)     MDCT normalization factor */
    )
{
  UINT16    bit_buffer;
  int       j;

  /* initialize decoded spectral envelope */
  for (j = 0; j < G729EV_TDAC_NB_SB; j++)
    rmsq[j] = (REAL) 0.0;

  *ndec_nb = 0;
  *ndec_wb = 0;

  /* fill buffer which contains MAX_LONG_HUF new bits */
  if (nbit_to_decode >= G729EV_TDAC_MAX_LONG_HUFF)
    bit_buffer = G729EV_TDAC_getBit(bitstream, G729EV_TDAC_MAX_LONG_HUFF);
  else
    return;

  /* decode spectral envelope in higher band */
  *ndec_wb = G729EV_TDAC_decode_rms_index(bitstream, rms_index + G729EV_TDAC_NB_SB_NB,
                                          bit_cnt, nbit_to_decode, G729EV_TDAC_NB_SB_WB, &bit_buffer, norm_MDCT);
  G729EV_TDAC_calc_rms_q(rms_index + G729EV_TDAC_NB_SB_NB, rmsq + G729EV_TDAC_NB_SB_NB, norm_MDCT, ndec_wb);

  /* decode spectral envelope in lower band */
  *ndec_nb = G729EV_TDAC_decode_rms_index(bitstream, rms_index, bit_cnt, nbit_to_decode,
                                          G729EV_TDAC_NB_SB_NB, &bit_buffer, norm_MDCT);
  G729EV_TDAC_calc_rms_q(rms_index, rmsq, norm_MDCT, ndec_nb);

  /* flush buffer */
  *bitstream -= G729EV_TDAC_MAX_LONG_HUFF;
}
