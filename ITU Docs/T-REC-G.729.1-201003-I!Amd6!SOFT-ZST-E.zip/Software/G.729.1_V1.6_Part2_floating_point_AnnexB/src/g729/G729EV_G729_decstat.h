/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __G729EV_G729_DECSTAT_H__
#define __G729EV_G729_DECSTAT_H__

#include <stdio.h>
#include "CodecTypedef.h"
#include "G729EV_G729_defines.h"
#include "G729EV_MAIN_defines.h"

/* Structure of the decoder status variables */

typedef struct
{
  REAL      old_exc[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];  /* Excitation vector          */
  REAL      lsp_old[G729EV_G729_M];     /* Lsp (Line spectral pairs)  */
  REAL      mem_syn[G729EV_G729_M_LPC]; /* Filter's memory            */
  REAL      freq_prev[G729EV_G729_MA_NP][G729EV_G729_M];  /* previous LSP vector        */
  REAL      prev_lsp[G729EV_G729_M];    /* previous LSP vector        */
  REAL      past_qua_en[4];             /* Past quantized energies    */
  INT16     rate;                       /* Rate                               */
  INT16     seed_fer;
  REAL      sharp;                      /* pitch sharpening of previous frame */
  REAL      gain_code;                  /* Code gain                          */
  REAL      gain_pitch;                 /* Pitch gain                         */
  INT16     prev_ma;                    /* previous MA prediction coef.       */
  REAL      lp_gainp;
  REAL      lp_gainc;
  INT16     i_subfr_cnt;
  REAL      tilt_code;
  REAL      stab_fac;
  INT16     upd_cnt;
  REAL      enr_old;
  REAL      fpitch[2];
  REAL      old_fpitch;
  INT16     bfi_cnt;
  REAL      pit_mem[5];
  INT16     bfi_mem;
  REAL      MemTam[G729EV_G729_MEM_LEN_TAM];

  /* G.729B mode */
  int       g729b_bst;
  INT16     ftyp[2];
  INT16     past_ftyp;
  INT16     seed;
  REAL      sid_sav;
  REAL      sid_gain;
  REAL      lspSid[G729EV_G729_M];
  REAL      cur_gain;
  REAL      noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M];

} G729EV_G729_DECSTAT;




#endif  /*__G729EV_G729_DECSTAT_H__ */
