/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*
   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/

/*
 File : TAB_DTX.C
*/

/*********************************************************************/
/******             Tables used for VAD/DTX/CNG                 ******/
/*********************************************************************/

#include "CodecTypedef.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729B_defines.h"

/* Quantization of LSF vector */
int       PtrTab_1[32] = { 96, 52, 20, 54, 86, 114, 82, 68, 36, 121, 48, 92, 18, 120,
  94, 124, 50, 125, 4, 100, 28, 76, 12, 117, 81, 22, 90, 116,
  127, 21, 108, 66
};
int       PtrTab_2[2][16] = { {31, 21, 9, 3, 10, 2, 19, 26, 4, 3, 11, 29, 15, 27, 21, 12},
{16, 1, 0, 0, 8, 25, 22, 20, 19, 23, 20, 31, 4, 31, 20, 31}
};
REAL      noise_fg_sum[G729EV_G729_MODE][G729EV_G729_M] = {
  {(REAL) 2.379833e-01f, (REAL) 2.577898e-01f, (REAL) 2.504044e-01f, (REAL) 2.530900e-01f, (REAL) 2.479934e-01f,
   (REAL) 2.587054e-01f, (REAL) 2.577898e-01f, (REAL) 2.656026e-01f, (REAL) 2.759789e-01f, (REAL) 2.625813e-01f}
  ,
  {(REAL) 0.320883796f, (REAL) 0.378502704f, (REAL) 0.391650136f, (REAL) 0.363609794f, (REAL) 0.349357626f,
   (REAL) 0.356157116f, (REAL) 0.339738164f, (REAL) 0.345200944f, (REAL) 0.361461228f, (REAL) 0.349363712f}
};

/* Quantization of SID gain */
REAL      fact[NB_GAIN + 1] = { (REAL) 0.003125, (REAL) 0.00078125, (REAL) 0.000390625 };
REAL      tab_Sidgain[32] = {
  (REAL) 0.502, (REAL) 1.262, (REAL) 2.000, (REAL) 3.170, (REAL) 5.024, (REAL) 7.962,
  (REAL) 12.619, (REAL) 15.887, (REAL) 20.000, (REAL) 25.179, (REAL) 31.698, (REAL) 39.905,
  (REAL) 50.238, (REAL) 63.246, (REAL) 79.621, (REAL) 100.237, (REAL) 126.191, (REAL) 158.866,
  (REAL) 200.000, (REAL) 251.785, (REAL) 316.979, (REAL) 399.052, (REAL) 502.377, (REAL) 632.456,
  (REAL) 796.214, (REAL) 1002.374, (REAL) 1261.915, (REAL) 1588.656, (REAL) 2000.000, (REAL) 2517.851,
  (REAL) 3169.786, (REAL) 3990.525
};
