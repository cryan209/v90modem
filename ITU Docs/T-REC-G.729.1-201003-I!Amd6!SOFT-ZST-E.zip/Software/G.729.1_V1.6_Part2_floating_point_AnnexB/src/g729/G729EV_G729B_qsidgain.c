/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*
   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/

/*
 File : QSIDGAIN.C
*/

/* Quantize SID gain                                      */

#include <math.h>


#include "G729EV_G729_defines.h"
#include "G729EV_G729B_defines.h"
#include "G729EV_G729B_tab_dtx.h"

/* Local function */
static int quant_Energy(REAL ener,    /* (i)  : Energy                 */
                        REAL * enerq  /* (o)  : quantized energy in dB */
    );

/*-------------------------------------------------------------------*
* Function  Qua_Sidgain                                             *
*           ~~~~~~~~~~~                                             *
*-------------------------------------------------------------------*/
void qua_Sidgain(REAL * ener,   /* (i)   array of energies                   */
                 int nb_ener,   /* (i)   number of energies or               */
                 REAL * enerq,  /* (o)   decoded energies in dB              */
                 int *idx       /* (o)   SID gain quantization index         */
    )
{
  int       i;
  REAL      avr_ener;

  if (nb_ener == 0)
  {
    /* Quantize energy saved for frame erasure case                */
    avr_ener = (*ener) * fact[0];
  }

  else
  {

    /*
     * Compute weighted average of energies
     * avr_ener = fact[nb_ener] x SUM(i=0->nb_ener-1) ener[i]
     * with fact[nb_ener] =  fact_ener / nb_ener x L_FRAME x nbAcf
     */
    avr_ener = (REAL) 0.;
    for (i = 0; i < nb_ener; i++)
    {
      avr_ener += ener[i];
    }
    avr_ener *= fact[nb_ener];
  }

  *idx = quant_Energy(avr_ener, enerq);

  return;
}

/* Local function */
static int quant_Energy(REAL ener,    /* (i)  : Energy                 */
                        REAL * enerq  /* (o)  : quantized energy in dB */
    )
{
  REAL      ener_dB;
  int       index;

  if (ener <= MIN_ENER)
  {                             /* MIN_ENER <=> -8dB */
    *enerq = (REAL) - 12.;
    return (0);
  }

  ener_dB = (REAL) 10. *(REAL) log10(ener);

  if (ener_dB <= (REAL) - 8.)
  {
    *enerq = (REAL) - 12.;
    return (0);
  }

  if (ener_dB >= (REAL) 65.)
  {
    *enerq = (REAL) 66.;
    return (31);
  }

  if (ener_dB <= (REAL) 14.)
  {
    index = (int) ((ener_dB + (REAL) 10.) * 0.25);
    if (index < 1)
      index = 1;
    *enerq = (REAL) 4. *(REAL) index - (REAL) 8.;

    return (index);
  }

  index = (int) ((ener_dB - (REAL) 3.) * 0.5);
  if (index < 6)
    index = 6;
  *enerq = (REAL) 2. *(REAL) index + (REAL) 4.;

  return (index);
}
