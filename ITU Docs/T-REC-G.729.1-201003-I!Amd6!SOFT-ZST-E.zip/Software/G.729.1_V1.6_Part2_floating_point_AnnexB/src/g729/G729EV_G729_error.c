/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

/*-------------------------------------------------------------------------------------
 * G729EV_G729_Corr_xy2 - compute the correlation products needed for gain computation
 *-------------------------------------------------------------------------------------*/
void G729EV_G729_Corr_xy2(REAL xn[],      /*  (i) : Target vector                     */
                          REAL y1[],      /*  (i) : Adaptive codebook.                */
                          REAL y2[],      /*  (i) : Filtered innovative vector        */
                          REAL g_coeff[]  /*  (o) : Correlations between xn,y1,y2     */
    )
{
  REAL      y2y2, xny2, y1y2;
  int       i;

  y2y2 = (REAL) 0.01;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    y2y2 += y2[i] * y2[i];
  g_coeff[2] = y2y2;

  xny2 = (REAL) 0.01;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    xny2 += xn[i] * y2[i];
  g_coeff[3] = (REAL) - 2.0 * xny2;

  y1y2 = (REAL) 0.01;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    y1y2 += y1[i] * y2[i];
  g_coeff[4] = (REAL) 2.0 *y1y2;

  return;

}

/*
 * Function G729EV_G729_test_err - computes the accumulated potential error in the    
 * adaptive codebook contribution                                         
 */
int G729EV_G729_test_err(                                         /* (o) flag set to 1 if taming is necessary  */
                          G729EV_G729_CODSTAT * pCodStat, int t0, /* (i) integer part of pitch delay           */
                          int t0_frac                             /* (i) fractional part of pitch delay        */
    )
{

  int       i, t1, zone1, zone2, flag;
  REAL      maxloc;

  t1 = (t0_frac > 0) ? (t0 + 1) : t0;

  i = t1 - G729EV_G729_L_SUBFR - G729EV_G729_L_INTER10;
  if (i < 0)
    i = 0;
  zone1 = (int) ((REAL) i * G729EV_G729_INV_L_SUBFR);

  i = t1 + G729EV_G729_L_INTER10 - 2;
  zone2 = (int) ((REAL) i * G729EV_G729_INV_L_SUBFR);

  maxloc = (REAL) - 1.;
  flag = 0;
  for (i = zone2; i >= zone1; i--)
  {
    if (pCodStat->exc_err[i] > maxloc)
      maxloc = pCodStat->exc_err[i];
  }
  if (maxloc > G729EV_G729_THRESH_ERR)
  {
    flag = 1;
  }

  return (flag);
}

/*
 * Function G729EV_G729_update_exc_err - maintains the memory used to compute the error 
 * function due to an adaptive codebook mismatch between encoder and      
 * decoder                                                                
 */

void G729EV_G729_update_exc_err(REAL gain_pit,  /* (i) pitch gain                  */
                                int t0,         /* (i) integer part of pitch delay */
                                REAL * exc_err  /* (o) excitation error            */
    )
{
  int       i, zone1, zone2, n;
  REAL      worst, temp;

  worst = (REAL) - 1.;

  n = t0 - G729EV_G729_L_SUBFR;
  if (n < 0)
  {
    temp = (REAL) 1. + gain_pit * exc_err[0];
    if (temp > worst)
      worst = temp;
    temp = (REAL) 1. + gain_pit * temp;
    if (temp > worst)
      worst = temp;
  }

  else
  {
    zone1 = (int) ((REAL) n * G729EV_G729_INV_L_SUBFR);

    i = t0 - 1;
    zone2 = (int) ((REAL) i * G729EV_G729_INV_L_SUBFR);

    for (i = zone1; i <= zone2; i++)
    {
      temp = (REAL) 1. + gain_pit * exc_err[i];
      if (temp > worst)
        worst = temp;
    }
  }

  for (i = 3; i >= 1; i--)
    exc_err[i] = exc_err[i - 1];
  exc_err[0] = worst;

  return;

}

/********************************************************************/
/*    G729EV_G729_UpdateMemTam   called for  an ereased frame       */
/* 1 tap LTP filtering of 1 as input value for one g729 frame       */
/* last G729EV_G729_MEM_LEN_TAM samples are saved                   */
/* (no fractional pitch for taming -> no interpolation)             */
/********************************************************************/
void G729EV_G729_UpdateMemTam(G729EV_G729_DECSTAT * pDecStat, REAL CoefLtp, int Pitch)
{
  REAL      tambuf[G729EV_G729_L_FRAME];
  int       i, j;

  /*filtering */
  j = 0;
  for (i = G729EV_G729_MEM_LEN_TAM - Pitch; (i < G729EV_G729_MEM_LEN_TAM) && (j < G729EV_G729_L_FRAME); i++)  /*memory from the end of MemTam */
  {
    tambuf[j] = CoefLtp * pDecStat->MemTam[i] + 1;
    j++;
  }
  for (; j < G729EV_G729_L_FRAME; j++)  /*memory from tambuf */
  {
    tambuf[j] = CoefLtp * tambuf[j - Pitch] + 1;
  }

  /*memory update */
  for (i = 0; i < G729EV_G729_LEN_MEMTAM_UPDATE_UPDATE; i++)  /*shift MemTam */
  {
    pDecStat->MemTam[i] = pDecStat->MemTam[i + G729EV_G729_L_FRAME];
  }
  for (j = 0; j < G729EV_G729_L_FRAME; j++) /*copie tambuf */
  {
    pDecStat->MemTam[i] = tambuf[j];
    i++;
  }

}

/********************************************************************/
/*    G729EV_G729_TamFer   called for  a not ereased frame          */
/* 1 tap LTP filtering of 1 as input value for one g729 subframe    */
/* last G729EV_G729_MEM_LEN_TAM samples are saved                   */
/* (no fractional pitch for taming -> no interpolation)             */
/********************************************************************/
REAL G729EV_G729_TamFer(G729EV_G729_DECSTAT * pDecStat, REAL CoefLtp, int Pitch)
{
  int       i, j;
  REAL      tambuf[G729EV_G729_L_SUBFR];
  REAL      MultGainBk;
  REAL      somme = 0;


  /*filtering */
  j = 0;
  for (i = G729EV_G729_MEM_LEN_TAM - Pitch; (i < G729EV_G729_MEM_LEN_TAM) && (j < G729EV_G729_L_SUBFR); i++)  /*memory from the end of MemTam */
  {
    tambuf[j] = CoefLtp * pDecStat->MemTam[i];
    somme += tambuf[j];         /*sum of the obtained subframe */
    j++;
  }
  for (; j < G729EV_G729_L_SUBFR; j++)  /*memory from tambuf */
  {
    tambuf[j] = CoefLtp * tambuf[j - Pitch];
    somme += tambuf[j];         /*sum of the obtained subframe */
  }

  somme /= G729EV_G729_L_SUBFR; /*mean of the obtained subframe */

  /*calcul of the weighting factor MultGainBk to use in the LTP synthesis */
  if (somme > G729EV_G729_MAXTAMLIM)
    somme = (REAL) G729EV_G729_MAXTAMLIM;
  if ((CoefLtp > (REAL) 1) && (somme > G729EV_G729_MINTAMLIM))
  {
    MultGainBk =
        1 - (CoefLtp - 1) * (somme - G729EV_G729_MINTAMLIM) / (G729EV_G729_MAXTAMLIM - G729EV_G729_MINTAMLIM) / CoefLtp;
  }
  else
    MultGainBk = (REAL) 1;

  /*filtering using MultGainBk cprrection */
  j = 0;
  for (i = G729EV_G729_MEM_LEN_TAM - Pitch; (i < G729EV_G729_MEM_LEN_TAM) && (j < G729EV_G729_L_SUBFR); i++)  /*excitation from the end of MemTam */
  {
    tambuf[j] = CoefLtp * pDecStat->MemTam[i] * MultGainBk;
    j++;
  }
  for (; j < G729EV_G729_L_SUBFR; j++)  /*excitation from tambuf */
  {
    tambuf[j] = CoefLtp * tambuf[j - Pitch] * MultGainBk;
  }

  /*memory update */
  for (i = 0; i < G729EV_G729_LEN_MEMTAM_UPDATE_TAM; i++) /*shift MemTam */
  {
    pDecStat->MemTam[i] = pDecStat->MemTam[i + G729EV_G729_L_SUBFR];
  }
  for (j = 0; j < G729EV_G729_L_SUBFR; j++) /*copie tambuf */
  {
    pDecStat->MemTam[i] = tambuf[j];
    i++;
  }

  return (MultGainBk * CoefLtp);
}
