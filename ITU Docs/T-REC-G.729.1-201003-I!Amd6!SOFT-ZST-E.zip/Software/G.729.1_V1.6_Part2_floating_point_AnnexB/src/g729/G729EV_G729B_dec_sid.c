/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*
   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/


/*
 File : DEC_SID.C
*/

/*
**
**
** Description:     Comfort noise generation
**                  performed at the decoder part
**
*/
/**** Floatting point version ***/

#include <math.h>


#include "G729EV_G729_defines.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"
#include "G729EV_G729B_defines.h"
#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729B_sid.h"
#include "G729EV_G729B_dtx.h"

/*-----------------------------------------------------------*
* procedure dec_cng:                                        *
*           ~~~~~~~~                                        *
*                     Receives frame type                   *
*                     0  :  for untransmitted frames        *
*                     2  :  for SID frames                  *
*                     Decodes SID frames                    *
*                     Computes current frame excitation     *
*                     Computes current frame LSPs
*-----------------------------------------------------------*/
void G729EV_G729B_Dec_cng(G729EV_G729_DECSTAT * pDecStat, int past_ftyp,    /* (i)   : past frame type                      */
                          REAL sid_sav,                                     /* (i)   : energy to recover SID gain           */
                          int *parm,                                        /* (i)   : coded SID parameters                 */
                          REAL * exc,                                       /* (i/o) : excitation array                     */
                          REAL * lsp_old,                                   /* (i/o) : previous lsp                         */
                          REAL * A_t,                                       /* (o)   : set of interpolated LPC coefficients */
                          INT16 * seed,                                     /* (i/o) : random generator seed                */
                          REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i/o) : previous LPS for quantization        */
                          REAL * sid_gain, REAL * cur_gain, INT16 ftyp)
{
  REAL      temp;
  int       ind;

  /* SID Frame */
    /*************/
  if (ftyp != 0)
  {

    *sid_gain = tab_Sidgain[parm[3]];

    /* Inverse quantization of the LSP */
    sid_lsfq_decode(&parm[0], pDecStat->lspSid, freq_prev, pDecStat->noise_fg);

  }

  /* non SID Frame */
    /*****************/
  else
  {

    /* Case of 1st SID frame erased : quantize-decode   */
    /* energy estimate stored in sid_gain         */
    if (past_ftyp == 1)
    {
      qua_Sidgain(&sid_sav, 0, &temp, &ind);
      *sid_gain = tab_Sidgain[ind];
    }

  }

  if (past_ftyp == 1)
  {
    *cur_gain = *sid_gain;
  }
  else
  {
    *cur_gain *= A_GAIN0;
    *cur_gain += A_GAIN1 * *sid_gain;
  }

  calc_exc_rand(pDecStat, *cur_gain, exc, seed, FLAG_DEC);

  /* Interpolate the Lsp vectors */
  G729EV_G729_Int_qlpc(lsp_old, pDecStat->lspSid, A_t);
  G729EV_G729_Copy(pDecStat->lspSid, lsp_old, G729EV_G729_M);

  return;
}

/*---------------------------------------------------------------------------*
* Function  init_lsfq_noise                                                 *
* ~~~~~~~~~~~~~~~~~~~~~~~~~                                                 *
*                                                                           *
* -> Initialization of variables for the lsf quantization in the SID        *
*                                                                           *
*---------------------------------------------------------------------------*/
void init_lsfq_noise(G729EV_G729_DECSTAT * pDecStat)
{
  int       i, j;

  /* initialize the noise_fg */
  for (i = 0; i < 4; i++)
    G729EV_G729_Copy((REAL *) fg[0][i], pDecStat->noise_fg[0][i], G729EV_G729_M);

  for (i = 0; i < 4; i++)
    for (j = 0; j < G729EV_G729_M; j++)
    {
      pDecStat->noise_fg[1][i][j] = fg[0][i][j] * (REAL) 0.6 + fg[1][i][j] * (REAL) 0.4;
    }

  return;
}

void sid_lsfq_decode(int *index,                                        /* (i) : quantized indices    */
                     REAL * lspq,                                       /* (o) : quantized lsp vector */
                     REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i) : memory of predictor  */
                     REAL noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M])
{
  int       i;
  REAL      lsfq[G729EV_G729_M], tmpbuf[G729EV_G729_M];

  /* get the lsf error vector */
  G729EV_G729_Copy((REAL *) lspcb1[PtrTab_1[index[1]]], tmpbuf, G729EV_G729_M);
  for (i = 0; i < G729EV_G729_M / 2; i++)
    tmpbuf[i] = tmpbuf[i] + lspcb2[PtrTab_2[0][index[2]]][i];
  for (i = G729EV_G729_M / 2; i < G729EV_G729_M; i++)
    tmpbuf[i] = tmpbuf[i] + lspcb2[PtrTab_2[1][index[2]]][i];

  /* guarantee minimum distance of 0.0012 between tmpbuf[j]
     and tmpbuf[j+1] */
  G729EV_G729_Lsp_expand_1_2(tmpbuf, (REAL) 0.0012);

  /* compute the quantized lsf vector */
  G729EV_G729_Lsp_prev_compose(tmpbuf, lsfq, noise_fg[index[0]], freq_prev, noise_fg_sum[index[0]]);

  /* update the prediction memory */
  G729EV_G729_Lsp_prev_update(tmpbuf, freq_prev);

  /* lsf stability check */
  G729EV_G729_Lsp_stability(lsfq);

  /* convert lsf to lsp */
  for (i = 0; i < G729EV_G729_M; i++)
    lspq[i] = (REAL) cos(lsfq[i]);

}
