/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_bitalloc.h"
#include "G729EV_TDAC_spectenv.h"
#include "G729EV_TDAC_vq.h"
#include "G729EV_TDAC_util.h"

#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_MAIN_oper_32b.h"
#include "stl.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_decoder()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  TDAC decoder                                                            *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_decoder(Word16 * bitstream,  /* (i)     TDAC bitstream */
                         Word16 nbit,         /* (i)     effective number of bits for TDAC */
                         Word16 nbit_max,     /* (i)     maximal bit allocation for TDAC */
                         Word16 * yt_hi,      /* (i)     MDCT spectrum of TDBWE synthesis */
                         Word16 * yq_lo,      /* (o)     reconstructed MDCT spectrum of lower band */
                         Word16 * yq_hi,      /* (o)     reconstructed MDCT spectrum of higher band */
                         Word16 norm_MDCT     /* (i)     MDCT normalization factor */
    )
{
  Word32    fact;
  Word32    tmp32;

  Word16    rmsq[G729EV_TDAC_NB_SB];  /* quantized spectrum envelope */
  Word16    rms_index[G729EV_TDAC_NB_SB];
  Word16    ip[G729EV_TDAC_NB_SB];
  Word16    ord_b[G729EV_TDAC_NB_SB];
  Word16    bit_alloc[G729EV_TDAC_NB_SB];
  Word16    startbit[G729EV_TDAC_NB_SB];
  Word16    vqbits[G729EV_TDAC_MAX_VQBITS];
  Word16    y[G729EV_MAIN_L_FRAME];

  Word16   *pBit, *pBit2;

  Word16    i, j, k;
  Word16    bit_cnt;
  Word16    tmp16;
  Word16    ndec_env_nb, ndec_env_wb;
  Word16    Hi, Lo;
  Word16    coef_ind;
  Word16    soi;
  Word16    delta;
  Word16    end_index;

  IF(nbit > 0)
  {
    pBit = bitstream;
    bit_cnt = (Word16) 0;
#if(WMOPS)
    move16();
#endif

    /* ------------------------------------------ */
    /* - decode spectral envelope (subband rms)   */
    /* ------------------------------------------ */

    G729EV_TDAC_dec_specEnv(&pBit, rms_index, rmsq, &bit_cnt, nbit, &ndec_env_nb, &ndec_env_wb, norm_MDCT);

#if(WMOPS)
    test();
#endif
    IF((sub(ndec_env_nb, G729EV_TDAC_NB_SB_NB) == 0) && (sub(ndec_env_wb, G729EV_TDAC_NB_SB_WB) == 0))
    {
      /* ---------------------------------------------------------------------------------------------- */
      /* - compute number of bits available for VQ */
      /* - allocate bits to subbands */
      /* - order subbands by decreasing perceptual importance */
      /* ---------------------------------------------------------------------------------------------- */

      /* compute the number of available bits */
      nbit_max = sub(nbit_max, bit_cnt);
      nbit = sub(nbit, bit_cnt);  /* number of bits left (at this stage) */

      /* compute perceptual importance:
         for 3dB step in spectral envelope coding
         1/2log2(enerq) = 1/2 ( rms_index + log2 nb_coef) */

      FOR(j = 0; j < G729EV_TDAC_NB_SB; j++)
      {
        ip[j] = rms_index[j];
#if(WMOPS)
        move16();
#endif
      }
      tmp16 = sub(G729EV_TDAC_NB_SB, 1);
      ip[tmp16] = add(ip[tmp16], 1);  /* ++ */
#if(WMOPS)
      move16();
#endif
      /* ip is in Q1 at this stage */

      /* order subbands by decreasing perceptual importance  */
      G729EV_TDAC_sort_ip(ip, G729EV_TDAC_NB_SB, ord_b);

      /* allocate bits to subbands */
      G729EV_TDAC_allocbit(bit_alloc, nbit_max, ip, G729EV_TDAC_NB_SB, G729EV_TDAC_nb_coef, ord_b);

      /* force zero bit to match bit budget (loop by decreasing perceptuel importance) */

      bit_cnt = (Word16) 0;
#if(WMOPS)
      move16();
#endif
      FOR(j = 0; j < G729EV_TDAC_NB_SB; j++)
      {
        coef_ind = ord_b[j];
#if(WMOPS)
        move16();
#endif
        tmp16 = add(bit_cnt, bit_alloc[coef_ind]);

        IF(sub(tmp16, nbit) <= 0)
        {
          bit_cnt = add(bit_cnt, bit_alloc[coef_ind]);
        }
        ELSE
        {
          /* bit budget is zero, set allocation to 0 bits for the other bands */
          FOR(i = j; i < G729EV_TDAC_NB_SB; i++)
          {
            coef_ind = ord_b[i];
            bit_alloc[coef_ind] = (Word16) 0;
#if(WMOPS)
            move16();
            move16();
#endif
          }
        }
      }


      /* ---------------------------------------------------------------------------------------------- */
      /* - decode MDCT coefficients */
      /* ---------------------------------------------------------------------------------------------- */

      /* read bits for VQ decoding */
      soi = (Word16) 0;
#if(WMOPS)
      move16();
#endif
      FOR(j = 0; j < G729EV_TDAC_NB_SB; j++)
      {
        startbit[j] = soi;
#if(WMOPS)
        move16();
#endif
        soi = add(soi, bit_alloc[j]);
      }

      FOR(j = 0; j < G729EV_TDAC_NB_SB; j++)
      {
        coef_ind = ord_b[j];
        soi = startbit[coef_ind];
#if(WMOPS)
        move16();
        move16();
#endif
        FOR(i = 0; i < bit_alloc[coef_ind]; i++)
        {
          vqbits[soi++] = *pBit++;
#if(WMOPS)
          move16();
#endif
        }
      }

      pBit2 = vqbits;
      G729EV_TDAC_decod_VQ(&pBit2, y, bit_alloc, rmsq, G729EV_TDAC_NB_SB);

      /* ---------------------------------------------------------------------------------------------- */
      /* - reconstruct lower- and higher-band spectra */
      /* ---------------------------------------------------------------------------------------------- */

      /* split full-band spectrum */
      FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        yq_lo[i] = y[i];
        yq_hi[i] = y[i + G729EV_MAIN_L_FRAME2];
#if(WMOPS)
        move16();
        move16();
#endif
      }

      /* extrapolation (in wideband part) of unquantized subbands */
      delta = G729EV_MAIN_L_FRAME2;
#if(WMOPS)
      move16();
#endif
      FOR(j = G729EV_TDAC_NB_SB_NB; j < G729EV_TDAC_NB_SB; j++)
      {
        IF(bit_alloc[j] == 0)
        {
          FOR(k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
          {
            tmp16 = sub(k, delta);
            yq_hi[tmp16] = yt_hi[tmp16];
#if(WMOPS)
            move16();
#endif
          }

          fact = (Word32) 32;
#if(WMOPS)
          move32();
#endif
          FOR(k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
          {
            tmp16 = sub(k, delta);
            fact = L_mac(fact, yq_hi[tmp16], yq_hi[tmp16]);
          }
          fact = L_shr(fact, 1);

          fact = L_shr(fact, G729EV_TDAC_nb_coef_div[j]);
          tmp32 = Inv_sqrt(fact);
          L_Extract(tmp32, &Hi, &Lo);
          fact = Mpy_32_16(Hi, Lo, rmsq[j]);
          FOR(k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
          {
            tmp16 = sub(k, delta);
            L_Extract(fact, &Hi, &Lo);
            tmp32 = Mpy_32_16(Hi, Lo, yq_hi[tmp16]);
            yq_hi[tmp16] = extract_l(tmp32);
#if(WMOPS)
            move16();
#endif
          }
        }
      }

      /* zero coefficients in 7-8 kHz band */
      FOR(i = 120; i < 160; i++)
      {
        yq_hi[i] = (Word16) 0;
#if(WMOPS)
        move16();
#endif
      }

      return;
    }
    ELSE
    {
      IF(ndec_env_wb > 0)
      {
        /* level adjustment of unquantized subbands (in wideband part) */
        delta = G729EV_MAIN_L_FRAME2;
#if(WMOPS)
        move16();
#endif
        end_index = add(G729EV_TDAC_NB_SB_NB, ndec_env_wb);
        FOR(j = G729EV_TDAC_NB_SB_NB; j < end_index; j++)
        {
          fact = (Word32) 32;
#if(WMOPS)
          move32();
#endif
          FOR(k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
          {
            tmp16 = sub(k, delta);
            fact = L_mac(fact, yt_hi[tmp16], yt_hi[tmp16]);
          }
          fact = L_shr(fact, 1);

          fact = L_shr(fact, G729EV_TDAC_nb_coef_div[j]);
          tmp32 = Inv_sqrt(fact);
          L_Extract(tmp32, &Hi, &Lo);
          fact = Mpy_32_16(Hi, Lo, rmsq[j]);

          FOR(k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
          {
            tmp16 = sub(k, delta);
            L_Extract(fact, &Hi, &Lo);
            tmp32 = Mpy_32_16(Hi, Lo, yt_hi[tmp16]);
            yt_hi[tmp16] = extract_l(tmp32);
#if(WMOPS)
            move16();
#endif
          }
        }
      }
    }
  }

    /************************
   * handle case: nbit = 0 
   ************************/

  /* zero coefficients in 7-8 kHz band */
  FOR(i = 120; i < 160; i++)
  {
    yt_hi[i] = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }

  /* split full-band spectrum */
  FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
  {
    yq_lo[i] = (Word16) 0;
    yq_hi[i] = yt_hi[i];
#if(WMOPS)
    move16();
    move16();
#endif
  }
}
