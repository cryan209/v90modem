/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_LIB_VQ_H__
#define __G729EV_TDAC_LIB_VQ_H__

#include <stdio.h>
#include "stl.h"


/* Functions : */

void      G729EV_TDAC_VQ_quant(Word16 * x, Word16 dim, Word16 nbit, UWord32 * cod);
UWord32   G729EV_TDAC_schalk(Word16 n, Word16 ind_lead, Word16 * tab_pos, Word16 * tab_sgn);
void      G729EV_TDAC_SrchDic(Word16 dim, Word16 nbit, Word16 * IdicSel);
void      G729EV_TDAC_SrchLead(Word16 * x, Word16 dim, Word16 * tab_pos, Word16 * tab_sgn, Word16 * xn);
Word16    G729EV_TDAC_getNbLead(Word16 dim, Word16 idic);
void      G729EV_TDAC_VQLead(Word16 * xn, Word16 dim, Word16 * ILead, Word16 ivq1);
Word16    G729EV_TDAC_getInfoLead(Word16 dim, Word16 ilead, Word16 ** ptr_nb_val,
                                  Word16 ** ptr_val, UWord32 * offset, Word16 * nb_sgn);
Word32    G729EV_TDAC_prod_prm_fact(Word16 * exp);
void      G729EV_TDAC_inv_schalk(UWord32 L_rank, Word16 n, Word16 ind_lead, Word16 * y);
Word16    G729EV_TDAC_SearchPrev(Word16 n, Word16 dim);
Word16    G729EV_TDAC_SelectCbk(Word16 nbit, Word16 dim);

/* Tables : */

extern const Word16 G729EV_TDAC_tab_nb_prm_fact[17];
extern const Word16 G729EV_TDAC_delta_decomp_val[17];
extern const Word16 G729EV_TDAC_tab_decomp_val[17 * 6];
extern const Word16 G729EV_TDAC_tab_decomp_fact[17 * 6];
extern const Word16 *G729EV_MAIN_adRate[G729EV_TDAC_N_NBC + 1];
extern const Word16 G729EV_MAIN_NbDic[G729EV_TDAC_N_NBC + 1];
extern const Word16 *G729EV_MAIN_adNbLeadpRat[G729EV_TDAC_N_NBC + 1];
extern const Word16 *G729EV_MAIN_adListLead[G729EV_TDAC_N_NBC + 1];
extern const UWord16 G729EV_MAIN_maskBit[G729EV_TDAC_MAX_LONG_HUFF + 1];
extern const Word16 G729EV_MAIN_dim_leader[G729EV_TDAC_NB_LEAD_H];
extern const Word16 G729EV_MAIN_delta_leader[G729EV_TDAC_NB_LEAD_H];
extern const Word16 *G729EV_MAIN_adLeader_norm[G729EV_TDAC_N_NBC + 1];
extern const UWord32 *G729EV_MAIN_adOffsetLead[G729EV_TDAC_N_NBC + 1];

extern const Word16 G729EV_TDAC_tab_pow3[8];
extern const Word16 G729EV_TDAC_tab_pow5[5];
extern const Word16 G729EV_TDAC_tab_pow7[4];
extern const Word16 G729EV_TDAC_tab_pow11[3];
extern const Word16 G729EV_TDAC_tab_pow13[3];


#endif  /*__G729EV_TDAC_LIB_VQ_H__ */
