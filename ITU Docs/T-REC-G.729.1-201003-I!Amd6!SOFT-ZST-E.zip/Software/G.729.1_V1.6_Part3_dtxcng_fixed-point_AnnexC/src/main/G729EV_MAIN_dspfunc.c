/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#include "stl.h"
#include "G729EV_MAIN_dspfunc.h"

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

/*___________________________________________________________________________
 |                                                                           |
 |   Function Name : Pow2()                                                  |
 |                                                                           |
 |     L_x = pow(2.0, exponent.fraction)                                     |
 |---------------------------------------------------------------------------|
 |  Algorithm:                                                               |
 |                                                                           |
 |   The function Pow2(L_x) is approximated by a table and linear            |
 |   interpolation.                                                          |
 |                                                                           |
 |   1- i = bit10-b15 of fraction,   0 <= i <= 31                            |
 |   2- a = bit0-b9   of fraction                                            |
 |   3- L_x = tabpow[i]<<16 - (tabpow[i] - tabpow[i+1]) * a * 2              |
 |   4- L_x = L_x >> (30-exponent)     (with rounding)                       |
 |___________________________________________________________________________|
*/


Word32 Pow2(                    /* (o) Q0  : result       (range: 0<=val<=0x7fffffff) */
             Word16 exponent,   /* (i) Q0  : Integer part.      (range: 0<=val<=30)   */
             Word16 fraction    /* (i) Q15 : Fractional part.   (range: 0.0<=val<1.0) */
    )
{
  Word32    L_x;

  Word16    exp, i, a, tmp;


  L_x = L_mult(fraction, 32);   /* L_x = fraction<<6           */
  i = extract_h(L_x);           /* Extract b10-b15 of fraction */
  L_x = L_shr(L_x, 1);
  a = extract_l(L_x);           /* Extract b0-b9   of fraction */
  a = a & (Word16) 0x7fff;

  L_x = L_deposit_h(tabpow[i]); /* tabpow[i] << 16        */
  tmp = sub(tabpow[i], tabpow[i + 1]);  /* tabpow[i] - tabpow[i+1] */
  L_x = L_msu(L_x, tmp, a);     /* L_x -= tmp*a*2        */

  exp = sub(30, exponent);
  L_x = L_shr_r(L_x, exp);

  return (L_x);
}

/*___________________________________________________________________________
 |                                                                           |
 |   Function Name : Log2()                                                  |
 |                                                                           |
 |       Compute log2(L_x).                                                  |
 |       L_x is positive.                                                    |
 |                                                                           |
 |       if L_x is negative or zero, result is 0.                            |
 |---------------------------------------------------------------------------|
 |  Algorithm:                                                               |
 |                                                                           |
 |   The function Log2(L_x) is approximated by a table and linear            |
 |   interpolation.                                                          |
 |                                                                           |
 |   1- Normalization of L_x.                                                |
 |   2- exponent = 30-exponent                                               |
 |   3- i = bit25-b31 of L_x,    32 <= i <= 63  ->because of normalization.  |
 |   4- a = bit10-b24                                                        |
 |   5- i -=32                                                               |
 |   6- fraction = tablog[i]<<16 - (tablog[i] - tablog[i+1]) * a * 2         |
 |___________________________________________________________________________|
*/

void Log2(Word32 L_x,           /* (i) Q0 : input value                                 */
          Word16 * exponent,    /* (o) Q0 : Integer part of Log2.   (range: 0<=val<=30) */
          Word16 * fraction     /* (o) Q15: Fractional  part of Log2. (range: 0<=val<1) */
    )
{
  Word32    L_y;

  Word16    exp, i, a, tmp;

  if (L_x <= (Word32) 0)
  {
    *exponent = 0;
    *fraction = 0;
    return;
  }

  exp = norm_l(L_x);
  L_x = L_shl(L_x, exp);        /* L_x is normalized */

  *exponent = sub(30, exp);

  L_x = L_shr(L_x, 9);
  i = extract_h(L_x);           /* Extract b25-b31 */
  L_x = L_shr(L_x, 1);
  a = extract_l(L_x);           /* Extract b10-b24 of fraction */
  a = a & (Word16) 0x7fff;

  i = sub(i, 32);

  L_y = L_deposit_h(tablog[i]); /* tablog[i] << 16        */
  tmp = sub(tablog[i], tablog[i + 1]);  /* tablog[i] - tablog[i+1] */
  L_y = L_msu(L_y, tmp, a);     /* L_y -= tmp*a*2        */

  *fraction = extract_h(L_y);

  return;
}

/*___________________________________________________________________________
 |                                                                           |
 |   Function Name : Inv_sqrt                                                |
 |                                                                           |
 |       Compute 1/sqrt(L_x).                                                |
 |       L_x is positive.                                                    |
 |                                                                           |
 |       if L_x is negative or zero, result is 1 (3fff ffff).                |
 |---------------------------------------------------------------------------|
 |  Algorithm:                                                               |
 |                                                                           |
 |   The function 1/sqrt(L_x) is approximated by a table and linear          |
 |   interpolation.                                                          |
 |                                                                           |
 |   1- Normalization of L_x.                                                |
 |   2- If (30-exponent) is even then shift right once.                      |
 |   3- exponent = (30-exponent)/2  +1                                       |
 |   4- i = bit25-b31 of L_x,    16 <= i <= 63  ->because of normalization.  |
 |   5- a = bit10-b24                                                        |
 |   6- i -=16                                                               |
 |   7- L_y = tabsqr[i]<<16 - (tabsqr[i] - tabsqr[i+1]) * a * 2              |
 |   8- L_y >>= exponent                                                     |
 |___________________________________________________________________________|
*/


Word32 Inv_sqrt(                /* (o) Q30 : output value   (range: 0<=val<1)           */
                 Word32 L_x     /* (i) Q0  : input value    (range: 0<=val<=7fffffff)   */
    )
{
  Word32    L_y;

  Word16    exp, i, a, tmp;

  if (L_x <= (Word32) 0)
    return ((Word32) 0x3fffffffL);

  exp = norm_l(L_x);
  L_x = L_shl(L_x, exp);        /* L_x is normalize */

  exp = sub(30, exp);
  if ((exp & 1) == 0)           /* If exponent even -> shift right */
    L_x = L_shr(L_x, 1);

  exp = shr(exp, 1);
  exp = add(exp, 1);

  L_x = L_shr(L_x, 9);
  i = extract_h(L_x);           /* Extract b25-b31 */
  L_x = L_shr(L_x, 1);
  a = extract_l(L_x);           /* Extract b10-b24 */
  a = a & (Word16) 0x7fff;

  i = sub(i, 16);

  L_y = L_deposit_h(tabsqr[i]); /* tabsqr[i] << 16          */
  tmp = sub(tabsqr[i], tabsqr[i + 1]);  /* tabsqr[i] - tabsqr[i+1])  */
  L_y = L_msu(L_y, tmp, a);     /* L_y -=  tmp*a*2         */

  L_y = L_shr(L_y, exp);        /* denormalization */

  return (L_y);
}

/* integer squareroot, give output additional precision up to 7 bits */
Word16 sqrt_qnls(Word16 in, Word16 nls) /* (i) Q.0 (o) Q.nls */
{
  Word16    tmp_lo, tmp_hi;
  Word32    acc;


  acc = L_deposit_l(in);
  acc = Inv_sqrt(acc);

  tmp_lo = extract_l(acc);
  tmp_hi = extract_h(acc);

  acc = L_mult0(tmp_lo, in);
  IF(tmp_lo < 0) acc = L_add(acc, L_deposit_h(in)); /* only needed to make mult0 above unsigned by signed */

  acc = L_and(L_shr(acc, 16), (Word32) 0x0000ffff);
  acc = L_mac0(acc, tmp_hi, in);
  acc = L_shl(acc, add(nls, 2));

  return round(acc);
}

/* fractional squareroot, use for numbers < 1.0 */
Word16 sqrt_q15(Word16 in)      /* (i) Q.15 (o) Q.15 */
{
  Word32    acc;
  Word16    tmp_lo, tmp_hi;
  Word16    ret, Sat;


  acc = L_shl(L_deposit_l(in), 1);
  acc = Inv_sqrt(acc);

  tmp_lo = extract_l(acc);
  tmp_hi = extract_h(acc);

  acc = L_mult0(tmp_lo, in);
  IF(tmp_lo < 0) acc = L_add(acc, L_deposit_h(in)); /* only needed to make mult0 above unsigned by signed */
  acc = L_and(L_shr(acc, 16), (Word32) 0x0000ffff);
  acc = L_mac0(acc, tmp_hi, in);
  acc = L_shl(acc, 10);

  Sat = Overflow;
  ret = round(acc);
  Overflow = Sat;
  return ret;
}

/*___________________________________________________________________________
|                                                                           |
|   Function Name : Inv_x()                                                 |
|                                                                           |
|       Compute 1/L_x.														|
|       L_x is positive.                                                    |
|																			|
|       if L_x is negative or zero, result is 0. YUSLAI                     |
|---------------------------------------------------------------------------|
|  Algorithm:                                                               |
|                                                                           |
|   The function 1/L_x is approximated by a table and linear				|
|   interpolation.                                                          |
|                                                                           |
|   1- Normalization of L_x.                                                |
|   2- exponent = 30-exponent                                               |
|   3- i = bit24-b31 of L_x,    64 <= i <= 127  ->because of normalization. |
|   4- YX = bit9-b23                                                        |
|   5- i -=64                                                               |
|   6- L_y = tablog[i]<<16 - (tablog[i] - tablog[i+1]) * YX * 2             |
|___________________________________________________________________________|
*/

Word32 Inv_x(                 /* (o) Q31 : output value   (range: 0 <=val<1)  */
			 Word32 L_x       /* (i) Q0 : input value                         */
)
{
	Word16 exp, i, yx, tmp;
	Word32 L_y;	
	if( L_x <= (Word32)0 )
		return 0;
	exp = norm_l(L_x);
	L_x = L_shl(L_x, exp );               /* L_x is normalized */
	exp = sub(30, exp);
	
	L_x = L_shr(L_x, 8);
	i   = extract_h(L_x);                 /* Extract b24-b31 */
	L_x = L_shr(L_x, 1);
	yx   = extract_l(L_x);                /* Extract b09-b24 of fraction */
	yx   = yx & (Word16)0x7fff;
	i   = sub(i, 64);
	
	L_y = L_deposit_h(tabinv[i]);         /* tabinv[i] << 16        */
	tmp = sub(tabinv[i], tabinv[i+1]);    /* tabinv[i] - tabinv[i+1] */
	L_y = L_msu(L_y, tmp, yx);            /* L_y -= tmp*a*2        */
	
	L_y = L_shr_r(L_y, exp);              /* denormalization */
	return (L_y);
}
/* Square root function : returns sqrt(Num/2) */
/**********************************************/
Word16 Sqrt(Word32 Num)
{
	Word16    i;
	Word16    Rez = (Word16) 0;
	Word16    Exp = (Word16) 0x4000;
	Word32    Acc, L_temp;
	FOR(i = 0; i < 14; i++)
	{
		Acc = L_mult(add(Rez, Exp), add(Rez, Exp));
		L_temp = L_sub(Num, Acc);
		IF(L_temp >= 0L)
			Rez = add(Rez, Exp);
		Exp = shr(Exp, (Word16) 1);
	}
	return Rez;
}

Word16 ful_Sqrt(Word32 Num)
{
	Word16 tmp16;
	IF(L_sub(Num, 65536L) < 0)
		tmp16 = extract_l(L_shr(Sqrt(L_shl(Num, 14)), 7)); /* tmp16 in Q0 */
	ELSE
		tmp16 = Sqrt(Num); /* tmp16 in Q0 */

	return tmp16;
}
Word16 ful_Sqrt_r(Word32 Num)
{
	Word16 tmp16;
	IF(L_sub(Num, 65536L) < 0)
		tmp16 = extract_l(L_shr_r(Sqrt(L_shl(Num, 14)), 7)); /* tmp16 in Q0 */
	ELSE
		tmp16 = Sqrt(Num); /* tmp16 in Q0 */
	
	return tmp16;
}
void Norm_shl_r(Word32 x, Word16 *sh_x, Word32 *x_norm, Word16 *x_norm_r)
{
	Word16 temp16;
	temp16 = norm_l(x);
	*x_norm = L_shl(x, temp16);
	*sh_x = add(*sh_x, temp16);
	*x_norm_r = round(*x_norm);
}
