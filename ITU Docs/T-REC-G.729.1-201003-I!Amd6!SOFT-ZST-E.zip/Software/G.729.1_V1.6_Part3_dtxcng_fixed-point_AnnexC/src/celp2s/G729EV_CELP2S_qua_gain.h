/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/



#ifndef __G729EV_G729_STAGE2_ENHA_GAINS_H__
#define __G729EV_G729_STAGE2_ENHA_GAINS_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_oper_32b.h"
#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_FEC_tools.h"



extern const Word16 G729EV_MAIN_tab_gain_enha[8];

extern const Word16 G729EV_MAIN_tab_gain_enha2bits[4];


Word16    G729EV_CELP2S_qua_gain_Stage2(Word16 gain_code, Word16 xn[], Word16 y1[], Word16 l_subfr, Word16 i_subfr);
Word16    G729EV_CELP2S_dec_gain_Stage2(Word16 gain_code, Word16 index, Word16 i_subfr);



#endif  /*__G729EV_G729_STAGE2_ENHA_GAINS_H__ */
