/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/


#ifndef __G729EV_SP2NO_TRANS_H__
#define __G729EV_SP2NO_TRANS_H__

#include "G729EV_G729_ld8k.h"
#include "typedef.h"
#include <stdlib.h>
void G729EV_Pitch_copy(Word16* old_exc,	/*excitation in the previous frame*/
 		  Word16* new_exc,	/*new excitation in the current superframe*/ 
 		  Word16 Tc);	/*pitch of the last subframe in previous frame*/

void G729EV_Exc_tans_sub(Word16* prev_exc,	/*excitation in the previous superframe*/
		 Word16* curr_exc,		/*excitation in the current superframe*/
		 Word16* new_exc,			/*excitation in the new superframe*/
		 Word16 subfr_num);			/*subframe number in the superframe*/
		 
/* complete excitation transition */
void G729EV_post_cng(Word16 transition_flag,/*excitation transition flag*/
			  Word16 *prev_exc,      /*excitation of the previous superframe*/
			  Word16 *exc,           /*excitation of the current superframe*/
			  Word16 *subfr_num);     /*subframe number in the superframe*/
/* accumulation with weighting */
void G729EV_linear_compose(Word16 *num1, /* input num1 */
					Word16 *sh1,  /* scalar of num1 */
					Word16 *num2, /* input num2 */
					Word16 *sh2,  /* scalar of num1 */ 
					Word16 fact1, /* weight 1*/
					Word16 fact2); /* weight 2*/
void G729EV_adjust_gain(Word16 *Ga, Word16 *Gf, Word16 g_p, Word16 g_c, Word16 g_a);
void G729EV_fir_filt(Word16 x[], Word16 i_frame, Word16 filt[], Word16 count);
Word16 G729EV_calc_alpha(Word16 last_good, Word16 bfi_cnt, Word16 stab_fac);
#endif  /*__G729EV_SP2NO_TRANS_H__ */
