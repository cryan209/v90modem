/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#ifndef __G729EV_TDBWE_VECTOR_QUANTIZATION_H__
#define __G729EV_TDBWE_VECTOR_QUANTIZATION_H__

#include "stl.h"


/* protoype for exported function */

void      G729EV_TDBWE_vector_quantization(Word16 * input,
                                           const Word16 * codebook,
                                           UWord16 * index, const Word16 vector_size, const Word16 codebook_size);


/* tables */

/* TDBWE table for mean time envelope quantization       */
extern const Word16 G729EV_TDBWE_MEAN_TIME_ENV_cb[32];
extern const Word16 G729EV_TDBWE_MEAN_TIME_ENV_cb_DTX[32];
/* TDBWE tables for time envelope quantization           */
extern const Word16 G729EV_TDBWE_TIME_ENV_cb[1024];

/* TDBWE tables for frequency envelope quantization      */
extern const Word16 G729EV_TDBWE_FREQ_ENV_NUMBER_ENTRIES[3];
extern const Word16 G729EV_TDBWE_FREQ_ENV_BITS[3];
extern const Word16 *G729EV_TDBWE_FREQ_ENV_cb[3];
extern const Word16 G729EV_TDBWE_FREQ_ENV_cb1[128];
extern const Word16 G729EV_TDBWE_FREQ_ENV_cb2[128];
extern const Word16 G729EV_TDBWE_FREQ_ENV_cb3[64];

#endif
