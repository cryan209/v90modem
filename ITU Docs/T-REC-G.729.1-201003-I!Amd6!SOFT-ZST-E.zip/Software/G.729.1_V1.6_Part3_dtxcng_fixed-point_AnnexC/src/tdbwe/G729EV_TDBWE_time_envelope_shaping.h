/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_TIME_ENVELOPE_SHAPING_H__
#define __G729EV_TDBWE_TIME_ENVELOPE_SHAPING_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"


/* prototype for exported function */

void      G729EV_TDBWE_time_envelope_shaping(Word16 * input,
                                             Word16 * envelope,
                                             Word16 * output, Word16 * prev_gain, Word16 * prev_norm);


/* tables */

extern const Word16 G729EV_TDBWE_TIME_ENVELOPE_SHAPING_WINDOW[G729EV_TDBWE_SUBFRAME_SIZE_2];


#endif
