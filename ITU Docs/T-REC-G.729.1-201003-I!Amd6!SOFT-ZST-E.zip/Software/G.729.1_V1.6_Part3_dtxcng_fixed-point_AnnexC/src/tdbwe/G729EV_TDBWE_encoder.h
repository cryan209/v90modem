/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#ifndef __G729EV_TDBWE_ENCODER_H__
#define __G729EV_TDBWE_ENCODER_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"


/* type definition TDBWE encoder state variable */
typedef struct
{

  Word16    old_speech[G729EV_TDBWE_MEM_SPEECH];
  Word16	mem_parameters[G729EV_TDBWE_NB_PARAMETERS];    /* filtered envelope parameters  */
  Word16    ltx_parameters[G729EV_TDBWE_NB_PARAMETERS];    /* envelope parameters last transmitted */
  Word16 Vad;
  Word16 cng_wb;

} G729EV_TDBWE_CODSTAT;


/* prototypes for exported functions */

void      G729EV_TDBWE_encoder_init(G729EV_TDBWE_CODSTAT * state);
void G729EV_TDBWE_update_ltx_parameters (G729EV_TDBWE_CODSTAT * state);
void G729EV_TDBWE_encoder_stage1(G729EV_TDBWE_CODSTAT * state, /* (i/o)  */
                                 Word16 * input_hi,            /* (i)    Q.0, high band input signal @ 8kHz */
                                 Word16 * parameters,          /* (i)    Q.10, the unquantized parameter set */
                                 Word16 * flag_chang_wb,       /* (o)    indicate upper-band parameter change */
                                 Word16 * input_hi_delay);     /* (o)    delayed input */

void G729EV_TDBWE_encoder_stage2(G729EV_TDBWE_CODSTAT * state, /* (i/o)  */
                                 Word16 * parameters,          /* (i)    Q.10, the unquantized parameter set */
                                 Word16 * coder_parameters);   /* (o)    quantized parameter set (codebook indices) */

/*****************************************************************************/

#endif
