/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"

#ifdef WMOPS
#include "count.h"
#endif

void G729EV_G729B_Get_decfreq_prev(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                   Word16 x[G729EV_G729_MA_NP][G729EV_G729_M])
{
  Word16    i;

  FOR(i = 0; i < G729EV_G729_MA_NP; i++)
  {
    G729EV_G729_Copy(&freq_prev[i][0], &x[i][0], G729EV_G729_M);
  }
}


void G729EV_G729B_Update_decfreq_prev(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                      Word16 x[G729EV_G729_MA_NP][G729EV_G729_M])
{
  Word16    i;

  FOR(i = 0; i < G729EV_G729_MA_NP; i++)
  {
    G729EV_G729_Copy(&x[i][0], &freq_prev[i][0], G729EV_G729_M);
  }
}
