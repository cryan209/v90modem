/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#ifndef __G729EV_G729_DTX_H__
#define __G729EV_G729_DTX_H__

#include "G729EV_G729_codstat.h"
#include "G729EV_G729_decstat.h"

/* quantize the energy */
void G729EV_Qua_Sidgain_quant_Energy(
    Word16 *enerq,    /* (o)   first stage decoded energies in dB              */
    Word16 *idx,       /* (o)   first stage SID gain quantization index         */
    Word16 *enerq2,   /* (o)   second stage decoded energies in dB              */
    Word16 *idx2,      /* (o)   second stage SID gain quantization index         */
    Word32 frame_energy,     /* (i)   frame energy                  */
    Word16 sh_frame_energy
);
/* SID gain Quantization */
void      G729EV_Qua_Sidgain(Word16 * ener,    /* (i)   array of energies                   */
                      Word16 * sh_ener, /* (i)   corresponding scaling factors       */
                      Word16 nb_ener,   /* (i)   number of energies or               */
                      Word16 * enerq,   /* (o)   decoded energies in dB              */
                      Word16 * idx      /* (o)   SID gain quantization index         */
					  ,Word16 *enerq2,   /* (o)   second stage decoded energies in dB              */
					  Word16 *idx2 ,      /* (o)   second stage SID gain quantization index         */
					  Word32 *frame_energy,     /* (i)   energy                                 */
					  Word16 *sh_frame_energy    /* (i)   corresponding scaling factors       */
);

/* CNG excitation generation */
void G729EV_calc_exc_rand(
    Word16 cur_gain,       /* (i)   :   target sample gain                 */
    Word16 * exc,          /* (i/o) :   excitation array                   */
    Word16 * seed,         /* (i)   :   current Vad decision               */
    Word16 flag_cod,       /* (i)   :   encoder/decoder flag               */
	Word32 *exc_err,	   /* Q14 */
	Word16 pastVad,
	Word16 *old_pitch,
	Word16 *old_gp,
	Word16 *pre_gain,
	Word16 *i_subfr_cnt,
	Word16 *lp_gainp,
	Word16 *lp_gainc,
	Word16 *tilt_code);    
void G729EV_cod_cng(
    G729EV_G729_CODSTAT * pCodStat,
	Word16   ftyp_j,         /* (i) : number of 10 ms frame */
    Word16 *exc,          /* (i/o) : excitation array                     */
    Word16 *Aq,           /* (o)   : set of interpolated LPC coefficients */
    Word16 *ana,            /* (o)   : coded SID parameters                 */
    Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i/o) : previous LPS for quantization        */
	Word16 *SID_tdbwe_parameters,
	Word16 *tdbwe_parameters
);

void G729EV_update_cng(
				G729EV_G729_CODSTAT * pCodStat,
				Word16 *r_h,      /* (i) :   MSB of frame autocorrelation        */
				Word16 exp_r,     /* (i) :   scaling factor associated           */
				Word16 Vad        /* (i) :   current Vad decision                */
);
#endif  //__G729EV_G729_DTX_H__
