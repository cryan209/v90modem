/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

#ifdef WMOPS
#include "count.h"
#endif


/*---------------------------------------------------------------------------*
 * Function  G729EV_G729_Dec_gain                                            *
 * ~~~~~~~~~~~~~~~~~~                                                        *
 * Decode the pitch and codebook gains                                       *
 *                                                                           *
 *---------------------------------------------------------------------------*
 * input arguments:                                                          *
 *                                                                           *
 *   index      :Quantization index                                          *
 *   code[]     :Innovative code vector                                      *
 *   L_subfr    :Subframe size                                               *
 *   bfi        :Bad frame indicator                                         *
 *                                                                           *
 * output arguments:                                                         *
 *                                                                           *
 *   gain_pit   :Quantized pitch gain                                        *
 *   gain_cod   :Quantized codebook gain                                     *
 *                                                                           *
 *---------------------------------------------------------------------------*/
void G729EV_G729_Dec_gain(Word16 index,         /* (i)     :Index of quantization.         */
                          Word16 code[],        /* (i) Q13 :Innovative vector.             */
                          Word16 L_subfr,       /* (i)     :Subframe length.               */
                          Word16 bfi,           /* (i)     :Bad frame indicator            */
                          Word16 * gain_pit,    /* (o) Q14 :Pitch gain.                    */
                          Word16 * gain_cod,    /* (o) Q1  :Code gain.                     */
                          Word16 past_qua_en[4])
{
  Word32    L_gbk12, L_acc, L_accb;

  Word16    index1, index2, tmp;
  Word16    gcode0, exp_gcode0;

  /* Gain predictor, Past quantized energies = -14.0 in Q10 */

   /*-------------- Decode pitch gain ---------------*/

#ifdef WMOPS
  move16();
  move16();
  move16();
#endif
  index1 = imap1[shr(index, G729EV_G729_NCODE2_B)];
  index2 = imap2[s_and(index, (G729EV_G729_NCODE2 - 1))];
  *gain_pit = add(gbk1[index1][0], gbk2[index2][0]);

   /*-------------- Decode codebook gain ---------------*/

  /*---------------------------------------------------*
   *-  energy due to innovation                       -*
   *-  predicted energy                               -*
   *-  predicted codebook gain => gcode0[exp_gcode0]  -*
   *---------------------------------------------------*/

  G729EV_G729_Gain_predict(past_qua_en, code, L_subfr, &gcode0, &exp_gcode0);

  /*-----------------------------------------------------------------*
   * *gain_code = (gbk1[indice1][1]+gbk2[indice2][1]) * gcode0;      *
   *-----------------------------------------------------------------*/

  L_acc = L_deposit_l(gbk1[index1][1]);
  L_accb = L_deposit_l(gbk2[index2][1]);
  L_gbk12 = L_add(L_acc, L_accb);     /* Q13 */
  tmp = extract_l(L_shr(L_gbk12, 1)); /* Q12 */
  L_acc = L_mult(tmp, gcode0);        /* Q[exp_gcode0+12+1] */

  L_acc = L_shl(L_acc, add(negate(exp_gcode0), (-12 - 1 + 1 + 16)));
  *gain_cod = extract_h(L_acc); /* Q1 */
#ifdef WMOPS
  move16();
#endif

  /*----------------------------------------------*
   * update table of past quantized energies      *
   *----------------------------------------------*/
  G729EV_G729_Gain_update(past_qua_en, L_gbk12);

  return;

}
