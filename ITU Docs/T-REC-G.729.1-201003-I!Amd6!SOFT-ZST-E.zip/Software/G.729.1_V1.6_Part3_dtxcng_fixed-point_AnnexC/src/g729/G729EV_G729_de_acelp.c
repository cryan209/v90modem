/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*-----------------------------------------------------------*
 *  Function  G729EV_G729_Decod_ACELP()                      *
 *  ~~~~~~~~~~~~~~~~~~~~~~~                                  *
 *   Algebraic codebook decoder.                             *
 *----------------------------------------------------------*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"


void G729EV_G729_Decod_ACELP(Word16 sign,   /* (i)     : signs of 4 pulses.                       */
                             Word16 index,  /* (i)     : Positions of the 4 pulses.               */
                             Word16 cod[]   /* (o) Q13 : algebraic (fixed) codebook excitation    */
    )
{
  Word16    pos[4];

  Word16    i, j;

  /* Decode the positions */

  i = s_and(index, (Word16) 7);
  pos[0] = add(i, shl(i, 2));   /* pos0 =i*5 */
#ifdef WMOPS
  move16();
#endif

  index = shr(index, 3);
  i = s_and(index, (Word16) 7);
  i = add(i, shl(i, 2));        /* pos1 =i*5+1 */
  pos[1] = add(i, 1);
#ifdef WMOPS
  move16();
#endif

  index = shr(index, 3);
  i = s_and(index, (Word16) 7);
  i = add(i, shl(i, 2));        /* pos2 =i*5+1 */
  pos[2] = add(i, 2);
#ifdef WMOPS
  move16();
#endif

  index = shr(index, 3);
  j = s_and(index, (Word16) 1);
  index = shr(index, 1);
  i = s_and(index, (Word16) 7);
  i = add(i, shl(i, 2));        /* pos3 =i*5+3+j */
  i = add(i, 3);
  pos[3] = add(i, j);
#ifdef WMOPS
  move16();
#endif

  /* decode the signs  and build the codeword */

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    cod[i] = 0;
#ifdef WMOPS
    move16();
#endif
  }

  FOR(j = 0; j < 4; j++)
  {
    i = s_and(sign, (Word16) 1);
    sign = shr(sign, 1);

    IF(i != 0)
    {
      cod[pos[j]] = 8191;       /* Q13 +1.0 */
#ifdef WMOPS
      move16();
#endif
    }
    ELSE
    {
      cod[pos[j]] = -8192;      /* Q13 -1.0 */
#ifdef WMOPS
      move16();
#endif
    }
  }

  return;
}
