/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*-------------------------------------------------------------------*
 * Function  G729EV_G729_Pred_lt_3()                                 *
 *           ~~~~~~~~~~~                                             *
 *-------------------------------------------------------------------*
 * Compute the result of long term prediction with fractional        *
 * interpolation of resolution 1/3.                                  *
 *                                                                   *
 * On return exc[0..L_subfr-1] contains the interpolated signal      *
 *   (adaptive codebook excitation)                                  *
 *-------------------------------------------------------------------*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"


void G729EV_G729_Pred_lt_3(Word16 exc[],  /* in/out: excitation buffer */
                           Word16 T0,     /* input : integer pitch lag */
                           Word16 frac,   /* input : fraction of lag   */
                           Word16 L_subfr /* input : subframe size     */
    )
{
  Word32    s;

  Word16   *x0, *x1, *x2, *c1, *c2;

  Word16    i, j, k;



  x0 = &exc[-T0];

  frac = negate(frac);
  if (frac < 0)
  {
    frac = add(frac, G729EV_G729_UP_SAMP);
    x0--;
  }

  FOR(j = 0; j < L_subfr; j++)
  {
    x1 = x0++;
    x2 = x0;
    c1 = &inter_3l[frac];
    c2 = &inter_3l[sub(G729EV_G729_UP_SAMP, frac)];

    s = 0;

#ifdef WMOPS
    move32();
#endif

#ifdef WMOPS
    move16();
#endif
    k = 0;
    FOR(i = 0; i < G729EV_G729_L_INTER10; i++)
    {
      s = L_mac(s, x1[-i], c1[k]);
      s = L_mac(s, x2[i], c2[k]);

      k += G729EV_G729_UP_SAMP;
    }

    exc[j] = round(s);
#ifdef WMOPS
    move16();
#endif
  }

  return;
}
