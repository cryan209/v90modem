/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#ifndef __G729EV_G729_TAB_DTX_H__
#define __G729EV_G729_TAB_DTX_H__

#include "stl.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729B_defines.h"

/* Quantization of LSF vector */
extern Word16 PtrTab_1[32];
extern Word16 PtrTab_2[2][16];
extern Word16 PtrTab_3[2][G729EV_G729B_3rdCB_LEN];
extern Word16 ratio_cb2[G729EV_G729B_3rdRAT_LEN];

/* Quantization of SID gain */
extern Word16 fact[NB_GAIN + 1];
extern Word16 Adjust_fact[NB_GAIN];
extern Word16 marg[NB_GAIN + 1];
extern Word16 tab_Sidgain[32];
extern Word16 tab_Sidgain2[8];
extern Word16 tab_Sidgain3[8];

/* SID LSF quantization */
extern Word16 noise_fg_sum[G729EV_G729_MODE][G729EV_G729_M];
extern Word16 noise_fg_sum_inv[G729EV_G729_MODE][G729EV_G729_M];
extern Word16 Mp[G729EV_G729_MODE];

/* DTX bitrate switching scheme */
extern const Word16 G729EV_DTX_switching_gain[G729EV_MAIN_COUNT_RCV_DTX_MAX+1];


extern const Word16 SmoothWindow[12];
extern const Word16 Shaping_filter[7];


extern Word16 noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M];
extern Word16 G729EV_DTX_LSP_INIT[G729EV_G729_M];
#endif
