/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#ifndef __G729EV_G729_SID_H__
#define __G729EV_G729_SID_H__

#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729_ld8k.h"
void G729EV_G729B_Dec_cng(G729EV_G729_DECSTAT * pDecStat, 
                          Word16 past_ftyp,   /* (i)   : past frame type                      */
                          Word16 sid_sav,     /* (i)   : energy to recover SID gain           */
                          Word16 sh_sid_sav,  /* (i)   : corresponding scaling factor         */
                          Word16 * parm,      /* (i)   : coded SID parameters                 */
                          Word16 * exc,       /* (i/o) : excitation array                     */
                          Word16 * lsp_old, /* (i/o) : previous lsp                         */
                          Word16 * A_t,       /* (o)   : set of interpolated LPC coefficients */
                          Word16 * seed,      /* (i/o) : random generator seed                */
                          Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
						  /* (i/o) : previous LPS for quantization        */
                          Word16 ftyp, Word16 bfi);
						  


void sid_lsfq_decode(Word16 * index,  /* (i) : quantized indices    */
                     Word16 * lspq, /* (o) : quantized lsp vector */
                     Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i) : memory of predictor  */
                     Word16 noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M],
					 Word16 sid_nb,
					 Word16 Ratio_3rd_idx);
#endif
