/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*-------------------------------------------------------------------*
 *                         VOICEFAC.C                 *
 *-------------------------------------------------------------------*
 * Find the voicing factor (1=voice to -1=unvoiced).         *
 *-------------------------------------------------------------------*/

#include "stl.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_FEC_tools.h"

Word16 G729EV_FEC_voice_factor( /* (o) Q15   : factor (-1=unvoiced to 1=voiced) */
                                Word16 exc_in[],  /* (i) Q_exc : pitch excitation                 */
                                Word16 gain_pit,  /* (i) Q14   : gain of pitch                    */
                                Word16 code[],    /* (i) Q13    : Fixed codebook excitation        */
                                Word16 gain_code  /* (i) Q1    : gain of code                     */
    )
{
  Word16    i, tmp, exp, ener1, exp1, ener2, exp2, exc[G729EV_G729_L_SUBFR], Q_exc;
  Word32    L_tmp;
  extern Flag Overflow;

#if(WMOPS)
  move32();
  move16();
#endif
  Overflow = 0;
  L_tmp = (Word32) 0;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    L_tmp = L_mac(L_tmp, exc_in[i], exc_in[i]);
  }


  IF(Overflow)
  {
    FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      exc[i] = shr(exc_in[i], 3);
#ifdef WMOPS
      move16();
#endif
    }
    Q_exc = (Word16) - 2;
#ifdef WMOPS
    move16();
#endif
  }
  ELSE
  {
    FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      exc[i] = exc_in[i];
#ifdef WMOPS
      move16();
#endif
    }
    Q_exc = (Word16) 1;
#ifdef WMOPS
    move16();
#endif

  }
  ener1 = extract_h(G729EV_Dot_product12(exc, exc, G729EV_G729_L_SUBFR, &exp1));
  exp1 = sub(exp1, add(Q_exc, Q_exc));
  L_tmp = L_mult(gain_pit, gain_pit);
  exp = norm_l(L_tmp);
  tmp = extract_h(L_shl(L_tmp, exp));
  ener1 = mult(ener1, tmp);
  exp1 = sub(sub(exp1, exp), 2 /*10 */ ); /* 10 -> gain_pit Q14 to Q13 */

  ener2 = extract_h(G729EV_Dot_product12(code, code, G729EV_G729_L_SUBFR, &exp2));

  exp = norm_s(gain_code);
  tmp = shl(gain_code, exp);    /* gain code in Q1 */
  exp = add(exp, 1);
  tmp = mult(tmp, tmp);
  ener2 = mult(ener2, tmp);
  exp2 = sub(exp2, add(exp, exp));

  i = sub(exp1, exp2);
  IF(sub(i, 15) > 0)
  {                             /*ener1 >> ener2   -> ener1 - ener2 / ener+ener2 -> 1.0 */
    return (Word16) 32767;
  }
  ELSE if   (sub(i, -15) < 0)
  {                             /*ener1 << ener2   -> ener1 - ener2 / ener+ener2 -> -1.0 */
    return (Word16) - 32768;
  }
  ELSE
  {
    Word32    L_ener1, L_ener2;

    IF(i >= 0)
    {
      L_ener1 = L_shl(ener1, i);
      L_ener2 = ener2;
    }
    ELSE
    {
      L_ener1 = ener1;
      L_ener2 = L_shr(ener2, i);
    }
#ifdef WMOPS
    move32();
#endif
    L_tmp = L_sub(L_ener1, L_ener2);
    L_ener1 = L_add(L_add(L_ener1, L_ener2), 1);
    exp1 = norm_l(L_ener1);
    ener1 = extract_h(L_shl(L_ener1, exp1));
    tmp = extract_h(L_shl(L_tmp, exp1));


    IF(L_tmp >= 0)
    {
      tmp = div_s(tmp, ener1);
    }
    ELSE
    {
      tmp = negate(div_s(negate(tmp), ener1));
    }
  }
  return (tmp);
}
