/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_CELP2S_POST_H__
#define __G729EV_CELP2S_POST_H__

#include "G729EV_MAIN_filt.h"

/* functions */
void      G729EV_CELP2S_init_post_filter(G729EV_MAIN_PFSTAT * pfstat);  /* (i)   : core decoder parameters                */

void      G729EV_CELP2S_post(G729EV_MAIN_PFSTAT * pfstat, /* (i/o): states strucure                           */
                             int t0,                      /* (i)  : pitch delay given by coder                */
                             REAL * signal_ptr,           /* (i)  : input signal (pointer to current subframe */
                             REAL * coeff,                /* (i)  : LPC coefficients for current subframe     */
                             REAL * sig_out,              /* (o)  : postfiltered output                       */
                             REAL gamma1,                 /* (i)  : short term postfilt. den. weighting factor */
                             REAL gamma2,                 /* (i)  : short term postfilt. num. weighting factor */
                             REAL PostNB, INT16 Vad);

#endif
