/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.6                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "CodecTypedef.h"

/* Quantization of LSF vector */
extern int PtrTab_1[32];
extern int PtrTab_2[2][16];
extern int PtrTab_3[2][G729EV_G729B_3rdCB_LEN];
extern REAL ratio_cb2[G729EV_G729B_3rdRAT_LEN];

/* Quantization of SID gain */
extern REAL fact[NB_GAIN + 1];
extern REAL tab_Sidgain[32];
extern REAL tab_Sidgain2[8];
extern REAL tab_Sidgain3[8];

/* SID LSF quantization */
extern REAL noise_fg_sum[G729EV_G729_MODE][G729EV_G729_M];
extern REAL noise_fg_sum_inv[G729EV_G729_MODE][G729EV_G729_M];
REAL Mp[G729EV_G729_MODE];

/* DTX bitrate switching scheme */
extern const REAL G729EV_DTX_switching_gain[G729EV_MAIN_COUNT_RCV_DTX_MAX+1];

extern const REAL Shaping_filter[5];
extern const REAL    SmoothWindow[12];
extern REAL G729EV_DTX_LSP_INIT[G729EV_G729_M];
extern REAL noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M];
