/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"
#include "G729EV_FEC_tools.h"




/*---------------------------------------------------------------------------
 * Function G729EV_G729_Lsp_decw_reset -   set the previous LSP vectors
 *----------------------------------------------------------------------------
*/
void G729EV_G729_Lsp_decw_reset(REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (o) : previous LSP MA vector */
                                REAL prev_lsp[G729EV_G729_M],                     /* (o) : previous LSP vector         */
                                INT16 * prev_ma                                   /* (i) : previous MA prediction coef. */
    )
{
  int       i;

  for (i = 0; i < G729EV_G729_MA_NP; i++)
    G729EV_G729_Copy(&freq_prev_reset[0], &freq_prev[i][0], G729EV_G729_M);

  *prev_ma = 0;

  G729EV_G729_Copy(freq_prev_reset, prev_lsp, G729EV_G729_M);

  return;
}


/*---------------------------------------------------------------------------
 * Function G729EV_G729_Lsp_iqua_cs -  LSP main quantization routine
 *----------------------------------------------------------------------------
*/

REAL G729EV_G729_Lsp_iqua_cs(int prm[],                                         /* (i) : codes of the selected LSP  */
                             REAL lsp_q[],                                      /* (o) : Quantized LSP parameters   */
                             int erase,                                         /* (i) : frame erase information    */
                             REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i/o) : previous LSP MA vector    */
                             REAL prev_lsp[G729EV_G729_M],                      /* (i/o) : previous LSP vector       */
                             INT16 * prev_ma                                    /* (i/o) previous MA prediction coef. */
    )
{
  int       mode_index;
  int       code0;
  int       code1;
  int       code2;
  REAL      buf[G729EV_G729_M];
  REAL      ftmp = 0.0f;


  if (erase == 0)               /* Not frame erasure */
  {
    mode_index = (prm[0] >> G729EV_G729_NC0_B) & 1;
    code0 = prm[0] & (INT16) (G729EV_G729_NC0 - 1);
    code1 = (prm[1] >> G729EV_G729_NC1_B) & (INT16) (G729EV_G729_NC1 - 1);
    code2 = prm[1] & (INT16) (G729EV_G729_NC1 - 1);

    /* compose quantized LSP (lsp_q) from indexes */
    G729EV_G729_Lsp_get_quant(lspcb1, lspcb2,
                              code0, code1, code2, fg[mode_index], freq_prev, lsp_q, fg_sum[mode_index]);

    ftmp = G729EV_FEC_Lsf_stab(lsp_q, prev_lsp);

    G729EV_G729_Copy(lsp_q, prev_lsp, G729EV_G729_M);
    *prev_ma = mode_index;
  }
  else if (erase == -1)         /* Frame erased but look for next filter */
  {
    int       j;

    mode_index = (prm[0] >> G729EV_G729_NC0_B) & 1;
    code0 = prm[0] & (INT16) (G729EV_G729_NC0 - 1);
    code1 = (prm[1] >> G729EV_G729_NC1_B) & (INT16) (G729EV_G729_NC1 - 1);
    code2 = prm[1] & (INT16) (G729EV_G729_NC1 - 1);

    for (j = 0; j < G729EV_G729_NC; j++)
      buf[j] = lspcb1[code0][j] + lspcb2[code1][j];
    for (j = G729EV_G729_NC; j < G729EV_G729_M; j++)
      buf[j] = lspcb1[code0][j] + lspcb2[code2][j];

    /* interpol old and new filter */
    for (j = 0; j < G729EV_G729_M; j++)
      buf[j] = 0.2f * buf[j] + 0.8f * freq_prev[0][j];

    /* check */
    G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP1);
    G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP2);


    /* reconstruct quantized LSP parameters */
    G729EV_G729_Lsp_prev_compose(buf, lsp_q, fg[mode_index], freq_prev, fg_sum[mode_index]);

    G729EV_G729_Lsp_prev_update(buf, freq_prev);

    /* check the stabilty */
    G729EV_G729_Lsp_stability(lsp_q);

    G729EV_G729_Copy(lsp_q, prev_lsp, G729EV_G729_M);
    *prev_ma = mode_index;
  }
  else                          /* Frame erased */
  {
    /* use revious LSP */
    G729EV_G729_Copy(prev_lsp, lsp_q, G729EV_G729_M);

    /* update freq_prev */
    G729EV_G729_Lsp_prev_extract(prev_lsp, buf, fg[*prev_ma], freq_prev, fg_sum_inv[*prev_ma]);

    G729EV_G729_Lsp_prev_update(buf, freq_prev);
  }

  return ftmp;
}



/**---------------------------------------------------------------------------
* Function G729EV_G729_D_lsp - decode lsp parameters
*----------------------------------------------------------------------------
*/

REAL G729EV_G729_D_lsp(int prm[],                                         /* (i)  : indexes of the selected LSP */
                       REAL lsp_q[],                                      /* (o)  : Quantized LSP parameters    */
                       int erase,                                         /* (i)  : frame erase information     */
                       REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i/o): previous LSP MA vector      */
                       REAL prev_lsp[],                                   /* (i/o): previous LSP vector         */
                       INT16 * prev_ma                                    /* (i/o): previous MA prediction coef. */
    )
{
  REAL      lsf_q[G729EV_G729_M];

  REAL      ftmp = G729EV_G729_Lsp_iqua_cs(prm, lsf_q, erase, freq_prev, prev_lsp, prev_ma);

  /* Convert LSFs to LSPs */
  G729EV_G729_Lsf_lsp(lsf_q, lsp_q, G729EV_G729_M);

  return ftmp;
}
