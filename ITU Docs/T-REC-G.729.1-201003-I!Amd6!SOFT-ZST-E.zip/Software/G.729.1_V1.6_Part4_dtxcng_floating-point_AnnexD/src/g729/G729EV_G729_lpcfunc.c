/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

/* local function */
static void G729EV_G729_Get_lsp_pol(REAL lsp[], REAL f[]);

/*-------------------------------------------------------------*
 *  Procedure G729EV_G729_Lsp_Az:                              *
 *            ~~~~~~                                           *
 *   Compute the LPC coefficients from lsp (order=10)          *
 *-------------------------------------------------------------*/

void G729EV_G729_Lsp_Az(REAL * lsp, /*(i) : line spectral frequencies                       */
                        REAL * a    /*(o) : predictor coefficients (order = 10)             */
    )
{

  REAL      f1[G729EV_G729_NC + 1], f2[G729EV_G729_NC + 1];
  int       i, j;

  G729EV_G729_Get_lsp_pol(&lsp[0], f1);
  G729EV_G729_Get_lsp_pol(&lsp[1], f2);

  for (i = G729EV_G729_NC; i > 0; i--)
  {
    f1[i] += f1[i - 1];
    f2[i] -= f2[i - 1];
  }

  a[0] = (REAL) 1.0;
  for (i = 1, j = G729EV_G729_M; i <= G729EV_G729_NC; i++, j--)
  {
    a[i] = (REAL) 0.5 *(f1[i] + f2[i]);
    a[j] = (REAL) 0.5 *(f1[i] - f2[i]);
  }

  return;
}

/*-----------------------------------------------------------*
 * procedure G729EV_G729_Get_lsp_pol:                        *
 *           ~~~~~~~~~~~                                     *
 *   Find the polynomial F1(z) or F2(z) from the LSPs        *
 *-----------------------------------------------------------*
 *                                                           *
 * Parameters:                                               *
 *  lsp[]   : line spectral freq. (cosine domain)            *
 *  f[]     : the coefficients of F1 or F2                   *
 *-----------------------------------------------------------*/

static void G729EV_G729_Get_lsp_pol(REAL lsp[], REAL f[])
{
  REAL      b;
  int       i, j;

  f[0] = (REAL) 1.0;
  b = (REAL) - 2.0 * lsp[0];
  f[1] = b;
  for (i = 2; i <= G729EV_G729_NC; i++)
  {
    b = (REAL) - 2.0 * lsp[2 * i - 2];
    f[i] = b * f[i - 1] + (REAL) 2.0 *f[i - 2];

    for (j = i - 1; j > 1; j--)
      f[j] += b * f[j - 1] + f[j - 2];
    f[1] += b;
  }
  return;
}

/*___________________________________________________________________________
 |                                                                           |
 |   Functions : G729EV_G729_Lsp_lsf and G729EV_G729_Lsf_lsp                 |
 |                                                                           |
 |      G729EV_G729_Lsp_lsf   Transformation lsp to lsf                      |
 |      G729EV_G729_Lsf_lsp   Transformation lsf to lsp                      |
  ___________________________________________________________________________
 */

void G729EV_G729_Lsp_lsf(REAL lsp[],  /* (i) :  lsp coefficients                           */
                         REAL lsf[],  /* (o) :  lsf (normalized frequencies)               */
                         int m        /* (i)     : LPC order                               */
    )
{
  int       i;

  for (i = 0; i < m; i++)
    lsf[i] = (REAL) acos((double) lsp[i]);

  return;
}

void G729EV_G729_Lsf_lsp(REAL lsf[],  /* (i) :  lsf coefficients                           */
                         REAL lsp[],  /* (o) :  lsp coefficients                           */
                         int m        /* (i)     : LPC order                               */
    )
{
  int       i;

  for (i = 0; i < m; i++)
    lsp[i] = (REAL) cos((double) lsf[i]);

  return;
}

/*-------------------------------------------------------------*
 *  procedure G729EV_G729_Weight_Az                            *
 *            ~~~~~~~~~~~~~~~~~~~~~                            *
 * Weighting of LPC coefficients.                              *
 *   ap[i]  =  a[i] * (gamma ** i)                             *
 *                                                             *
 *-------------------------------------------------------------*/

void G729EV_G729_Weight_Az(REAL * a,    /*(i) : lpc coefficients a[0:m]            */
                           REAL gamma,  /*(i) : Spectral expansion factor          */
                           int m,       /*(i) : LPC order                          */
                           REAL * ap    /*(o) : Spectral expanded LPC coefficients */
    )
{
  REAL      fac;
  int       i;

  ap[0] = a[0];
  fac = gamma;
  for (i = 1; i < m; i++)
  {
    ap[i] = fac * a[i];
    fac *= gamma;
  }
  ap[m] = fac * a[m];
  return;
}

/*----------------------------------------------------------------------*
 * Function G729EV_G729_Int_qlpc() and Int_lpc()                        *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                        *
 * Interpolation of the LPC parameters.                                 *
 *----------------------------------------------------------------------*/

/* Interpolation of the quantized LSP's */

void G729EV_G729_Int_qlpc(REAL lsp_old[], /* (i) : LSP vector of past frame              */
                          REAL lsp_new[], /* (i) : LSP vector of present frame           */
                          REAL az[]       /* (o): interpolated Az() for the 2 subframes */
    )
{
  int       i;
  REAL      lsp[G729EV_G729_M];

  for (i = 0; i < G729EV_G729_M; i++)
    lsp[i] = lsp_old[i] * (REAL) 0.5 + lsp_new[i] * (REAL) 0.5;

  G729EV_G729_Lsp_Az(lsp, az);  /* Subframe 1 */
  G729EV_G729_Lsp_Az(lsp_new, &az[G729EV_G729_MP1]);  /* Subframe 2 */

  return;
}

void G729EV_G729_Int_qlpc_bfi(REAL lsp_old[], /* input : LSP vector of past frame              */
                              REAL lsp_new[], /* input : LSP vector of present frame           */
                              REAL az[],      /* output: interpolated Az() for the 2 subframes */
                              const REAL * interpol_frac1)
{
  REAL      isp[G729EV_G729_M], fnew, fold, *p_a;
  INT16     i, k;

  p_a = az;
  for (k = 0; k < G729EV_MAIN_NB_SUBFR; k++)
  {
    fnew = interpol_frac1[k];
    fold = (REAL) (1.0f - fnew);

    for (i = 0; i < G729EV_G729_M; i++)
    {
      isp[i] = lsp_old[i] * fold + lsp_new[i] * fnew;
    }
    G729EV_G729_Lsp_Az(isp, p_a);
    p_a += (G729EV_G729_MP1);
  }

  return;
}

/*----------------------------------------------------------------------*
 * Function G729EV_G729_Int_lpc()                                       *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 * Interpolation of the unquantized LPC parameters.                     *
 * Same as the previous function but we do not recompute Az() for       *
 * subframe 2  because it is already available.                         *
 * We also compute the interpolate LSF (frequency domain).              *
 *----------------------------------------------------------------------*/

void G729EV_G729_Int_lpc(REAL lsp_old[],  /* input : LSP vector of past frame              */
                         REAL lsp_new[],  /* input : LSP vector of present frame           */
                         REAL lsf_int[],  /* output: interpolated lsf coefficients         */
                         REAL lsf_new[],  /* input : LSF vector of present frame           */
                         REAL az[]        /* output: interpolated Az() for the 2 subframes */
    )
{
  int       i;
  REAL      lsp[G729EV_G729_M];

  for (i = 0; i < G729EV_G729_M; i++)
    lsp[i] = lsp_old[i] * (REAL) 0.5 + lsp_new[i] * (REAL) 0.5;

  G729EV_G729_Lsp_Az(lsp, az);

  G729EV_G729_Lsp_lsf(lsp, lsf_int, G729EV_G729_M); /* transformation from LSP to LSF (freq.domain) */
  G729EV_G729_Lsp_lsf(lsp_new, lsf_new, G729EV_G729_M); /* transformation from LSP to LSF (freq.domain) */

  return;
}
