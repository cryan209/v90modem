/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"


/**-----------------------------------------------------------------------------------
* Function lsp_get_quant - reconstruct quantized LSP parameter and check the stabilty
*-------------------------------------------------------------------------------------
*/
void G729EV_G729_Lsp_get_quant(REAL lspcb1[][G729EV_G729_M],    /* (i)    : First stage LSP codebook      */
                               REAL lspcb2[][G729EV_G729_M],    /* (i)    : Second stage LSP codebook     */
                               int code0,                       /* (i)    : selected code of first stage */
                               int code1,                       /* (i)    : selected code of second stage */
                               int code2,                       /* (i)    : selected code of second stage */
                               REAL fg[][G729EV_G729_M],        /*(i) : MA prediction coef.          */
                               REAL freq_prev[][G729EV_G729_M], /* (i)    : previous LSP vector          */
                               REAL lspq[],                     /* (o)    : quantized LSP parameters     */
                               REAL fg_sum[]                    /* (i)    : present MA prediction coef.  */
    )
{
  int       j;
  REAL      buf[G729EV_G729_M];

  for (j = 0; j < G729EV_G729_NC; j++)
    buf[j] = lspcb1[code0][j] + lspcb2[code1][j];
  for (j = G729EV_G729_NC; j < G729EV_G729_M; j++)
    buf[j] = lspcb1[code0][j] + lspcb2[code2][j];

  /* check */
  G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP1);
  G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP2);

  /* reconstruct quantized LSP parameters */
  G729EV_G729_Lsp_prev_compose(buf, lspq, fg, freq_prev, fg_sum);

  G729EV_G729_Lsp_prev_update(buf, freq_prev);

  /* check the stabilty */
  G729EV_G729_Lsp_stability(lspq);

  return;
}


/*---------------------------------------------------------------------------
 * Function G729EV_G729_Lsp_expand_1  - check for lower (0-4)
 *----------------------------------------------------------------------------
*/
void G729EV_G729_Lsp_expand_1(REAL buf[], /* (i/o)  : lsp vectors */
                              REAL gap    /* (i)    : gap         */
    )
{
  int       j;
  REAL      diff, tmp;

  for (j = 1; j < G729EV_G729_NC; j++)
  {
    diff = buf[j - 1] - buf[j];
    tmp = (diff + gap) * (REAL) 0.5;
    if (tmp > 0)
    {
      buf[j - 1] -= tmp;
      buf[j] += tmp;
    }
  }
  return;
}


/*---------------------------------------------------------------------------
 * Function G729EV_G729_Lsp_expand_2 - check for higher (5-9)
 *----------------------------------------------------------------------------
*/
void G729EV_G729_Lsp_expand_2(REAL buf[], /* (i/o) : lsp vectors  */
                              REAL gap    /* (i)   : gap          */
    )
{
  int       j;
  REAL      diff, tmp;

  for (j = G729EV_G729_NC; j < G729EV_G729_M; j++)
  {
    diff = buf[j - 1] - buf[j];
    tmp = (diff + gap) * (REAL) 0.5;
    if (tmp > 0)
    {
      buf[j - 1] -= tmp;
      buf[j] += tmp;
    }
  }
  return;
}


/*---------------------------------------------------------------------------
 * Function G729EV_G729_Lsp_expand_1_2 - ..
 *----------------------------------------------------------------------------
*/
void G729EV_G729_Lsp_expand_1_2(REAL buf[], /* (i/o) : LSP parameters  */
                                REAL gap    /* (i)   : gap             */
    )
{
  int       j;
  REAL      diff, tmp;

  for (j = 1; j < G729EV_G729_M; j++)
  {
    diff = buf[j - 1] - buf[j];
    tmp = (diff + gap) * (REAL) 0.5;
    if (tmp > 0)
    {
      buf[j - 1] -= tmp;
      buf[j] += tmp;
    }
  }
  return;
}

/*
Functions which use previous LSP parameter (freq_prev).
*/

/*
 * Function G729EV_G729_Lsp_prev_compose : compose LSP parameter from elementary LSP with previous LSP.
 */
void G729EV_G729_Lsp_prev_compose(REAL lsp_ele[],                   /* (i)  : LSP vectors                 */
                                  REAL lsp[],                       /* (o)  : quantized LSP parameters    */
                                  REAL fg[][G729EV_G729_M],         /* (i)  : MA prediction coef.         */
                                  REAL freq_prev[][G729EV_G729_M],  /* (i)  : previous LSP vector         */
                                  REAL fg_sum[]                     /* (i)  : present MA prediction coef. */
    )
{
  int       j, k;

  for (j = 0; j < G729EV_G729_M; j++)
  {
    lsp[j] = lsp_ele[j] * fg_sum[j];
    for (k = 0; k < G729EV_G729_MA_NP; k++)
      lsp[j] += freq_prev[k][j] * fg[k][j];
  }

  return;
}

/*
 * Function  G729EV_G729_Lsp_prev_extract : extract elementary LSP from composed LSP with previous LSP
 */
void G729EV_G729_Lsp_prev_extract(REAL lsp[G729EV_G729_M],                          /* (i)  : unquantized LSP parameters  */
                                  REAL lsp_ele[G729EV_G729_M],                      /* (o)  : target vector               */
                                  REAL fg[G729EV_G729_MA_NP][G729EV_G729_M],        /* (i)  : MA prediction coef.         */
                                  REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i)  : previous LSP vector         */
                                  REAL fg_sum_inv[G729EV_G729_M]                    /* (i)  : inverse previous LSP vector */
    )
{
  int       j, k;

  for (j = 0; j < G729EV_G729_M; j++)
  {
    lsp_ele[j] = lsp[j];
    for (k = 0; k < G729EV_G729_MA_NP; k++)
      lsp_ele[j] -= freq_prev[k][j] * fg[k][j];
    lsp_ele[j] *= fg_sum_inv[j];
  }

  return;
}


/*
 * Function G729EV_G729_Lsp_prev_update : update previous LSP parameter
 */
void G729EV_G729_Lsp_prev_update(REAL lsp_ele[G729EV_G729_M],                     /*(i) : LSP vectors              */
                                 REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M] /* (i/o) : previous LSP vectors  */
    )
{
  int       k;

  for (k = G729EV_G729_MA_NP - 1; k > 0; k--)
    G729EV_G729_Copy(freq_prev[k - 1], freq_prev[k], G729EV_G729_M);

  G729EV_G729_Copy(lsp_ele, freq_prev[0], G729EV_G729_M);

  return;
}

/*---------------------------------------------------------------------------
 * Function G729EV_G729_Lsp_stability - check stability of lsp coefficients
 *----------------------------------------------------------------------------
 */
void G729EV_G729_Lsp_stability(REAL buf[] /*  (i/o) : LSP parameters  */
    )
{
  int       j;
  REAL      diff, tmp;

  for (j = 0; j < G729EV_G729_M - 1; j++)
  {
    diff = buf[j + 1] - buf[j];
    if (diff < (REAL) 0.)
    {
      tmp = buf[j + 1];
      buf[j + 1] = buf[j];
      buf[j] = tmp;
    }
  }

  if (buf[0] < G729EV_G729_L_LIMIT)
  {
    buf[0] = G729EV_G729_L_LIMIT;
    printf("lsp_stability warning Low \n");
  }

  for (j = 0; j < G729EV_G729_M - 1; j++)
  {
    diff = buf[j + 1] - buf[j];
    if (diff < G729EV_G729_GAP3)
    {
      buf[j + 1] = buf[j] + G729EV_G729_GAP3;
    }
  }

  if (buf[G729EV_G729_M - 1] > G729EV_G729_M_LIMIT)
  {
    buf[G729EV_G729_M - 1] = G729EV_G729_M_LIMIT;
    printf("lsp_stability warning High \n");
  }
  return;
}
