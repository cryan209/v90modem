/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.6                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* Computation of Comfort Noise excitation             */

#include <math.h>


#include "G729EV_G729_defines.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729B_defines.h"
#include "G729EV_G729_tab_ld8k.h"

/* Local functions */
static REAL gauss(INT16 * seed);

/*-----------------------------------------------------------*
* procedure G729EV_calc_exc_rand                             *
*           ~~~~~~~~~~~~~                                   *
*   Computes comfort noise excitation                       *
*   for SID and not-transmitted frames                      *
*-----------------------------------------------------------*/
void G729EV_calc_exc_rand(
    REAL cur_gain,       /* (i)   :   target sample gain                 */
    REAL * exc,          /* (i/o) :   excitation array                   */
    INT16 * seed,        /* (i)   :   current Vad decision               */
    int flag_cod,        /* (i)   :   encoder/decoder flag               */
	REAL *exc_err,
	INT16 pastVad,
	INT16 *old_pitch,
	REAL *old_gp,
	REAL *pre_gain,
	INT16 *i_subfr_cnt,
	REAL *lp_gainp,
	REAL *lp_gainc,
	REAL *tilt_code
    )
{
  REAL      excg[G729EV_G729_L_SUBFR];
  int       pos[4];
  REAL      sign[4];
  REAL     *cur_exc;
  REAL      gp, ener, g;
  REAL  Gp, fact, inter_exc, k, delta, x1, x2;
  int       i, i_subfr, t0, frac;
  INT16     temp1, temp2;

/* if not the 1st 10ms frame in first SID */
if(pastVad == 0)
{
    if(cur_gain == (REAL)0.) {
        for(i=0; i<G729EV_G729_L_FRAME; i++) {
            exc[i] = (REAL)0.;
        }
        if(flag_cod == FLAG_COD)
        {
            gp = (REAL)0.;
            t0 = G729EV_G729_L_SUBFR+1;
        
	    	for (i_subfr = 0;  i_subfr < G729EV_G729_L_FRAME; i_subfr += G729EV_G729_L_SUBFR) {
                G729EV_G729_update_exc_err(gp, t0, exc_err);
            }
        }
    return;
  }
}


  /* Loop on subframes */

  cur_exc = exc;

  for (i_subfr = 0; i_subfr < G729EV_G729_L_FRAME; i_subfr += G729EV_G729_L_SUBFR)
  {
    /* generate random adaptive codebook & fixed codebook parameters */
        /*****************************************************************/
    temp1 = G729EV_G729_Random(seed);
    frac = (int) (temp1 & (INT16) 0x0003) - 1;
    if (frac == 2)
      frac = 0;
    temp1 >>= 2;
  t0 = (int) (temp1 & (INT16) 0x000F) + ((*old_pitch) & (INT16) 0x0030);
  t0=(t0 < G729EV_G729_PIT_MIN) ? G729EV_G729_PIT_MIN : ((t0 > G729EV_G729_PIT_MAX) ? G729EV_G729_PIT_MAX : t0);
  *old_pitch = t0;
    temp1 >>= 6;
    temp2 = (INT16) (temp1 & (INT16) 0x0007);
    pos[0] = 5 * (int) temp2;
    temp1 >>= 3;
    temp2 = (INT16) (temp1 & (INT16) 0x0001);
    sign[0] = (REAL) 2. *(REAL) temp2 - (REAL) 1.;

    temp1 >>= 1;
    temp2 = (INT16) (temp1 & (INT16) 0x0007);
    pos[1] = 5 * (int) temp2 + 1;
    temp1 >>= 3;
    temp2 = (INT16) (temp1 & (INT16) 0x0001);
    sign[1] = (REAL) 2. *(REAL) temp2 - (REAL) 1.;

    temp1 = G729EV_G729_Random(seed);
    temp2 = (INT16) (temp1 & (INT16) 0x0007);
    pos[2] = 5 * (int) temp2 + 2;
    temp1 >>= 3;
    temp2 = (INT16) (temp1 & (INT16) 0x0001);
    sign[2] = (REAL) 2. *(REAL) temp2 - (REAL) 1.;

    temp1 >>= 1;
    temp2 = (INT16) (temp1 & (INT16) 0x000F);
    pos[3] = (int) (temp2 & (INT16) 0x0001) + 3;  /* j+3 */
    temp2 >>= 1;
    temp2 &= (INT16) 0x0007;
    pos[3] += 5 * (int) temp2;
    temp1 >>= 4;
    temp2 = (INT16) (temp1 & (INT16) 0x0001);
    sign[3] = (REAL) 2. *(REAL) temp2 - (REAL) 1.;

    Gp = (INT16) (G729EV_G729_Random(seed) & (INT16) 0x1FFF); /* < 0.5  */
    gp = (REAL) Gp / (REAL) 16384.;
  gp = 0.5 * gp + 0.5 * (*old_gp);
  *old_gp = gp;
    /* Generate gaussian excitation */
        /********************************/
    ener = (REAL) 0.;
    for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      excg[i] = gauss(seed);
      ener += excg[i] * excg[i];
    }

    /*  Compute fact = alpha x cur_gain * sqrt(L_SUBFR / ener) */
    /*  with alpha = 0.5, and multiply excg[] by fact          */
    fact = NORM_GAUSS * cur_gain;
    fact /= (REAL) sqrt(ener);
    for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      excg[i] *= fact;
    }

    /* generate random  adaptive excitation */
        /****************************************/
    G729EV_G729_Pred_lt_3(cur_exc, t0, frac, G729EV_G729_L_SUBFR);

    /* compute adaptive + gaussian exc -> cur_exc */
        /**********************************************/
    ener = (REAL) 0.;
    for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      cur_exc[i] *= gp;
      cur_exc[i] += excg[i];
      ener += cur_exc[i] * cur_exc[i];
    }


    /* Compute fixed code gain */
        /***************************/

        /**********************************************************/
        /*** Solve EQ(X) = 4 X**2 + 2 b X + c                     */
        /**********************************************************/

    /* Compute b = inter_exc */
    inter_exc = (REAL) 0.;
    for (i = 0; i < 4; i++)
    {
      inter_exc += cur_exc[pos[i]] * sign[i];
    }

    /* Compute k = cur_gain x cur_gain x L_SUBFR */
    k = cur_gain * cur_gain * (REAL) G729EV_G729_L_SUBFR;

    /* Compute delta = b^2 - 4 c    */
    /* with c = ener - k            */
    delta = inter_exc * inter_exc - (REAL) 4. *(ener - k);

    if (delta < (REAL) 0.)
    {

      /* adaptive excitation = 0 */
      G729EV_G729_Copy(excg, cur_exc, G729EV_G729_L_SUBFR);
      inter_exc = (REAL) 0.;
      for (i = 0; i < 4; i++)
      {
        inter_exc += cur_exc[pos[i]] * sign[i];
      }
      /* Compute delta = b^2 - 4 c      */
      /* with c = - k x (1- alpha^2)    */
      delta = inter_exc * inter_exc + K0 * k;
      gp = (REAL) 0.;
    }

    delta = (REAL) sqrt(delta);
    x1 = (delta - inter_exc) * (REAL) 0.25;
    x2 = -(delta + inter_exc) * (REAL) 0.25;
    g = ((REAL) fabs(x1) < (REAL) fabs(x2)) ? x1 : x2;
    if (g >= (REAL) 0.)
    {
      if (g > G_MAX)
        g = G_MAX;
    }
    else
    {
      if (g < (-G_MAX))
        g = -G_MAX;
    }
    /* Update cur_exc with ACELP excitation */
    for (i = 0; i < 4; i++)
    {
      cur_exc[pos[i]] += g * sign[i];
    }
	if( (flag_cod == FLAG_COD && pastVad != 0) ||
	    (flag_cod == FLAG_DEC && pastVad == 1) )
	{
		ener = (REAL)0.;
		for(i=0; i<G729EV_G729_L_SUBFR; i++) 
		{
			ener += cur_exc[i] * cur_exc[i];
		}
		ener = ener*0.025;
		*pre_gain = (REAL)sqrt(ener);
	}
		if(flag_cod == FLAG_COD)
        {
		    G729EV_G729_update_exc_err(gp, t0, exc_err);
		}
		else
		{
			if( *i_subfr_cnt == 0 )
            {
                *lp_gainp = 0.1f * gp;
                *lp_gainc = 0.1f * g;
            }
            else if( *i_subfr_cnt == 1 )
            {
                *lp_gainp += 0.2f * gp;
                *lp_gainc += 0.2f * g;
            }
            else if( *i_subfr_cnt == 2)
            {
                *lp_gainp += 0.3f * gp;
                *lp_gainc += 0.3f * g;
            }
            else
            {
                *lp_gainp += 0.4f * gp;
                *lp_gainc += 0.4f * g;
            }
            
            *tilt_code = (REAL)0.025f;
			*i_subfr_cnt = (*i_subfr_cnt) + 1;
		}
    cur_exc += G729EV_G729_L_SUBFR;
  }                             /* end of loop on subframes */

  return;
}

/*-----------------------------------------------------------*
*         Local procedures                                  *
*         ~~~~~~~~~~~~~~~~                                  *
*-----------------------------------------------------------*/

/* Gaussian generation */
/***********************/
static REAL gauss(INT16 * seed)
{

    /****  Xi = uniform v.a. in [-32768, 32767]       ****/
    /****  Z = SUM(i=1->12) Xi / 2 x 32768 is N(0,1)  ****/
    /****  output : Z                                 ****/

  int       i;
  INT16     temp;
  INT32     L_acc, L_temp;

  L_acc = 0L;
  for (i = 0; i < 12; i++)
  {
    L_temp = (INT32) G729EV_G729_Random(seed);
    L_acc += L_temp;
  }
  L_acc >>= 7;
  temp = (INT16) L_acc;         /* Z x 512 */
  return ((REAL) temp * (REAL) 0.001953125);  /* Z */
}
