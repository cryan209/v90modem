/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __G729EV_TDAC_BITALLOC_H__
#define __G729EV_TDAC_BITALLOC_H__

#include <stdio.h>
#include "CodecTypedef.h"


/*********************************************************************/
/* words for bitstream packing*/
/*********************************************************************/

/* Functions : */
void      G729EV_TDAC_sort_ip(REAL * ip, int nb_ssb, int *pos);
void      G729EV_TDAC_calc_nbit_total(int nb_sb, const INT16 * nb_coef, REAL * ip, REAL lam, int *nbit_total,
                                      int *bit_alloc);
void      G729EV_TDAC_allocbit(int *bit_alloc, int nbit_max, REAL * ip, int nb_sb, const INT16 * nb_coef, int *ord_b);

/* Tables : */
extern const INT16 G729EV_TDAC_nb_coef[G729EV_TDAC_NB_SB];


#endif  /*__G729EV_TDAC_ECALLOC_H__ */
