/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <stdlib.h>
#include <math.h>
#include <memory.h>

#include "G729EV_G729_defines.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_encod.h"
#include "G729EV_TDAC_util.h"
#include "G729EV_TDAC_mdct.h"
#include "G729EV_TDAC_vq.h"
#include "G729EV_TDAC_tfr.h"
#include "G729EV_TDAC_spectenv.h"
#include "G729EV_TDAC_encod.h"
#include "G729EV_TDAC_bitalloc.h"


/****************************************************************/
/* G729EV_TDAC_encoder                                          */
/*--------------------------------------------------------------*/
/*                                                              */
/****************************************************************/

void G729EV_TDAC_encoder(REAL * y_lo, REAL * y_hi, INT16 * bitstream, int nbit, int nbit_max, int norm_MDCT)
{
  REAL      y[G729EV_MAIN_L_FRAME];
  int       i, j;
  INT16    *pBit, *pBit2;

  int       bit_cnt;
  INT16     vqbits[G729EV_TDAC_MAX_VQBITS];
  int       ord_b[G729EV_TDAC_NB_SB];
  int       coef_ind;
  int       startbit[G729EV_TDAC_NB_SB];
  int       soi;

  REAL      log_rms[G729EV_TDAC_NB_SB]; /* log2 of the spectrum envelope */
  int       bit_alloc[G729EV_TDAC_NB_SB]; /* number of bits allocated to each subband */
  int       rms_index[G729EV_TDAC_NB_SB];
  REAL      ip[G729EV_TDAC_NB_SB];

  if (nbit > 0)
  {
    pBit = bitstream;

    /* form full-band spectrum */
    for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
    {
      y[i] = y_lo[i];
      y[i + G729EV_MAIN_L_FRAME2] = y_hi[i];
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* - compute and encode of spectral envelope (subband rms) */
    /* ---------------------------------------------------------------------------------------------- */

    /* compute spectral envelope */
    G729EV_TDAC_calc_specEnv(y, log_rms, G729EV_TDAC_NB_SB);

    /* encode spectral envelope */
    bit_cnt = 0;

    G729EV_TDAC_cod_spenv(log_rms, rms_index, &pBit, &bit_cnt, nbit, norm_MDCT);

    /* ---------------------------------------------------------------------------------------------- */
    /* - compute number of bits available for VQ */
    /* - allocate bits to subbands */
    /* - order subbands by decreasing perceptual importance */
    /* ---------------------------------------------------------------------------------------------- */

    /* compute the number of available bits */
    nbit_max -= bit_cnt;
    nbit -= bit_cnt;            /* number of bits left (at this stage) */

    /* compute perceptual importance:
       for 3dB step in spectral envelope coding
       1/2log2(enerq) = 1/2 ( rms_index + log2 nb_coef) */
    for (j = 0; j < G729EV_TDAC_NB_SB; j++)
      ip[j] = (REAL) rms_index[j];  /* integer */
    ip[G729EV_TDAC_NB_SB - 1] += 1.0; /* ++ */
    for (j = 0; j < G729EV_TDAC_NB_SB; j++)
      ip[j] /= 2.0;             /* >>1 */

    /* order subbands by decreasing perceptual importance  */
    G729EV_TDAC_sort_ip(ip, G729EV_TDAC_NB_SB, ord_b);

    /* allocate bits to subbands */
    G729EV_TDAC_allocbit(bit_alloc, nbit_max, ip, G729EV_TDAC_NB_SB, G729EV_TDAC_nb_coef, ord_b);


    /* force zero bit to match bit budget (loop by decreasing perceptual importance) */
    bit_cnt = 0;
    for (j = 0; j < G729EV_TDAC_NB_SB; j++)
    {
      coef_ind = ord_b[j];
      if (((bit_cnt + bit_alloc[coef_ind]) <= nbit))
      {
        bit_cnt += bit_alloc[coef_ind];
      }
      else
      {
        /* bit budget is zero, set allocation to 0 bits for the other bands  */
        for (i = j; i < G729EV_TDAC_NB_SB; i++)
        {
          coef_ind = ord_b[i];
          bit_alloc[coef_ind] = 0;
        }
      }
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* - quantize MDCT coefficients */
    /* ---------------------------------------------------------------------------------------------- */

    /* apply split spherical vector quantization to MDCT coefficients */
    pBit2 = vqbits;
    G729EV_TDAC_quantif(y, &pBit2, bit_alloc, G729EV_TDAC_NB_SB);

    /* write VQ bits to bitstream */
    soi = 0;
    for (j = 0; j < G729EV_TDAC_NB_SB; j++)
    {
      startbit[j] = soi;
      soi += bit_alloc[j];
    }
    for (j = 0; j < G729EV_TDAC_NB_SB; j++)
    {
      coef_ind = ord_b[j];
      soi = startbit[coef_ind];
      for (i = 0; i < bit_alloc[coef_ind]; i++)
        *pBit++ = vqbits[soi++];
    }
    for (i = bit_cnt; i < nbit; i++)
    {
      *pBit++ = ITU_G192_BIT_0;
    }
  }                             /* if (nbit > 0) */

  return;

}
