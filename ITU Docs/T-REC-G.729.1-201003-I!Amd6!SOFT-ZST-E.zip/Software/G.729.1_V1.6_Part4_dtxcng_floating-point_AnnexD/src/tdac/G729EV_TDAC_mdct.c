/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <stdlib.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_tfr.h"
#include "G729EV_TDAC_mdct.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_mdct()                                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~                                              *
 *  Compute MDCT                                                            *
 * The MDCT is computed using the fast algorithm described in               *
 * - "A fast algorithm for the implementation of Filter Banks based on Time *
 * Domain Aliasing Cancellation", P. Duhamel et al., ICASSP91, pp 2209-2212 *
 * Petit, Conference ICASSP 1991, pp 2209 - 2212,                           *
 *                                                                          *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_mdct(REAL * mem,   /* (i)     old input samples */
                      REAL * input, /* (i)     input samples */
                      REAL * ykr    /* (o)     MDCT coefficients */
    )
{
  REAL      temp0, temp1;
  REAL      xin[G729EV_TDAC_L_WIN];

  REAL      ycr[G729EV_TDAC_L_WIN2], yci[G729EV_TDAC_L_WIN2];

  const REAL *ptr_h1, *ptr_h2;  /* pointers on window */

  REAL     *ptr_x1, *ptr_x2;    /* pointers on input samples */
  REAL     *ptr_ycr;            /* pointer on ycr */
  REAL     *ptr_yci;            /* pointer on yci */

  int       i, k;
  int       sign;               /* sign for FFT/IFFT */


  for (i = 0; i < G729EV_TDAC_L_WIN2; i++)
    xin[i] = mem[i];
  for (i = 0; i < G729EV_TDAC_L_WIN2; i++)
    xin[i + G729EV_TDAC_L_WIN2] = input[i];

  /*   MDCT computation */
  /*  1) computing Xc[n) (complex terms)   */
  ptr_h1 = G729EV_TDAC_h + G729EV_TDAC_L_WIN2;  /* Middle of the window */
  ptr_x1 = xin + G729EV_TDAC_L_WIN2;

  ptr_h2 = G729EV_TDAC_h + G729EV_TDAC_L_WIN; /* End of the window */
  ptr_x2 = xin + G729EV_TDAC_L_WIN;
  k = 0;
  ptr_yci = yci;
  ptr_ycr = ycr;
  for (i = 0; i < G729EV_TDAC_L_WIN4; i++)
  {
    /*  real */
    ycr[i] = G729EV_TDAC_h[k] * xin[k] - ptr_h1[-k - 1] * ptr_x1[-k - 1];
    yci[i] = ptr_h2[-k - 1] * ptr_x2[-k - 1] + ptr_h1[k] * ptr_x1[k];
    k += 2;
  }

  /*  2) Product of Xc(n) by  W**i    */
  ptr_yci = yci;
  ptr_ycr = ycr;

  for (k = 0; k < G729EV_TDAC_L_WIN4; k++)
  {
    temp1 = *ptr_ycr;


    temp0 = temp1 * G729EV_TDAC_wcos[k];
    temp0 -= yci[k] * G729EV_TDAC_wsin[k];
    *ptr_ycr++ = temp0;


    temp0 = temp1 * G729EV_TDAC_wsin[k];
    temp0 += yci[k] * G729EV_TDAC_wcos[k];
    *ptr_yci++ = temp0;
  }

  /*  3) inverse  TFD */
  sign = -1;
  G729EV_TDAC_tfr(ycr, yci, sign);

  /*  4) final product and rearranging the results  */
  ptr_x1 = ykr;
  ptr_x2 = ykr + G729EV_TDAC_L_WIN2 - 1;
  for (k = 0; k < G729EV_TDAC_L_WIN4; k++)
  {
    temp1 = ycr[k];
    /* symmetry of the coeff k-1 and N-k */
    temp0 = yci[k] * G729EV_TDAC_weti[k];
    temp0 -= temp1 * G729EV_TDAC_wetr[k];
    *ptr_x2-- = temp0;
    ptr_x2--;

    temp0 = temp1 * G729EV_TDAC_weti[k];
    temp0 += yci[k] * G729EV_TDAC_wetr[k];
    *ptr_x1++ = temp0;
    ptr_x1++;

  }

  for (i = 0; i < G729EV_TDAC_L_WIN2; i++)
    mem[i] = input[i];

  return;
}                               /* END MDCT */

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_inv_mdct()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Compute inverse MDCT and overlap-add                                    *
 * The underlying algorithm is described in                                 *
 * - "A fast algorithm for the implementation of Filter Banks based on Time *
 * Domain Aliasing Cancellation", P. Duhamel et al., ICASSP91, pp 2209-2212 *
 * Petit, Conference ICASSP 1991, pp 2209 - 2212,                           *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_inv_mdct(REAL * xr,    /* (o)     output samples */
                          REAL * ykq,   /* (i)     MDCT coefficients */
                          REAL * ycim1  /* (i)     previous MDCT memory */
    )
{

  REAL      temp, temp1;
  REAL      ycr[G729EV_TDAC_L_WIN4], yci[G729EV_TDAC_L_WIN4];
  REAL      sig_cur[G729EV_TDAC_L_WIN2], sig_next[G729EV_TDAC_L_WIN2];
  REAL     *ptr_yci;
  REAL     *ptr_ycr;
  REAL     *ptr1;
  REAL     *ptr2;
  REAL     *ptr1_next;
  REAL     *ptr2_next;
  const REAL *ptr_h;            /* Pointer on window */

  int       k;
  int       sign;               /* sign for FFT / IFFT */

 /*******************************************************************************/
  /* Inverse MDCT computation                                                    */
 /*******************************************************************************/

  /* 1 --> Input rotation = Product by wetrm1 */

  ptr1 = ykq;
  ptr2 = ykq + (G729EV_TDAC_L_WIN2 - 1);
  ptr_yci = yci;
  ptr_ycr = ycr;

  for (k = 0; k < G729EV_TDAC_L_WIN4; k++)
  {
    temp = -(*ptr2 * G729EV_TDAC_wetrm1[k]);
    temp -= *ptr1 * G729EV_TDAC_wetim1[k];
    *ptr_ycr++ = temp;

    temp = *ptr1++ * G729EV_TDAC_wetrm1[k];
    temp -= *ptr2-- * G729EV_TDAC_wetim1[k];
    *ptr_yci++ = temp;

    ptr1++;
    ptr2--;
  }

  /* 2 --> Forward FFT : size = 160 */

  sign = 1;
  G729EV_TDAC_tfr(ycr, yci, sign);

  /*  3) Output rotation = product by a complex exponent */
  ptr_yci = yci;
  ptr_ycr = ycr;

  for (k = 0; k < G729EV_TDAC_L_WIN4; k++)
  {
    temp1 = *ptr_ycr;
    temp = temp1 * G729EV_TDAC_wcos[k];
    temp += yci[k] * G729EV_TDAC_wsin[k];
    *ptr_ycr++ = temp;

    temp = yci[k] * G729EV_TDAC_wcos[k];
    temp -= temp1 * G729EV_TDAC_wsin[k];
    *ptr_yci++ = temp;

  }

  /* 4 --> Overlap and windowing (in one step) - equivalent to complex product */
  ptr1 = sig_cur;
  ptr2 = sig_cur + G729EV_TDAC_L_WIN2 - 1;
  ptr1_next = sig_next;
  ptr2_next = sig_next + G729EV_TDAC_L_WIN2 - 1;
  for (k = 0; k < G729EV_TDAC_L_WIN4; k++)
  {
    *ptr1++ = ycr[k];
    *ptr2-- = -ycr[k];
    *ptr1_next++ = yci[k];
    *ptr2_next-- = yci[k];
    ptr1++;
    ptr1_next++;
    ptr2--;
    ptr2_next--;

  }

  ptr_h = G729EV_TDAC_h + G729EV_TDAC_L_WIN2;

  for (k = 0; k < G729EV_TDAC_L_WIN2; k++)
  {
    temp = sig_cur[k] * G729EV_TDAC_h[k];
    temp += ycim1[k] * *(--ptr_h);
    xr[k] = temp;
    ycim1[k] = sig_next[k];
  }

  return;
}

int G729EV_TDAC_mdct_norm(REAL * mem, REAL * input)
{
  REAL      xin[G729EV_TDAC_L_WIN];
  REAL      ycr[G729EV_TDAC_L_WIN2], yci[G729EV_TDAC_L_WIN2];
  const REAL *ptr_h1, *ptr_h2;  /* pointers on window */
  REAL     *ptr_x1, *ptr_x2;    /* pointers on input samples */
  REAL     *ptr_ycr;            /* pointer on ycr */
  REAL     *ptr_yci;            /* pointer on yci */

  REAL      temp1, temp2, temp3, temp;
  int       i, k;
  int       norm;
  int       norm_shift;

  for (i = 0; i < G729EV_TDAC_L_WIN2; i++)
    xin[i] = mem[i];
  for (i = 0; i < G729EV_TDAC_L_WIN2; i++)
    xin[i + G729EV_TDAC_L_WIN2] = input[i];

  /*  1) computing Xc[n) (complex terms)   */
  /*   MDCT computation */
  /*  1) computing Xc[n) (complex terms)   */
  ptr_h1 = G729EV_TDAC_h + G729EV_TDAC_L_WIN2;  /* Middle of the window */
  ptr_x1 = xin + G729EV_TDAC_L_WIN2;

  ptr_h2 = G729EV_TDAC_h + G729EV_TDAC_L_WIN; /* End of the window */
  ptr_x2 = xin + G729EV_TDAC_L_WIN;
  k = 0;
  ptr_yci = yci;
  ptr_ycr = ycr;
  for (i = 0; i < G729EV_TDAC_L_WIN4; i++)
  {
    /*  real */
    ycr[i] = (G729EV_TDAC_h[k] * xin[k] - ptr_h1[-k - 1] * ptr_x1[-k - 1]) / 2;
    yci[i] = (ptr_h2[-k - 1] * ptr_x2[-k - 1] + ptr_h1[k] * ptr_x1[k]) / 2;
    k += 2;
  }

  temp1 = (REAL) 0;
  for (i = 0; i < G729EV_TDAC_L_WIN4; i++)
  {
    temp2 = (REAL) fabs(ycr[i]);  /* real part */
    temp3 = (REAL) fabs(yci[i]);  /* imaginary part */
    temp = temp3 - temp2;       /* keep bigger value between R and I */
    if (temp > 0)               /* temp2 is the bigger value (imag[i] vs. real[i]) */
    {
      temp2 = temp3;
    }

    if (temp1 < temp2)          /* temp1 is the max value */
      temp1 = temp2;
  }

  if ((temp1 - 14000) >= 0)
  {
    norm_shift = 0;
  }
  else
  {
    temp1 = ((int) (temp1 + 0.5) * 9587) / (REAL) pow(2, 19);
    norm = (int) temp1;
    i = 0;
    if (norm > 0)
    {
      while (norm <= 32767)
      {
        i++;
        norm = norm * 2;
      }
      i--;
    }

    if (i == 0)
      norm_shift = 8;
    else
      norm_shift = i - 6;
  }
  return norm_shift;
}
