/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/



#include <stdlib.h>
#include <math.h>
#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_lib_vq.h"
#include "G729EV_TDAC_util.h"


/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_VQ_quant()                                        *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
*  Encode TDAC subband by spherical vector quantization                    *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_VQ_quant(REAL * x,     /* (i)     subband coefficients */
                          int dim,      /* (i)     subband dimension */
                          int nbit,     /* (i)     number of bits for spherical vector quantization */
                          UINT32 * cod  /* (o)     vector quantization index */
    )
{
  int       tab_pos[G729EV_TDAC_N_NBC], tab_sgn[G729EV_TDAC_N_NBC];
  REAL      xn[G729EV_TDAC_N_NBC];
  int       nb_lead;
  int       ivq;
  int       idic;

  /* identify codebook in dimension 'dim' with 'nbit' bits */
  G729EV_TDAC_SrchDic(dim, nbit, &idic);

  /* compute absolute vector 'xn' as well as permutation ('tab_pos') and signs of components ('tab_sgn') */
  G729EV_TDAC_SrchLead(x, dim, tab_pos, tab_sgn, xn);

  /* get the number of absolute leaders in the codebook 'idic' */
  nb_lead = (int) G729EV_TDAC_getNbLead(dim, idic);

  /* find the best match (dot product maximization due to spherical VQ) */
  G729EV_TDAC_VQLead(xn, dim, &ivq, nb_lead);

  /* compute the index of reconstructed vector as 'cod' = cardinality offset + rank of signed permutation */
  *cod = G729EV_TDAC_schalk(dim, ivq, tab_pos, tab_sgn);

  return;
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_schalk()                                          *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
*  Compute permutation rank by Schalkwijk's formula                        *
*--------------------------------------------------------------------------*/
UINT32 G729EV_TDAC_schalk(int n,        /* (i)     dimension */
                          int ind_lead, /* (i)     index of leader */
                          int *tab_pos, /* (i)     permutation table */
                          int *tab_sgn  /* (i)     sign table */
    )
{

  UINT32    code, offset_lead;  /*, code0 */
  UINT32    UL_rank;

  INT32     L_rank, L_prod;

  INT16     exp[G729EV_TDAC_MAX_NB_PRM_FACT], prod_fact[G729EV_TDAC_MAX_NB_PRM_FACT];
  INT16     tab_values_online[G729EV_TDAC_N_NBC];
  INT16     tab_nb_values_online[G729EV_TDAC_N_NBC];

  INT16    *ptr_nb_val, *ptr_val;

  INT16     nb_sgn, sum_w;
  INT16     nb_val;

  const INT16 *ptr, *ptr_fact;

  int       w[G729EV_TDAC_N_NBC + 1], D[G729EV_TDAC_N_NBC + 1];
  int       k, i, d, j, imin, pos, delta, nb_prm_fact, d0;
  int       tmp;
  int      *ptr_pos;
  int       index;

  REAL      temp;

  ptr_val = tab_values_online;
  ptr_nb_val = tab_nb_values_online;


  /* get pointers to alphabet (values) and weight of sequence, size of alphabet, */
  /* cardinality offset, dimension of leader */
  nb_val = G729EV_TDAC_getInfoLead(n, ind_lead, &ptr_nb_val, &ptr_val, &offset_lead, &nb_sgn, &temp);

  /* translate sequence into the alphabet 0, 1, 2, nb_val-1 */
  /* the letter 0 is added in the alphabet when n > dimension of leader = nb_sgn */
  ptr_pos = tab_pos;
  for (d = 0; d < nb_val; d++)
  {
    w[d] = ptr_nb_val[d];

    /* sort positions in increasing order for the current letter of the alphabet  */
    /* (for sign encoding) */
    for (i = 0; i < w[d]; i++)
    {
      pos = ptr_pos[i];
      imin = i;
      for (j = i + 1; j < w[d]; j++)
      {
        tmp = ptr_pos[j] - pos; /*(to access ptr_pos[j]) */
        if (tmp < 0)
        {
          pos = ptr_pos[j];
          imin = j;
        }
      }
      ptr_pos[imin] = ptr_pos[i];
      ptr_pos[i] = pos;

      D[pos] = d;               /* D */
    }
    ptr_pos += w[d];            /* pointer incrementation */
  }

  i = n - nb_sgn;

  if (i > 0)
  {
    for (k = nb_sgn; k < n; k++)
    {
      pos = tab_pos[k];
      D[pos] = nb_val;          /* D */
    }
    nb_val = nb_val + 1;
  }

  /* ---------- compute rank using Schalkwijk's formula */

  /* get the number of prime factors */

  nb_prm_fact = G729EV_TDAC_tab_nb_prm_fact[n];

  /* initialize */

  L_rank = 0;

  for (d = 0; d < nb_val; d++)
  {
    w[d] = 0;
  }

  for (i = 0; i < nb_prm_fact; i++)
  {
    prod_fact[i] = 0;
  }

  /* treat k=n-1 apart : sum_w = 0 if d=0, and if d>0 w[0]+...+w[d-1]=0 since only w[d]=1 */

  k = n - 1;
  d0 = D[k];
  w[d0] = 1;

  /* treat k=n-2 apart */

  k = n - 2;
  d = D[k];
  w[d] = w[d] + 1;
  tmp = d - d0;

  if (tmp == 0)
  {
    prod_fact[0] = 1;           /* prod_fact = 2^1; */
  }
  else
  {
    if (tmp > 0)
    {
      L_rank = 1;
    }
  }

  /* treat other cases: k=n-3...0 */
  for (i = nb_prm_fact; i < G729EV_TDAC_MAX_NB_PRM_FACT; i++)
  {
    exp[i] = 0;
  }

  for (k = n - 3; k >= 0; k--)
  {
    d = D[k];
    w[d] = w[d] + 1;

    /* prod_fact = prod_fact * w[d] */
    i = w[d];
    delta = G729EV_TDAC_delta_decomp_val[i];
    ptr = G729EV_TDAC_tab_decomp_val + delta; /* pointer incrementation */

    for (i = 0; i < nb_prm_fact; i++)
    {
      prod_fact[i] = prod_fact[i] + *ptr++;
    }

    /* compute sum */
    sum_w = 0;
    for (i = 0; i < d; i++)
    {
      sum_w = sum_w + w[i];
    }

    /* update rank */
    if (sum_w > 0)
    {

      /* compute the prime factor decomposition of fact*sum_w/prod_fact */
      index = n - k;
      index = index - 1;
      delta = G729EV_TDAC_delta_decomp_val[index];
      ptr_fact = G729EV_TDAC_tab_decomp_fact + delta; /* pointer incrementation */
      delta = G729EV_TDAC_delta_decomp_val[sum_w];
      ptr = G729EV_TDAC_tab_decomp_val + delta; /* pointer incrementation */

      for (i = 0; i < nb_prm_fact; i++)
      {
        tmp = *ptr++ + *ptr_fact++;
        exp[i] = tmp - prod_fact[i];
      }

      /* compute the product of powers */
      L_prod = G729EV_TDAC_prod_prm_fact(exp);

      /* accumulate intermediate term */
      L_rank = L_rank + L_prod;
    }
  }

  /* >>>>> switch to unsigned arithmetic */

  /* ------- sign encoding */
  UL_rank = L_rank;             /* no count (unsigned arithmetic switching - variable renamed for the sake of clarity) */
  for (i = 0; i < nb_sgn; i++)
  {
    UL_rank = UL_rank << 1;
    pos = tab_pos[i];
    if (tab_sgn[pos] < 0)
    {
      UL_rank = UL_rank + 1;
    }
  }

  /* -------- compute index in the codebook */
  code = offset_lead + UL_rank;

  return (code);
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_SrchDic()                                         *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
*  Select codebook for a given dimension and bit allocation                *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_SrchDic(int dim,     /* (i)     dimension */
                         int nbit,    /* (i)     bit allocation */
                         int *IdicSel /* (o)     index of selected codebook */
    )
{
  const INT16 *ptr;
  int       i, nb;

  ptr = G729EV_MAIN_adRate[dim];
  nb = (int) G729EV_MAIN_NbDic[dim];
  *IdicSel = 0;
  for (i = 1; i < nb; i++)
  {
    if (ptr[i] == nbit)
      *IdicSel = i;
  }
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_SrchLead()                                        *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
*  Compute absolute vector                                                 *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_SrchLead(REAL * x,     /* (i)     subband coefficients */
                          int dim,      /* (i)     dimension */
                          int *tab_pos, /* (o)     permutation table */
                          int *tab_sgn, /* (o)     sign table */
                          REAL * xn     /* (o)     absolute vector */
    )
{
  int       i, j, k;
  int       imax;
  REAL      max_value;

  /* compute absolute vector xn and initialize permutation table */
  for (j = 0; j < dim; j++)
  {
    tab_pos[j] = j;

    if (x[j] < 0.)
    {
      tab_sgn[j] = -1;
      xn[j] = -x[j];
    }
    else
    {
      tab_sgn[j] = 1;
      xn[j] = x[j];
    }
  }

  /* compute absolute leader: ordering of xn in decreasing values */
  for (k = 0; k < dim; k++)
  {
    max_value = xn[k];
    imax = k;
    for (i = k + 1; i < dim; i++)
      if (xn[i] > max_value)
      {
        max_value = xn[i];
        imax = i;
      }

    xn[imax] = xn[k];
    xn[k] = max_value;
    i = tab_pos[k];
    tab_pos[k] = tab_pos[imax];
    tab_pos[imax] = i;
  }

  return;
}


/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_getNbLead()                                       *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
*  Get number of leaders in a codebook                                     *
*--------------------------------------------------------------------------*/
INT16 G729EV_TDAC_getNbLead(int dim,  /* (i)     dimension */
                            int idic  /* (i)     index of codebook */
    )
{
  const INT16 *ptr1;

  ptr1 = G729EV_MAIN_adNbLeadpRat[dim];

  return (ptr1[idic]);
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_VQLead()                                          *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
*  Search for best spherical codevector                                    *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_VQLead(REAL * xn,  /* (i)     absolute vector */
                        int dim,    /* (i)     dimension */
                        int *ILead, /* (o)     index of selected leader */
                        int ivq1    /* (i)     number of candidate leaders */
    )
{
  int       i, k;
  REAL      dist_max;
  REAL      inv_norm_l2;
  REAL      ps, *ptr2;
  int       ivq;
  const INT16 *leader, *ptr1;
  int       dim_lead, jlead;
  int       delta;

  /* set initial survivor */
  dist_max = xn[0];
  ivq = 0;

  /* loop over other candidate */
  for (k = 1; k < ivq1; k++)
  {
    jlead = *(G729EV_MAIN_adListLead[dim] + k);
    dim_lead = G729EV_MAIN_dim_leader[jlead];
    inv_norm_l2 = G729EV_MAIN_InvNormL2Lead[jlead];
    delta = G729EV_MAIN_delta_leader[jlead];
    leader = G729EV_MAIN_adLeader[dim_lead] + delta;  /* pointer incrementation */

    /* compute dot product  */
    ptr1 = leader;
    ptr2 = xn;
    ps = (REAL) * ptr1++ * *ptr2++;
    for (i = 1; i < dim_lead; i++)
    {
      ps += (REAL) * ptr1++ * *ptr2++;
    }

    ps *= inv_norm_l2;
    if (ps > dist_max)
    {
      ivq = k;
      dist_max = ps;

    }
  }
  *ILead = ivq;

  return;
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_getInfoLead()                                     *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
*  Get leader information                                                  *
*--------------------------------------------------------------------------*/
INT16 G729EV_TDAC_getInfoLead(int dim,              /* (i)     dimension */
                              int ilead,            /* (i)     index of leader */
                              INT16 ** ptr_nb_val,  /* (o)     pointer to weights */
                              INT16 ** ptr_val,     /* (o)     pointer to alphabet */
                              UINT32 * offset,      /* (o)     cardinality offset */
                              INT16 * nb_sgn,       /* (o)     number of signs */
                              REAL * inv_norm_l2    /* (o)     */
    )
{
  INT16     nb_val;
  INT16    *p_val, *p_nb_val;
  int       dim_leader, jlead, delta;
  const INT16 *leader;
  int       i;

  /* search the dimension of the non zero components */
  jlead = *(G729EV_MAIN_adListLead[dim] + ilead);
  dim_leader = G729EV_MAIN_dim_leader[jlead];

  /* get the information of the leader */
  *inv_norm_l2 = G729EV_MAIN_InvNormL2Lead[jlead];
  *nb_sgn = dim_leader;
  delta = G729EV_MAIN_delta_leader[jlead];
  leader = G729EV_MAIN_adLeader[dim_leader] + delta;  /* pointer incrementation */

  p_val = (INT16 *) * ptr_val;
  p_nb_val = (INT16 *) * ptr_nb_val;

  *p_val = *leader++;
  *p_nb_val = (INT16) 1;
  nb_val = (INT16) 1;

  for (i = 1; i < dim_leader; i++)
  {
    if ((*leader - *p_val) != 0)
    {
      p_val++;
      p_nb_val++;
      nb_val++;;
      *p_val = *leader;
      *p_nb_val = 1;
    }
    else
    {
      *p_nb_val += 1;
    }
    leader++;
  }

  *offset = *(G729EV_MAIN_adOffsetLead[dim] + ilead);
  return (nb_val);
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_prod_prm_fact()                                   *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                     *
*  Compute integer from its prime decomposition                            *
*--------------------------------------------------------------------------*/
INT32 G729EV_TDAC_prod_prm_fact(INT16 * exp /* (i)     exponents to prime factors */
    )
{
  INT32     L_prod;

  INT16     pow3, pow5, pow7, pow11, pow13;

  /* get powers of prime factors 3, 5, 7, 11 and 13 */

  pow3 = G729EV_TDAC_tab_pow3[exp[1]];
  pow5 = G729EV_TDAC_tab_pow5[exp[2]];
  pow7 = G729EV_TDAC_tab_pow7[exp[3]];
  pow11 = G729EV_TDAC_tab_pow11[exp[4]];
  pow13 = G729EV_TDAC_tab_pow13[exp[5]];

  L_prod = (pow3 * pow5 * pow7 * pow11 * pow13) << exp[0];

  return (L_prod);
}



/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_inv_schalk()                                      *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
*  Decode permutation rank computed by Schalkwijk's formula                *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_inv_schalk(UINT32 UL_rank, /* (i)     permutation rank */
                            int n,          /* (i)     dimension */
                            int ind_lead,   /* (i)     index of leader */
                            INT16 * y,      /* (o)     permuted leader */
                            REAL * inv_norm_l2)
{
  UINT32    L_prod;
  UINT32    mem_I, offset_lead;

  INT32     L_rank;

  const INT16 *ptr, *ptr_fact;

  INT16    *ptr_sgn;
  INT16    *ptr_val, *ptr_nb_val;

  INT16     prod_fact[G729EV_TDAC_MAX_NB_PRM_FACT];
  INT16     fact[G729EV_TDAC_MAX_NB_PRM_FACT];
  INT16     exp[G729EV_TDAC_MAX_NB_PRM_FACT];
  INT16     A[G729EV_TDAC_N_NBC + 1];
  INT16     tab_sgn[G729EV_TDAC_N_NBC];
  INT16     offset_sgn[G729EV_TDAC_N_NBC + 1];
  INT16     w[G729EV_TDAC_N_NBC + 1];
  INT16     tab_values_online[G729EV_TDAC_N_NBC];
  INT16     tab_nb_values_online[G729EV_TDAC_N_NBC];
  INT16     nb_val, nb_sgn;

  int       k, i, d, nb_prm_fact;
  int       sum_w;
  int       j;
  int       delta;
  int       tmp;


  ptr_val = tab_values_online;
  ptr_nb_val = tab_nb_values_online;


  /* get pointers to alphabet (values) and weight of sequence and size of alphabet, dimension of leader  */
  nb_val = G729EV_TDAC_getInfoLead(n, ind_lead, &ptr_nb_val, &ptr_val, &offset_lead, &nb_sgn, inv_norm_l2);

  /* initalize weight (w), alphabet (A)  */
  j = 0;

  for (d = 0; d < nb_val; d++)
  {
    w[d] = ptr_nb_val[d];
    A[d] = ptr_val[d];
    j = j + w[d];
    offset_sgn[d] = j;          /* (store for sign decoding) */
  }

  i = n - nb_sgn;               /* if n > dimension of leader, add 0 in the alphabet */

  if (i > 0)
  {
    w[nb_val] = i;
    A[nb_val] = 0;
    j = j + w[nb_val];
    offset_sgn[nb_val] = j;     /* for sign decoding */
    nb_val = nb_val + 1;
  }

  /*sign decoding (the sign positions are in the coordinate system of the absolute leader)  */
  ptr_sgn = tab_sgn + nb_sgn - 1;

  for (i = 0; i < nb_sgn; i++)
  {
    if ((UL_rank & 0x01) == 1)
    {
      *ptr_sgn-- = 1;           /* not -1 because no mult but if/negate */
    }
    else
    {
      *ptr_sgn-- = 0;           /* not 0, because no mult but if/negate */
    }
    UL_rank = UL_rank >> 1;
  }
  for (i = nb_sgn; i < n; i++)
  {
    tab_sgn[i] = 0;
  }

  /*------------- decode the rank of permutation of the absolute leader  */

  /* >>>>>>>>>>>>>>>>> switched to signed arithmetic */
  L_rank = UL_rank;             /* no count (variable is renamed for the sake of clarity) */

  /* get the number of prime factorsf */
  nb_prm_fact = G729EV_TDAC_tab_nb_prm_fact[n];

  for (i = nb_prm_fact; i < G729EV_TDAC_MAX_NB_PRM_FACT; i++)
  {
    exp[i] = 0;
  }


  /*set prod_fact=prod_i (w^i!) for k=0  */
  /* to save complexity, this initialization could be computed in advance except for the zero letter */

  i = w[0];
  delta = G729EV_TDAC_delta_decomp_val[i];
  ptr = G729EV_TDAC_tab_decomp_fact + delta;  /* pointer incrementation */

  for (i = 0; i < nb_prm_fact; i++)
  {
    prod_fact[i] = *ptr++;
  }
  for (d = 1; d < nb_val; d++)
  {
    i = w[d];
    delta = G729EV_TDAC_delta_decomp_val[i];
    ptr = G729EV_TDAC_tab_decomp_fact + delta;  /* pointer incrementation */
    for (i = 0; i < nb_prm_fact; i++)
      prod_fact[i] = prod_fact[i] + *ptr++;
  }

  /* determine the values of d_k, k=1,..,n (with the notations of Lamblin88)  */
  for (k = 0; k < n; k++)
  {
    /* initialize d_k */
    d = 0;
    L_prod = 0;

    /* increment d_k to avoid useless evaluation of the formula */
    while (w[d] == 0)
    {
      d = d + 1;
    }

    if (L_rank > 0)
    {
      /* initialize prime decomposition of factorial */
      delta = G729EV_TDAC_delta_decomp_val[(n - (k + 1))];
      ptr_fact = G729EV_TDAC_tab_decomp_fact + delta; /* pointer incrementation */

      for (i = 0; i < nb_prm_fact; i++)
      {
        fact[i] = *ptr_fact++;
      }

      /* increment d_k until fact*sum_w/prod_fact is superior to rank */
      sum_w = 0;
      do
      {
        mem_I = L_prod;

        /* compute L_prod = fact*sum_w/prod_fact */
        sum_w = sum_w + w[d];
        delta = G729EV_TDAC_delta_decomp_val[sum_w];
        ptr = G729EV_TDAC_tab_decomp_val + delta; /* pointer incrementation */

        for (i = 0; i < nb_prm_fact; i++)
        {
          tmp = fact[i] + *ptr++;
          exp[i] = tmp - prod_fact[i];
        }
        L_prod = G729EV_TDAC_prod_prm_fact(exp);

        d = d + 1;
      }
      while (L_rank >= (INT32) L_prod);

      d = d - 1;

      /* retrieve the last value */
      L_prod = mem_I;
    }

    /* set value y[k] */
    j = offset_sgn[d] - w[d];

    if (tab_sgn[j] > 0)         /* y[k] = A[d] * tab_sgn[d] if tab_sgn = -1 for negative, 0 for positive */
    {
      y[k] = -A[d];
    }
    else
    {
      y[k] = A[d];
    }


    /* update rank */
    L_rank = (INT32) (L_rank - L_prod);

    /* update prod_fact */
    i = w[d];
    if (i > 1)
    {
      delta = G729EV_TDAC_delta_decomp_val[i];
      ptr = G729EV_TDAC_tab_decomp_val + delta; /* pointer incrementation */
      for (i = 0; i < nb_prm_fact; i++)
      {
        prod_fact[i] = prod_fact[i] - *ptr++;
      }
    }

    /* update weight */
    w[d] = w[d] - 1;
  }

}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_SearchPrev()                                   *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                     *
*  Search for codebook in dimension dim with rate < n bits                 *
*--------------------------------------------------------------------------*/
int G729EV_TDAC_SearchPrev(int n,   /* (i)     number of bits */
                           int dim  /* (i)     dimension */
    )
{
  const INT16 *ptr;
  int       i, idic_sup;

  ptr = G729EV_MAIN_adRate[dim];
  idic_sup = (int) G729EV_MAIN_NbDic[dim] - 1;

  for (i = idic_sup; i > 0; i--)
    if (ptr[i] < n)
      return (ptr[i]);

  return (ptr[0]);

}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_SelectCbk()                                   *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                     *
*  Select codebook in dimension dim with closest rate to n bits            *
*--------------------------------------------------------------------------*/
int G729EV_TDAC_SelectCbk(int nbit, /* (i)     number of bits */
                          int dim   /* (i)     dimension */
    )
{

  const INT16 *ptr;
  int       nb, i, dif, difmin, imin;

  ptr = G729EV_MAIN_adRate[dim];
  nb = (int) G729EV_MAIN_NbDic[dim];
  imin = 0;
  difmin = ptr[0] - nbit;
  if (difmin < 0)
    difmin = -difmin;
  for (i = 1; i < nb; i++)
  {
    dif = ptr[i] - nbit;
    if (dif < 0)
      dif = -dif;
    if (dif < difmin)
    {
      difmin = dif;
      imin = i;
    }
  }
  return (ptr[imin]);
}
