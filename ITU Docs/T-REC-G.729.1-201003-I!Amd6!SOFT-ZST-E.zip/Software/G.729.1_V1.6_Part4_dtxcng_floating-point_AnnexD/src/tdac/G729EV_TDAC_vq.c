/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <stdlib.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_bitalloc.h"
#include "G729EV_TDAC_lib_vq.h"
#include "G729EV_TDAC_vq.h"
#include "G729EV_TDAC_util.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_quantif()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Split spherical vector quantization                                     *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_quantif(REAL * ykr,    /* (i)      MDCT coefficients to encode             */
                         INT16 ** bit,  /* (i/o)    pointer on adress of next bit           */
                         int *nb_niv,   /* (i)      number of bits allocated per subbands   */
                         int nb_ssb)    /* (i)      number of subbands                      */
{
  int       j, k, nbit, pos;
  UINT32    cod32;
  const INT16 *ptr1, *ptr0;

  /* quantize - normalized - spectrum (loop over subbands) */
  /* because spherical VQ is used, there is no need for per-band normalization by the spectral enveloppe */
  ptr0 = G729EV_TDAC_sb_bound;
  ptr1 = ptr0 + 1;
  for (j = 0; j < nb_ssb; j++)
  {
    /* get the bit allocation */
    nbit = nb_niv[j];
    /* if the j-th subband has a non-zero bit allocation 'nbit' */
    if (nbit != 0)
    {
      /* compute dimension 'k' of subband */
      k = (*ptr1) - (*ptr0);

      /* get position of first coefficient in the subband */
      pos = *ptr0;

      /* apply spherical VQ */
      G729EV_TDAC_VQ_quant(&ykr[pos], k, nbit, &cod32);

      /* write index in bitstream */
      G729EV_TDAC_pushBitL(cod32, bit, nbit);
    }
    ptr0++;
    ptr1++;
  }

  return;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_dec_VQcoef()                                      *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      *
 *  Codevector definition                                                   *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_dec_VQcoef(UINT32 code,        /* (i)  Index read from bitstream                   */
                            int dim,            /* (i)  Number of MDCT coefficients per subbands    */
                            INT16 * yq,         /* (o)  Codeword                                    */
                            REAL * inv_norm_l2  /* (o) : leader inverse L2_norm */
    )
{
  UINT32    rank;
  const UINT32 *ptr_offset, *ptr;
  int       nb_lead, i, ilead, t;

  /* initialize the pointer to cardinality offset */
  ptr_offset = G729EV_MAIN_adOffsetLead[dim]; /* pointer init */
  ptr = ptr_offset;

  /* find the absolute leader which has a permutation of index 'code' (parse table of cardinality offsets) */
  t = G729EV_MAIN_NbDic[dim] - 1;
  nb_lead = *(G729EV_MAIN_adNbLeadpRat[dim] + t);

  ilead = nb_lead - 1;

  for (i = 0; i < nb_lead; i++)
  {
    if (code < ptr_offset[i])
    {
      ilead = i - 1;
      break;
    }
  }

  if (code >= ptr_offset[ilead + 1])
  {                             /*invalid code for the last band, non valid vq code due to bst error */
    if (dim == 16)
    {
      ilead = 10;               /*leader AAAAAAAAAAAAAAAA */
      rank = 21845;             /*signs +-+-+-+-+-+-+-+- */
    }
    else                        /*if(nbc == 8) */
    {
      ilead = 8;                /*leader AAAAAAAA */
      rank = 85;                /*signs +-+-+-+- */
    }
  }
  else
  {
    /* compute rank of permutation: rank = index - cardinality offset */
    rank = code - ptr_offset[ilead];
  }
  /* decode rank of permutation (as a side product, get also the inverse L2 norm of the leader)     */
  G729EV_TDAC_inv_schalk(rank, dim, ilead, yq, inv_norm_l2);

  return;
}

/*--------------------------------------------------------------------------*
*  Function  G729EV_TDAC_decod_VQ()                                        *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
*  Inverse split spherical vector quantization                             *
*--------------------------------------------------------------------------*/

void G729EV_TDAC_decod_VQ(INT16 ** bit, /* (i/o)    Pointer on address of next bit          */
                          REAL * ykr,   /* (o)      Decoded MDCT coefficients               */
                          int *nb_niv,  /* (i)      number of bits allocated per subbands   */
                          int nb_ssb,   /* (i)      number of subbands                      */
                          REAL * rmsq)  /* (i)      rms                                     */
{
  int       j, k, i, nbit;
  UINT32    cod32;
  INT16     y[G729EV_TDAC_N_NBC];
  REAL      inv_norm_lead, temp;
  REAL     *ptr_ykr;

  const INT16 *ptr1, *ptr0;

  ptr0 = G729EV_TDAC_sb_bound;
  ptr1 = ptr0 + 1;
  ptr_ykr = ykr;
  for (j = 0; j < nb_ssb; j++)
  {
    k = G729EV_TDAC_nb_coef[j];
    /* if the j-th subband is uncoded or if the bit allocation to the j-th subband is zero, reconstruct a zero subband */
    nbit = nb_niv[j];           /* bit allocation */
    if (nbit == 0)
    {
      for (i = 0; i < k; i++)
      {
        *ptr_ykr++ = (REAL) 0.0;
      }
    }
    else
    {

      /* read index (cod32) and decode it into a codevector (y) */
      /* get also the inverse L2 norm of y */
      cod32 = G729EV_TDAC_getBitL(bit, nbit);
      G729EV_TDAC_dec_VQcoef(cod32, k, y, &inv_norm_lead);

      /* shape codevector (y) : ykr = y  *  rmsq * sqrt(j) */
      temp = inv_norm_lead * rmsq[j] * (REAL) sqrt(G729EV_TDAC_nb_coef[j]);
      for (i = 0; i < k; i++)
      {
        *ptr_ykr++ = temp * (REAL) y[i];
      }
    }
  }

  k = G729EV_TDAC_sb_bound[nb_ssb];
  /* fill the last uncoded subband (>7.x kHz) */
  for (i = k; i < G729EV_MAIN_L_FRAME; i++)
  {
    *ptr_ykr++ = (REAL) 0.;
  }
  return;
}
