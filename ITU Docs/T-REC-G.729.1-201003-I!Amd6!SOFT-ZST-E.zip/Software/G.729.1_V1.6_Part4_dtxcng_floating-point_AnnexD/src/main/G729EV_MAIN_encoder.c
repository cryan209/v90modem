/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.6                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_G729_codstat.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_encod.h"


/*--------------------------------------------------------------------------*
 *  Function  display_usage()                                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~                                               *
 *  Display Encoder usage                                                   *
 *--------------------------------------------------------------------------*/

static void display_usage(char *argv)
{
#ifdef MKVAD
  printf("Usage: %s [options] [<vadfile>] <inputfile> <bitstream>\n", argv);
#else
  printf("Usage: %s [options] <inputfile> <bitstream>\n", argv);
#endif
  printf("\n");
  printf("Options:\n");
  printf("  -quiet     do not display frame counter\n");
  printf("  -rXXXXX    run encoder at bit rate XXXXX bit/s (32000 by default)\n");
  printf("  -f8        input sampled at 8 kHz\n");
  printf("  -g729_bst  write G.729 bitstream (maximal bit rate must be set to 8 kbit/s)\n");
#ifdef MKVAD
  printf("  -dtx	   produce SID frames during inactive periods.  The [<vadfile>] has to be specified)\n");
#endif
  printf("  -fXXX	   force SID frame after XXX 10ms frames; 0..never\n");
  printf("\n");
}


/*--------------------------------------------------------------------------*
 *  Function  check_arguments()                                             *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  Check encoder arguments                                                 *
 *--------------------------------------------------------------------------*/

static void check_arguments(
							INT16 *cng_nb,
							INT16 *cng_wb,
							INT16 *g729ev_dtx,
							int argc, char *argv[],
                            int     * sent_rate,     /* (i/o)    rate used by encoder        */
                            int     * dtx_max_fr,    /* (i/o)    max DTX frame used by encoder        */
                            INT16 * frame_size,                     /* (i/o)    frame size used by encoder  */
                            int *i,                                 /* (o)      argv index                  */
                            int *quiet,                             /* (o)      quiet mode flag             */
                            int *f8,                                /* (o)      8kHz sampled input flag     */
                            int *g729_bst)                          /* (o)      G.729 bitstream mode flag   */
{

  *quiet = 0;
  *f8 = 0;
  *g729_bst = 0;
  *g729ev_dtx = 0;
  *cng_nb = *cng_wb = 0; 
#ifdef MKVAD
  if ((argc < 3) || (argc > 9))
  {
#else
  if ((argc < 3) || (argc > 8))
  {
#endif	// MKVAD
    display_usage(argv[0]);
    exit(-1);
  }

  *sent_rate = G729EV_MAX_BITRATE;

  for (*i = 1; (*i < argc) && (strncmp(argv[*i], "-", 1) == 0); (*i)++)
  {
    if (strcmp(argv[*i], "-quiet") == 0)
      *quiet = 1;
    else if (strcmp(argv[*i], "-f8") == 0)
    {
      *f8 = 1;
      *frame_size = G729EV_MAIN_L_FRAME2;
    }
    else if (strcmp(argv[*i], "-g729_bst") == 0)
    {
      *sent_rate = 8000;
      *g729_bst = 1;
    }
    else if (strncmp(argv[*i], "-r", 2) == 0)
    {
      *sent_rate = atoi(&argv[*i][2]);
      if (((*sent_rate != 8000) && (*sent_rate < 12000)) || (*sent_rate > 32000) || (*sent_rate % 2000 != 0))
      {
        printf("Error: wrong sent bit rate\n");
        exit(-1);
      }
    }
	else if (strcmp(argv[*i], "-dtx") == 0)
    {
	  *g729ev_dtx = 1;
	}
    else if (strncmp(argv[*i], "-m", 2) == 0)
    {
      *dtx_max_fr = atoi(&argv[*i][2]);
      if ((*dtx_max_fr < 0) && (*dtx_max_fr > 1000))
      {
        printf("Error: invalid max DTX frame rate %d\n", *dtx_max_fr);
        exit(-1);
      }
    }
    else
    {
      printf("Error: unrecognized option %s\n", argv[*i]);
      display_usage(argv[0]);
      exit(-1);
    }
  }

  if ((*g729_bst) && (*sent_rate != 8000))
  {
    *sent_rate = 8000;
    printf("Warning: bit rate limited to 8000 bit/s (G729_BST mode on)\n");
  }
  // SID bitstream
  if(*g729ev_dtx)
  {

#ifdef MKVAD
	if (argc < *i+3)
	{
		printf("Error: too few input parameters\n\n");
		display_usage(argv[0]);
		exit(-1);
	}
#endif
	// Narrowband SID
	if (*sent_rate <= 8000)
	{
      printf("Narrow Band DTX-> G.729 SID \n");
	}
	// Narrowband enhancement SID
	else if (*sent_rate <= 12000)
	{
      printf("Narrow Band DTX-> G.729 SID + Narrowband enhancement \n");
	  *cng_nb = 1;
	}
	// Wideband SID
	else
	{
      printf("Wide Band DTX-> G.729 SID + Narrowband enhancement + Wideband SID\n");
	  *cng_nb = *cng_wb = 1; 
	}
  }
}


int main(int argc, char *argv[])
{
  FILE     *pfilin;             /* input file descriptor */
  FILE     *pfilout;            /* output file descriptor */
  CODSTATMAIN codStat;          /* structure of coder states variables */
  INT16     tabin[G729EV_MAIN_L_FRAME]; /* table of the 16 bits input samples */
  int       nb_bits_sent;       /* number of bits sent by encoder */
  INT16     frame_size = G729EV_MAIN_L_FRAME; /* number of samples per frame */
  int       sent_rate;          /* bit rate sent by encoder (sent bit rate) */
  int       nb_frame = 0;       /* frame counter */
  int       nb;                 /* number of samples/bytes read in input file */
  int       i;
  INT16     itu_192_bitstream[G729EV_MAX_BITS_BST + 2];
  int       quiet = 0;          /* flag for quiet mode */
  int       f8 = 0;             /* flag for 8kHz input  */
  int       g729_bst = 0;       /* flag for G729 bitstream mode */
  INT16 cng_wb, cng_nb;
  int       dtx_max_fr = FR_SID_MAX;
#ifdef MKVAD
  FILE	*pvadin;
  INT16 mkvad_vadflag = 0;
#endif	//	MKVAD
  INT16 g729ev_dtx;
  printf("\n");
  printf("              ***** ITU-T G.729EV Annex D Encoder *****\n");
  printf("\n");
  printf("                Floating-point C simulation\n");
  printf("                Version 1.4 - Sep. 16, 2008 \n");
  printf("\n");

  /*------------------------------- read command line and check arguments -----------------------*/
  check_arguments(
	  &cng_nb,
	  &cng_wb,
	  &g729ev_dtx,
		argc, argv, &sent_rate,
      &dtx_max_fr,
      &frame_size, &i, &quiet, &f8, &g729_bst);
#ifdef MKVAD
  if (g729ev_dtx)
  {
	/* open vad file */
	if (i < argc)
	{
		if ((pvadin = fopen(argv[i], "r")) == NULL)
		{
		printf("Error: cannot open file %s\n", argv[i]);
		exit(-1);
		}
		i++;
	}
	else
	{
		printf("Error: no output file specified\n");
		exit(-1);
	}
  }
#endif // MKVAD

  /* open input file */
  if (i < argc)
  {
    if ((pfilin = fopen(argv[i], "rb")) == NULL)
    {
      printf("Error: cannot open file %s\n", argv[i]);
      exit(-1);
    }
    i++;
  }
  else
  {
    printf("Error: no input and output files specified\n");
    exit(-1);
  }

  /* open output file */
  if (i < argc)
  {
    if ((pfilout = fopen(argv[i], "wb")) == NULL)
    {
      printf("Error: cannot open file %s\n", argv[i]);
      exit(-1);
    }
  }
  else
  {
    printf("Error: no output file specified\n");
    exit(-1);
  }

  /* print arguments */
#ifdef MKVAD
  if (g729ev_dtx)
	printf("input VAD file     : %s\n", argv[i - 2]);
#endif // MKVAD
  printf("Input file         : %s\n", argv[i - 1]);
  printf("Output file        : %s\n", argv[i]);
  printf("Sent rate          : %d\n", (int) sent_rate);
  if (f8)
    printf("Sampling frequency : 8000 Hz\n");
  else
    printf("Sampling frequency : 16000 Hz\n");
  if (g729_bst)
    printf("Mode               : G729_BST\n");
  printf("Encoding file %s...\n", argv[i - 1]);

  /*------------------------------------------ main processing ---------------------------------------*/

  /* compute the number of bytes written/read for each frame */
  nb_bits_sent = (int) ((20 * sent_rate) / 1000);

  /* init encoder */
  G729EV_MAIN_InitEncoder(&codStat, sent_rate, dtx_max_fr, f8, g729_bst, cng_nb, cng_wb, g729ev_dtx);

  /* initialize bitstream */
  for (i = 0; i < nb_bits_sent; i++)
  {
    itu_192_bitstream[i] = (INT16) 0;
  }

  /* loop over input file */
  while ((nb = fread(tabin, sizeof(INT16), frame_size, pfilin)) != 0)
  {
    /* fill remaining samples of frame with zeros if number of samples read < frame size */
    if (nb < frame_size)
      for (i = nb; i < frame_size; i++)
        tabin[i] = (INT16) 0;

    itu_192_bitstream[0] = ITU_G192_SYNCWORD;
    if (g729_bst == 0)
      itu_192_bitstream[1] = sent_rate / 50;
    else
      itu_192_bitstream[1] = sent_rate / 100;

    /* encode */
#ifdef MKVAD
	if (g729ev_dtx)
	{
		if (!feof(pvadin)) {
			fscanf(pvadin, "%d", &mkvad_vadflag);
			if ((mkvad_vadflag != 0) && (mkvad_vadflag != 1)) {
				printf("Error: Values out of range [0 or 1] !\n");
				exit(-1);
			}
		}
		else
		{
			printf("Error: more VAD decisions are needed !\n");
			exit(-1);
		}
	}
	else
		mkvad_vadflag = 1;

      G729EV_MAIN_Encode (mkvad_vadflag, &codStat, tabin, &itu_192_bitstream[2], sent_rate);
#else
      G729EV_MAIN_Encode (st, &codStat, tabin, &itu_192_bitstream[2], sent_rate);
#endif	// MKVAD
      /* write data in bitstream */
	  // During Hangover periods bitrate is reduced
	  if (codStat.codStG729.Vad >= 2){
		if (itu_192_bitstream[1] >= 14000 / 50){
			itu_192_bitstream[1]  = 14000 / 50;
		}
		else if(itu_192_bitstream[1] >= 8000 / 50)
			itu_192_bitstream[1]  = 8000 / 50;
	  }
      // the number of bits to put in the bitstream is in itu_192_bitstream[1] to which
	  // the sync_word is added as well as the value number of bits.
	  // | Sync_word | Number of bits | bits values |
	  if (g729_bst == 0)
          fwrite(itu_192_bitstream, sizeof(*itu_192_bitstream), itu_192_bitstream[1] + 2, pfilout);
	  // | Sync_word | Number of bits | bits values | Sync_word | Number of bits | bits values |
      else
          fwrite(itu_192_bitstream, sizeof(*itu_192_bitstream), itu_192_bitstream[1] + itu_192_bitstream[itu_192_bitstream[1]+3] + 4, pfilout);


    nb_frame++;
    if (quiet == 0)
    {
      if (nb_frame % 100 == 0)
      {
        printf(" frame  %ld  \r", (long) nb_frame);
        fflush(stdout);
      }
    }
  }

  printf("Number of processed frames: %ld\n\n", (long) nb_frame);

#ifdef MKVAD
  if (g729ev_dtx)
	  fclose(pvadin);
#endif	
  fclose(pfilin);
  fclose(pfilout);

  return (0);
}
