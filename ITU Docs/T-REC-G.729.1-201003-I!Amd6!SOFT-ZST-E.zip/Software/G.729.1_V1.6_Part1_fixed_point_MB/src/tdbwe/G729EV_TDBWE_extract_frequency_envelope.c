/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include "G729EV_TDBWE_extract_frequency_envelope.h"

#include "G729EV_TDBWE_fft.h"
#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_MAIN_oper_32b.h"
#include "G729EV_G729_ld8k.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_extract_frequency_envelope()                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                     *
 *  TDBWE frequency envelope (sub-band energy) computation                  *
 *                                                                          *
 *  (note, that for calls operating on the same state the nls of signal[]   *
 *   must always be the same!)                                              *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_extract_frequency_envelope(Word16 * signal,   /* (i) framing memory */
                                             Word16 nls,        /* (i)   normalization of input signal */
                                             Word16 * envelope) /* (o)   Q.10, frequency envelope parameters */
{
  Word32    ACC0;
  Word16    i, j;
  Word16    tmp, sh;
  Word16    exp, frac;
  Word16    fft_in[G729EV_TDBWE_FFT_SIZE];
  Word16    re_fft_out[25];
  Word16    im_fft_out[25];
  Word16    power_spectrum[25];
  Word16    norm;

  /* compute FFT normalization factor nls */
  sh = (Word16) 16;
#ifdef WMOPS
  move16();
#endif

  FOR(i = 0; i < G729EV_TDBWE_FFT_SIZE2; i++)
  {
    IF(signal[i] != 0)          /* norm_s(0) returns 0 */
    {
      tmp = norm_s(signal[i]);
      if (sub(tmp, sh) < 0)
      {
        sh = tmp;
#ifdef WMOPS
        move16();
#endif
      }
    }
  }

  if (sub(sh, 16) == 0)
  {
    sh = (Word16) 0;
#ifdef WMOPS
    move16();
#endif
  }

  sh = sub(sh, 1);
  nls = add(nls, sh);

  /* apply windowing */
  FOR(i = 0; i < G729EV_TDBWE_FFT_SIZE; i++)
  {
    j = add(i, G729EV_TDBWE_FFT_SIZE);
    ACC0 = L_mult(signal[i], G729EV_TDBWE_frequency_envelope_window[i]);
    ACC0 = L_mac(ACC0, signal[j], G729EV_TDBWE_frequency_envelope_window[j]);
    fft_in[i] = round(L_shl(ACC0, sh));
#ifdef WMOPS
    move16();
#endif
  }

  /* half-length DFT "trick": compute even short-term power spectrum bins */
  /* fft_in Q.nls-1 */
  G729EV_TDBWE_fft(fft_in, re_fft_out, im_fft_out, G729EV_TDBWE_FFT_SIZE, &nls);
  /* fft_out Q.nls-1 */

  /* compute necessary power spectrum bins only */
  FOR(i = 0; i < 25; i++)
  {
    ACC0 = L_mult(re_fft_out[i], re_fft_out[i]);
    ACC0 = L_mac(ACC0, im_fft_out[i], im_fft_out[i]);
    power_spectrum[i] = round(ACC0);
#ifdef WMOPS
    move16();
#endif
  }
  /* power_spectrum is in Q(2*nls - 11) */

  /* accumulate sub-band powers */
  FOR(i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
  {
    ACC0 = (Word32) 0;
#ifdef WMOPS
    move32();
#endif

    FOR(j = 0; j < G729EV_TDBWE_BINS_PER_SUBBAND; j++)
    {
      tmp = sub(G729EV_TDBWE_center_bins[i], G729EV_TDBWE_BINS_BTW_CENTER_BINS);
      tmp = add(tmp, j);
      ACC0 = L_mac(ACC0, G729EV_TDBWE_subband_window[j], power_spectrum[tmp]);
    }
    /* ACC0 is in Q(2*nls+2); */


    /* compute (1/2)log2 of sub-band energies */

    /* Normalize ACC0 before Log2 for max precision */
    norm = norm_l(ACC0);
    ACC0 = L_shl(ACC0, norm);

    /* Log2 operation */
    Log2(ACC0, &exp, &frac);
    norm = add(norm, add(shl(nls, 1), 4));
    ACC0 = L_Comp(sub(exp, norm), frac);  /* ACC0 = envelope[i] in Q17 */
    envelope[i] = extract_h(L_shl(ACC0, 9));  /* envelope[i] in Q10 */
#ifdef WMOPS
    move16();
#endif
  }
}
