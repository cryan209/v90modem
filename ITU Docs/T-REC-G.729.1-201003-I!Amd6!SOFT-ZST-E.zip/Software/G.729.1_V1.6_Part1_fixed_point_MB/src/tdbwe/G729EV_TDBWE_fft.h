/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_FFT_H__
#define __G729EV_TDBWE_FFT_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"


/* prototype for exported function */

void      G729EV_TDBWE_fft(Word16 * x, Word16 * reX, Word16 * imX, Word16 vector_size, Word16 * nls);

/* tables */

extern const Word16 G729EV_TDBWE_fft_phs_tbl[G729EV_TDBWE_FFT_SIZE];


/*****************************************************************************/
#endif
