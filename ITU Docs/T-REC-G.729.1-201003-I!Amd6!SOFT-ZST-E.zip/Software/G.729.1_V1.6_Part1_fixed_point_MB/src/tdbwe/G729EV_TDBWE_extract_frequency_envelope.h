/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_EXTRACT_FREQUENCY_ENVELOPE_H__
#define __G729EV_TDBWE_EXTRACT_FREQUENCY_ENVELOPE_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"

/* prototype for exported function */

void      G729EV_TDBWE_extract_frequency_envelope(Word16 * input, Word16 nls, Word16 * envelope);

/* tables */

extern const Word16 G729EV_TDBWE_center_bins[G729EV_TDBWE_NB_SUBBANDS];
extern const Word16 G729EV_TDBWE_subband_window[G729EV_TDBWE_BINS_PER_SUBBAND];
extern const Word16 G729EV_TDBWE_frequency_envelope_window[G729EV_TDBWE_FREQUENCY_ENVELOPE_WINDOW_SIZE];

#endif
