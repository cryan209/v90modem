/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include "G729EV_TDBWE_frequency_envelope_shaping.h"

#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_G729_ld8k.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_frequency_envelope_shaping_initialize()          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~          *
 *  initialization of TDBWE frequency envelope shaping module               *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_frequency_envelope_shaping_initialize(G729EV_TDBWE_frequency_envelope_shaping_state * state)  /* (o) */
{
  G729EV_TDBWE_fir_initialize(&state->fir, state->filter_coeffs);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_frequency_envelope_shaping()                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                     *
 *  TDBWE frequency envelope shaping module                                 *
 *  shape frequency envelope of input[] according to desired_envelope[]     *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_frequency_envelope_shaping(G729EV_TDBWE_frequency_envelope_shaping_state * state, /* (i/o) */
                                             Word16 * input,            /* (i)   Q.0, input signal */
                                             Word16 * output,           /* (o)   Q.0, shaped signal */
                                             Word16 * desired_envelope) /* (i)   Q.10, envelope parameters */
{
  Word16    i, k;
  Word16    actual_envelope[G729EV_TDBWE_NB_SUBBANDS];
  Word16    exp, expf;
  Word16    gain16;             /* Q.8 */
  Word16    m16;
  Word32    tmp32;              /* Q.8+16 */
  const Word16 *coeffs;         /* Q.15 */
  Word16   *pfk;
  Word16    nrs, nrm;
  Word32    c_max;

  Word32    filter_coeffs[G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH];  /* Q.(15+8) */


  /* get frequency envelope of input signal */
  G729EV_TDBWE_extract_frequency_envelope(input - G729EV_TDBWE_MEM_EXC, 0, actual_envelope);

  FOR(i = 0; i < G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH; i++)
  {
    filter_coeffs[i] = 0;
#ifdef WMOPS
    move32();
#endif
  }

  coeffs = G729EV_TDBWE_fes_coeffs_matrix;

  FOR(i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
  {
    /* gain computation */
    m16 = sub(desired_envelope[i], actual_envelope[i]);
    exp = shr(m16, 10);
    expf = shl(s_and(m16, 0x03ff), 5);
    gain16 = extract_l(Pow2(8, expf));  /* +8 because Q0 -> Q8 */

    /* FIR filter design by weighted summation */
    FOR(k = 0; k < G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH; k++)
    {
      tmp32 = L_shl(L_mult0(gain16, coeffs[k]), exp);
      filter_coeffs[k] = L_add(filter_coeffs[k], tmp32);
#ifdef WMOPS
      move32();
#endif
    }
    coeffs = &coeffs[G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH];
  }


  /* add highpass contribution and store maximum */
  c_max = 0;
#ifdef WMOPS
  move32();
#endif
  FOR(k = 0; k < G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH; k++)
  {
    filter_coeffs[k] = L_mac0(filter_coeffs[k], G729EV_TDBWE_FREQ_ENV_SHAPING_GAIN_HIGHPASS, coeffs[k]);
#ifdef WMOPS
    move32();
#endif
    c_max = L_max(c_max, filter_coeffs[k]);
  }

  /* fighting overflows */
  nrm = sub(norm_l(c_max), 2);
  nrs = sub(13, nrm);

  FOR(k = 0; k < G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH; k++)
  {
    state->filter_coeffs[k] = extract_h(L_shl(filter_coeffs[k], nrm));  /* Q.23->Q29->Q.13 */
#ifdef WMOPS
    move16();
#endif
  }


  /* symmetrical extension (the filter has linear phase, i.e., even symmetry) */
  pfk = state->filter_coeffs;
  FOR(k = G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1; k >= G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH; k--)
  {
    state->filter_coeffs[k] = *pfk++;
#ifdef WMOPS
    move16();
#endif
  }

  /* do the filtering */
  G729EV_TDBWE_fir(&state->fir, input, output, G729EV_TDBWE_L_FRAME2);

  IF(nrs != 0)
  {
    FOR(i = 0; i < G729EV_TDBWE_L_FRAME2; i++)
    {
      output[i] = shl_r(output[i], nrs);
#ifdef WMOPS
      move16();
#endif
    }
  }
}
