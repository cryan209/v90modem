/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_FILT_H__
#define __G729EV_MAIN_FILT_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"

/* Types : */

typedef struct
{
  /* QMF filter states */
  Word16    mem[2 * G729EV_MAIN_S_QMF - 1];
} G729EV_MAIN_QMFCODSTAT;

typedef struct
{
  /* QMF filter states */
  Word16    mem_add[2 * G729EV_MAIN_S_QMF_FS - 1];
  Word16    mem_sub[2 * G729EV_MAIN_S_QMF_FS - 1];
} G729EV_MAIN_QMFDECSTAT;


typedef struct
{                               /* memory state structure */
  Word16    x0, x1;             /* input samples */
  Word16    y1_hi, y2_hi;       /* output samples MSB */
  Word16    y1_lo, y2_lo;       /* output samples LSB */
} G729EV_MAIN_IIR2STAT;


typedef struct
{                               /* memory state structure */
  Word16    x[G729EV_MAIN_LP_ORD];  /* input samples */
  Word16    y_hi[G729EV_MAIN_LP_ORD]; /* output samples MSB */
  Word16    y_lo[G729EV_MAIN_LP_ORD]; /* output samples LSB */
} G729EV_MAIN_IIRN_STAT;


typedef struct
{                               /* memory state structure */
  Word32    Level_in_sm;
  Word16    mem_stp[G729EV_G729_M_LPC];
  Word16    mem_res2[G729EV_G729_MEM_RES2];
  Word16    mem_zero[G729EV_G729_M_LPC];
  Word16    apond2[G729EV_G729_LONG_H_ST];
  Word16    gain_prec;
} G729EV_MAIN_PFSTAT;

/* Functions : */

/* set gammas */
void      G729EV_MAIN_set_gamma(Word16 * output_lo, Word16 * tab_Th, Word16 rate, Word16 * ga1_post, Word16 * ga2_post);

/* median filter */
Word16    G729EV_MAIN_gmed_n(Word16 ind[], Word16 n);

/* weighting filter */
void      G729EV_MAIN_weighting_filter(Word16 * ptr_Az, Word16 * mem_Wz_in, Word16 * mem_wsp, Word16 * diff);
void      G729EV_MAIN_inverse_weighting_filter(Word16 * ptr_Az, Word16 * mem_invWz_in, Word16 * mem_invwsp,
                                               Word16 * diff_q);

/* pre/post-processing routines */
void      G729EV_MAIN_init_iir2(G729EV_MAIN_IIR2STAT * stat);
void      G729EV_MAIN_iir2(G729EV_MAIN_IIR2STAT * exStat, /* (io)   : filter states       */
                           Word16 signal[],               /* (i/o)  : signal              */
                           Word16 lg,                     /* (i)    : lenght of signal    */
                           const Word16 * b,              /* (i)    : Filter coefficients */
                           const Word16 * a,              /* (i)    : Filter coefficients */
                           Word16 ScalingMode);           /* (i)    : ScalingMode =  1 : Upscale by 2   */
                                                          /* (i)    : ScalingMode = -1 : Downscale by 2 */



void      G729EV_MAIN_init_lp3k(G729EV_MAIN_IIRN_STAT * stat);
void      G729EV_MAIN_lp3k(G729EV_MAIN_IIRN_STAT * stat, Word16 signal[], Word16 lg);


/* QMF routines */
void      G729EV_MAIN_initQMF_ana(G729EV_MAIN_QMFCODSTAT * codstat);
void      G729EV_MAIN_initQMF_syn(G729EV_MAIN_QMFDECSTAT * codstat);
void      G729EV_MAIN_QMF_ana(G729EV_MAIN_QMFCODSTAT * codstat, Word16 * input, Word16 * bf, Word16 * hf, Word16 size);
void      G729EV_MAIN_QMF_syn(G729EV_MAIN_QMFDECSTAT * qmf, Word16 * inputBF, Word16 * inputHF,
                              Word16 * output, Word16 size, Word16 gain_switching);

void      G729EV_MAIN_QMF_mirror(Word16 * s, Word16 l);


/* convolution routines */
void      G729EV_MAIN_CONVOLVE_2Tap(Word16 Input[], Word16 Output[], Word16 Coef, Word16 Length);
void      G729EV_MAIN_CONVOLVE_3Tap(Word16 Input[], Word16 Output[], Word16 Coef, Word16 Length);



/* Tables : */
extern const Word16 G729EV_MAIN_qmf_J64D[32];

extern const Word16 G729EV_MAIN_hp50_b[3];
extern const Word16 G729EV_MAIN_hp50_a[3];
extern const Word16 G729EV_MAIN_b100[3];
extern const Word16 G729EV_MAIN_a100[3];

extern const Word16 G729EV_MAIN_lp3k_b_hi[G729EV_MAIN_LP_ORD + 1];
extern const Word16 G729EV_MAIN_lp3k_b_lo[G729EV_MAIN_LP_ORD + 1];
extern const Word16 G729EV_MAIN_lp3k_a_hi[G729EV_MAIN_LP_ORD + 1];
extern const Word16 G729EV_MAIN_lp3k_a_lo[G729EV_MAIN_LP_ORD + 1];

/* codebook for fixed-codebook gain correction in cascade CELP (2 bits) Q14*/
extern const Word16 G729EV_MAIN_tab_gain_enha2bits[];
extern const Word16 Sqrt_han_wind8k[];  /*Q15 */
extern const Word16 G729EV_FEC_h_low[];
extern const Word16 G729EV_FEC_h_high[];
extern const Word16 interpol_frac1[];
extern const Word16 sqi[];
extern const Word16 inv_sqi[];

#endif  /*__G729EV_MAIN_FILT_H__ */
