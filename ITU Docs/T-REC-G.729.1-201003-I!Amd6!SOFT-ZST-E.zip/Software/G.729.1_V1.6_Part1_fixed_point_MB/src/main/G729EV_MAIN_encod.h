/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_ENCOD_H__
#define __G729EV_MAIN_ENCOD_H__

#include "stl.h"

#include "G729EV_G729_codstat.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_TDBWE_encoder.h"

/* Types : */

typedef struct
{
  /* filter states */
  G729EV_MAIN_QMFCODSTAT qmf_ana;
  G729EV_MAIN_IIR2STAT mem_hp50;
  G729EV_MAIN_IIRN_STAT mem_lp3k;

  /* G.729 state variables */
  G729EV_G729_CODSTAT codStG729;
  G729EV_G729_DECSTAT decStG729;
  G729EV_TDBWE_CODSTAT tdbwe;

  /* states for perceptual weighting filtering of lower-band difference signal */
  Word16    mem_Wz_in[G729EV_G729_M];
  Word16    mem_wsp[G729EV_G729_M];

  /* memory of MDCT */
  Word16    mem_mdct_lo[G729EV_MAIN_L_FRAME2];
  Word16    mem_mdct_hi[G729EV_MAIN_L_FRAME2];

  /* states variables of FER encoder */
  Word16    oldferclass;
  Word16    lp_speech;
  Word16    relE_hist;
  Word16    relE_var;
  Word16    old_pulspos;

  /* encoder flags (8kHz sampled input, G729 bitstream mode) */
  Word16    f8;
  Word16    g729_bst;

} CODSTATMAIN;


/* Functions : */

void      G729EV_MAIN_InitEncoder(CODSTATMAIN * codstat, Word16 rate, Word16 f8, Word16 g729_bst);

void      G729EV_MAIN_Encode(CODSTATMAIN * codstat, Word16 * samplesIn, Word16 * itu_192_bitstream, Word16 rate);


#endif  /*__G729EV_MAIN_ENCOD_H__ */
