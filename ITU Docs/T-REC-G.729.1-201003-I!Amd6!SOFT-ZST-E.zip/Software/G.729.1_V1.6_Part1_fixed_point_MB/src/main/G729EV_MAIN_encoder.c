/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "stl.h"

#include "G729EV_G729_defines.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_G729_codstat.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_encod.h"


/*--------------------------------------------------------------------------*
 *  Function  display_usage()                                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~                                               *
 *  Display Encoder usage                                                   *
 *--------------------------------------------------------------------------*/

static void display_usage(char *argv)
{
  printf("Usage: %s [options] <inputfile> <bitstream>\n", argv);
  printf("\n");
  printf("Options:\n");
  printf("  -quiet     do not display frame counter\n");
  printf("  -rXXXXX    run encoder at bit rate XXXXX bit/s (32000 by default)\n");
  printf("  -f8        input sampled at 8 kHz\n");
  printf("  -g729_bst  write G.729 bitstream (maximal bit rate must be set to 8 kbit/s)\n");
  printf("\n");
}


/*--------------------------------------------------------------------------*
 *  Function  check_arguments()                                             *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  Check encoder arguments                                                 *
 *--------------------------------------------------------------------------*/

static void check_arguments(int argc, char *argv[],
                            Word16 * sent_rate,     /* (i/o)    rate used by encoder        */
                            Word16 * frame_size,    /* (i/o)    frame size used by encoder  */
                            Word16 * i,             /* (o)      argv index                  */
                            Word16 * quiet,         /* (o)      quiet mode flag             */
                            Word16 * f8,            /* (o)      8kHz sampled input flag     */
                            Word16 * g729_bst)      /* (o)      G.729 bitstream mode flag   */
{

  *quiet = 0;
  *f8 = 0;
  *g729_bst = 0;

  if ((argc < 3) || (argc > 7))
  {
    display_usage(argv[0]);
    exit(-1);
  }

  *sent_rate = G729EV_MAX_BITRATE;

  for(*i = (Word16) 1; (*i < argc) && (strncmp(argv[*i], "-", 1) == 0); (*i)++)
  {
    if (strcmp(argv[*i], "-quiet") == 0)
      *quiet = 1;
    else if (strcmp(argv[*i], "-f8") == 0)
    {
      *f8 = (Word16) 1;
      *frame_size = G729EV_MAIN_L_FRAME2;
    }
    else if (strcmp(argv[*i], "-g729_bst") == 0)
    {
      *sent_rate = 8000;
      *g729_bst = (Word16) 1;
    }
    else if (strncmp(argv[*i], "-r", 2) == 0)
    {
      *sent_rate = (Word16) atoi(&argv[*i][2]);
      if (((*sent_rate != 8000) && (*sent_rate < 12000)) || (*sent_rate > 32000) || (*sent_rate % 2000 != 0))
      {
        printf("Error: wrong sent bit rate\n");
        exit(-1);
      }
    }
    else
    {
      printf("Error: unrecognized option %s\n", argv[*i]);
      display_usage(argv[0]);
      exit(-1);
    }
  }

  if ((*g729_bst) && (*sent_rate != 8000))
  {
    *sent_rate = 8000;
    printf("Warning: bit rate limited to 8000 bit/s (G729_BST mode on)\n");
  }

}

int main(int argc, char *argv[])
{
  FILE     *pfilin;             /* input file descriptor */
  FILE     *pfilout;            /* output file descriptor */
  CODSTATMAIN codStat;          /* structure of coder states variables */
  Word16    tabin[G729EV_MAIN_L_FRAME]; /* table of the 16 bits input samples */
  Word16    nb_bits_sent;       /* number of bits sent by encoder */
  Word16    frame_size = G729EV_MAIN_L_FRAME; /* number of samples per frame */
  Word16    sent_rate;          /* bit rate sent by encoder (sent bit rate) */
  Word32    nb_frame = 0;       /* frame counter */
  Word16    nb;                 /* number of samples/bytes read in input file */
  Word16    i;
  Word16    itu_192_bitstream[G729EV_MAX_BITS_BST + 2];
  Word16    quiet = 0;          /* flag for quiet mode */
  Word16    f8 = 0;             /* flag for 8kHz input */
  Word16    g729_bst = 0;       /* flag for G729 bitstream mode */


  printf("\n");
  printf("              ***** ITU-T G.729EV Encoder *****\n");
  printf("\n");
  printf("                Fixed-point C simulation\n");
  printf("               Version 1.5 - August 29, 2009\n");
  printf("\n");

    /*------------------------------- read command line and check arguments -----------------------*/
  check_arguments(argc, argv, &sent_rate, &frame_size, &i, &quiet, &f8, &g729_bst);

  /* open input file */
  if (i < argc)
  {
    if ((pfilin = fopen(argv[i], "rb")) == NULL)
    {
      printf("Error: cannot open file %s\n", argv[i]);
      exit(-1);
    }
    i++;
  }
  else
  {
    printf("Error: no input and output files specified\n");
    exit(-1);
  }

  /* open output file */
  if (i < argc)
  {
    if ((pfilout = fopen(argv[i], "wb")) == NULL)
    {
      printf("Error: cannot open file %s\n", argv[i]);
      exit(-1);
    }
  }
  else
  {
    printf("Error: no output file specified\n");
    exit(-1);
  }

#ifdef WMOPS
  Init_WMOPS_counter();
#endif

  /* print arguments */
  printf("Input file         : %s\n", argv[i - 1]);
  printf("Output file        : %s\n", argv[i]);
  printf("Sent rate          : %d\n", (int) sent_rate);
  if (f8)
    printf("Sampling frequency : 8000 Hz\n");
  else
    printf("Sampling frequency : 16000 Hz\n");
  if (g729_bst)
    printf("Mode               : G729_BST\n");
  printf("Encoding file %s...\n", argv[i - 1]);

  /*------------------------------------------ main processing ---------------------------------------*/

  /* compute the number of bits written/read for each frame */
  nb_bits_sent = (Word16) ((20 * sent_rate) / 1000);

  /* init encoder */
  G729EV_MAIN_InitEncoder(&codStat, sent_rate, f8, g729_bst);

  /* initialize bitstream */
  for(i = 0; i < nb_bits_sent; i++)
  {
    itu_192_bitstream[i] = (Word16) 0;
  }

  /* loop over input file */
  while ((nb = fread(tabin, sizeof(Word16), frame_size, pfilin)) != 0)
  {

    fwc();
    Reset_WMOPS_counter();

    /* fill remaining samples of frame with zeros if number of samples read < frame size */
    if (nb < frame_size) {
      for(i = nb; i < frame_size; i++)
        tabin[i] = (Word16) 0;
	}

    itu_192_bitstream[0] = ITU_G192_SYNCWORD;
    if (g729_bst == 0)
      itu_192_bitstream[1] = sent_rate / 50;
    else
      itu_192_bitstream[1] = sent_rate / 100;

    /* encoder */
    G729EV_MAIN_Encode(&codStat, tabin, &itu_192_bitstream[2], sent_rate);

    /* write data in bitstream */
    if (g729_bst == 0)
      fwrite(itu_192_bitstream, sizeof(*itu_192_bitstream), itu_192_bitstream[1] + 2, pfilout);
    else
      fwrite(itu_192_bitstream, sizeof(*itu_192_bitstream), itu_192_bitstream[1] * 2 + 4, pfilout);

    nb_frame++;
    if (quiet == 0)
    {
      if (nb_frame % 100 == 0)
      {
        printf(" frame  %ld  \r", (long) nb_frame);
        fflush(stdout);
      }
    }
  }
  printf("Number of processed frames: %ld\n\n", (long) nb_frame);

#ifdef WMOPS
  fwc();
  printf("Encoder complexity\n");
  WMOPS_output(0);
  printf("\n");
#endif

  fclose(pfilin);
  fclose(pfilout);

  return (0);
}
