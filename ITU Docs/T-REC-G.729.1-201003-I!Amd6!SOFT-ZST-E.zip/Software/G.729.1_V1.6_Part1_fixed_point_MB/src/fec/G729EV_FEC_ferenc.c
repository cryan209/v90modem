/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <stdlib.h>
#include <stdio.h>
#include <time.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_MAIN_oper_32b.h"
#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_TDAC_util.h"
#include "G729EV_FEC_tools.h"
#include "stl.h"


/*---------------------------------------------------------------------*
*                             Prototypes 
*---------------------------------------------------------------------*/
static Word16 G729EV_FEC_clas_enc(const Word16 clas);
static Word16 G729EV_FEC_sig_clas(const Word16 old_clas, const Word16 voicing[6], const Word16 * speech,
                                  const Word16 pit[3], const Word16 * ee, const Word16 * sync_sp, const Word16 * synth,
                                  Word16 * lp_speech, Word16 * rel_hist, Word16 * rel_var);

/******************************************************************************/
/* G729EV_FEC_encod :  Decode FER informatio                                  */
/* - Find signal classification                                               */
/* - Find signal energy                                                       */
/* - Find last glotal pulse postion                                           */
/******************************************************************************/
void G729EV_FEC_encod(const Word16 old_clas,      /* i:   signal classification result from previous frames  */
                      const Word16 * voicing,     /* i:   normalized correlation for 3 half-frames           Q15 */
                      const Word16 * speech,      /* i:   pointer to denoised speech signal                  Q_new */
                      const Word16 * synth,       /* i:   pointer to synthesized speech for E computation    Q_new */
                      const Word16 * T_op,        /* i:   close loop pitch values for 3 half-frames           */
                      const Word16 * ee,          /* i:   lf/hf E ration for 2 half-frames                   Q14 */
                      const Word16 * sync_sp,     /* i:   time syncronised input speech                      Q_new */
                      Word16 * clas,              /* o:   signal clas for current frame                      */
                      Word16 * coder_parameters,  /* o:   coder_parameters                                   */
                      const Word16 T0,            /* i:   close loop integer pitch                           */
                      const Word16 T0_frac,       /* i:   close loop fractional part of the pitch            */
                      const Word16 * res,         /* i:   LP residual signal frame                           Q_new */
                      Word16 * lp_speech,         /* i/o: LP speech energu                                 Q8 */
                      Word16 * rel_hist,          /* i/o: relative energy memory                            */
                      Word16 * rel_var,           /* i/o: relative erergy variation                         */
                      Word16 * old_pos            /* i/o: Position of the last pulse                        */
    )
{
  Word16    tmpS;
  Word16    maxi, FER_pitch;
  Word16    index[3];
  Word16    sign, exp_enrq, enr_lg_ent, enr_lg_frac;
  Word32    enr_q, Ltmp;
  Word16   *coder_param_ptr;

  coder_param_ptr = coder_parameters;
  sign = 0;
  enr_q = 0;
  FER_pitch = T_op[3];
#if(WMOPS)
  move16();
  move16();
  move16();
  move32();
#endif
   /*------------------------------------------------------------------------*
    *  Signal classification 
    *-----------------------------------------------------------------*/
  *clas = G729EV_FEC_sig_clas(old_clas, voicing, speech, T_op, ee, sync_sp, synth, lp_speech, rel_hist, rel_var);

   /*-----------------------------------------------------------------*
    *  Speech energy information
    *  - Maximum of energy per pitch period for G729EV_FEC_VOICED frames
    *  - mean energy per sample over 2nd half of the frame for other
    *    frames
    *-----------------------------------------------------------------*/
  exp_enrq =
      G729EV_FEC_energy(*clas, synth,
                        shr(add(shl(T0, G729EV_FEC_SQPIT), mult_r(shl(T0_frac, G729EV_FEC_SQPIT), 10922)),
                            G729EV_FEC_SQPIT), &enr_q, G729EV_FEC_L_FRAME_FER);

  /*tmpS = (short)( 10.0 * log10( enr_q + 0.001f ) / 1.55 ); */
  Log2(enr_q, &enr_lg_ent, &enr_lg_frac);
  enr_lg_ent = sub(enr_lg_ent, exp_enrq);
  IF(sub(*clas, G729EV_FEC_VOICED) < 0) /* Voiced current frame */
  {
    Ltmp = L_sub(Mpy_32_16(enr_lg_ent, enr_lg_frac, G729EV_FEC_LG10_s1_55), G729EV_FEC_LG10_LFRAME_155);
  }
  ELSE
  {
    Ltmp = Mpy_32_16(enr_lg_ent, enr_lg_frac, G729EV_FEC_LG10_s1_55);
  }

  tmpS = extract_h(Ltmp);


  if (sub(tmpS, 31) >= 0)
  {
    tmpS = 31;
#if(WMOPS)
    move16();
#endif
  }

  if (tmpS < 0)
  {
    tmpS = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }
#if(WMOPS)
  move16();
  move16();
  move16();
#endif

  index[1] = tmpS;

   /*-----------------------------------------------------------------*
    *  Signal classification encoding
    *-----------------------------------------------------------------*/
  index[0] = G729EV_FEC_clas_enc(*clas);

   /*-----------------------------------------------------------------*
    *  First pitch pulse position encoding
    *  - Find first pitch pulse of current frame
    *  - Encode first pitch pulse position
    *-----------------------------------------------------------------*/

  maxi = (Word16) 0;

  IF(sub(*clas, G729EV_FEC_UNVOICED) > 0)
  {
    maxi = G729EV_FEC_findpulse(res, FER_pitch, 1);
  }

  if (sub(maxi, 160) > 0)
  {
    maxi = sub(maxi, 256);
    sign = (Word16) 1;
#if(WMOPS)
    move16();
#endif
  }

  if (sub(FER_pitch, 64) >= 0)
  {
    maxi = shr(maxi, 1);
  }

  if (sub(FER_pitch, 128) >= 0)
  {
    maxi = shr(maxi, 1);
  }

  if (sub(maxi, 64) > 0)
  {
    maxi = (Word16) 63;         /* This should never happen... */
#if(WMOPS)
    move16();
#endif
  }
  if (sign)
  {
    maxi = add(maxi, 64);
  }

#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
#endif
  /* delay puls pos parameter */
  tmpS = maxi;
  maxi = *old_pos;
  *old_pos = tmpS;

  index[2] = maxi;

#if(WMOPS)
  move16();
  move16();
  move16();
#endif
  *coder_param_ptr++ = index[2];
  *coder_param_ptr++ = index[0];
  *coder_param_ptr++ = index[1];
}

/******************************************************************************/
/* G729EV_FEC_sig_clas :  Do signal classification                            */
/* - Find realtive signal energy                                              */
/* - Find signal to noise ratio                                               */
/* - Find average voicing                                                     */
/* - Compute the zero crossing rate                                           */
/* - Compute pitch stability                                                  */
/* - Compute function of merit                                                */
/* - Find signal classification                                               */
/******************************************************************************/
static Word16 G729EV_FEC_sig_clas(  /* o:   classification for current frames             */
                                   const Word16 old_clas,   /* i:   signal classification result from previous frames    */
                                   const Word16 voicing[],  /* i:   normalized correlation for 3 half-frames             */
                                   const Word16 * speech,   /* i:   pointer to speech signal for E computation           */
                                   const Word16 pit[],      /* i:   open loop pitch values for 3 half-frames             */
                                   const Word16 * ee,       /* i:   lf/hf E ration for 2 half-frames                     */
                                   const Word16 * wsp,      /* i:   weighted speech                                      */
                                   const Word16 * wsyn,     /* i:   weighted synthesized signal                          */
                                   Word16 * lp_speech,      /* i/o: LP speech energu                                 Q8  */
                                   Word16 * last_relE,      /* i/o: relative energy memory                               */
                                   Word16 * relE_var        /* i/o: relative erergy variation                            */
    )
{
  Word16    i, pc, zc;

  Word16    clas, *pt_windfx, exp_et, frac_et, relE, Etot, tmp_mean, fmerit_fac;
  Word32    Ltmp, Ltmp1, Letot;
  Word32    Lsegen, Lnoiseen;
  Word16    tmp16, snr_val, exp_snr;
  Word16    mean_voi2, een, corn, zcn, relEn, pcn, snrn, fmerit1;
  Word16    exp_wsp, exp_noise, mant_noise, mant_wsp;
  Word16    var1, var2, var3;
  Word16    wsyn_scl[G729EV_FEC_L_FRAME_FER], wsp_scl[G729EV_FEC_L_FRAME_FER];

   /*-----------------------------------------------------------------*
    * Signal classification preprocessing   
    *-----------------------------------------------------------------*/

#if(WMOPS)
  move16();
  move32();
  move32();
  move32();
  move32();
  move32();
#endif
  clas = (Word16) 0;
  /* Etot is the total energy over all the bandwith in dB */
  Letot = 1;
  Ltmp1 = (Word32) 0;
  pt_windfx = (Word16 *) Sqrt_han_wind8k; /*Q13 */
  FOR(i = 0; i < G729EV_FEC_L_FRAME_FER / 4; i++)
  {
    tmp16 = mult_r(speech[i], *pt_windfx++);  /*Q14*Q13 ->Q12 */
    Ltmp1 = L_mac(Ltmp1, tmp16, tmp16); /*Q12+Q12+6 */
  }
  Letot = L_add(L_shr(Ltmp1, 2), Letot);
  Ltmp1 = (Word32) 0;
  FOR(; i < G729EV_FEC_L_FRAME_FER / 2; i++)
  {
    tmp16 = mult_r(speech[i], *pt_windfx++);
    Ltmp1 = L_mac(Ltmp1, tmp16, tmp16);
  }
  Letot = L_add(L_shr(Ltmp1, 2), Letot);
  Ltmp1 = (Word32) 0;
  FOR(; i < 3 * G729EV_FEC_L_FRAME_FER / 4; i++)
  {
    tmp16 = mult_r(speech[i], *pt_windfx--);
    Ltmp1 = L_mac(Ltmp1, tmp16, tmp16);
  }
  Letot = L_add(L_shr(Ltmp1, 2), Letot);
  Ltmp1 = (Word32) 0;
  FOR(; i < G729EV_FEC_L_FRAME_FER; i++)
  {
    tmp16 = mult_r(speech[i], *pt_windfx--);
    Ltmp1 = L_mac(Ltmp1, tmp16, tmp16);
  }

  Letot = L_add(L_shr(Ltmp1, 2), Letot);  /* Q_speech - 6 */
#if(WMOSP)
  move16();
  move16();
#endif
  Log2(Letot, &exp_et, &frac_et);
  exp_et = sub(exp_et, -7);     /*sub(shl(-1,1),5) */
  Ltmp = L_sub(Mpy_32_16(exp_et, frac_et, G729EV_FEC_LG10), G729EV_FEC_LG10_LFRAME);  /*Ltmp Q14 */
  Etot = round(L_shl(Ltmp, 10));
  relE = sub(Etot, *lp_speech); /* Q8 */


   /*-----------------------------------------------------------------*
    * Signal classification preprocessing   
    *-----------------------------------------------------------------*/


  /* Compute the SNR */
  Ltmp = (Word32) 0;
  Overflow = 0;
#if(WMOPS)
  move32();
  move16();
#endif
  FOR(i = 0; i < G729EV_FEC_L_FRAME_FER; i++)
  {
    Ltmp = L_mac(Ltmp, wsp[i], wsp[i]);
  }
  IF(Overflow)
  {
    FOR(i = 0; i < G729EV_FEC_L_FRAME_FER; i++)
    {
      wsyn_scl[i] = shr(wsyn[i], 2);
      wsp_scl[i] = shr(wsp[i], 2);
#if(WMOPS)
      move16();
      move16();
#endif
    }
  }
  ELSE
  {
    FOR(i = 0; i < G729EV_FEC_L_FRAME_FER; i++)
    {
      wsyn_scl[i] = wsyn[i];
      wsp_scl[i] = wsp[i];
#if(WMOPS)
      move16();
      move16();
#endif
    }
  }
#if(WMOPS)
  move32();
  move32();
#endif
  Lsegen = (Word32) 0;
  Lnoiseen = (Word32) 0;

  FOR(i = 0; i < G729EV_FEC_L_FRAME_FER; i++)
  {
    Lsegen = L_mac(Lsegen, wsp_scl[i], wsp_scl[i]);
    tmp16 = sub(wsp_scl[i], wsyn_scl[i]); /* ajust scaling between signals */
    Lnoiseen = L_mac(Lnoiseen, tmp16, tmp16);
  }
  IF(Lnoiseen != 0 && Lsegen != 0)
  {
    /* Normalize segen */
    exp_wsp = norm_l(Lsegen);
    mant_wsp = extract_h(L_shl(Lsegen, exp_wsp));
    exp_wsp = sub(30, exp_wsp);

    /* Normalize noiseen */
    exp_noise = norm_l(Lnoiseen);
    mant_noise = extract_h(L_shl(Lnoiseen, exp_noise));
    exp_noise = sub(30, exp_noise);

    /* ensure mant_wsp < mant_noise */
    mant_wsp = shr(mant_wsp, 1);
    exp_wsp = add(exp_wsp, 1);

    /*snr_val = segen / noiseen; *//* Total SNR    */
    snr_val = div_s(mant_wsp, mant_noise);
    exp_snr = sub(exp_wsp, exp_noise);

#if(WMOPS)
    move16();
    move16();
#endif
    /* Put snr_val in Q9 */
    Ltmp = L_shr(snr_val, sub((15 - 9 - 7), exp_snr));  /* Q16 */
    Log2(Ltmp, &exp_et, &frac_et);
    exp_et = sub(exp_et, 16);
    Ltmp = Mpy_32_16(exp_et, frac_et, G729EV_FEC_LG10); /*Ltmp Q14 */
    snr_val = round(L_shl(Ltmp, 16 - 5)); /*Q11 -> Q8 */
  }
  ELSE
  {
    snr_val = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }

  /* average voicing on second half-frame and look-ahead  */
  Ltmp = L_mult(voicing[0], 16384);
  mean_voi2 = mac_r(Ltmp, voicing[3], 16384);

  /* Average the spectral tilt in dB        */
  Ltmp = L_mult(ee[0], ee[1]);

  een = extract_h(L_shr(Ltmp, 2));  /*Q14 -> Q11 */
  een = mac_r(G729EV_FEC_C_EE, een, G729EV_FEC_K_EE);
#if(WMOPS)
  test();
  test();
#endif
  if (een < 0 || ee[0] < 0 || ee[1] < 0)
  {
    een = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }
  if (sub(een, 512) > 0)        /* 1 Q9 */
  {
    een = (Word16) 512;
#if(WMOPS)
    move16();
#endif
  }
#if(WMOPS)
  move16();
#endif

  /* Compute the zero crossing rate    */
  zc = (Word16) 0;
  FOR(i = 1; i < G729EV_FEC_L_FRAME_FER; i++)
  {
#if(WMOPS)
    test();
#endif
    if ((speech[i] <= 0) && (speech[i - 1] > 0))
    {
      zc = add(zc, 1);
    }
  }

  /* Compute the pitch stability      */
  pc = add(abs_s(sub(pit[2], pit[1])), abs_s(sub(pit[3], pit[2])));
#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
  test();
  test();
  test();
#endif
  /* This section is needed ot improve signal classification in noisy condition */
  tmp_mean = *last_relE;
  *last_relE = relE;
  fmerit_fac = (Word16) 16384;

  IF(sub(abs_s(sub(relE, tmp_mean)), add(abs_s(*relE_var), 6 * 256)) < 0 && (sub(old_clas, G729EV_FEC_UNVOICED) <= 0))  /* absolute variation */
  {
    fmerit_fac = (Word16) 13107;
  }
  ELSE if   (sub(sub(relE, tmp_mean), add(*relE_var, 3 * 256)) > 0 && (sub(old_clas, G729EV_FEC_V_TRANSITION) <= 0))
  {
    fmerit_fac = (Word16) 18022;
  }
  ELSE if   (sub(sub(relE, tmp_mean), (add(*relE_var, -5 * 256))) < 0 && (sub(old_clas, G729EV_FEC_V_TRANSITION) >= 0))
  {
    fmerit_fac = (Word16) 9830;
  }
  *relE_var = mac_r(L_mult(1638, sub(relE, tmp_mean)), 31130, *relE_var);
#if(WMOPS)
  move16();
  move32();
#endif

   /*------------------------------------------------------------------------*
    * transform parameters between 0 & 1    
    * find unique merit function            
    *------------------------------------------------------------------------*/
  /*corn = G729EV_FEC_K_COR * mean_voi2 + G729EV_FEC_C_COR; */
  Ltmp = G729EV_FEC_C_COR;

  corn = round(L_shl(L_mac(Ltmp, mean_voi2, G729EV_FEC_K_COR), -4));  /*Q13->Q9 */

  if (sub(corn, 512) > 0)
  {
    corn = (Word16) 512;
#if(WMOPS)
    move16();
#endif
  }
  if (corn < 0)
  {
    corn = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }
  Ltmp = L_mult(G729EV_FEC_C_ZC_ENC, 4);  /*Q13*Q2 -> Q16 */
  zcn = round(L_shl(L_mac(Ltmp, zc, G729EV_FEC_K_ZC_ENC), 16 - 7)); /*Q0*Q15 + Q16 */

  if (sub(zcn, 512) > 0)
  {
    zcn = (Word16) 512;
#if(WMOPS)
    move16();
#endif
  }
  if (zcn < 0)
  {
    zcn = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }
  Ltmp = L_mult(G729EV_FEC_C_RELE, 256);  /*Q15 ->Q24 */
  relEn = round(L_shl(L_mac(Ltmp, relE, G729EV_FEC_K_RELE), 1));  /*relE in Q8 but relEn in Q9 */
  if (sub(relEn, 512) > 0)
  {
    relEn = (Word16) 512;
#if(WMOPS)
    move16();
#endif
  }
  if (sub(relEn, 256) < 0)
  {
    relEn = (Word16) 256;
#if(WMOPS)
    move16();
#endif
  }
  Ltmp = G729EV_FEC_C_PC_ENC;   /*Q16 */
  pcn = round(L_shl(L_mac(Ltmp, pc, G729EV_FEC_K_PC_ENC), 16 - 7)); /*Q16 + Q0*Q15 */
#if(WMOPS)
  move32();
#endif

  if (sub(pcn, 512) > 0)
  {
    pcn = (Word16) 512;
#if(WMOPS)
    move16();
#endif
  }
  if (pcn < 0)
  {
    pcn = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }

  Ltmp = L_mult(G729EV_FEC_C_SNR, 512);
  snrn = mac_r(Ltmp, snr_val, G729EV_FEC_K_SNR);  /* Q25 +Q9*Q15 */


  if (sub(snrn, 512) > 0)
  {
    snrn = (Word16) 512;
#if(WMOPS)
    move16();
#endif
  }
  if (snrn < 0)
  {
    snrn = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }
#if(WMOPS)
  move16();
  move16();
  move16();
#endif
  IF(sub(relEn, 256) <= 0)
  {
    var1 = (Word16) 9830;
    var2 = (Word16) 19661;
    var3 = (Word16) 11796;
  }
  ELSE if   (sub(relEn, 384) > 0)
  {
    var1 = (Word16) 11703;
    var2 = (Word16) 23406;
    var3 = (Word16) 14043;
  }
  ELSE
  {
    var1 = (Word16) 9362;
    var2 = (Word16) 18725;
    var3 = (Word16) 11235;
  }

  Ltmp = L_mult(een, var1);
  Ltmp = L_mac(Ltmp, corn, var2);
  Ltmp = L_mac(Ltmp, zcn, var1);
  Ltmp = L_mac(Ltmp, relEn, var1);
  Ltmp = L_mac(Ltmp, pcn, var1);

  fmerit1 = round(L_shl(L_mac(Ltmp, snrn, var3), 16 - 10 - 1)); /*fmerit1 ->Q15 */
  /* Correction when noisy condition */
  fmerit1 = shl(mult(fmerit_fac, fmerit1), 1);
   /*-----------------------------------------------------------------*
    * frame classification                  
    *-----------------------------------------------------------------*/
#if(WMOPS)
  move16();
#endif
  IF(sub(relE, -2560) < 0)
  {
    clas = G729EV_FEC_UNVOICED;
  }
  ELSE
  {
    SWITCH(old_clas)
    {
case G729EV_FEC_VOICED:
case G729EV_FEC_ONSET:
case G729EV_FEC_V_TRANSITION:

      IF(sub(fmerit1, 18350) < 0)
      {
        clas = G729EV_FEC_UNVOICED;
      }
      ELSE if   (sub(fmerit1, 22282) < 0)
      {
        clas = G729EV_FEC_V_TRANSITION;
      }
      ELSE
      {
        clas = G729EV_FEC_VOICED;
      }
      BREAK;

case G729EV_FEC_UNVOICED:
case G729EV_FEC_UV_TRANSITION:


      IF(sub(fmerit1, 20972) > 0)
      {
        clas = G729EV_FEC_ONSET;
      }
      ELSE if   (sub(fmerit1, 19005) > 0)
      {
        clas = G729EV_FEC_UV_TRANSITION;
      }
      ELSE
      {
        clas = G729EV_FEC_UNVOICED;
      }
      BREAK;

default:
      clas = G729EV_FEC_UNVOICED;
      BREAK;
    }
  }

  IF(sub(clas, G729EV_FEC_V_TRANSITION) > 0)
  {
    *lp_speech = mac_r(L_mult(32440, *lp_speech), 328, Etot);
#if(WMOPS)
    move16();
#endif
  }


  return clas;
}


/*---------------------------------------------------------------------*
 *  Signal classification encoding
 *---------------------------------------------------------------------*/

static Word16 G729EV_FEC_clas_enc(  /* o: quantization index                */
                                   const Word16 clas  /* i:   signal clas for current frame   */
    )
{
  Word16    index;

#if(WMOPS)
  move16();
  test();
#endif
  IF(sub(clas, G729EV_FEC_UNVOICED) == 0)
  {
    index = (Word16) 0;
  }
  ELSE if   ((sub(clas, G729EV_FEC_V_TRANSITION) == 0) || (sub(clas, G729EV_FEC_UV_TRANSITION) == 0))
  {
    index = (Word16) 1;
  }
  ELSE if   (sub(clas, G729EV_FEC_VOICED) == 0)
  {
    index = (Word16) 2;
  }
  ELSE                          /* G729EV_FEC_ONSET        */
  {
    index = (Word16) 3;
  }
  return index;
}
