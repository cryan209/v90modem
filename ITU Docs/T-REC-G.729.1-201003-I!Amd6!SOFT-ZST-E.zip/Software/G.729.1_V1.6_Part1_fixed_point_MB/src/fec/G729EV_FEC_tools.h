/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TOOLS_H__
#define __G729EV_TOOLS_H__

/*-----------------------------------------------------------*
 * Tool library
 * ~~~~~~~~~~~~~~~~~~~                                             
 *-----------------------------------------------------------*/



/* Fixed-point definitions and prototypes */
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "stl.h"


Word16    G729EV_Emaximum2(     /* o:   return index with energy value in vector  Q0 */
                            const Word16 Qvec,  /* i:   Q of input vector                         Q0 */
                            const Word16 * vec, /* i:   input vector                              Qx */
                            const Word16 lvec,  /* i:   length of input vector                    Q0 */
                            Word32 * ener_max   /* o:   maximum energy value                      Q0 */
    );

/*----------------------------------------------------------------------------------*
 * Function Name : Dot_product()                           
 * Compute scalar product of <x[],y[]> using accumulator.   
 * Performs no normalization, as opposed to Dot_product12()  
 *----------------------------------------------------------------------------------*/
Word32    G729EV_Dot_product(   /* o:   Sum               */
                              const Word16 x[], /* i:   12bits: x vector  */
                              const Word16 y[], /* i:   12bits: y vector  */
                              const Word16 lg   /* i:   vector length     */
    );

void      G729EV_Scale_sig(Word16 x[],       /* i/o: signal to scale                 Qx        */
                           const Word16 lg,  /* i:   size of x[]                     Q0        */
                           const Word16 exp0 /* i:   exponent: x = round(x << exp)   Qx � exp  */
    );

void      G729EV_G729_Int_qlpc_bfi(Word16 lsp_old[],  /* input : LSP vector of past frame              */
                                   Word16 lsp_new[],  /* input : LSP vector of present frame           */
                                   Word16 Az[],       /* output: interpolated Az() for the 2 subframes */
                                   const Word16 * interpol_frac1);

void      Isqrt_n(Word32 * frac,  /* (i/o) Q31: normalized value (1.0 < frac <= 0.5) */
                  Word16 * exp    /* (i/o)    : exponent (value = frac x 2^exponent) */
    );
Word32    G729EV_Dot_product12( /* (o) Q31: normalized result (1 < val <= -1) */
                                const Word16 x[], /* (i) 12bits: x vector                       */
                                const Word16 y[], /* (i) 12bits: y vector                       */
                                const Word16 lg,  /* (i)    : vector length                     */
                                Word16 * exp      /* (o)    : exponent of result (0..+30)       */
    );
Word16    G729EV_FEC_voice_factor(  /* (o) Q15   : factor (-1=unvoiced to 1=voiced) */
                                   Word16 exc_in[], /* (i) Q_exc : pitch excitation                 */
                                   Word16 gain_pit, /* (i) Q14   : gain of pitch                    */
                                   Word16 code[],   /* (i) Q9    : Fixed codebook excitation        */
                                   Word16 gain_code /* (i) Q0    : gain of code                     */
    );
Word16    G729EV_FEC_Lsf_stab(  /* o:   LP filter stability */
                               const Word16 * Lsf,    /* i:   LSF vector          */
                               const Word16 * Lsfold  /* i:   old LSF vector      */
    );


#endif /* __G729EV_TOOLS_H__ */
