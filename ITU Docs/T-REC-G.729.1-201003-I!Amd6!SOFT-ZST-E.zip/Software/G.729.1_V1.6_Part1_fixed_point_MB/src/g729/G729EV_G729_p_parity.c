/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*------------------------------------------------------*
 * G729EV_G729_Parity_pitch - compute parity bit for first 6 MSBs   *
 *------------------------------------------------------*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"


Word16 G729EV_G729_Parity_Pitch(  /* output: parity bit (XOR of 6 MSB bits)    */
                                 Word16 pitch_index /* input : index for which parity to compute */
    )
{
  Word16    temp, sum, i, bit;

  temp = shr(pitch_index, 1);

  sum = 1;
#ifdef WMOPS
  move16();
#endif
  FOR(i = 0; i <= 5; i++)
  {
    temp = shr(temp, 1);
    bit = s_and(temp, (Word16) 1);
    sum = add(sum, bit);
  }
  sum = s_and(sum, (Word16) 1);


  return sum;
}

/*--------------------------------------------------------------------*
 * G729EV_G729_check_parity_pitch - check parity of index with transmitted parity *
 *--------------------------------------------------------------------*/

Word16 G729EV_G729_Check_Parity_Pitch(                      /* output: 0 = no error, 1= error */
                                       Word16 pitch_index,  /* input : index of parameter     */
                                       Word16 parity        /* input : parity bit             */
    )
{
  Word16    temp, sum, i, bit;

  temp = shr(pitch_index, 1);

  sum = 1;
#ifdef WMOPS
  move16();
#endif
  FOR(i = 0; i <= 5; i++)
  {
    temp = shr(temp, 1);
    bit = s_and(temp, (Word16) 1);
    sum = add(sum, bit);
  }
  sum = add(sum, parity);
  sum = s_and(sum, (Word16) 1);

  return sum;
}
