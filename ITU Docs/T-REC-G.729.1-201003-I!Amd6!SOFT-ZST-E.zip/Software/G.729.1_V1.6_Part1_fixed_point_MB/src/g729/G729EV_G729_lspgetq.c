/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"



void G729EV_G729_Lsp_get_quant(Word16 lspcb1[][G729EV_G729_M],    /* (i) Q13 : first stage LSP codebook      */
                               Word16 lspcb2[][G729EV_G729_M],    /* (i) Q13 : Second stage LSP codebook     */
                               Word16 code0,                      /* (i)     : selected code of first stage  */
                               Word16 code1,                      /* (i)     : selected code of second stage */
                               Word16 code2,                      /* (i)     : selected code of second stage */
                               Word16 fg[][G729EV_G729_M],        /* (i) Q15 : MA prediction coef.           */
                               Word16 freq_prev[][G729EV_G729_M], /* (i) Q13 : previous LSP vector           */
                               Word16 lspq[],                     /* (o) Q13 : quantized LSP parameters      */
                               Word16 fg_sum[]                    /* (i) Q15 : present MA prediction coef.   */
    )
{
  Word16    j;
  Word16    buf[G729EV_G729_M]; /* Q13 */


  FOR(j = 0; j < G729EV_G729_NC; j++)
  {
    buf[j] = add(lspcb1[code0][j], lspcb2[code1][j]);
#if (WMOPS)
    move16();
#endif
  }

  FOR(j = G729EV_G729_NC; j < G729EV_G729_M; j++)
  {
    buf[j] = add(lspcb1[code0][j], lspcb2[code2][j]);
#if (WMOPS)
    move16();
#endif
  }

  G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP1);
  G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP2);

  G729EV_G729_Lsp_prev_compose(buf, lspq, fg, freq_prev, fg_sum);

  G729EV_G729_Lsp_prev_update(buf, freq_prev);

  G729EV_G729_Lsp_stability(lspq);

  return;
}


void G729EV_G729_Lsp_expand_1(Word16 buf[], /* (i/o) Q13 : LSP vectors */
                              Word16 gap    /* (i)   Q13 : gap         */
    )
{
  Word16    j, tmp;
  Word16    diff;               /* Q13 */

  FOR(j = 1; j < G729EV_G729_NC; j++)
  {
    diff = sub(buf[j - 1], buf[j]);
    tmp = shr(add(diff, gap), 1);

    IF(tmp > 0)
    {
      buf[j - 1] = sub(buf[j - 1], tmp);
      buf[j] = add(buf[j], tmp);
#if (WMOPS)
      move16();
      move16();
#endif
    }
  }
  return;
}


void G729EV_G729_Lsp_expand_2(Word16 buf[], /* (i/o) Q13 : LSP vectors */
                              Word16 gap    /* (i)   Q13 : gap         */
    )
{
  Word16    j, tmp;
  Word16    diff;               /* Q13 */

  FOR(j = G729EV_G729_NC; j < G729EV_G729_M; j++)
  {
    diff = sub(buf[j - 1], buf[j]);
    tmp = shr(add(diff, gap), 1);

    IF(tmp > 0)
    {
      buf[j - 1] = sub(buf[j - 1], tmp);
      buf[j] = add(buf[j], tmp);
#if (WMOPS)
      move16();
      move16();
#endif
    }
  }
  return;
}


void G729EV_G729_Lsp_expand_1_2(Word16 buf[], /* (i/o) Q13 : LSP vectors */
                                Word16 gap    /* (i)   Q13 : gap         */
    )
{
  Word16    j, tmp;
  Word16    diff;               /* Q13 */

  FOR(j = 1; j < G729EV_G729_M; j++)
  {
    diff = sub(buf[j - 1], buf[j]);
    tmp = shr(add(diff, gap), 1);

    IF(tmp > 0)
    {
      buf[j - 1] = sub(buf[j - 1], tmp);
      buf[j] = add(buf[j], tmp);
#if (WMOPS)
      move16();
      move16();
#endif
    }
  }
  return;
}


/*
  Functions which use previous LSP parameter (freq_prev).
*/


/*
  compose LSP parameter from elementary LSP with previous LSP.
*/
void G729EV_G729_Lsp_prev_compose(Word16 lsp_ele[],                   /* (i) Q13 : LSP vectors                 */
                                  Word16 lsp[],                       /* (o) Q13 : quantized LSP parameters    */
                                  Word16 fg[][G729EV_G729_M],         /* (i) Q15 : MA prediction coef.         */
                                  Word16 freq_prev[][G729EV_G729_M],  /* (i) Q13 : previous LSP vector         */
                                  Word16 fg_sum[]                     /* (i) Q15 : present MA prediction coef. */
    )
{
  Word32    L_acc;              /* Q29 */

  Word16    j, k;


  FOR(j = 0; j < G729EV_G729_M; j++)
  {
    L_acc = L_mult(lsp_ele[j], fg_sum[j]);
    FOR(k = 0; k < G729EV_G729_MA_NP; k++)
    {
      L_acc = L_mac(L_acc, freq_prev[k][j], fg[k][j]);
    }
    lsp[j] = extract_h(L_acc);
#if (WMOPS)
    move16();
#endif
  }
  return;
}


/*
  extract elementary LSP from composed LSP with previous LSP
*/
void G729EV_G729_Lsp_prev_extract(Word16 lsp[G729EV_G729_M],                    /* (i) Q13 : unquantized LSP parameters  */
                                  Word16 lsp_ele[G729EV_G729_M],                /* (o) Q13 : target vector               */
                                  Word16 fg[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i) Q15 : MA prediction coef.         */
                                  Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i) Q13 : previous LSP vector         */
                                  Word16 fg_sum_inv[G729EV_G729_M]              /* (i) Q12 : inverse previous LSP vector */
    )
{
  Word32    L_temp;             /* Q19 */

  Word16    j, k;
  Word16    temp;               /* Q13 */


  FOR(j = 0; j < G729EV_G729_M; j++)
  {
    L_temp = L_deposit_h(lsp[j]);
    FOR(k = 0; k < G729EV_G729_MA_NP; k++)
    {
      L_temp = L_msu(L_temp, freq_prev[k][j], fg[k][j]);
    }
    temp = extract_h(L_temp);
    L_temp = L_mult(temp, fg_sum_inv[j]);
    lsp_ele[j] = extract_h(L_shl(L_temp, 3));
#if (WMOPS)
    move16();
#endif

  }
  return;
}


/*
  update previous LSP parameter
*/
void G729EV_G729_Lsp_prev_update(Word16 lsp_ele[G729EV_G729_M], /* (i)   Q13 : LSP vectors           */
                                 Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M] /* (i/o) Q13 : previous LSP vectors  */
    )
{
  Word16    k;

  FOR(k = G729EV_G729_MA_NP - 1; k > 0; k--)
  {
    G729EV_G729_Copy(freq_prev[k - 1], freq_prev[k], G729EV_G729_M);
  }

  G729EV_G729_Copy(lsp_ele, freq_prev[0], G729EV_G729_M);
  return;
}

void G729EV_G729_Lsp_stability(Word16 buf[] /* (i/o) Q13 : quantized LSP parameters      */
    )
{
  Word32    L_diff;
  Word32    L_acc, L_accb;

  Word16    j;
  Word16    tmp;


  FOR(j = 0; j < G729EV_G729_M - 1; j++)
  {
    L_acc = L_deposit_l(buf[j + 1]);
    L_accb = L_deposit_l(buf[j]);
    L_diff = L_sub(L_acc, L_accb);

    if (L_diff < 0L)
    {
      /* exchange buf[j]<->buf[j+1] */
#if (WMOPS)
      move16();
      move16();
      move16();
#endif
      tmp = buf[j + 1];
      buf[j + 1] = buf[j];
      buf[j] = tmp;
    }
  }

  IF(sub(buf[0], G729EV_G729_L_LIMIT) < 0)
  {
#if (WMOPS)
    move16();
#endif
    buf[0] = G729EV_G729_L_LIMIT;
    printf("lsp_stability warning Low \n");
  }
  FOR(j = 0; j < G729EV_G729_M - 1; j++)
  {
    L_acc = L_deposit_l(buf[j + 1]);
    L_accb = L_deposit_l(buf[j]);
    L_diff = L_sub(L_acc, L_accb);

    if (L_sub(L_diff, G729EV_G729_GAP3) < 0L)
    {
      buf[j + 1] = add(buf[j], G729EV_G729_GAP3);
#if (WMOPS)
      move16();
#endif
    }
  }

  IF(sub(buf[G729EV_G729_M - 1], G729EV_G729_M_LIMIT) > 0)
  {
#if (WMOPS)
    move16();
#endif
    buf[G729EV_G729_M - 1] = G729EV_G729_M_LIMIT;
    printf("lsp_stability warning High \n");
  }
  return;
}
