/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729_TAB_DTX_H__
#define __G729EV_G729_TAB_DTX_H__

#include "stl.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729B_defines.h"

/* Quantization of LSF vector */
extern Word16 PtrTab_1[32];
extern Word16 PtrTab_2[2][16];

/* Quantization of SID gain */
extern Word16 fact[NB_GAIN + 1];
extern Word16 marg[NB_GAIN + 1];
extern Word16 tab_Sidgain[32];

/* SID LSF quantization */
extern Word16 noise_fg_sum[G729EV_G729_MODE][G729EV_G729_M];

#endif
