/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729_DTX_H__
#define __G729EV_G729_DTX_H__

#include "stl.h"
#include "G729EV_G729_decstat.h"

/* SID gain Quantization */
void      Qua_Sidgain(Word16 * ener,    /* (i)   array of energies                   */
                      Word16 * sh_ener, /* (i)   corresponding scaling factors       */
                      Word16 nb_ener,   /* (i)   number of energies or               */
                      Word16 * enerq,   /* (o)   decoded energies in dB              */
                      Word16 * idx      /* (o)   SID gain quantization index         */
    );

/* CNG excitation generation */
void      Calc_exc_rand(G729EV_G729_DECSTAT * pDecStat, Word16 cur_gain,  /* (i)   :   target sample gain                 */
                        Word16 * exc,   /* (i/o) :   excitation array                   */
                        Word16 * seed,  /* (i)   :   current Vad decision               */
                        Flag flag_cod   /* (i)   :   encoder/decoder flag               */
    );

#endif
