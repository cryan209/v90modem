/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.6                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*-------------------------------------------------------------------*
 * Function  Set zero()                                              *
 *           ~~~~~~~~~~                                              *
 * Set vector x[] to zero                                            *
 *-------------------------------------------------------------------*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_decstat.h"


void G729EV_G729_Set_zero(Word16 x[], /* (o)    : vector to clear     */
                          Word16 L    /* (i)    : length of vector    */
    )
{
  Word16    i;

  FOR(i = 0; i < L; i++)
  {
    x[i] = 0;
#ifdef WMOPS
    move16();
#endif
  }

  return;
}

/*-------------------------------------------------------------------*
 * Function  Copy:                                                   *
 *           ~~~~~                                                   *
 * Copy vector x[] to y[]                                            *
 *-------------------------------------------------------------------*/

void G729EV_G729_Copy(Word16 x[], /* (i)   : input vector   */
                      Word16 y[], /* (o)   : output vector  */
                      Word16 L    /* (i)   : vector length  */
    ) 
{
  Word16    i;

  FOR(i = 0; i < L; i++)
  {
    y[i] = x[i];
#ifdef WMOPS
    move16();
#endif
  }

  return;
}

/* Random generator  */

Word16 G729EV_G729_Random(Word16 * seed)
{
  /* seed = seed*31821 + 13849; */
  *seed = extract_l(L_add(L_shr(L_mult(*seed, 31821), 1), 13849L));
#ifdef WMOPS
  move16();
#endif

  return (*seed);
}
