/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"




/**------------------------------------------------------------------*
* Function  Pred_lt_3()                                             *
*           ~~~~~~~~~~~                                             *
*-------------------------------------------------------------------*
* Compute the result of long term prediction with fractional        *
* interpolation of resolution 1/3.                                  *
*                                                                   *
* On return exc[0..L_subfr-1] contains the interpolated signal      *
*   (adaptive codebook excitation)                                  *
*-------------------------------------------------------------------*/

void G729EV_G729_Pred_lt_3(REAL exc[],  /* (i/o)  : excitation vector, exc[0:l_sub-1] = out */
                           int t0,      /* (i)    : pitch lag                               */
                           int frac,    /* (i)    : Fraction of pitch lag (-1, 0, 1)  / 3   */
                           int l_subfr  /* (i)    : length of subframe.                     */
    )
{
  int       i, j, k;
  REAL      s, *x0, *x1, *x2;
  const REAL *c1, *c2;

  x0 = &exc[-t0];

  frac = -frac;
  if (frac < 0)
  {
    frac += G729EV_G729_UP_SAMP;
    x0--;
  }

  for (j = 0; j < l_subfr; j++)
  {
    x1 = x0++;
    x2 = x0;
    c1 = &inter_3l[frac];
    c2 = &inter_3l[G729EV_G729_UP_SAMP - frac];

    s = (REAL) 0.0;
    for (i = 0, k = 0; i < G729EV_G729_L_INTER10; i++, k += G729EV_G729_UP_SAMP)
      s += x1[-i] * c1[k] + x2[i] * c2[k];

    exc[j] = s;
  }

  return;
}
