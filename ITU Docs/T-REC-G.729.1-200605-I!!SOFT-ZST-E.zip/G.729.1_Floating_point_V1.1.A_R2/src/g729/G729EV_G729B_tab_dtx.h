/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

/*
   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                         Version 2.1 of October 1999
*/

/*
 File : TAB_DTX.H
*/

#include "CodecTypedef.h"

/* Quantization of LSF vector */
extern int PtrTab_1[32];
extern int PtrTab_2[2][16];

/* Quantization of SID gain */
extern REAL fact[NB_GAIN + 1];
extern REAL tab_Sidgain[32];

/* SID LSF quantization */
extern REAL noise_fg_sum[G729EV_G729_MODE][G729EV_G729_M];
