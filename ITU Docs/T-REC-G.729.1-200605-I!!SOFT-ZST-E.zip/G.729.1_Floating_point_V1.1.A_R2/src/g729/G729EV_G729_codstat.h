/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/


#ifndef __G729EV_G729_CODSTAT_H__
#define __G729EV_G729_CODSTAT_H__

#include <stdio.h>
#include "CodecTypedef.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"


/* Structure of the encoder status variables */

typedef struct
{

  REAL      exc_err[4];                         /* to tame coder */
  REAL      old_speech[G729EV_G729_MEM_SPEECH]; /* Speech vector          */
  REAL      old_wsp[G729EV_G729_PIT_MAX];       /* Weighted speech vector */
  REAL      old_exc[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];  /* Excitation vector      */
  REAL      lsp_old[G729EV_G729_M];             /* Line Spectral Pairs  */
  REAL      lsp_old_q[G729EV_G729_M];           /* Quantified LSP       */
  REAL      mem_syn[G729EV_G729_M_LPC];         /* Filter's memory      */
  REAL      mem_w0[G729EV_G729_M_LPC];
  REAL      mem_w[G729EV_G729_M_LPC];
  REAL      mem_err[G729EV_G729_M_LPC];
  REAL      old_A[G729EV_G729_MP1];             /* Last LPC coefs       */
  REAL      old_rc[2];
  REAL      freq_prev[G729EV_G729_MA_NP][G729EV_G729_M];  /* previous LSP vector       */
  REAL      past_qua_en[4];                     /* Past quantized energies */
  REAL      lar_old[2];
  INT16     rate;                               /* Rate */
  REAL      pit_sharp;
  INT16     smooth;
  REAL      mem_w0_2[G729EV_G729_M_LPC];
  REAL      mem_err2[G729EV_G729_M_LPC];
  REAL      mem_synth[G729EV_G729_M_LPC];       /* Memory for output synthesis  */
  REAL      mem_zero[G729EV_G729_M_LPC];        /* null memory to compute h_st  */
  INT16     pit_old;

} G729EV_G729_CODSTAT;

#endif  /*__G729EV_G729_CODSTAT_H__ */
