/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_G729_DEFINES_H__
#define __G729EV_G729_DEFINES_H__


/*--------------------------------------------------------------------------*
 *       Codec constant parameters (coder, decoder, and postfilter)         *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_L_TOTAL         240 /* Total size of speech buffer                */
#define G729EV_G729_L_WINDOW        240 /* LPC analysis window size                   */
#define G729EV_G729_L_NEXT          40  /* Lookahead in LP analysis                   */
#define G729EV_G729_L_FRAME         80  /* Frame size                                 */
#define G729EV_G729_L_SUBFR         40  /* Sub-frame size                             */
#define G729EV_G729_M               10  /* LPC order                                  */
#define G729EV_G729_MP1            (G729EV_G729_M+1)    /* LPC order+1                */
#define G729EV_G729_PIT_MIN         20  /* Minimum pitch lag in samples               */
#define G729EV_G729_PIT_MAX         143 /* Maximum pitch lag in samples               */
#define G729EV_G729_L_INTERPOL      (10+1)/* Length of filter for interpolation.      */

#define G729EV_G729_PRM_SIZE        11  /* Size of vector of analysis parameters.     */

#define G729EV_G729_SHARPMAX        (REAL)0.7945 /* Maximum value of pitch sharpening */
#define G729EV_G729_SHARPMIN        (REAL)0.2    /* minimum value of pitch sharpening */

#define G729EV_G729_L_SUBFRP1 (G729EV_G729_L_SUBFR + 1) /* Sub-frame size + 1         */

#define G729EV_G729_GPCLIP      (REAL)0.95  /* Maximum pitch gain if taming is needed */
#define G729EV_G729_GPCLIP2     (REAL)0.94  /* Maximum pitch gain if taming is needed */
#define G729EV_G729_GP0999      (REAL)0.9999/* Maximum pitch gain if taming is needed */
#define G729EV_G729_THRESH_ERR  (REAL)60000./* Error threshold taming                 */
#define G729EV_G729_INV_L_SUBFR (REAL) ((REAL)1./(REAL)G729EV_G729_L_SUBFR) /* =0.025 */

#define G729EV_G729_MEM_SPEECH      (G729EV_G729_L_TOTAL - G729EV_G729_L_FRAME)
#define G729EV_G729_M_LPC G729EV_G729_M
#define G729EV_G729_M_LPC1 (G729EV_G729_M_LPC+1)

/*--------------------------------------------------------------------------*
 *       PWF constant parameters                                            *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_THRESH_L1   (REAL)-1.74
#define G729EV_G729_THRESH_L2   (REAL)-1.52
#define G729EV_G729_THRESH_H1   (REAL)0.65
#define G729EV_G729_THRESH_H2   (REAL)0.43
#define G729EV_G729_GAMMA1_0    (REAL)0.98
#define G729EV_G729_GAMMA2_0_H  (REAL)0.7
#define G729EV_G729_GAMMA2_0_L  (REAL)0.4
#define G729EV_G729_GAMMA1_1    (REAL)0.94
#define G729EV_G729_GAMMA2_1    (REAL)0.6
#define G729EV_G729_ALPHA       (REAL)-6.0
#define G729EV_G729_BETA        (REAL)1.0

/*--------------------------------------------------------------------------*
 *       LTP constant parameters                                            *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_UP_SAMP         3   /* upsampling factor for fractional pitch    */
#define G729EV_G729_L_INTER4        4   /* length/2 for interpolation filter         */

#define G729EV_G729_FIR_SIZE_ANA (G729EV_G729_UP_SAMP*G729EV_G729_L_INTER4+1)

#define G729EV_G729_L_INTER10       10  /* length/2 for interpolation filter         */

#define G729EV_G729_FIR_SIZE_SYN (G729EV_G729_UP_SAMP*G729EV_G729_L_INTER10+1)


/*--------------------------------------------------------------------------*
 *       FCB constant parameters                                            *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_DIM_RR  616     /* size of correlation matrix                     */
#define G729EV_G729_NB_POS  8       /* Number of positions for each pulse             */
#define G729EV_G729_STEP    5       /* spacing for individual pulse                   */
#define G729EV_G729_MSIZE   64      /* Size of vectors for cross-correlation between 2 pulses */

/*--------------------------------------------------------------------------*
 *       LSP quantizer constant parameters                                  *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_NC              (G729EV_G729_M/2)
#define G729EV_G729_MA_NP           4                   /* MA prediction order for LSP               */
#define G729EV_G729_MODE            2                   /* number of modes for MA prediction         */
#define G729EV_G729_NC0_B           7                   /* number of bits in first stage             */
#define G729EV_G729_NC1_B           5                   /* number of bits in second stage            */
#define G729EV_G729_NC0          (1<<G729EV_G729_NC0_B) /* number of entries in first stage          */
#define G729EV_G729_NC1          (1<<G729EV_G729_NC1_B) /* number of entries in second stage         */

#define G729EV_G729_L_LIMIT         (REAL)0.005
#define G729EV_G729_M_LIMIT         (REAL)3.135

#define G729EV_G729_GAP1            (REAL)0.0012        /* bandwidth expansion factor                */
#define G729EV_G729_GAP2            (REAL)0.0006        /* bandwidth expansion factor                */
#define G729EV_G729_GAP3            (REAL)0.0392        /* bandwidth expansion factor                */
#define G729EV_G729_GRID_POINTS     60                  /* search grid                               */

#define G729EV_G729_PI              (REAL)3.14159265358979323846
#define G729EV_G729_PI2             (REAL)6.283185307
#define G729EV_G729_PI04            G729EV_G729_PI*(REAL)0.04
#define G729EV_G729_PI92            G729EV_G729_PI*(REAL)0.92
#define G729EV_G729_CONST12         (REAL)1.2

/*--------------------------------------------------------------------------*
 * gain VQ constants.                                                       *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_NCODE1_B  3                         /* number of Codebook-bit     */
#define G729EV_G729_NCODE2_B  4                         /* number of Codebook-bit     */
#define G729EV_G729_NCODE1    (1<<G729EV_G729_NCODE1_B) /* Codebook 1 size            */
#define G729EV_G729_NCODE2    (1<<G729EV_G729_NCODE2_B) /* Codebook 2 size            */
#define G729EV_G729_NCAN1            4                  /* Pre-selecting order for #1 */
#define G729EV_G729_NCAN2            8                  /* Pre-selecting order for #2 */
#define G729EV_G729_INV_COEF   (REAL)-0.032623

#define G729EV_G729_PIT_MAX_GAIN (REAL)1.2      /* maximum adaptive codebook gain     */
#define G729EV_G729_MEAN_ENER        (REAL)36.0 /* average innovation energy */

/*--------------------------------------------------------------------------*
 * Postfilter constants                                                     *
 *--------------------------------------------------------------------------*/

         /* short term pst parameters :  */
#define G729EV_G729_GAMMA1_PST      (REAL)0.7   /* denominator weighting factor     */
#define G729EV_G729_GAMMA2_PST      (REAL)0.55  /* numerator  weighting factor      */
#define G729EV_G729_GAMMA1_PST12K   (REAL)0.75  /* denominator weighting factor 12K */
#define G729EV_G729_GAMMA2_PST12K   (REAL)0.7   /* numerator  weighting factor  12K */
#define G729EV_G729_LONG_H_ST       20          /* impulse response length          */
#define G729EV_G729_GAMMA3_PLUS     (REAL)0.2   /* tilt weighting factor when k1>0  */
#define G729EV_G729_GAMMA3_MINUS    (REAL)0.9   /* tilt weighting factor when k1<0  */
#define G729EV_G729_GAMMA_HARM (REAL)0.5

         /* long term pst parameters :   */
#define G729EV_G729_F_UP_PST        8   /* resolution for fractionnal delay   */
#define G729EV_G729_LH2_S           4   /* length of INT16 interp. subfilters */
#define G729EV_G729_LH2_L           16  /* length of long interp. subfilters  */
#define G729EV_G729_MIN_GPLT    ((REAL)1. / ((REAL)1.5))   /* LT gain minimum  */

#define G729EV_G729_LH_UP_S         (G729EV_G729_LH2_S/2)
#define G729EV_G729_LH_UP_L         (G729EV_G729_LH2_L/2)
#define G729EV_G729_LH2_L_P1    (G729EV_G729_LH2_L + 1)

#define G729EV_G729_THRESCRIT       (REAL)0.5   /* threshold LT pst switch off        */

/* gain adjustment parameters :                                                                    */
#define G729EV_G729_AGC_FAC         (REAL)0.9875             /* gain adjustment factor             */
#define G729EV_G729_AGC_FAC1        ((REAL)1. - G729EV_G729_AGC_FAC)    /* gain adjustment factor  */

/* Array sizes */
#define G729EV_G729_MEM_RES2 (G729EV_G729_PIT_MAX + 1 + G729EV_G729_LH_UP_L)
#define G729EV_G729_SIZ_RES2 (G729EV_G729_MEM_RES2 + G729EV_G729_L_SUBFR)
#define G729EV_G729_SIZ_Y_UP  ((G729EV_G729_F_UP_PST-1) * G729EV_G729_L_SUBFRP1)
#define G729EV_G729_SIZ_TAB_HUP_L ((G729EV_G729_F_UP_PST-1) * G729EV_G729_LH2_L)
#define G729EV_G729_SIZ_TAB_HUP_S ((G729EV_G729_F_UP_PST-1) * G729EV_G729_LH2_S)

/***************************************************************************************** */

#define G729EV_G729_PRM_SIZE_MAX    17

#define G729EV_G729_MEM_LEN_TAM    150  /* Maximum G.729 pitch not enough, higher then 143 */
#define G729EV_G729_LEN_MEMTAM_UPDATE_UPDATE (G729EV_G729_MEM_LEN_TAM-G729EV_G729_L_FRAME)
#define G729EV_G729_LEN_MEMTAM_UPDATE_TAM (G729EV_G729_MEM_LEN_TAM-G729EV_G729_L_SUBFR)
#define G729EV_G729_MAXTAMLIM 3
#define G729EV_G729_MINTAMLIM 2

#define G729EV_G729_FLT_MAX_G729    (REAL)1.e38                 /* largest floating point number */
#define G729EV_G729_FLT_MIN_G729    -G729EV_G729_FLT_MAX_G729   /* largest floating point number */

#endif  /*__G729EV_G729_DEFINES_H__ */
