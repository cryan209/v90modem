/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include <math.h>
#include <stdlib.h>

/*------------------------------------------------------------------------------*
 *  G729EV_G729_Gain_predict()        : make gcode0(exp_gcode0)                 *
 *  G729EV_G729_Gain_update()         : update table of past quantized energies.*
 *                                                        (frame erasure)       *
 *    This function is used both Coder and Decoder.                             *
 *------------------------------------------------------------------------------*/

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"


/*--------------------------------------------------------------------------*
* Function  G729EV_G729_Gain_predict :                                      *
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      *
* MA prediction is performed on the innovation energy (in dB with mean      *
* removed).                                                                 *
*---------------------------------------------------------------------------*/

void G729EV_G729_Gain_predict(REAL past_qua_en[], /* (i)     :Past quantized energies        */
                              REAL code[],        /* (i)     :Innovative vector.             */
                              int l_subfr,        /* (i)     :Subframe length.               */
                              REAL * gcode0       /* (o)     :Predicted codebook gain        */
    )
{
  REAL      ener_code, pred_code;
  int       i;

  pred_code = G729EV_G729_MEAN_ENER;

  /* innovation energy */
  ener_code = (REAL) 0.01;
  for (i = 0; i < l_subfr; i++)
    ener_code += code[i] * code[i];
  ener_code = (REAL) 10.0 *(REAL) log10(ener_code / (REAL) l_subfr);

  pred_code -= ener_code;

  /* predicted energy */
  for (i = 0; i < 4; i++)
    pred_code += pred[i] * past_qua_en[i];

  /* predicted codebook gain */
  *gcode0 = (REAL) pow((double) 10.0, (double) (pred_code / 20.0)); /* predicted gain */

  return;
}

/*--------------------------------------------------------------------------*
* Function  G729EV_G729_Gain_update :                                       *
* ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
* update table of past quantized energies                                   *
*---------------------------------------------------------------------------*/

void G729EV_G729_Gain_update(REAL past_qua_en[],  /*(i/o)  :Past quantized energies            */
                             REAL L_gbk12         /*(i)    : gbk1[indice1][1]+gbk2[indice2][1] */
    )
{
  int       i;

  /* update table of past quantized energies */
  for (i = 3; i > 0; i--)
    past_qua_en[i] = past_qua_en[i - 1];
  past_qua_en[0] = (REAL) 20.0 *(REAL) log10((double) L_gbk12);

  return;
}
