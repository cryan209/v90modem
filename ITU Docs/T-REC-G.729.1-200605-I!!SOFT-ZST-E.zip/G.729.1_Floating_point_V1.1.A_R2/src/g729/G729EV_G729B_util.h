/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_G729B_UTIL_H__
#define __G729EV_G729B_UTIL_H__

void      G729EV_G729B_Get_decfreq_prev(REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                        REAL x[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729B_Update_decfreq_prev(REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                           REAL x[G729EV_G729_MA_NP][G729EV_G729_M]);

#endif
