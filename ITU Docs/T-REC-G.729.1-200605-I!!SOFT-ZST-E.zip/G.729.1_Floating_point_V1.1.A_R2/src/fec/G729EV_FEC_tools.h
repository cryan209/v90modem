/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TOOLS_H__
#define __G729EV_TOOLS_H__

/*-----------------------------------------------------------*
 * Tool library
 * ~~~~~~~~~~~~~~~~~~~                                             
 *-----------------------------------------------------------*/


/* definitions and prototypes */
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"


INT16     G729EV_Emaximum2(                   /* o:   return index with energy value in vector  */
                            const REAL * vec, /* i:   input vector                 */
                            int lvec,         /* i:   length of input vector       */
                            REAL * ener_max   /* o:   maximum energy value         */
    );
REAL      G729EV_Dot_product(                 /* o:   Sum              */
                              const REAL x[], /* i:   x vector         */
                              const REAL y[], /* i:   y vector         */
                              int lg          /* i:   vector length    */
    );
void      G729EV_G729_Int_qlpc_bfi(REAL lsp_old[],  /* input : LSP vector of past frame              */
                                   REAL lsp_new[],  /* input : LSP vector of present frame           */
                                   REAL Az[],       /* output: interpolated Az() for the 2 subframes */
                                   const REAL * interpol_frac1);

REAL      G729EV_FEC_voice_factor(                /* (o) : factor (-1=unvoiced to 1=voiced) */
                                   REAL exc[],    /* (i) : pitch excitation                 */
                                   REAL gain_pit, /* (i) : gain of pitch                    */
                                   REAL code[],   /* (i) : Fixed codebook excitation        */
                                   REAL gain_code /* (i) : gain of code                     */
    );
REAL      G729EV_FEC_Lsf_stab(                      /* o:   LP filter stability */
                               const REAL * Lsf,    /* i:   LSF vector          */
                               const REAL * Lsfold  /* i:   old LSF vector      */
    );


#endif /* __G729EV_TOOLS_H__ */
