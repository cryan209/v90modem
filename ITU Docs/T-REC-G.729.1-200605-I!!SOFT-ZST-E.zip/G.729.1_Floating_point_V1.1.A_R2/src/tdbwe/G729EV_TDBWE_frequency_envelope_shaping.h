/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDBWE_FREQUENCY_ENVELOPE_SHAPING_H__
#define __G729EV_TDBWE_FREQUENCY_ENVELOPE_SHAPING_H__

#include "G729EV_MAIN_defines.h"

#include "G729EV_TDBWE_extract_frequency_envelope.h"
#include "G729EV_TDBWE_fir.h"


/* type definition for the state of the frequency envelope shaping
   module */
typedef struct
{
  REAL      filter_coeffs[G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH];
  G729EV_TDBWE_fir_state fir;
} G729EV_TDBWE_frequency_envelope_shaping_state;


/* prototypes for exported functions */

void      G729EV_TDBWE_frequency_envelope_shaping_initialize(G729EV_TDBWE_frequency_envelope_shaping_state * state);

void      G729EV_TDBWE_frequency_envelope_shaping(G729EV_TDBWE_frequency_envelope_shaping_state * state,
                                                  REAL * input, REAL * output, REAL * desired_envelope);

/* tables */

extern const REAL G729EV_TDBWE_fes_coeffs_matrix[221];

#endif
