/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDBWE_ENCODER_H__
#define __G729EV_TDBWE_ENCODER_H__


#include "G729EV_MAIN_defines.h"

/* type definition TDBWE encoder state variable */
typedef struct
{

  REAL      old_speech[G729EV_TDBWE_MEM_SPEECH];

} G729EV_TDBWE_CODSTAT;


/* prototypes for exported functions */

void      G729EV_TDBWE_encoder_init(G729EV_TDBWE_CODSTAT * state);

void      G729EV_TDBWE_encoder(G729EV_TDBWE_CODSTAT * state,
                               REAL * input_hi, int *coder_parameters, REAL * input_hi_delay);

#endif
