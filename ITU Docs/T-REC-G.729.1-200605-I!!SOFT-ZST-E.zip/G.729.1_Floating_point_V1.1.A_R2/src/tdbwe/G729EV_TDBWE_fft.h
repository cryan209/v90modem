/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDBWE_FFT_H__
#define __G729EV_TDBWE_FFT_H__

#include "G729EV_MAIN_defines.h"


/* prototype for exported function */

void      G729EV_TDBWE_fft(REAL * x, REAL * reX, REAL * imX, int vector_size, int *nls);


/* tables */

extern const REAL G729EV_TDBWE_fft_halsec[20];
extern const REAL G729EV_TDBWE_fft_costab[20];
extern const REAL G729EV_TDBWE_fft_sintab[20];
extern REAL G729EV_TDBWE_fft_coswrk[20];
extern REAL G729EV_TDBWE_fft_sinwrk[20];

/* TD-BWE constants for FFT computation */

#define G729EV_TDBWE_fft_SQRT2_2   ((REAL)0.70710678118654752440084436210484)
#define G729EV_TDBWE_fft_SQRT2     ((REAL)(2*0.70710678118654752440084436210484))

/* TD-BWE macros for trigonometric functions */

#define G729EV_TDBWE_fft_FHT_SWAP(a,b,t) {(t)=(a);(a)=(b);(b)=(t);}

#define G729EV_TDBWE_fft_TRIG_VARS    \
  int t_lam=0;

#define G729EV_TDBWE_fft_TRIG_INIT(k,c,s)                                         \
  {         \
    int i;        \
    for (i=2 ; i<=k ; i++)      \
      {G729EV_TDBWE_fft_coswrk[i]=G729EV_TDBWE_fft_costab[i];G729EV_TDBWE_fft_sinwrk[i]=G729EV_TDBWE_fft_sintab[i];}   \
    t_lam = 0;        \
    c = 1;        \
    s = 0;        \
  }

#define G729EV_TDBWE_fft_TRIG_NEXT(k,c,s)                                         \
  {         \
    int i,j;        \
    (t_lam)++;        \
    for (i=0 ; !((1<<i)&t_lam) ; i++);     \
    i = k-i;        \
    s = G729EV_TDBWE_fft_sinwrk[i];       \
    c = G729EV_TDBWE_fft_coswrk[i];       \
    if (i>1)        \
      {         \
 for (j=k-i+2 ; (1<<j)&t_lam ; j++);    \
 j         = k - j;      \
 G729EV_TDBWE_fft_sinwrk[i] = G729EV_TDBWE_fft_halsec[i] * (G729EV_TDBWE_fft_sinwrk[i-1] + G729EV_TDBWE_fft_sinwrk[j]);  \
 G729EV_TDBWE_fft_coswrk[i] = G729EV_TDBWE_fft_halsec[i] * (G729EV_TDBWE_fft_coswrk[i-1] + G729EV_TDBWE_fft_coswrk[j]);  \
      }         \
  }

#define G729EV_TDBWE_fft_TRIG_RESET(k,c,s)


#endif
