/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include "G729EV_TDBWE_generate_excitation.h"

#include "G729EV_G729_ld8k.h"
#include "G729EV_MAIN_filt.h"

#include <math.h>

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_rand()                                           *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  TDBWE random generator                                                  *
 *  Same as Random() of G.729, except for seed type (INT32)                 *
 *--------------------------------------------------------------------------*/
REAL G729EV_TDBWE_rand(long *seed)
{
  INT16     tmp;

  tmp = (INT16) (*seed);
  *seed = tmp * 31821 + 13849L;
  tmp = (INT16) (*seed);

  return (REAL) tmp;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_generate_excitation_initialize()                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                 *
 *  initialization of TDBWE excitation generator                            *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_generate_excitation_initialize(G729EV_TDBWE_generate_excitation_state * state)  /* (i/o) */
{

  G729EV_G729_Set_zero(state->signal_tonal_buffer, G729EV_TDBWE_LENGTH_PULSE_SHAPE);

  G729EV_MAIN_init_lp3k(&(state->lowpass_3_kHz));

  state->old_lag = 60;
  state->old_gain_tonal = (REAL) 0.0;

  state->prev_pulse = G729EV_TDBWE_L_FRAME2;
  state->prev_pulse_frac = 0;

  state->seed = 0x78a426da;

  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_generate_excitation_initialize()                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                 *
 *  TDBWE excitation generator: produce pitch-synchronous excitation        *
 *  signal based on G.729 parameters                                        *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_generate_excitation(G729EV_TDBWE_generate_excitation_state * state, /* (i/o) generate excitation state               */
                                      G729EV_TDBWE_g729_info * parameters,            /* (i)   parameters from G.729A+ (8k/12k layers) */
                                      REAL * output)                                  /* (o)   output signal                           */
{
  int       i, l;
  REAL      gain_tonal[2];
  REAL      new_gain_tonal;
  REAL      gain_noise[2];
  int       lag[2] = { 0, 0 };
  int       frac_lag[2] = { 0, 0 };
  int       next_pulse;
  int       next_pulse_frac;
  REAL      signal_tonal[G729EV_TDBWE_L_FRAME2 + G729EV_TDBWE_LENGTH_PULSE_SHAPE];

  REAL      lfr_raw, lfr;
  REAL      power_fix;
  REAL      power_ltp;

  REAL      gain;
  int       factor;
  REAL      error;
  int       new_lag;

  /* Compute ltp-to-fix power ratio (LFR) from NB excitation.
     We implicitly assume here that the adaptive codebook contributes
     only tonal components and the fixed codebook contributes noisy
     components only, and that the contributions are orthogonal. */

  for (l = 0; l < 2; l++)       /* for two 5ms subframes */
  {
    power_fix = parameters->power_fix[l];
    power_ltp = parameters->power_ltp[l];

    /* instantaneous ltp-to-fix ratio (LFR) */
    if (power_fix > 0.0)
    {
      lfr_raw = power_ltp / power_fix;
    }
    else
    {
      lfr_raw = 0.0;
    }

    /* apply kind of "Wiener filtering" to get "nice" noise segments later */
    lfr = lfr_raw * lfr_raw / ((REAL) 1.0 + lfr_raw);

    /* determine gain factors (incl. gliding average length 2) */
    gain_tonal[l] = (REAL) sqrt(lfr / ((REAL) 1.0 + lfr));
    new_gain_tonal = (REAL) sqrt((REAL) 0.5 *
                                 (gain_tonal[l] * gain_tonal[l] + state->old_gain_tonal * state->old_gain_tonal));
    state->old_gain_tonal = gain_tonal[l];

    gain_tonal[l] = new_gain_tonal;
    gain_noise[l] = (REAL) sqrt((REAL) 1.0 - gain_tonal[l] * gain_tonal[l]);
  }


  /* Remove certain obvious pitch-doubling errors from pitch lag
     contour.  Here, we assume that a rise of the pitch lag by
     (about) an integer factor from one sub-frame to another
     corresponds to a beginning pitch-doubling error. A small drawback
     is that this mechanism may produce half-pitch errors. */

  for (l = 0; l < 2; l++)       /* for two 5ms subframes */
  {
    lag[l] = (int) (6 * parameters->lag[l] + 2 * parameters->frac_lag[l]);

    factor = (int) floor((REAL) lag[l] / (REAL) state->old_lag + 0.5);

    if ((factor > 1) && (factor < 5))
    {
      error = (REAL) lag[l] / ((REAL) factor * (REAL) state->old_lag);
      if (fabs(1.0 - error) < 0.1)
        lag[l] = (int) floor((REAL) lag[l] / (REAL) factor + 0.5);
    }

    /* simple low-pass filtering (gliding average length 2) */
    new_lag = (state->old_lag + lag[l]) / 2;
    state->old_lag = lag[l];

    lag[l] = new_lag / 6;
    frac_lag[l] = new_lag - 6 * lag[l];
  }


  /* produce tonal contributions */

  G729EV_G729_Copy(state->signal_tonal_buffer, signal_tonal, G729EV_TDBWE_LENGTH_PULSE_SHAPE);
  G729EV_G729_Set_zero(signal_tonal + G729EV_TDBWE_LENGTH_PULSE_SHAPE, G729EV_TDBWE_L_FRAME2);

  state->prev_pulse -= G729EV_TDBWE_L_FRAME2;
  next_pulse = state->prev_pulse + lag[0];
  next_pulse_frac = state->prev_pulse_frac + frac_lag[0];

  while (next_pulse_frac >= 6)
  {
    next_pulse_frac -= 6;
    next_pulse++;
  }

  if (next_pulse < 0)
    next_pulse = 0;

  for (l = 0; l < 2; l++)
  {
    while (next_pulse < (l + 1) * G729EV_TDBWE_L_FRAME4)
    {
      gain = (REAL) sqrt(lag[l] * 6 + frac_lag[l]) * gain_tonal[l];

      if (next_pulse % 2 == 0)
        gain *= -1.0;

      for (i = 0; i < G729EV_TDBWE_LENGTH_PULSE_SHAPE; i++)
      {
        signal_tonal[next_pulse + i] += gain *
            G729EV_TDBWE_pulse_shapes_frac6[next_pulse_frac * G729EV_TDBWE_LENGTH_PULSE_SHAPE + i];
      }

      state->prev_pulse = next_pulse;
      state->prev_pulse_frac = next_pulse_frac;

      next_pulse = state->prev_pulse + lag[l];
      next_pulse_frac = state->prev_pulse_frac + frac_lag[l];

      while (next_pulse_frac >= 6)
      {
        next_pulse_frac -= 6;
        next_pulse++;
      }
    }
  }

  G729EV_G729_Copy(signal_tonal, output, G729EV_TDBWE_L_FRAME2);
  G729EV_G729_Copy(&signal_tonal[G729EV_TDBWE_L_FRAME2], state->signal_tonal_buffer, G729EV_TDBWE_LENGTH_PULSE_SHAPE);


  /* produce and add noise contributions */

  for (i = 0; i < G729EV_TDBWE_L_FRAME4; i++)
  {
    output[i] += gain_noise[0] * (REAL) (G729EV_TDBWE_rand(&(state->seed)) - 0.5);
  }

  for (i = G729EV_TDBWE_L_FRAME4; i < G729EV_TDBWE_L_FRAME2; i++)
  {
    output[i] += gain_noise[1] * (REAL) (G729EV_TDBWE_rand(&(state->seed)) - 0.5);
  }

  /* use additional 3 kHz lowpass */

  G729EV_MAIN_lp3k(&(state->lowpass_3_kHz), output, G729EV_TDBWE_L_FRAME2);
}
