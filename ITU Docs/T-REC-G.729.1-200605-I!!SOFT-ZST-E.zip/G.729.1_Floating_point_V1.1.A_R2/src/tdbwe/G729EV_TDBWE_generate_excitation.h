/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDBWE_GENERATE_EXCITATION_H__
#define __G729EV_TDBWE_GENERATE_EXCITATION_H__

#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"



/* type definition for excitation information (for 10 ms frames)
   from the G.729A+ baseband codec */
typedef struct
{

  REAL      power_ltp[2];
  REAL      power_fix[2];
  REAL      lag[2];
  REAL      frac_lag[2];

} G729EV_TDBWE_g729_info;


/* type definition for the excitation generator's state */
typedef struct
{
  G729EV_MAIN_IIRN_STAT lowpass_3_kHz;

  REAL      signal_tonal_buffer[G729EV_TDBWE_LENGTH_PULSE_SHAPE];

  int       old_lag;
  REAL      old_gain_tonal;
  long      seed;

  int       prev_pulse;
  int       prev_pulse_frac;

} G729EV_TDBWE_generate_excitation_state;

/* prototypes for exported functions */

void      G729EV_TDBWE_generate_excitation_initialize(G729EV_TDBWE_generate_excitation_state * state);

void
 
 
 G729EV_TDBWE_generate_excitation(G729EV_TDBWE_generate_excitation_state * state,
                                  G729EV_TDBWE_g729_info * parameters, REAL * output);

/* tables */

extern const REAL G729EV_TDBWE_pulse_shapes_frac6[G729EV_TDBWE_LENGTH_PULSE_SHAPE * G729EV_TDBWE_NUMBER_PULSE_SHAPES];

#endif
