/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/


#ifndef __G729EV_CELP2S_ENCODE_H__
#define __G729EV_CELP2S_ENCODE_H__

#include <stdio.h>
#include "CodecTypedef.h"

#include "G729EV_CELP2S.h"

#include "G729EV_G729_ld8k.h"
#include "G729EV_CELP2S_acelp_ca.h"
#include "G729EV_CELP2S_qua_gain.h"

/* Functions */
void      G729EV_CELP2S_InitEncoder(G729EV_G729_CODSTAT * pCodStat, int rate);

void      G729EV_CELP2S_encoder(G729EV_G729_CODSTAT * pCodStat, /* (i)  core coder states vaiables  */
                                REAL * DataIn,                  /* (i)  data to encode              */
                                int *coder_parameters,          /* (o)  coder parameters            */
                                REAL * synth,                   /* (o)  Synthesis signal            */
                                int SubFrNum,                   /* (i)  Subframe number             */
                                REAL * celp_Az,                 /* (i)  Az buffer                   */
                                REAL * sp_sync,                 /* (0) weighted synthesis           */
                                REAL * resBF8k,                 /* (0) residual signal frame        */
                                INT16 * pit_ol,                 /* (0) open loop pitch values for 3 half-frames */
                                INT16 * t0,                     /* (0) close loop integer pitch                */
                                INT16 * t0_frac,                /* (0) close loop fractional part of the pitch */
                                REAL * voicing,                 /* (0) frame voicing                */
                                REAL * ee,                      /* (o) spectral tilt information    */
                                REAL * diff                     /* (o) difference signal between input and local  */
                                                                /*     synthesis at 12 kbit/s                     */
    );

#endif  /*__G729EV_CELP2S_ENCODE_H__ */
