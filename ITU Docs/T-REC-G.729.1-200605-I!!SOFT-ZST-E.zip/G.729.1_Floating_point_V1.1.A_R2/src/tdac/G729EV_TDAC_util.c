/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include <stdlib.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_util.h"



/****************************************************************************/
/* ROUTINE FOR FLOATING POINT TO FIXED POINT CONVERSION                     */
/****************************************************************************/
INT16 G729EV_MAIN_c_REAL_INT16(REAL round_var)
{
  /* rounding procedure */
    /***********************/
  round_var = (round_var < (REAL) 0.) ? round_var - (REAL) 0.5 : round_var + (REAL) 0.5;

  /* limitation to [-32768 32767] (16 bits) */
    /***************************/
  round_var = (round_var <= -32768.0) ? (REAL) - 32768.0 : ((round_var >= 32767.0) ? (REAL) 32767.0 : round_var);

  return ((INT16) round_var);

}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_pushBit()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Push bits of codeword (UWord16) into bitstream array                    *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_pushBit(UINT16 code,   /* (i)      codeword                        */
                         INT16 ** pBit, /* (i/o)    pointer on adress of next bit   */
                         int nbit)      /* (i)      number of bits of code          */
{
  int       i, nbitm1;
  INT16     mask;

  /* MSB -> LSB */
  nbitm1 = nbit - 1;
  for (i = nbitm1; i >= 0; i--)
  {
    *(*pBit) = ITU_G192_BIT_1;
    mask = (INT16) ((code >> i) & 0x0001);
    if (mask == 0)
    {
      *(*pBit) = ITU_G192_BIT_0;
    }

    (*pBit)++;
  }
  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_pushBitL()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 *  Push bits of codeword (UWord32) into bitstream array                    *
 *--------------------------------------------------------------------------*/

void G729EV_TDAC_pushBitL(UINT32 code,    /* (i)      codeINT                        */
                          INT16 ** pBit,  /* (i/o)    pointer on adress of next bit   */
                          int nbit)       /* (i)      number of bits of code          */
{
  UINT32    t, bit;

  int       i, temp;

  /* write bits sequentially */
  temp = nbit - 1;

  for (i = temp; i >= 0; i--)
  {
    *(*pBit) = (INT16) ITU_G192_BIT_1;
    t = code >> i;
    bit = t & 0x01;
    if (bit == 0)
    {
      *(*pBit) = (INT16) ITU_G192_BIT_0;
    }
    (*pBit)++;
  }
  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_getBit()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Get bits of codeword (UWord16) from bitstream array                     *
 *--------------------------------------------------------------------------*/

UINT16 G729EV_TDAC_getBit(INT16 ** pBit,  /* (i/o)    pointer on adress of next bit   */
                          int nbit)       /* (i)      number of bits of code          */
{
  int       i;

  UINT16    code;
  UINT16    temp16 = 0;

  code = (UINT16) 0;
  for (i = 0; i < nbit; i++)
  {
    code <<= 1;
    temp16 = (INT16) 1;
    if ((**pBit - ITU_G192_BIT_0) == 0)
    {
      temp16 = (INT16) 0;
    }

    code |= temp16;
    (*pBit)++;
  }

  return (code);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_getBitL()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Get bits of codeword (UWord32) from bitstream array                     *
 *--------------------------------------------------------------------------*/

UINT32 G729EV_TDAC_getBitL(INT16 ** pBit, /* (i/o)    pointer on adress of next bit   */
                           int nbit)      /* (i)      number of bits of code          */
{
  int       i;
  UINT32    code;

  code = (UINT32) 0;

  for (i = 0; i < nbit; i++)
  {
    code <<= 1;
    if (((**pBit) - ITU_G192_BIT_1) == 0)
    {
      code = code | 0x00000001; /* code = UL_add(code, (Word32) 1); */
    }
    (*pBit)++;
  }

  return (code);
}

/*-------------------------------------------------------------------------*
* Function copyRealToInt:  conversion  REAL array -> INT16 array      *
*-------------------------------------------------------------------------*/
void G729EV_MAIN_copyRealToInt(REAL * src, INT16 * dest, int n)
{
  int       i;
  REAL      temp;

  for (i = 0; i < n; i++)
  {
    if (src[i] < 0)
      temp = src[i] - (REAL) 0.5;
    else
      temp = src[i] + (REAL) 0.5;

    if (temp < -32768)
      dest[i] = -32768;
    else
    {
      if (temp > 32767)
        dest[i] = 32767;
      else
        dest[i] = (INT16) (temp);
    }
  }

  return;
}
