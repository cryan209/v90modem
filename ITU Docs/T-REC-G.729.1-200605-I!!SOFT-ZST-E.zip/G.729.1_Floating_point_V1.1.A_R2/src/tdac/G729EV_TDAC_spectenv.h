/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/


#ifndef __G729EV_TDAC_ENVSPECT_H__
#define __G729EV_TDAC_ENVSPECT_H__

#include <stdio.h>
#include "CodecTypedef.h"

/* Functions : */

void      G729EV_TDAC_calc_specEnv(REAL * y, REAL * log_rms, int n);
int       G729EV_TDAC_compute_diff_index(int *rms_index, int n, int *diff_index);
void      G729EV_TDAC_quant_3dB(int *index, REAL * log_rms, int norm_MDCT);
void      G729EV_TDAC_encode_spenv(int *rms_index, int *diff_index, INT16 * bitstream,
                                   int *nbit_env, int n, int satur, int norm_MDCT);
void      G729EV_TDAC_writ_specEnv(INT16 * bits_env, int *nb_bits_env, int n,
                                   int nbit, INT16 ** bitstream, int *bit_cnt);
void      G729EV_TDAC_cod_spenv(REAL * log_rms, int *rms_index, INT16 ** pBit,
                                int *bit_cnt, int nbit_to_encode, int norm_MDCT);
UINT16    G729EV_TDAC_read_bits(UINT16 * buffer, int len, INT16 ** bitstream, int *bit_cnt);
void      G729EV_TDAC_dec(UINT16 * buffer, INT16 ** bitstream, int *bit_cnt, int *rms_index, int norm_MDCT);
void      G729EV_TDAC_find_huffman(UINT16 * buffer, const INT16 * len, const UINT16 * code, int nb_code, int *k);
void      G729EV_TDAC_flush_buffer(UINT16 * buffer, int len, INT16 ** bitstream, int *bit_cnt);
int       G729EV_TDAC_decode_rms_index(INT16 ** bitstream, int *rms_index,
                                       int *bit_cnt, int nbit_to_decode, int n, UINT16 * buffer, int norm_MDCT);
void      G729EV_TDAC_calc_rms_q(int *rms_index, REAL * rmsq, int norm_MDCT, int *ndec);
void      G729EV_TDAC_dec_specEnv(INT16 ** bitstream, int *rms_index, REAL * rmsq,
                                  int *bit_cnt, int nbit_to_decode, int *ndec_nb, int *ndec_wb, int norm_MDCT);


/* Tables : */
extern const INT16 G729EV_TDAC_sb_bound[G729EV_TDAC_NB_SB + 1];
extern const INT16 G729EV_TDAC_len_huff_diff[25];
extern const UINT16 G729EV_TDAC_code_huff_diff[25];

#endif  /*__G729EV_TDAC_ENVSPECT_H__ */
