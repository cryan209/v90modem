/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/


#ifndef __G729EV_TDAC_POST_H__
#define __G729EV_TDAC_POST_H__

#include <stdio.h>
#include "CodecTypedef.h"


/* Functions */
void      G729EV_TDAC_PostProcess(REAL * ykr, int nbits);
void      G729EV_TDAC_PostModify(REAL * yq, int n_yq, REAL alfa);

#endif /* __G729EV_TDAC_POST_H__ */
