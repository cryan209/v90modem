/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/


#ifndef __G729EV_TDAC_TFR_H__
#define __G729EV_TDAC_TFR_H__

#include <stdio.h>
#include "CodecTypedef.h"

/* Functions : */
void      G729EV_TDAC_tfr(REAL * x1, REAL * x2, int sign);

/* Tables : */
extern const INT16 G729EV_TDAC_tab_map[G729EV_TDAC_NP * G729EV_TDAC_NPP];
extern const INT16 G729EV_TDAC_tab_map2[G729EV_TDAC_NP * G729EV_TDAC_NPP];
extern const INT16 G729EV_TDAC_tab_rev_i[G729EV_TDAC_NB_REV];
extern const INT16 G729EV_TDAC_tab_rev_ipp[G729EV_TDAC_NB_REV];
extern const REAL G729EV_TDAC_rw1[G729EV_TDAC_L_WIN4];
extern const REAL G729EV_TDAC_rw2[G729EV_TDAC_L_WIN4];
extern const REAL G729EV_TDAC_xcos[25];
extern const REAL G729EV_TDAC_xsin[25];

#endif  /*__G729EV_TDAC_TFR_H__ */
