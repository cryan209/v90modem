/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/


#ifndef __G729EV_TDAC_UTIL_H__
#define __G729EV_TDAC_UTIL_H__

#include <stdio.h>
#include "CodecTypedef.h"

/* Functions : */

INT16     G729EV_MAIN_c_REAL_INT16(REAL round_var);
void      G729EV_TDAC_pushBit(UINT16 code, INT16 ** pBit, int nbit);
void      G729EV_TDAC_pushBitL(UINT32 code, INT16 ** pBit, int nbit);
UINT16    G729EV_TDAC_getBit(INT16 ** pBit, int nbit);
UINT32    G729EV_TDAC_getBitL(INT16 ** pBit, int nbit);
void      G729EV_MAIN_copyRealToInt(REAL * src, INT16 * dest, int n);


/* Tables : */


#endif  /*__G729EV_TDAC_UTIL_H__ */
