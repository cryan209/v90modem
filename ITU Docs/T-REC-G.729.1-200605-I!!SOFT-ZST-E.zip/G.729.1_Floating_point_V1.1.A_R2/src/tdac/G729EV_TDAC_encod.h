/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDAC_ENCOD_H__
#define __G729EV_TDAC_ENCOD_H__

#include <stdio.h>
#include "CodecTypedef.h"

/* Functions : */
void      G729EV_TDAC_encoder(REAL * y_lo, REAL * y_hi, INT16 * bitstream, int nbit, int nbit_max, int norm_MDCT);

/* Tables : */

#endif /* __G729EV_TDAC_ENCOD_H__ */
