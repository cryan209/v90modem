/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/


#include <stdlib.h>
#include <math.h>
#include <string.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_codstat.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_CELP2S.h"
#include "G729EV_CELP2S_encod.h"
#include "G729EV_CELP2S_decod.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_encod.h"
#include "G729EV_TDAC_encod.h"
#include "G729EV_TDAC_util.h"
#include "G729EV_TDBWE_encoder.h"
#include "G729EV_TDAC_mdct.h"
#include "G729EV_TDAC_spectenv.h"
#include "G729EV_TDAC_post.h"
#include "G729EV_MAIN_envadaption.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_MAIN_prm.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_InitEncoder()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                     *
 *  Encoder Initializations                                                 *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_InitEncoder(CODSTATMAIN * codstat, /* (o)  Encoder states variables    */
                             int rate,              /* (i)  Encoder rate                */
                             int f8,                /* (i)  8kHz sampled input flag     */
                             int g729_bst)          /* (i)  G.729 bistream mode flag    */
{

  if (codstat == NULL)
    exit(-1);

  memset(codstat, 0, sizeof(*codstat));

  /* initialize QMF filterbank */
  G729EV_MAIN_initQMF_ana(&codstat->qmf_ana);

  /* initialize preprocessing of lower and higher bands */
  G729EV_MAIN_init_iir2(&codstat->mem_hp50);
  G729EV_MAIN_init_lp3k(&codstat->mem_lp3k);

  /* set the flag for 8kHz sampled input */
  codstat->f8 = f8;

  /* set the flag for g729 bitstream mode */
  codstat->g729_bst = g729_bst;

  /* initialize memories for MDCT computation */
  G729EV_G729_Set_zero(codstat->mem_mdct_lo, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Set_zero(codstat->mem_mdct_hi, G729EV_MAIN_L_FRAME2);

  /* initialize G729 encoder */
  G729EV_CELP2S_InitEncoder(&codstat->codStG729, rate);

  /* initialize FEC variables */
  codstat->oldferclass = G729EV_FEC_UNVOICED;
  codstat->lp_speech = 55.0f;

  codstat->relE_hist = 0.0f;
  codstat->relE_var = 0.0f;
  codstat->old_pulspos = 0;

  /* initialize TDBWE encoder */
  G729EV_TDBWE_encoder_init(&codstat->tdbwe);

  /* perceptual weighting filter of lower band difference signal */
  G729EV_G729_Set_zero(codstat->mem_Wz_in, G729EV_G729_M);
  G729EV_G729_Set_zero(codstat->mem_wsp, G729EV_G729_M);

  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_Encode()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Main encoder routine                                                    *
 *--------------------------------------------------------------------------*/

void G729EV_MAIN_Encode(CODSTATMAIN * codstat,      /* (i)  Encoder states variables        */
                        INT16 * samples_in,         /* (i)  Frame of samples to be encoded  */
                        INT16 * itu_192_bitstream,  /* (o)  G.192 bitstream                 */
                        int rate)                   /* (i)  Encoder rate                    */
{
  REAL      input[G729EV_MAIN_L_FRAME];
  REAL      input_lo[G729EV_MAIN_L_FRAME2];
  REAL      input_hi[G729EV_MAIN_L_FRAME2];
  REAL      input_hi_delay[G729EV_MAIN_L_FRAME2];
  REAL      celp_output[G729EV_MAIN_L_FRAME2];
  REAL      diff[G729EV_MAIN_L_FRAME2];
  REAL      y_lo[G729EV_MAIN_L_FRAME2];
  REAL      y_hi[G729EV_MAIN_L_FRAME2];

  REAL      voicing[6];
  REAL      sp_sync[G729EV_MAIN_L_FRAME2], resBF8k[G729EV_MAIN_L_FRAME2];
  REAL      ee[2];
  INT16     pit[4];
  int       coder_parameters[G729EV_G729_PRM_SIZE_MAX * 2 + 10];
  int      *coder_param_ptr;

  int       i, i_frame, j;
  int       nb_bits_max;        /* maximal bit allocation (-> 32 kbps) */
  int       nb_bits_left;       /* number of bits left */
  int       nb_bits_used;       /* number of bits used */
  INT16     clas, t0, t0_frac;
  int       norm_hi;
  int       norm_lo;
  int       norm_MDCT;

  G729EV_CELP2S_PARAM nb_celp_param;

  /* set number of bits for 20-ms frame */
  nb_bits_max = G729EV_MAX_BITRATE / 50;  /* maximal bit allocation (-> 32 kbit/s) */
  nb_bits_left = rate / 50;     /* actual bit allocation  (-> actual encoding bit rate) */

  /* initialize number of bytes */
  nb_bits_used = 0;
  coder_param_ptr = coder_parameters;

  /*************
   * buffering *
   *************/

  if (codstat->f8 == 0)
  {                             /* test if 8kHz sampled input */
    for (i = 0; i < G729EV_MAIN_L_FRAME; i++)
      input[i] = (REAL) samples_in[i];
  }
  else
  {
    for (i = 0; i < G729EV_MAIN_L_FRAME / 2; i++)
      input_lo[i] = (REAL) samples_in[i];
    for (i = 0; i < G729EV_MAIN_L_FRAME / 2; i++)
      input_hi[i] = (REAL) 0.0;
  }

  /***************************
   * QMF analysis filterbank *
   ***************************/
  if (codstat->f8 == 0)
  {                             /* test if 8kHz sampled input */
    /* filter */
    G729EV_MAIN_QMF_ana(&codstat->qmf_ana, input, input_lo, input_hi, G729EV_MAIN_L_FRAME);

    /* fold higher band */
    G729EV_MAIN_QMF_mirror(input_hi, G729EV_MAIN_L_FRAME2);
  }

  /**************************************************************
   * Encoding of lower band : 8k core and 12k enhancement layer
   * - preprocessing (HPF)
   * - cascade CELP encoder
   **************************************************************/

  /* preprocessing of lower band (50 Hz high-pass) */
  G729EV_MAIN_iir2(&codstat->mem_hp50, input_lo, G729EV_MAIN_L_FRAME2, G729EV_MAIN_hp50_b, G729EV_MAIN_hp50_a);

  for (i_frame = 0, j = 0; i_frame < (G729EV_MAIN_L_FRAME2); i_frame += G729EV_G729_L_FRAME, j++)
  {
    /* cascade CELP (10 ms frame) */
    G729EV_CELP2S_encoder(&codstat->codStG729, &input_lo[i_frame],
                          coder_param_ptr, &celp_output[i_frame],
                          j, nb_celp_param.Az,
                          &sp_sync[i_frame],
                          &resBF8k[i_frame], &(pit[2 * j]), &t0, &t0_frac, &voicing[j * 3], &ee[j], &diff[i_frame]);

    /* update bitscounter */
    if (rate >= 12000)
      nb_bits_used += 120;
    else
      nb_bits_used += 80;

    coder_param_ptr += G729EV_G729_PRM_SIZE_MAX;
  }

  /* update number of bits left to encode frame */
  nb_bits_left -= nb_bits_used;

   /***************************************************
    * Encoding of higher band : 14k enhancement layer
    * - preprocessing (LPF)
    * - TDBWE encoder
    ***************************************************/

  /* perform time-domain BWE */
  if (rate >= 14000)
  {
    if (codstat->f8 == 0)
    {
      /* preprocessing of higher band (3 kHz low-pass filter) */
      G729EV_MAIN_lp3k(&codstat->mem_lp3k, input_hi, G729EV_MAIN_L_FRAME2);

      G729EV_TDBWE_encoder(&codstat->tdbwe, input_hi, coder_param_ptr, input_hi_delay);
    }
    else
    {
      coder_param_ptr[0] = 0;
      coder_param_ptr[1] = 4;
      coder_param_ptr[2] = 4;
      coder_param_ptr[3] = 0;
      coder_param_ptr[4] = 21;
      coder_param_ptr[5] = 8;
    }

    /* update bits counter and number of bits left */
    nb_bits_used += 40;
    nb_bits_left -= 40;
  }
  coder_param_ptr += 6;         /* 6 parameters for TDBWE */


  /***************************************************
   * FEC Encoder
   ***************************************************/

  if (rate >= 12000)
  {

    /* Should compute FER parameters of next frame here; before lag */
    G729EV_FEC_encod(codstat->oldferclass, voicing, input_lo, celp_output, pit,
                     ee, sp_sync, &clas, coder_param_ptr, t0, t0_frac, resBF8k, &(codstat->lp_speech),
                     &(codstat->relE_hist), &(codstat->relE_var), &(codstat->old_pulspos));

    coder_param_ptr += 3;       /* 3 parameters in FEC */

    /* Update FER parameters memory  */
    codstat->oldferclass = clas;
  }


  /*************************************************************
   * Encoding of full-band spectrum: 16-32k enhancement layers
   * - perceptual weighting of difference signal
   * - MDCT of weighted difference signal
   * - MDCT of higher band signal
   * - TDAC encoder
   *************************************************************/

  if (rate >= 16000)
  {
    /* apply perceptual weighting filter */
    G729EV_MAIN_weighting_filter(nb_celp_param.Az, codstat->mem_Wz_in, codstat->mem_wsp, diff);

    /* perform MDCT of difference signal in lower band */
    norm_lo = G729EV_TDAC_mdct_norm(codstat->mem_mdct_lo, diff);
    for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
    {
      codstat->mem_mdct_lo[i] = codstat->mem_mdct_lo[i] * (REAL) pow(2, norm_lo);
      diff[i] = diff[i] * (REAL) pow(2, norm_lo);
    }
    G729EV_TDAC_mdct(codstat->mem_mdct_lo, diff, y_lo);
    for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
    {
      codstat->mem_mdct_lo[i] = codstat->mem_mdct_lo[i] / (REAL) pow(2, norm_lo);
      diff[i] = diff[i] / (REAL) pow(2, norm_lo);
    }

    /* compute MDCT of higher band */
    if (codstat->f8 == 0)
    {
      norm_hi = G729EV_TDAC_mdct_norm(codstat->mem_mdct_hi, input_hi_delay);
      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        codstat->mem_mdct_hi[i] = codstat->mem_mdct_hi[i] * (REAL) pow(2, norm_hi);
        input_hi_delay[i] = input_hi_delay[i] * (REAL) pow(2, norm_hi);
      }
      G729EV_TDAC_mdct(codstat->mem_mdct_hi, input_hi_delay, y_hi);
      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        codstat->mem_mdct_hi[i] = codstat->mem_mdct_hi[i] / (REAL) pow(2, norm_hi);
        input_hi_delay[i] = input_hi_delay[i] / (REAL) pow(2, norm_hi);
      }
    }
    else
    {
      norm_hi = norm_lo;
      G729EV_G729_Set_zero(y_hi, G729EV_MAIN_L_FRAME2);
    }

    /* use same norm for y_hi and y_lo --> norm_MDCT */
    if (norm_hi > norm_lo)
    {
      norm_MDCT = norm_lo;
      for (i = 0; i < (G729EV_MAIN_L_FRAME2); i++)
      {
        y_hi[i] = y_hi[i] / (REAL) pow(2, norm_hi - norm_lo);
      }
    }
    else
    {
      norm_MDCT = norm_hi;
      for (i = 0; i < (G729EV_MAIN_L_FRAME2); i++)
      {
        y_lo[i] = y_lo[i] / (REAL) pow(2, norm_lo - norm_hi);
      }
    }

    /* update maximum number of bits for encoding based on previous layers */
    nb_bits_max -= nb_bits_used;
    nb_bits_max -= 9;
    nb_bits_left -= 9;
    if (nb_bits_left < 0)
    {
      nb_bits_left = 0;
    }

    /* encode in MDCT domain difference signal in lower band and original signal 
       in higher band, using: 
       - number of bits for encoding (nb_bits_left)
       - number of bits for allocation (nb_bits_max)
     */

    /* write norm_shift in coder_parameters */
    *coder_param_ptr++ = norm_MDCT;

    /* apply TDAC */
    G729EV_TDAC_encoder(y_lo, y_hi, &itu_192_bitstream[289], nb_bits_left, nb_bits_max, norm_MDCT);
  }

  /***************************************************
   * Multiplexer
   ***************************************************/

  if (rate > 14000)
  {
    /* number of bytes counted in 8, 12 and 14k layers 
       + number of bits for TDAC layer + 5 bit of FEC + 4 bit of norm_shift in MDCT */
    nb_bits_used = nb_bits_used + 9 + nb_bits_left;
  }

  /* Create itu_192_bitstream */
  G729EV_MAIN_param2bit(coder_parameters, nb_bits_used, itu_192_bitstream, codstat);
}
