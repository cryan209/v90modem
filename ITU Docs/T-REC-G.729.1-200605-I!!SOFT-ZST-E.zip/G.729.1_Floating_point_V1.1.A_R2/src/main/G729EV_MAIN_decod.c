/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.1.a                                                          */
/* Revision Date: Feb 27, 2007                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include <stdlib.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_CELP2S_decod.h"
#include "G729EV_TDAC_decod.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_decod.h"
#include "G729EV_TDAC_util.h"
#include "G729EV_TDAC_tfr.h"
#include "G729EV_TDAC_mdct.h"
#include "G729EV_TDAC_spectenv.h"
#include "G729EV_TDAC_post.h"
#include "G729EV_TDBWE_decoder.h"
#include "G729EV_MAIN_envadaption.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_MAIN_prm.h"




/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_InitDecoder()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                     *
 *  Decoder Initializations                                                 *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_InitDecoder(DECSTATMAIN * decstat, /* (o)  decoder states variables    */
                             int f8,                /* (i)  8kHz sampled input flag     */
                             int g729b_bst,         /* (i)  G.729 bistream mode flag    */
                             int low_delay)         /* (i)  Low-delay mode flag         */
{
  int       i;

  if (decstat == NULL)
    exit(-1);

  memset(decstat, 0, sizeof(*decstat));

  /* set previous bad frame indicator */
  decstat->prev_bfi = 0;

  /* set the flag for 8kHz sampled output */
  decstat->f8 = f8;

  /* set the flag for g729 bitstream mode */
  decstat->g729b_bst = g729b_bst;

  /* low delay mode flag */
  decstat->low_delay = low_delay;

  /* initialize QMF filterbank */
  G729EV_MAIN_initQMF_syn(&decstat->qmf_syn);

  /* initialize CELP decoder */
  G729EV_CELP2S_InitDecoder(&decstat->decStG729, g729b_bst);

  /* initialize memories for MDCT computation */
  G729EV_G729_Set_zero(decstat->mem_mdct_hi, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Set_zero(decstat->mem_inv_mdct_lo, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Set_zero(decstat->mem_inv_mdct_hi, G729EV_MAIN_L_FRAME2);

  G729EV_G729_Set_zero(decstat->sTdbweOld, G729EV_MAIN_L_FRAME2);

  decstat->vmhold = (REAL) 1.0;
  decstat->vmlold = (REAL) 1.0;

  /* initialize TDBWE decoder */
  G729EV_TDBWE_decoder_init(&decstat->tdbwe);

  /* initialize memory of previous CELP-decoded frame (for difference computation in lower band) */
  G729EV_G729_Set_zero(decstat->old_celp_output, G729EV_MAIN_L_FRAME2);

  /* postfiltering */
  G729EV_G729_Set_zero(decstat->mem_pf_in, G729EV_G729_M_LPC);
  G729EV_CELP2S_init_post_filter(&decstat->mem_pf);
  G729EV_G729_Set_zero(decstat->mem_Az, 4 * G729EV_G729_MP1);
  for (i = 0; i < (4 * G729EV_G729_MP1); i += G729EV_G729_MP1)
    decstat->mem_Az[i] = (REAL) 1.0;
  for (i = 0; i < 4; i++)
    decstat->mem_t0[i] = 60;

  /* post processing */
  if (low_delay == 0)
    decstat->mem_postflag = 0;
  else
    decstat->mem_postflag = 1;

  G729EV_MAIN_init_iir2(&decstat->mem_postpro);

  /* perceptual weighting filter of lower band difference signal */
  G729EV_G729_Set_zero(decstat->mem_invWz_in, G729EV_G729_M);
  G729EV_G729_Set_zero(decstat->mem_invwsp, G729EV_G729_M);

  /* bitrate switching initialization */
  decstat->count_rcv = G729EV_MAIN_COUNT_RCV_MAX;
  decstat->first_frame = 1;
  decstat->prev_nRcv_hi = 0;
  decstat->prev_rate = 0;

  /* initialize FEC module */
  decstat->lp_ener_FER = 60.0f;
  decstat->lastgood = G729EV_FEC_UNVOICED;
  decstat->plast_good = G729EV_FEC_UNVOICED;
  decstat->old_enrLP = 0.0f;
  G729EV_G729_Set_zero(decstat->synth_buf, G729EV_G729_PIT_MAX);

  /* initialize memory for median filter to smooth the gamma parameters of the postfilter */
  G729EV_G729_Set_zero(decstat->tab_Th, G729EV_MAIN_NMAX);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_Decode()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Main decoder routine                                                    *
 *--------------------------------------------------------------------------*/

void G729EV_MAIN_Decode(DECSTATMAIN * decstat,      /* (i)  decoder states variables        */
                        INT16 * itu_192_bitstream,  /* (i)  G.192 bitstream to decode       */
                        INT16 * tabout,             /* (o)  20 ms  speech signal            */
                        int rate,                   /* (i)  Decoding rate                   */
                        int bfi                     /* (i)  Bad Frame Indicator             */
    )
{
  G729EV_CELP2S_PARAM nb_celp_param;
  G729EV_MAIN_PFSTAT *pfstat;

  REAL      enr_q;

  REAL      celp_output[G729EV_MAIN_L_FRAME2];
  REAL      output_lo[G729EV_MAIN_L_FRAME2];
  REAL      output_hi[G729EV_MAIN_L_FRAME2];
  REAL      output_hiTdbwe[G729EV_MAIN_L_FRAME2];
  REAL      diff_q[G729EV_MAIN_L_FRAME2];
  REAL      yq_lo[G729EV_MAIN_L_FRAME2];
  REAL      yt_hi[G729EV_MAIN_L_FRAME2];
  REAL      yq_hi[G729EV_MAIN_L_FRAME2];
  REAL      pst_in[G729EV_MAIN_L_FRAME2];
  REAL      output[G729EV_MAIN_L_FRAME];
  REAL      parameters_tdbwe[G729EV_TDBWE_NB_PARAMETERS];
  REAL      pf_in_buffer[G729EV_G729_M_LPC + G729EV_MAIN_L_FRAME2];
  REAL      coreExc[G729EV_MAIN_L_FRAME2], extExc[G729EV_MAIN_L_FRAME2], BfAq[4 * G729EV_G729_MP1];
  REAL      pitch_buf[G729EV_MAIN_NB_SUBFR];
  REAL      mem_syntmp[G729EV_G729_M];
  int       ind_fer[3];
  INT32     parm_FEC[13];
  int       coder_parameters[G729EV_G729_PRM_SIZE_MAX * 2 + 10];

  REAL     *ptr_Az;
  REAL     *pf_in;
  int      *coder_param_ptr;

  int       i_frame, i, j, ind;
  int       nb_bits_to_decode;
  int       nb_bits_left;
  int       nb_bits_used;
  int       nb_bits_max;
  int       norm_MDCT;
  int       norm_local;
  int       diff_norm;
  int       nRcv_hi;
  int       t0_first;           /* Pitch lag in 1st subframe   */
  REAL      ga1_post, ga2_post;
  REAL      tmp;
  INT16     clas;
  INT16     FerPitch;
  int       begin_index_low, end_index_low, begin_index_high, end_index_high; /*beggining & end of the false alarm zone */


  /* set pointer to parameters */
  coder_param_ptr = coder_parameters;

  /* compute number of bits to decode */
  nb_bits_to_decode = rate / 50;

  /* set FEC variables */
  enr_q = -1.0f;
  clas = decstat->lastgood;
  pitch_buf[0] = decstat->decStG729.pit_mem[0];
  pitch_buf[1] = decstat->decStG729.pit_mem[1];
  pitch_buf[2] = decstat->decStG729.pit_mem[2];
  pitch_buf[3] = decstat->decStG729.pit_mem[3];

  ind_fer[0] = -1000;
  ind_fer[1] = -1000;
  ind_fer[2] = -1000;

  /* set frame type (ftyp) for G.729B decoding */
  if (decstat->g729b_bst && bfi)
  {
    if (decstat->decStG729.past_ftyp == 1)
    {
      decstat->decStG729.ftyp[0] = 1;
      decstat->decStG729.ftyp[1] = 1;
    }
    else
    {
      decstat->decStG729.ftyp[0] = 0;
      decstat->decStG729.ftyp[1] = 0;
    }
  }

  if ((!bfi) || ((decstat->g729b_bst) && (decstat->decStG729.ftyp[0] == 0)))
  {
    /************************************ decode received frame (bfi=0) **************************/

    /***************************
     * Initialize bit counters *
     ***************************/

    /* set number of bits for 20-ms frame */
    nb_bits_max = G729EV_MAX_BITRATE / 50;  /* maximal bit allocation (-> 32 kbit/s) */
    nb_bits_left = nb_bits_to_decode; /* number of bits available for decoder */
    nb_bits_used = 0;           /* number of bits used */

    /*******************************************
     * Read bitstream and demultiplex parameters
     *******************************************/

    G729EV_MAIN_bit2param(itu_192_bitstream, nb_bits_to_decode, coder_parameters, ind_fer, decstat);

    /*********************************************************
     * decode FEC information (clas, puslse offset and energy)
     *********************************************************/

    if (rate >= 12000)          /* 12 kbps input */
    {
      clas =
          G729EV_FEC_dec(&(decstat->lastgood), decstat->plast_good, (INT16) decstat->prev_bfi, ind_fer, &enr_q, rate);
    }

    /************************************************************************
     * Update decoder CELP parameters if previous frame was erased (recovery)
     ************************************************************************/

    if ((decstat->prev_bfi == 1) && (decstat->low_delay == 0))
    {
      coder_parameters[3] = G729EV_G729_Check_Parity_Pitch(coder_parameters[2], coder_parameters[3]);

      /* The new clas is already known with the 14 kbit/s bitstream */
      G729EV_FEC_dec_bf(coder_parameters, decstat->old_celp_output, BfAq, G729EV_FEC_SINGLE_FRAME,
                        &(decstat->lastgood), pitch_buf, decstat->old_enrLP,
                        decstat->decStG729.old_exc, &(decstat->decStG729), clas, (INT16) ind_fer[2]);

      /* Update to be done before decoding a good frame */
      FerPitch = (INT16) (pitch_buf[0] + 0.5f);
      if (FerPitch < G729EV_G729_PIT_MIN)
        FerPitch = G729EV_G729_PIT_MIN;
      if (FerPitch > G729EV_G729_PIT_MAX)
        FerPitch = G729EV_G729_PIT_MAX;
      G729EV_G729_UpdateMemTam(&decstat->decStG729, decstat->decStG729.lp_gainp, FerPitch);
      G729EV_G729_UpdateMemTam(&decstat->decStG729, decstat->decStG729.lp_gainp, FerPitch);

      /* update memory of A(z) and t0_first */
      G729EV_G729_Copy(BfAq, decstat->mem_Az, 4 * G729EV_G729_MP1);
      for (i = 0; i < 4; i++)
      {
        decstat->mem_t0[i] = (INT16) (pitch_buf[i] + 0.5f);
      }
    }

    if ((clas == G729EV_FEC_SIN_ONSET) && (rate >= 14000) && (ind_fer[2] != 0))
    {
      if (rate < 16000)
      {
        /* Use reconstruct energy information when not present in bitstream */
        enr_q = decstat->decStG729.enr_old;
      }

      if (decstat->decStG729.bfi_cnt == 1)
        G729EV_FEC_mod_adapt_codebook(decstat->decStG729.old_exc, ind_fer[2], pitch_buf, enr_q,
                                      BfAq + 3 * G729EV_G729_MP1);
      else
        G729EV_FEC_mod_adapt_codebook(decstat->decStG729.old_exc, ind_fer[2], pitch_buf, enr_q,
                                      decstat->mem_Az + 3 * G729EV_G729_MP1);
    }

    G729EV_G729_Copy(decstat->decStG729.mem_syn, mem_syntmp, G729EV_G729_M);
    decstat->decStG729.lp_gainc = (REAL) 0.0;
    decstat->decStG729.lp_gainp = (REAL) 0.0;
    decstat->decStG729.i_subfr_cnt = 0;

    /**************************************************************
     * Decoding of lower band : 8k core and 12k enhancement layer *
     **************************************************************/

    for (i_frame = 0, j = 0; i_frame < G729EV_MAIN_L_FRAME2; i_frame += G729EV_G729_L_FRAME, j++)
    {
      /* get synthesis of G729/12k decoder (without postfilter) */
      G729EV_CELP2S_decoder(&decstat->decStG729, coder_param_ptr,
                            rate, j, &nb_celp_param,
                            &BfAq[j * 2 * G729EV_G729_MP1], &coreExc[i_frame], &extExc[i_frame], pitch_buf, clas, bfi);

      if (rate >= 12000)
      {
        nb_bits_used += 120;
      }
      else
      {
        nb_bits_used += 80;
      }

      /* update pointer to coder parameters offset */
      coder_param_ptr += G729EV_G729_PRM_SIZE_MAX;
    }

    /* number of bits lefts for decoding after CELP decoding */
    nb_bits_left -= nb_bits_used;

    G729EV_G729_syn(coreExc, extExc, BfAq, celp_output, decstat->decStG729.mem_syn, decstat->decStG729.rate);

    /* if clas is not tranmist */
    if (rate < 12000)
    {
      G729EV_FEC_clas_dec(&clas, pitch_buf, decstat->lastgood, celp_output, decstat->synth_buf,
                          &(decstat->lp_ener_FER));
    }

    G729EV_FEC_pit_updt(clas, pitch_buf, decstat->lastgood, &(decstat->decStG729.upd_cnt),
                        &(decstat->decStG729.old_fpitch), decstat->decStG729.fpitch);

    G729EV_FEC_scale_syn((INT16) nb_bits_left, clas, decstat->lastgood, celp_output, pitch_buf, enr_q,
                         (INT16) decstat->prev_bfi, BfAq, &(decstat->old_enrLP), mem_syntmp, coreExc,
                         decstat->decStG729.enr_old, decstat->decStG729.old_exc, decstat->decStG729.mem_syn,
                         decstat->decStG729.bfi_cnt);

    /***************************************************
    * Decoding of higher band : 14k enhancement layer *
    ***************************************************/
    if (rate >= 14000)
    {
      /* decode TDBWE parameters */
      G729EV_TDBWE_dequantization(coder_param_ptr, parameters_tdbwe);
      G729EV_TDBWE_decoder(&decstat->tdbwe, &nb_celp_param, output_hiTdbwe, parameters_tdbwe);

      /* copy TDBWE parameters for FEC */
      G729EV_G729_Copy(parameters_tdbwe, decstat->prev_parameters_tdbwe, G729EV_TDBWE_NB_PARAMETERS);
      for (i = 0; i < G729EV_MAIN_NB_SUBFR; i++)
      {
        decstat->prev_nb_celp_param.t0[i] = nb_celp_param.t0[i];
        decstat->prev_nb_celp_param.t0_frac[i] = nb_celp_param.t0_frac[i];
        decstat->prev_nb_celp_param.power_fix[i] = nb_celp_param.power_fix[i];
        decstat->prev_nb_celp_param.power_ltp[i] = nb_celp_param.power_ltp[i];
      }

      /* update byte counter and number of bits left */
      nb_bits_used += 40;
      nb_bits_left -= 40;

      /* update pointer to coder parameters offset */
      coder_param_ptr += 6;
    }
    else
    {
      /* if rate < 14000 TDBWE output is forced to 0 */
      G729EV_G729_Set_zero(output_hiTdbwe, G729EV_MAIN_L_FRAME2);
    }

    /*************************************************************
    * Decoding of full-band spectrum: 16-32k enhancement layers *
    *************************************************************/

    if (decstat->low_delay == 0)
    {
      /* update maximum number of bits for encoding based on previous layers */
      nb_bits_max -= nb_bits_used;

      /* decode TDAC module - get norm_MDCT value */
      norm_MDCT = *coder_param_ptr;

      /* compute MDCT of the TDBWE synthesis */
      norm_local = G729EV_TDAC_mdct_norm(decstat->mem_mdct_hi, output_hiTdbwe);
      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        decstat->mem_mdct_hi[i] = decstat->mem_mdct_hi[i] * (REAL) pow(2, norm_local);
        output_hiTdbwe[i] = output_hiTdbwe[i] * (REAL) pow(2, norm_local);
      }
      G729EV_TDAC_mdct(decstat->mem_mdct_hi, output_hiTdbwe, yt_hi);
      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        decstat->mem_mdct_hi[i] = decstat->mem_mdct_hi[i] / (REAL) pow(2, norm_local);
        output_hiTdbwe[i] = output_hiTdbwe[i] / (REAL) pow(2, norm_local);
      }

      /* Update nb_bits (read FEC (5 bits) + norm_shift (4 bits)) */
      nb_bits_max -= 9;
      if (rate >= 16000)
      {
        nb_bits_left -= 9;
      }
      else
      {
        nb_bits_left = 0;
        norm_MDCT = norm_local;
      }

      /* rescale yt_hi to be norm_shift compliant */
      diff_norm = norm_MDCT - norm_local;
      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        yt_hi[i] = yt_hi[i] * (REAL) pow(2, diff_norm);
      }

      /* TDAC decoder */
      G729EV_TDAC_decoder(&itu_192_bitstream[289], nb_bits_left, nb_bits_max, yt_hi, yq_lo, yq_hi, norm_MDCT);

      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        yq_hi[i] = yq_hi[i] / (REAL) pow(2, norm_MDCT);
      }

      /* post-process reconstructed higher-band spectrum */
      G729EV_TDAC_PostProcess(yq_hi, nb_bits_to_decode);

      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        yq_hi[i] = yq_hi[i] * (REAL) pow(2, norm_MDCT);
      }

      /* inverse MDCT to obtain
         - reconstructed difference signal in lower band
         - reconstructed signal in higher band */
      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        decstat->mem_inv_mdct_lo[i] = decstat->mem_inv_mdct_lo[i] * (REAL) pow(2, norm_MDCT);
        decstat->mem_inv_mdct_hi[i] = decstat->mem_inv_mdct_hi[i] * (REAL) pow(2, norm_MDCT);
      }
      G729EV_TDAC_inv_mdct(diff_q, yq_lo, decstat->mem_inv_mdct_lo);
      G729EV_TDAC_inv_mdct(output_hi, yq_hi, decstat->mem_inv_mdct_hi);
      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        decstat->mem_inv_mdct_lo[i] = decstat->mem_inv_mdct_lo[i] / (REAL) pow(2, norm_MDCT);
        decstat->mem_inv_mdct_hi[i] = decstat->mem_inv_mdct_hi[i] / (REAL) pow(2, norm_MDCT);
        diff_q[i] = diff_q[i] / (REAL) pow(2, norm_MDCT);
        output_hi[i] = output_hi[i] / (REAL) pow(2, norm_MDCT);
      }

      /* compute false alarm zones for pre/post-echo reduction */
      G729EV_MAIN_PreechoFalseAlarm(diff_q, decstat->mem_inv_mdct_lo, &decstat->max_prev_lo,
                                    &begin_index_low, &end_index_low);
      G729EV_MAIN_PreechoFalseAlarm(output_hi, decstat->mem_inv_mdct_hi, &decstat->max_prev_hi,
                                    &begin_index_high, &end_index_high);

      /* apply inverse weighting filter to the reconstructed lower-band difference signal */
      G729EV_MAIN_inverse_weighting_filter(decstat->mem_Az, decstat->mem_invWz_in, decstat->mem_invwsp, diff_q);

      /* preecho reduction & add 12k output to reconstructed difference signal */
      G729EV_MAIN_envAdapt(output_lo, decstat->old_celp_output, diff_q, &decstat->vmlold,
                           output_hi, decstat->sTdbweOld, output_hi, &decstat->vmhold, rate > 14000,
                           begin_index_low, end_index_low, begin_index_high, end_index_high);

      /* update output for next frame */
      G729EV_G729_Copy(output_hiTdbwe, decstat->sTdbweOld, G729EV_MAIN_L_FRAME2);
      G729EV_G729_Copy(celp_output, decstat->old_celp_output, G729EV_MAIN_L_FRAME2);
    }
    else
    {
      G729EV_G729_Copy(celp_output, output_lo, G729EV_MAIN_L_FRAME2);
      G729EV_G729_Copy(output_hiTdbwe, output_hi, G729EV_MAIN_L_FRAME2);
      G729EV_G729_Copy(celp_output, decstat->old_celp_output, G729EV_MAIN_L_FRAME2);
    }

    /********************************
     * Adapt bitrate switching gain *
     ********************************/

    /* count number of frames with same bandwidth */
    if (rate <= 12000)
    {
      nRcv_hi = 1;
    }
    else
    {
      nRcv_hi = 0;
    }

    if ((nRcv_hi == 0) && (decstat->prev_nRcv_hi == 0))
    {
      decstat->count_rcv++;
      if (decstat->count_rcv > G729EV_MAIN_COUNT_RCV_MAX)
        decstat->count_rcv = G729EV_MAIN_COUNT_RCV_MAX;
    }
    else
    {
      if (nRcv_hi != 0)
      {
        if (decstat->first_frame ||
            decstat->prev_nRcv_hi || ((decstat->prev_nRcv_hi == 0) && (decstat->count_rcv < G729EV_MAIN_COUNT_RCV_MAX)))
        {
          decstat->count_rcv = 0;
        }
      }
    }
    decstat->prev_nRcv_hi = nRcv_hi;
    decstat->first_frame = 0;

    /*******************************
     * Postfiltering in lower-band *
     *******************************/

    /* set adaptive gamma parameters of postfilter */
    G729EV_MAIN_set_gamma(output_lo, decstat->tab_Th, rate, &ga1_post, &ga2_post);

    /* set post-filter input */
    pf_in = &pf_in_buffer[G729EV_G729_M_LPC];
    G729EV_G729_Copy(decstat->mem_pf_in, &pf_in[-G729EV_G729_M_LPC], G729EV_G729_M_LPC);
    G729EV_G729_Copy(output_lo, pf_in, G729EV_MAIN_L_FRAME2);
    G729EV_G729_Copy(&output_lo[(G729EV_MAIN_L_FRAME2) - G729EV_G729_M_LPC], decstat->mem_pf_in, G729EV_G729_M_LPC);

    /* postfilter */
    pfstat = &decstat->mem_pf;
    if (decstat->low_delay == 0)
      ptr_Az = decstat->mem_Az;
    else
      ptr_Az = nb_celp_param.Az;

    for (i = 0, j = 0; i < (G729EV_MAIN_L_FRAME2); i += G729EV_G729_L_SUBFR, j++)
    {
      if (decstat->low_delay == 0)
        t0_first = decstat->mem_t0[(j / 2) * 2];
      else
        t0_first = nb_celp_param.t0[(j / 2) * 2];

      G729EV_CELP2S_post(pfstat, t0_first, &pf_in[i], ptr_Az, &output_lo[i],
                         ga1_post, ga2_post, G729EV_MAIN_switching_gain[decstat->count_rcv],
                         decstat->decStG729.ftyp[(int) (j / 2)]);

      ptr_Az += G729EV_G729_MP1;
    }

    if (decstat->low_delay == 0)
    {
      /* update memory of A(z) and t0_first */
      G729EV_G729_Copy(nb_celp_param.Az, decstat->mem_Az, 4 * G729EV_G729_MP1);
      for (i = 0; i < 4; i++)
        decstat->mem_t0[i] = nb_celp_param.t0[i];
    }

    /**************************
     * Postprocess lower-band *
     **************************/

    /* G729 postprocessing */
    G729EV_G729_Copy(output_lo, pst_in, G729EV_MAIN_L_FRAME2);

    G729EV_MAIN_iir2(&decstat->mem_postpro, output_lo, G729EV_MAIN_L_FRAME2, G729EV_MAIN_b100, G729EV_MAIN_a100);

    /* cross-fade output_lo and pst_out if bit rate switching */
    if (rate <= 12000)
    {
      /* narrowband output (8, 12k modes) */
      /* cross-fade two narrowband outputs (without or with postprocessing) if previous decoded frame was not postprocessed */
      if (decstat->mem_postflag == 0)
      {
        for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
        {
          tmp = (REAL) i / ((REAL) G729EV_MAIN_L_FRAME2 - (REAL) 1.0);
          output_lo[i] = tmp * output_lo[i] + ((REAL) 1.0 - tmp) * pst_in[i];
        }
      }
      /* declare this frame as postfiltered */
      decstat->mem_postflag = 1;
    }
    else
    {
      /* wideband output (modes >= 14k) */
      /* cross-fade two narrowband outputs (without or with postprocessing) if previous decoded frame was postprocessed
         otherwise copy non postprocessed output */
      if (decstat->mem_postflag == 1)
      {
        for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
        {
          tmp = (REAL) i / ((REAL) G729EV_MAIN_L_FRAME2 - (REAL) 1.0);
          output_lo[i] = tmp * pst_in[i] + ((REAL) 1.0 - tmp) * output_lo[i];
        }
      }
      else
      {
        G729EV_G729_Copy(pst_in, output_lo, G729EV_MAIN_L_FRAME2);
      }
      /* declare this frame as non postfiltered */
      decstat->mem_postflag = 0;
    }

    /*****************************************************************
    * Fold higher band and combine bands by QMF synthesis filterbank *
    ******************************************************************/

    if (decstat->f8 == 0)
    {                           /* test if 8kHz sampled output */
      /* mirror signal prior to filterbank synthesis */
      G729EV_MAIN_QMF_mirror(output_hi, G729EV_MAIN_L_FRAME2);

      /* synthesis filterbank */
      G729EV_MAIN_QMF_syn(&decstat->qmf_syn, output_lo, output_hi, output, G729EV_MAIN_L_FRAME2,
                          G729EV_MAIN_switching_gain[decstat->count_rcv]);

      G729EV_MAIN_copyRealToInt(output, tabout, G729EV_MAIN_L_FRAME);
    }
    else
    {
      G729EV_MAIN_copyRealToInt(output_lo, tabout, G729EV_MAIN_L_FRAME2);
    }

    /*******************
     * Update memories *
     *******************/

    decstat->plast_good = decstat->lastgood;
    decstat->lastgood = clas;
    decstat->decStG729.bfi_cnt = 0;
    decstat->prev_rate = rate;
  }
  else
  {
    /************************************************ FEC (bfi=1) ***********************************/


    /***********************
     * Decode 8-12k layers *
     ***********************/
    if ((decstat->decStG729.bfi_cnt > 0) || (decstat->low_delay))
    {
      /* FEC decoder */
      G729EV_FEC_dec_bf(parm_FEC, decstat->old_celp_output, BfAq, (INT16) bfi,
                        &(decstat->lastgood), pitch_buf, decstat->old_enrLP,
                        decstat->decStG729.old_exc, &(decstat->decStG729), clas, (INT16) ind_fer[2]);

      /* Update to be done before decoding a good frame */
      FerPitch = (INT16) (pitch_buf[0] + 0.5f);
      if (FerPitch < G729EV_G729_PIT_MIN)
        FerPitch = G729EV_G729_PIT_MIN;
      if (FerPitch > G729EV_G729_PIT_MAX)
        FerPitch = G729EV_G729_PIT_MAX;

      /* taming */
      G729EV_G729_UpdateMemTam(&decstat->decStG729, decstat->decStG729.lp_gainp, FerPitch);
      G729EV_G729_UpdateMemTam(&decstat->decStG729, decstat->decStG729.lp_gainp, FerPitch);

      /* update memory of A(z) and t0_first */
      G729EV_G729_Copy(BfAq, decstat->mem_Az, 4 * G729EV_G729_MP1);

      for (i = 0; i < 4; i++)
      {
        decstat->mem_t0[i] = (INT16) (pitch_buf[i] + 0.5f);
      }
    }

    if (decstat->low_delay == 0)
    {
      ind = G729EV_TDAC_L_WIN2 - 1;
      for (i = 0; i < G729EV_TDAC_L_WIN2; i++)
      {
        output_lo[i] = decstat->old_celp_output[i] + decstat->mem_inv_mdct_lo[i] * G729EV_TDAC_h[ind];
        ind--;
        decstat->mem_inv_mdct_lo[i] = 0;
      }
    }
    else
    {
      G729EV_G729_Copy(decstat->old_celp_output, output_lo, G729EV_MAIN_L_FRAME2);
    }

    /************************************
     * Decode 14-32k enhancement layers *
     ************************************/

    /* TDBWE decoder in FEC */
    if (decstat->prev_rate >= 14000)  /* 14 kbit/s */
    {
      if (decstat->decStG729.bfi_cnt > 2)
      {
        for (i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++)
        {
          tmp = decstat->prev_parameters_tdbwe[i] - (REAL) 1.0; /* -3 dB */
          if (tmp < (REAL) - 1.66)
            tmp = (REAL) - 1.66;
          decstat->prev_parameters_tdbwe[i] = tmp;
        }
        for (i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
        {
          tmp = decstat->prev_parameters_tdbwe[i + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE] - (REAL) 1.0; /* -3 dB */
          if (tmp < (REAL) - 11.0)
            tmp = (REAL) - 11.0;
          decstat->prev_parameters_tdbwe[i + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE] = tmp;
        }
      }

      G729EV_TDBWE_decoder(&decstat->tdbwe, &decstat->prev_nb_celp_param,
                           output_hiTdbwe, decstat->prev_parameters_tdbwe);
    }
    else
    {
      G729EV_G729_Set_zero(output_hiTdbwe, G729EV_MAIN_L_FRAME2);
    }

    /* TDAC decoder in FEC */
    if (decstat->low_delay == 0)
    {
      /* set 3000-4000 Hz band of TDBWE synthesis to zero */
      G729EV_TDAC_mdct(decstat->mem_mdct_hi, output_hiTdbwe, yq_hi);
      G729EV_G729_Set_zero(&yq_hi[G729EV_MAIN_L_FRAME2 - G729EV_G729_L_SUBFR], G729EV_G729_L_SUBFR);

      /* inverse MDCT to obtain reconstructed signal in higher band */
      G729EV_TDAC_inv_mdct(output_hi, yq_hi, decstat->mem_inv_mdct_hi);
    }
    else
    {
      G729EV_G729_Copy(output_hiTdbwe, output_hi, G729EV_MAIN_L_FRAME2);
    }

    /*************************
     * Postfilter lower band *
     *************************/

    /* set adaptive gamma paramaters of postfilter */
    G729EV_MAIN_set_gamma(output_lo, decstat->tab_Th, decstat->prev_rate, &ga1_post, &ga2_post);

    /* set post-filter input */
    pf_in = &pf_in_buffer[G729EV_G729_M_LPC];
    G729EV_G729_Copy(decstat->mem_pf_in, &pf_in[-G729EV_G729_M_LPC], G729EV_G729_M_LPC);
    G729EV_G729_Copy(output_lo, pf_in, G729EV_MAIN_L_FRAME2);
    G729EV_G729_Copy(&output_lo[(G729EV_MAIN_L_FRAME2) - G729EV_G729_M_LPC], decstat->mem_pf_in, G729EV_G729_M_LPC);

    /* postfilter */
    pfstat = &decstat->mem_pf;
    ptr_Az = decstat->mem_Az;

    for (i = 0, j = 0; i < (G729EV_MAIN_L_FRAME2); i += G729EV_G729_L_SUBFR, j++)
    {
      t0_first = decstat->mem_t0[(j / 2) * 2];

      G729EV_CELP2S_post(pfstat, t0_first, &pf_in[i], ptr_Az, &output_lo[i],
                         ga1_post, ga2_post, G729EV_MAIN_switching_gain[decstat->count_rcv],
                         decstat->decStG729.ftyp[(int) (j / 2)]);

      ptr_Az += G729EV_G729_MP1;
    }

    /**************************
     * Postprocess lower band *
     **************************/

    /* G729 postprocessing */
    G729EV_G729_Copy(output_lo, pst_in, G729EV_MAIN_L_FRAME2);
    G729EV_MAIN_iir2(&decstat->mem_postpro, output_lo, G729EV_MAIN_L_FRAME2, G729EV_MAIN_b100, G729EV_MAIN_a100);
    if (decstat->mem_postflag == 0)
    {
      /* wideband bit rate -> leave lower-band unprocessed */
      G729EV_G729_Copy(pst_in, output_lo, G729EV_MAIN_L_FRAME2);
    }

    /******************************************************************
     * Fold higher band and combine bands by QMF synthesis filterbank *
     ******************************************************************/
    if (decstat->f8 == 0)
    {                           /* test if 8kHz sampled output */
      /* mirror signal prior to filterbank synthesis */
      G729EV_MAIN_QMF_mirror(output_hi, G729EV_MAIN_L_FRAME2);

      /* synthesis filterbank */
      G729EV_MAIN_QMF_syn(&decstat->qmf_syn, output_lo, output_hi, output, G729EV_MAIN_L_FRAME2,
                          G729EV_MAIN_switching_gain[decstat->count_rcv]);

      G729EV_MAIN_copyRealToInt(output, tabout, G729EV_MAIN_L_FRAME);
    }
    else
    {
      G729EV_MAIN_copyRealToInt(output_lo, tabout, G729EV_MAIN_L_FRAME2);
    }

    /*******************
     * Update memories *
     *******************/

    /* Update to be done before decoding a good frame */
    decstat->decStG729.bfi_cnt++;

    /* set buffer for W(z) */
    G729EV_G729_Set_zero(decstat->mem_invWz_in, G729EV_G729_M);
    G729EV_G729_Set_zero(decstat->mem_invwsp, G729EV_G729_M);
  }
  decstat->prev_bfi = bfi;
}
