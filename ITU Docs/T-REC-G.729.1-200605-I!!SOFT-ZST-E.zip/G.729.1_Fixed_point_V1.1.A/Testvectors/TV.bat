@echo off

REM BATCH FILE FOR G.729.1 V1.1.a TEST SEQUENCES
REM Authors:       Cyril Guillaume, Stephane Ragot
REM Revision Date: Dec 4, 2006
REM Contact:       <stephane.ragot@orange-ftgroup.com>

REM SET file_compare=FC /B
SET file_compare=cmp -b

del /Q *.p*

REM G.729/CELP2S modules test-vectors
REM ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

encoder -quiet -r12000 -f8 ALGTHM.in ALGTHM.pb12
encoder -quiet -r12000 -f8 FIXED.in FIXED.pb12
encoder -quiet -r12000 -f8 LSP.in LSP.pb12
encoder -quiet -r12000 -f8 PITCH.in PITCH.pb12
encoder -quiet -r12000 -f8 SPEECH.in SPEECH.pb12
encoder -quiet -r12000 -f8 TAME.in TAME.pb12

decoder -quiet -f8 ALGTHM.b12 ALGTHM.po12
decoder -quiet -f8 FIXED.b12 FIXED.po12
decoder -quiet -f8 LSP.b12 LSP.po12
decoder -quiet -f8 PITCH.b12 PITCH.po12
decoder -quiet -f8 SPEECH.b12 SPEECH.po12
decoder -quiet -f8 TAME.b12 TAME.po12

decoder -quiet -f8 -g729b_bst ERASURE.b8 ERASURE.po8
decoder -quiet -f8 -g729b_bst OVERFLOW.b8 OVERFLOW.po8
decoder -quiet -f8 -g729b_bst PARITY.b8 PARITY.po8

decoder -quiet -f8 -g729b_bst stabilit.b8 stabilit.po8


REM G.729B module test-vectors
REM ~~~~~~~~~~~~~~~~~~~~~~~~~~

decoder -quiet -g729b_bst -f8 tstseq1.b8 tstseq1.po8
decoder -quiet -g729b_bst -f8 tstseq2.b8 tstseq2.po8
decoder -quiet -g729b_bst -f8 tstseq3.b8 tstseq3.po8
decoder -quiet -g729b_bst -f8 tstseq4.b8 tstseq4.po8
decoder -quiet -g729b_bst -f8 tstseq5.b8 tstseq5.po8
decoder -quiet -g729b_bst -f8 tstseq6.b8 tstseq6.po8


REM TDBWE module test-vectors
REM ~~~~~~~~~~~~~~~~~~~~~~~~~~

encoder -quiet TDBWE1.in TDBWE1.pb32
encoder -quiet TDBWE2.in TDBWE2.pb32

decoder -quiet TDBWE1.b32 TDBWE1.po32
decoder -quiet TDBWE2.b32 TDBWE2.po32


REM TDAC module test-vectors
REM ~~~~~~~~~~~~~~~~~~~~~~~~~

encoder -quiet TDAC1.in TDAC1.pb32
encoder -quiet TDAC2.in TDAC2.pb32
encoder -quiet -r12000 TDAC2.in TDAC2.pb12

decoder -quiet TDAC1.b32 TDAC1.po32
decoder -quiet TDAC2.b32 TDAC2.po32
decoder -quiet TDAC2.b12 TDAC2.po12
decoder -quiet TDAC3.b32 TDAC3.po32


REM FEC module test-vectors
REM ~~~~~~~~~~~~~~~~~~~~~~~~

decoder -quiet FEC1.b32 FEC1.po32
decoder -quiet -r8000 FEC1.b32 FEC1.po8
decoder -quiet -r14000 FEC1.b32 FEC1.po14
decoder -quiet FEC2.b32 FEC2.po32


REM NB input/ouput + g729 bst + ld modes test-vectors
REM ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

encoder -quiet test1_16k.in test1_16k.pb32
encoder -quiet -g729_bst test1_16k.in test1_16k.pb8
encoder -quiet -f8 test1_8k.in test1_8k.pb32

decoder -quiet -ld -r12000 test1_16k.b32 test1_16k.po12
decoder -quiet -g729b_bst test1_16k.b8 test1_16k.po8
decoder -quiet -f8 test1_8k.b32 test1_8k.po32


REM bitrate switching test-vector
REM ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

decoder -quiet bitswitch.bsw bitswitch.posw


REM end of processing
REM    comparison
REM ~~~~~~~~~~~~~~~~~~

%file_compare% ALGTHM.pb12 ALGTHM.b12
%file_compare% FIXED.pb12 FIXED.b12
%file_compare% LSP.pb12 LSP.b12
%file_compare% PITCH.pb12 PITCH.b12
%file_compare% SPEECH.pb12 SPEECH.b12
%file_compare% TAME.pb12 TAME.b12

%file_compare% ALGTHM.po12 ALGTHM.o12
%file_compare% FIXED.po12 FIXED.o12
%file_compare% LSP.po12 LSP.o12
%file_compare% PITCH.po12 PITCH.o12
%file_compare% SPEECH.po12 SPEECH.o12
%file_compare% TAME.po12 TAME.o12 

%file_compare% ERASURE.po8 ERASURE.o8
%file_compare% OVERFLOW.po8 OVERFLOW.o8
%file_compare% PARITY.po8 PARITY.o8

%file_compare% stabilit.po8 stabilit.o8

%file_compare% tstseq1.po8 tstseq1.o8
%file_compare% tstseq2.po8 tstseq2.o8
%file_compare% tstseq3.po8 tstseq3.o8
%file_compare% tstseq4.po8 tstseq4.o8
%file_compare% tstseq5.po8 tstseq5.o8
%file_compare% tstseq6.po8 tstseq6.o8

%file_compare% TDBWE1.pb32 TDBWE1.b32
%file_compare% TDBWE2.pb32 TDBWE2.b32

%file_compare% TDBWE1.po32 TDBWE1.o32
%file_compare% TDBWE2.po32 TDBWE2.o32

%file_compare% TDAC1.pb32 TDAC1.b32
%file_compare% TDAC2.pb32 TDAC2.b32
%file_compare% TDAC2.pb12 TDAC2.b12

%file_compare% TDAC1.po32 TDAC1.o32
%file_compare% TDAC2.po32 TDAC2.o32
%file_compare% TDAC2.po12 TDAC2.o12
%file_compare% TDAC3.po32 TDAC3.o32

%file_compare% FEC1.po32 FEC1.o32
%file_compare% FEC1.po8 FEC1.o8
%file_compare% FEC1.po14 FEC1.o14
%file_compare% FEC2.po32 FEC2.o32

%file_compare% test1_16k.pb32 test1_16k.b32
%file_compare% test1_16k.pb8 test1_16k.b8
%file_compare% test1_8k.pb32 test1_8k.b32

%file_compare% test1_16k.po12 test1_16k.o12
%file_compare% test1_16k.po8 test1_16k.o8
%file_compare% test1_8k.po32 test1_8k.o32

%file_compare% bitswitch.posw bitswitch.osw
