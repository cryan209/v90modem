/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_G729_SID_H__
#define __G729EV_G729_SID_H__

#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729_ld8k.h"

void      G729EV_G729B_Dec_cng(G729EV_G729_DECSTAT * pDecStat, Word16 past_ftyp,  /* (i)   : past frame type                      */
                               Word16 sid_sav,   /* (i)   : energy to recover SID gain           */
                               Word16 sh_sid_sav,/* (i)   : corresponding scaling factor         */
                               Word16 * parm,    /* (i)   : coded SID parameters                 */
                               Word16 * exc,     /* (i/o) : excitation array                     */
                               Word16 * lsp_old, /* (i/o) : previous lsp                         */
                               Word16 * A_t,     /* (o)   : set of interpolated LPC coefficients */
                               Word16 * seed,    /* (i/o) : random generator seed                */
                               Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                                 /* (i/o) : previous LPS for quantization        */
                               Word16 * sid_gain, Word16 * cur_gain, Word16 ftyp);

void      Init_lsfq_noise(G729EV_G729_DECSTAT * pDecStat);

void      sid_lsfq_decode(Word16 * index, Word16 * lspq,
                          Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                          Word16 noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M]);

#endif
