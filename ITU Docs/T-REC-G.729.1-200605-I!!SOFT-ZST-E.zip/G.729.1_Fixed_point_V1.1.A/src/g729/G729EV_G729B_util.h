/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_G729_UTIL_H__
#define __G729EV_G729_UTIL_H__

void      G729EV_G729B_Get_decfreq_prev(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                        Word16 x[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729B_Update_decfreq_prev(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                           Word16 x[G729EV_G729_MA_NP][G729EV_G729_M]);

#endif
