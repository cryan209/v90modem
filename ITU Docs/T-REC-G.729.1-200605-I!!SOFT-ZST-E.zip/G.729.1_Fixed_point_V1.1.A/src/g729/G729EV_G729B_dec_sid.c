/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include "G729EV_G729_TAB_ld8k.h"

#include "G729EV_G729B_sid.h"
#include "G729EV_G729B_dtx.h"

/*-----------------------------------------------------------*
 * procedure Dec_cng:                                        *
 *           ~~~~~~~~                                        *
 *                     Receives frame type                   *
 *                     0  :  for untransmitted frames        *
 *                     2  :  for SID frames                  *
 *                     Decodes SID frames                    *
 *                     Computes current frame excitation     *
 *                     Computes current frame LSPs
 *-----------------------------------------------------------*/
void G729EV_G729B_Dec_cng(G729EV_G729_DECSTAT * pDecStat, 
                          Word16 past_ftyp,   /* (i)   : past frame type                      */
                          Word16 sid_sav,     /* (i)   : energy to recover SID gain           */
                          Word16 sh_sid_sav,  /* (i)   : corresponding scaling factor         */
                          Word16 * parm,      /* (i)   : coded SID parameters                 */
                          Word16 * exc,       /* (i/o) : excitation array                     */
                          Word16 * lspOld,    /* (i/o) : previous lsp                         */
                          Word16 * A_t,       /* (o)   : set of interpolated LPC coefficients */
                          Word16 * seed,      /* (i/o) : random generator seed                */
                          Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                              /* (i/o) : previous LPS for quantization        */
                          Word16 * sid_gain, Word16 * cur_gain, Word16 ftyp)
{
  Word16    temp, ind;
  Word16    dif;

  dif = sub(past_ftyp, 1);

  /* SID Frame */
  /*************/
  IF(ftyp != 0)
  {
    *sid_gain = tab_Sidgain[(Word16) parm[3]];
#if(WMOPS)
    move16();
#endif

    /* Inverse quantization of the LSP */
    sid_lsfq_decode(&parm[0], pDecStat->lspSid, freq_prev, pDecStat->noise_fg);
  }

  /* non SID Frame */
  /*****************/
  ELSE
  {

    /* Case of 1st SID frame erased : quantize-decode   */
    /* energy estimate stored in sid_gain         */
    IF(dif == 0)
    {
      Qua_Sidgain(&sid_sav, &sh_sid_sav, 0, &temp, &ind);
      *sid_gain = tab_Sidgain[(int) ind];
#if(WMOPS)
      move16();
#endif
    }

  }

  IF(dif == 0)
  {
    *cur_gain = *sid_gain;
#if(WMOPS)
    move16();
#endif
  }
  ELSE
  {
    *cur_gain = mult_r(*cur_gain, A_GAIN0);
    *cur_gain = add(*cur_gain, mult_r(*sid_gain, A_GAIN1));
  }

  Calc_exc_rand(pDecStat, *cur_gain, exc, seed, FLAG_DEC);

  /* Interpolate the Lsp vectors */
  G729EV_G729_Int_qlpc(lspOld, pDecStat->lspSid, A_t);
  G729EV_G729_Copy(pDecStat->lspSid, lspOld, G729EV_G729_M);

  return;
}

/*---------------------------------------------------------------------------*
 * Function  Init_lsfq_noise                                                 *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~                                                 *
 *                                                                           *
 * -> Initialization of variables for the lsf quantization in the SID        *
 *                                                                           *
 *---------------------------------------------------------------------------*/
void Init_lsfq_noise(G729EV_G729_DECSTAT * pDecStat)
{
  Word32    acc0;
  Word16    i, j;

  /* initialize the noise_fg */
  FOR(i = 0; i < 4; i++)
  {
    G729EV_G729_Copy(fg[0][i], pDecStat->noise_fg[0][i], G729EV_G729_M);
  }

  FOR(i = 0; i < 4; i++)
  {
    FOR(j = 0; j < G729EV_G729_M; j++)
    {
      acc0 = L_mult(fg[0][i][j], 19660);
      acc0 = L_mac(acc0, fg[1][i][j], 13107);
      pDecStat->noise_fg[1][i][j] = extract_h(acc0);
#if(WMOPS)
      move16();
#endif
    }
  }
}

void sid_lsfq_decode(Word16 * index,  /* (i) : quantized indices    */
                     Word16 * lspq, /* (o) : quantized lsp vector */
                     Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i) : memory of predictor  */
                     Word16 noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M])
{
  Word32    acc0;
  Word16    lsfq[G729EV_G729_M], tmpbuf[G729EV_G729_M];
  Word16    i, j, k;

  /* get the lsf error vector */
  G729EV_G729_Copy(lspcb1[PtrTab_1[index[1]]], tmpbuf, G729EV_G729_M);
  FOR(i = 0; i < G729EV_G729_M / 2; i++)
  {
    tmpbuf[i] = add(tmpbuf[i], lspcb2[PtrTab_2[0][index[2]]][i]);
#if(WMOPS)
    move16();
#endif
  }
  FOR(i = G729EV_G729_M / 2; i < G729EV_G729_M; i++)
  {
    tmpbuf[i] = add(tmpbuf[i], lspcb2[PtrTab_2[1][index[2]]][i]);
#if(WMOPS)
    move16();
#endif
  }

  /* guarantee minimum distance of 0.0012 (~10 in Q13) between tmpbuf[j] 
     and tmpbuf[j+1] */
  FOR(j = 1; j < G729EV_G729_M; j++)
  {
    acc0 = L_mult(tmpbuf[j - 1], 16384);
    acc0 = L_mac(acc0, tmpbuf[j], -16384);
    acc0 = L_mac(acc0, 10, 16384);
    k = extract_h(acc0);

    IF(k > 0)
    {
      tmpbuf[j - 1] = sub(tmpbuf[j - 1], k);
      tmpbuf[j] = add(tmpbuf[j], k);
#if(WMOPS)
      move16();
      move16();
#endif
    }
  }

  /* compute the quantized lsf vector */
  G729EV_G729_Lsp_prev_compose(tmpbuf, lsfq, noise_fg[index[0]], freq_prev, noise_fg_sum[index[0]]);

  /* update the prediction memory */
  G729EV_G729_Lsp_prev_update(tmpbuf, freq_prev);

  /* lsf stability check */
  G729EV_G729_Lsp_stability(lsfq);

  /* convert lsf to lsp */
  G729EV_G729_Lsf_lsp2(lsfq, lspq, G729EV_G729_M);

}
