/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

/*------------------------------------------------------------------------*/
/* From Original Version :                                                */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B Floating point ANSI C source code      */
/*   Copyright (C) 1999, AT&T, France Telecom, NTT, University of         */
/*   Sherbrooke, Conexant, Ericsson. All rights reserved.                 */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B - Reference C code for Floating point  */
/*                         implementation of G.729 Annex AB               */
/*                                                                        */
/*========================================================================*/


#ifndef __G729EV_G729_DECSTAT_H__
#define __G729EV_G729_DECSTAT_H__

#include <stdio.h>
#include "stl.h"
#include "G729EV_G729_defines.h"
#include "G729EV_MAIN_defines.h"


/* Structure of the decoder status variables */

typedef struct
{
  Word16    old_exc[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];  /* Excitation vector */
  Word16    lsp_old[G729EV_G729_M];                                 /* Line Spectral Pairs */
  Word16    mem_syn[G729EV_G729_M_LPC];                             /* Filter's memory */
  Word16    freq_prev[G729EV_G729_MA_NP][G729EV_G729_M];            /* previous LSP vector        */
  Word16    prev_lsp[G729EV_G729_M];                                /* previous LSP vector  */
  Word16    past_qua_en[4];                                         /* Past quantized energies */
  Word16    mem_zero[G729EV_G729_M_LPC];    /* null memory to compute h_st */
  Word16    apond2[G729EV_G729_LONG_H_ST];  /* s.t.numerator coef */
  Word16    mem_res2[G729EV_G729_SIZ_RES2]; /* memory of A(gamma2) residual */

  Word16    rate;               /* Rate */
  Word16    seed_fer;
  Word16    sharp;              /* Pitch sharpening of previous frame */
  Word16    gain_code;          /* Code gain */
  Word16    gain_pitch;         /* pitch gain   */
  Word16    prev_ma;            /* Previous MA prediction coef */

  Word16    lp_gainp;
  Word16    lp_gainc;
  Word16    i_subfr_cnt;
  Word16    tilt_code;
  Word16    stab_fac;
  Word16    upd_cnt;
  Word32    Lenr_old;
  Word16    fpitch[2];
  Word16    old_fpitch;
  Word16    bfi_cnt;

  Word16    pit_mem[5];
  Word16    bfi_mem;
  Word16    MemTam[G729EV_G729_MEM_LEN_TAM];

  /* G.729B mode */
  Word16    g729b_bst;
  Word16    ftyp[2];
  Word16    sid_sav;
  Word16    sh_sid_sav;
  Word16    sid_gain;
  Word16    cur_gain;
  Word32    L_exc_err[4];       /* To tame the coder */
  Word16    past_ftyp;
  Word16    seed;
  Word16    noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M];
  Word16    lspSid[G729EV_G729_M];

} G729EV_G729_DECSTAT;




#endif  /*__G729EV_G729_DECSTAT_H__ */
