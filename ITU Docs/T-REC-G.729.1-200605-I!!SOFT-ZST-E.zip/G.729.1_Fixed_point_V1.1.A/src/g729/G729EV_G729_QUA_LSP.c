/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

/*-------------------------------------------------------------------*
 * Function  G729EV_G729_Qua_lsp:                                    *
 *           ~~~~~~~~                                                *
 *-------------------------------------------------------------------*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_TAB_ld8k.h"


void G729EV_G729_Qua_lsp(Word16 lsp[],  /* (i) Q15 : Unquantized LSP            */
                         Word16 lsp_q[],/* (o) Q15 : Quantized LSP              */
                         Word16 ana[],  /* (o)     : indexes                    */
                         Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M])
{
  Word16    lsf[G729EV_G729_M], lsf_q[G729EV_G729_M]; /* domain 0.0<= lsf <PI in Q13 */

  /* Convert LSPs to LSFs */
  G729EV_G729_Lsp_lsf2(lsp, lsf, G729EV_G729_M);

  G729EV_G729_Lsp_qua_cs(lsf, lsf_q, ana, freq_prev);

  /* Convert LSFs to LSPs */
  G729EV_G729_Lsf_lsp2(lsf_q, lsp_q, G729EV_G729_M);

  return;
}



void G729EV_G729_Lsp_encw_reset(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M])
{
  Word16    i;

  FOR(i = 0; i < G729EV_G729_MA_NP; i++)
    G729EV_G729_Copy(&freq_prev_reset[0], &freq_prev[i][0], G729EV_G729_M);
}


void G729EV_G729_Lsp_qua_cs(Word16 flsp_in[G729EV_G729_M],  /* (i) Q13 : Original LSP parameters    */
                            Word16 lspq_out[G729EV_G729_M], /* (o) Q13 : Quantized LSP parameters   */
                            Word16 * code,                  /* (o)     : codes of the selected LSP  */
                            Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M])
{
  Word16    wegt[G729EV_G729_M];  /* Q11->normalized : weighting coefficients */

  G729EV_G729_Get_wegt(flsp_in, wegt);

  G729EV_G729_Relspwed(flsp_in, wegt, lspq_out, lspcb1, lspcb2, fg, freq_prev, fg_sum, fg_sum_inv, code);
}

void G729EV_G729_Relspwed(Word16 lsp[],                   /* (i) Q13 : unquantized LSP parameters */
                          Word16 wegt[],                  /* (i) norm: weighting coefficients     */
                          Word16 lspq[],                  /* (o) Q13 : quantized LSP parameters   */
                          Word16 lspcb1[][G729EV_G729_M], /* (i) Q13 : first stage LSP codebook   */
                          Word16 lspcb2[][G729EV_G729_M], /* (i) Q13 : Second stage LSP codebook  */
                          Word16 fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M],  /* (i) Q15 : MA prediction coefficients */
                          Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i) Q13 : previous LSP vector        */
                          Word16 fg_sum[G729EV_G729_MODE][G729EV_G729_M],     /* (i) Q15 : present MA prediction coef. */
                          Word16 fg_sum_inv[G729EV_G729_MODE][G729EV_G729_M], /* (i) Q12 : inverse coef.              */
                          Word16 code_ana[]                                   /* (o)     : codes of the selected LSP  */
    )
{
  Word32    L_tdist[G729EV_G729_MODE];  /* Q26 */

  Word16    tindex1[G729EV_G729_MODE], tindex2[G729EV_G729_MODE];
  Word16    rbuf[G729EV_G729_M];  /* Q13 */
  Word16    buf[G729EV_G729_M]; /* Q13 */
  Word16    cand[G729EV_G729_MODE];


  Word16    mode, j;
  Word16    index, mode_index;
  Word16    cand_cur;




  FOR(mode = 0; mode < G729EV_G729_MODE; mode++)
  {
    G729EV_G729_Lsp_prev_extract(lsp, rbuf, fg[mode], freq_prev, fg_sum_inv[mode]);

    G729EV_G729_Lsp_pre_select(rbuf, lspcb1, &cand_cur);
    cand[mode] = cand_cur;
#ifdef WMOPS
    move16();
#endif

    G729EV_G729_Lsp_select_1(rbuf, lspcb1[cand_cur], wegt, lspcb2, &index);

    tindex1[mode] = index;
#ifdef WMOPS
    move16();
#endif

    FOR(j = 0; j < G729EV_G729_NC; j++)
    {
#ifdef WMOPS
      move16();
#endif
      buf[j] = add(lspcb1[cand_cur][j], lspcb2[index][j]);
    }

    G729EV_G729_Lsp_expand_1(buf, G729EV_G729_GAP1);

    G729EV_G729_Lsp_select_2(rbuf, lspcb1[cand_cur], wegt, lspcb2, &index);

    tindex2[mode] = index;
#ifdef WMOPS
    move16();
#endif

    FOR(j = G729EV_G729_NC; j < G729EV_G729_M; j++)
    {
#ifdef WMOPS
      move16();
#endif
      buf[j] = add(lspcb1[cand_cur][j], lspcb2[index][j]);
    }

    G729EV_G729_Lsp_expand_2(buf, G729EV_G729_GAP1);

    G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP2);

    G729EV_G729_Lsp_get_tdist(wegt, buf, &L_tdist[mode], rbuf, fg_sum[mode]);
  }

  G729EV_G729_Lsp_last_select(L_tdist, &mode_index);

  code_ana[0] = s_or(shl(mode_index, G729EV_G729_NC0_B), cand[mode_index]);
  code_ana[1] = s_or(shl(tindex1[mode_index], G729EV_G729_NC1_B), tindex2[mode_index]);
#ifdef WMOPS
  move16();
  move16();
#endif

  G729EV_G729_Lsp_get_quant(lspcb1, lspcb2, cand[mode_index],
                            tindex1[mode_index], tindex2[mode_index],
                            fg[mode_index], freq_prev, lspq, fg_sum[mode_index]);

  return;
}


void G729EV_G729_Lsp_pre_select(Word16 rbuf[],                  /* (i) Q13 : target vetor             */
                                Word16 lspcb1[][G729EV_G729_M], /* (i) Q13 : first stage LSP codebook */
                                Word16 * cand                   /* (o)     : selected code            */
    )
{
  Word32    L_dmin;             /* Q26 */
  Word32    L_tmp;              /* Q26 */
  Word32    L_temp;


  Word16    i, j;
  Word16    tmp;                /* Q13 */

  /* avoid the worst case. (all over flow) */
  *cand = 0;
  L_dmin = MAX_32;

#ifdef WMOPS
  move16();
  move32();
#endif

  FOR(i = 0; i < G729EV_G729_NC0; i++)
  {
    L_tmp = 0;
#ifdef WMOPS
    move32();
#endif
    FOR(j = 0; j < G729EV_G729_M; j++)
    {
      tmp = sub(rbuf[j], lspcb1[i][j]);
      L_tmp = L_mac(L_tmp, tmp, tmp);
    }

    L_temp = L_sub(L_tmp, L_dmin);
    if (L_temp < 0L)
    {
      L_dmin = L_tmp;
      *cand = i;
#ifdef WMOPS
      move16();
      move32();
#endif
    }
  }
  return;
}



void G729EV_G729_Lsp_select_1(Word16 rbuf[],                 /* (i) Q13 : target vector             */
                              Word16 lspcb1[],               /* (i) Q13 : first stage lsp codebook  */
                              Word16 wegt[],                 /* (i) norm: weighting coefficients    */
                              Word16 lspcb2[][G729EV_G729_M],/* (i) Q13 : second stage lsp codebook */
                              Word16 * index                 /* (o)     : selected codebook index   */
    )
{
  Word32    L_dist;             /* Q26 */
  Word32    L_dmin;             /* Q26 */
  Word32    L_temp;

  Word16    buf[G729EV_G729_M]; /* Q13 */

  Word16    j, k1;
  Word16    tmp, tmp2;          /* Q13 */


  FOR(j = 0; j < G729EV_G729_NC; j++)
  {
#ifdef WMOPS
    move16();
#endif
    buf[j] = sub(rbuf[j], lspcb1[j]);
  }

  /* avoid the worst case. (all over flow) */
  *index = 0;
  L_dmin = MAX_32;
#ifdef WMOPS
  move32();
  move16();
#endif

  FOR(k1 = 0; k1 < G729EV_G729_NC1; k1++)
  {
    L_dist = 0;
#ifdef WMOPS
    move32();
#endif
    FOR(j = 0; j < G729EV_G729_NC; j++)
    {
      tmp = sub(buf[j], lspcb2[k1][j]);
      tmp2 = mult(wegt[j], tmp);
      L_dist = L_mac(L_dist, tmp2, tmp);
    }

    L_temp = L_sub(L_dist, L_dmin);
    if (L_temp < 0L)
    {
      L_dmin = L_dist;
      *index = k1;
#ifdef WMOPS
      move16();
      move32();
#endif
    }
  }
  return;
}



void G729EV_G729_Lsp_select_2(Word16 rbuf[],                  /* (i) Q13 : target vector             */
                              Word16 lspcb1[],                /* (i) Q13 : first stage lsp codebook  */
                              Word16 wegt[],                  /* (i) norm: weighting coef.           */
                              Word16 lspcb2[][G729EV_G729_M], /* (i) Q13 : second stage lsp codebook */
                              Word16 * index                  /* (o)     : selected codebook index   */
    )
{
  Word32    L_dist;             /* Q26 */
  Word32    L_dmin;             /* Q26 */
  Word32    L_temp;

  Word16    buf[G729EV_G729_M]; /* Q13 */

  Word16    j, k1;
  Word16    tmp, tmp2;          /* Q13 */


  FOR(j = G729EV_G729_NC; j < G729EV_G729_M; j++)
  {
#ifdef WMOPS
    move16();
#endif
    buf[j] = sub(rbuf[j], lspcb1[j]);
  }

  /* avoid the worst case. (all over flow) */
  *index = 0;
  L_dmin = MAX_32;

#ifdef WMOPS
  move16();
  move32();
#endif

  FOR(k1 = 0; k1 < G729EV_G729_NC1; k1++)
  {
    L_dist = 0;
#ifdef WMOPS
    move32();
#endif
    FOR(j = G729EV_G729_NC; j < G729EV_G729_M; j++)
    {
      tmp = sub(buf[j], lspcb2[k1][j]);
      tmp2 = mult(wegt[j], tmp);
      L_dist = L_mac(L_dist, tmp2, tmp);
    }

    L_temp = L_sub(L_dist, L_dmin);
    if (L_temp < 0L)
    {
      L_dmin = L_dist;
      *index = k1;
#ifdef WMOPS
      move16();
      move32();
#endif
    }
  }
  return;
}



void G729EV_G729_Lsp_get_tdist(Word16 wegt[],     /* (i) norm: weight coef.                */
                               Word16 buf[],      /* (i) Q13 : candidate LSP vector        */
                               Word32 * L_tdist,  /* (o) Q27 : distortion                  */
                               Word16 rbuf[],     /* (i) Q13 : target vector               */
                               Word16 fg_sum[]    /* (i) Q15 : present MA prediction coef. */
    )
{
  Word32    L_acc;              /* Q25 */

  Word16    j;
  Word16    tmp, tmp2;          /* Q13 */


  *L_tdist = 0;
#ifdef WMOPS
  move32();
#endif
  FOR(j = 0; j < G729EV_G729_M; j++)
  {
    /* tmp = (buf - rbuf)*fg_sum */
    tmp = sub(buf[j], rbuf[j]);
    tmp = mult(tmp, fg_sum[j]);

    /* *L_tdist += wegt * tmp * tmp */
    L_acc = L_mult(wegt[j], tmp);
    tmp2 = extract_h(L_shl(L_acc, 4));
    *L_tdist = L_mac(*L_tdist, tmp2, tmp);
#ifdef WMOPS
    move32();
#endif
  }

  return;
}



void G729EV_G729_Lsp_last_select(Word32 L_tdist[],    /* (i) Q27 : distortion         */
                                 Word16 * mode_index  /* (o)     : the selected mode  */
    )
{
  Word32    L_temp;

  *mode_index = 0;
#ifdef WMOPS
  move16();
#endif
  L_temp = L_sub(L_tdist[1], L_tdist[0]);
  if (L_temp < 0L)
  {
    *mode_index = 1;
#ifdef WMOPS
    move16();
#endif
  }
  return;
}

void G729EV_G729_Get_wegt(Word16 flsp[],  /* (i) Q13 : M LSP parameters  */
                          Word16 wegt[]   /* (o) Q11->norm : M weighting coefficients */
    )
{
  Word32    L_acc;

  Word16    buf[G729EV_G729_M]; /* in Q13 */

  Word16    i;
  Word16    tmp;
  Word16    sft;


#ifdef WMOPS
  move16();
#endif
  buf[0] = sub(flsp[1], (G729EV_G729_PI04 + 8192)); /* 8192:1.0(Q13) */

  FOR(i = 1; i < G729EV_G729_M - 1; i++)
  {
    tmp = sub(flsp[i + 1], flsp[i - 1]);
    buf[i] = sub(tmp, 8192);
#ifdef WMOPS
    move16();
#endif
  }

  buf[G729EV_G729_M - 1] = sub((G729EV_G729_PI92 - 8192), flsp[G729EV_G729_M - 2]);
#ifdef WMOPS
  move16();
#endif

  /* */
  FOR(i = 0; i < G729EV_G729_M; i++)
  {
    IF(buf[i] > 0)
    {
      wegt[i] = 2048;           /* 2048:1.0(Q11) */
#ifdef WMOPS
      move16();
#endif
    }
    ELSE
    {
      L_acc = L_mult(buf[i], buf[i]); /* L_acc in Q27 */
      tmp = extract_h(L_shl(L_acc, 2)); /* tmp in Q13 */

      L_acc = L_mult(tmp, G729EV_G729_CONST10); /* L_acc in Q25 */
      tmp = extract_h(L_shl(L_acc, 2)); /* tmp in Q11 */

      wegt[i] = add(tmp, 2048); /* wegt in Q11 */
#ifdef WMOPS
      move16();
#endif
    }
  }

  /* */
  L_acc = L_mult(wegt[4], G729EV_G729_CONST12); /* L_acc in Q26 */
  wegt[4] = extract_h(L_shl(L_acc, 1)); /* wegt in Q11 */

  L_acc = L_mult(wegt[5], G729EV_G729_CONST12); /* L_acc in Q26 */
  wegt[5] = extract_h(L_shl(L_acc, 1)); /* wegt in Q11 */
#ifdef WMOPS
  move16();
  move16();
#endif

  /* wegt: Q11 -> normalized */
  tmp = 0;
#ifdef WMOPS
  move16();
#endif
  FOR(i = 0; i < G729EV_G729_M; i++)
  {
    if (sub(wegt[i], tmp) > 0)
    {
#ifdef WMOPS
      move16();
#endif
      tmp = wegt[i];
    }
  }

  sft = norm_s(tmp);
  FOR(i = 0; i < G729EV_G729_M; i++)
  {
    wegt[i] = shl(wegt[i], sft);  /* wegt in Q(11+sft) */
#ifdef WMOPS
    move16();
#endif
  }

  return;
}
