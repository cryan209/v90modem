/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDAC_MDCT_H__
#define __G729EV_TDAC_MDCT_H__

#include <stdio.h>
#include "stl.h"

/* Functions : */

Word16    G729EV_TDAC_mdct(Word16 * mem, Word16 * input, Word16 * ykr, Word16 norm_shift);
void      G729EV_TDAC_inv_mdct(Word16 * xr, Word16 * ykq, Word16 * ycim1, Word16 norm_shift);

/* Tables : */

extern const Word16 G729EV_TDAC_h[G729EV_TDAC_L_WIN];
extern const Word16 G729EV_TDAC_wcos[G729EV_TDAC_L_WIN4];
extern const Word16 G729EV_TDAC_wsin[G729EV_TDAC_L_WIN4];
extern const Word16 G729EV_TDAC_weti[G729EV_TDAC_L_WIN4];
extern const Word16 G729EV_TDAC_wetr[G729EV_TDAC_L_WIN4];
extern const Word16 G729EV_TDAC_wetrm1[G729EV_TDAC_L_WIN4];
extern const Word16 G729EV_TDAC_wetim1[G729EV_TDAC_L_WIN4];
extern const Word16 G729EV_TDAC_win[G729EV_TDAC_L_WIN2];


#endif /* __G729EV_TDAC_MDCT_H__ */
