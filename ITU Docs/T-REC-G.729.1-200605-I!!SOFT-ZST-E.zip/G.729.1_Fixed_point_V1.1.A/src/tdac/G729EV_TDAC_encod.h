/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDAC_ENCOD_H__
#define __G729EV_TDAC_ENCOD_H__

#include <stdio.h>
#include "stl.h"

/* Functions : */

void      G729EV_TDAC_encoder(Word16 * y_lo, Word16 * y_hi, Word16 * bitstream, Word16 nbit, Word16 nbit_max,
                              Word16 norm_lo, Word16 norm_hi, Word16 norm_MDCT);


/* Tables : */

#endif /* __G729EV_TDAC_ENCOD_H__ */
