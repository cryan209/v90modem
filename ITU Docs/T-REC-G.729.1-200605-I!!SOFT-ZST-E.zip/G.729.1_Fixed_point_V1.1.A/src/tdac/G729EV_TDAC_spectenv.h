/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDAC_ENVSPECT_H__
#define __G729EV_TDAC_ENVSPECT_H__

#include <stdio.h>
#include "stl.h"

/* Functions : */

void      G729EV_TDAC_calc_specEnv(Word16 * y, Word16 * log_rms, Word16 n, Word16 norm_lo, Word16 norm_hi,
                                   Word16 norm_MDCT);

Word16    G729EV_TDAC_compute_diff_index(Word16 * rms_index, Word16 n, Word16 * diff_index);
void      G729EV_TDAC_quant_3dB(Word16 * index, Word16 * log_rms, Word16 norm_MDCT);
void      G729EV_TDAC_encode_spenv(Word16 * rms_index, Word16 * diff_index, Word16 * bitstream, Word16 * nbit_env,
                                   Word16 n, Word16 satur, Word16 norm_MDCT);
void      G729EV_TDAC_writ_specEnv(Word16 * bits_env, Word16 * nb_bits_env, Word16 n, Word16 nbit, Word16 ** bitstream,
                                   Word16 * bit_cnt);
void      G729EV_TDAC_cod_spenv(Word16 * log_rms, Word16 * rms_index, Word16 ** pBit, Word16 * bit_cnt,
                                Word16 nbit_to_encode, Word16 norm_MDCT);

UWord16   G729EV_TDAC_read_bits(UWord16 * buffer, Word16 len, Word16 ** bitstream, Word16 * bit_cnt);
void      G729EV_TDAC_dec(UWord16 * buffer, Word16 ** bitstream, Word16 * bit_cnt, Word16 * rms_index,
                          Word16 norm_MDCT);
void      G729EV_TDAC_find_huffman(UWord16 * buffer, const Word16 * len, const UWord16 * code, Word16 nb_code,
                                   Word16 * k);
void      G729EV_TDAC_flush_buffer(UWord16 * buffer, Word16 len, Word16 ** bitstream, Word16 * bit_cnt);
Word16    G729EV_TDAC_decode_rms_index(Word16 ** bitstream, Word16 * rms_index, Word16 * bit_cnt, Word16 nbit_to_decode,
                                       Word16 n, UWord16 * buffer, Word16 norm_MDCT);
void      G729EV_TDAC_calc_rms_q(Word16 * rms_index, Word16 * rmsq, Word16 norm_MDCT, Word16 * ndec);
void      G729EV_TDAC_dec_specEnv(Word16 ** bitstream, Word16 * rms_index, Word16 * rmsq, Word16 * bit_cnt,
                                  Word16 nbit_to_decode, Word16 * bad_env_nb, Word16 * bad_env_wb, Word16 norm_MDCT);

/* Tables : */

extern const Word16 G729EV_TDAC_sb_bound[G729EV_TDAC_NB_SB + 1];
extern const Word16 G729EV_TDAC_nb_coef_div[G729EV_TDAC_NB_SB];

extern const Word16 G729EV_TDAC_len_huff_diff[25];
extern const UWord16 G729EV_TDAC_code_huff_diff[25];





#endif  /*__G729EV_TDAC_ENVSPECT_H__ */
