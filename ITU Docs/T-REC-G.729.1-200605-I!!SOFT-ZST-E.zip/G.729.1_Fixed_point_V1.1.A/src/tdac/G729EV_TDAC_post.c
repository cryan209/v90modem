/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include <stdlib.h>

#include "stl.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_post.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_PostModify()                                      *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 *  Modify envelope for post-processing of MDCT coefficients                *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_PostModify(Word16 * yq,  /* (i)     envelope per subbands */
                            Word16 n_yq,  /* (i)     number of subbands */
                            Word16 alfa   /* (i)     tuning factor */
    )
{
  Word16    Max, alfa0, alfa1;
  Word16    temp, exp1, exp2;
  Word16    j;

  Max = (Word16) 0;
#if(WMOPS)
  move16();
#endif
  FOR(j = 0; j < n_yq; j++)
  {
    if (sub(yq[j], Max) > 0)
    {
      Max = yq[j];
#if(WMOPS)
      move16();
#endif
    }
  }
  Max = add(Max, 1);

  alfa1 = sub(32767, alfa);
  exp1 = norm_s(alfa);
  exp1 = sub(exp1, 1);
  alfa = shl(alfa, exp1);
  exp2 = norm_s(Max);
  Max = shl(Max, exp2);
  exp1 = sub(exp1, exp2);
  alfa0 = div_s(alfa, Max);

  FOR(j = 0; j < n_yq; j++)
  {
    temp = shr(mult_r(yq[j], alfa0), exp1);
    temp = add(temp, alfa1);
    yq[j] = mult_r(yq[j], temp);
#if(WMOPS)
    move16();
#endif
  }
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_PostProcess()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Post-processing of higher-band MDCT coefficients                        *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_PostProcess(Word16 * ykr,  /* (i)     reconstructed higher-band MDCT coefficients */
                             Word16 nbits   /* (i)     number of bits to decode in TDAC */
    )
{
  Word32    L_tmp;
  Word32    Mag0, Mag1;

  Word16    EnvelopQ[G729EV_TDAC_NB_SB_PST], EnvelopQ_P[G729EV_TDAC_NB_SB_PST];

  Word16    sign[G729EV_MAIN_L_FRAME2];
  Word16    g, alfa, beta;
  Word16    i, j, i_s, rate_flag;
  Word16    temp, exp;

  alfa = 8192;                  /* 0.25 in Q15 */
  beta = 9830;                  /* 0.3  in Q15 */
#if(WMOPS)
  move16();
  move16();
#endif

  rate_flag = mult_r(shl(sub(shr(nbits, 3), 35), 7), 26214);
  alfa = sub(alfa, rate_flag);
  beta = sub(beta, rate_flag);

  /* ----------------- Record sign ----------------- */
  FOR(j = 0; j < G729EV_MAIN_L_FRAME2; j++)
  {
    sign[j] = 32767;
#if(WMOPS)
    move16();
#endif
    IF(ykr[j] < 0)
    {
      sign[j] = -32767;
      ykr[j] = negate(ykr[j]);
#if(WMOPS)
      move16();
      move16();
#endif
    }
  }

  /* ----------------------------------------------- */
  /* Envelope estimate  and Post-processing         */
  /* ----------------------------------------------- */

  /* Envelope */
  i_s = (Word16) 0;
#if(WMOPS)
  move16();
#endif
  FOR(j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    /* Envelope estimate */
    L_tmp = (Word32) 1;
#if(WMOPS)
    move32();
#endif
    FOR(i = i_s; i < i_s + G729EV_TDAC_NB_SB_LEN; i++)
    {
      L_tmp = L_mac(L_tmp, 1, ykr[i]);
    }
    EnvelopQ[j] = extract_l(L_shr(L_tmp, 4));
    i_s = add(i_s, (Word16) G729EV_TDAC_NB_SB_LEN);
#if(WMOPS)
    move16();
#endif
  }

  /* Post-processing */
  Mag0 = (Word32) 1;
#if(WMOPS)
  move32();
#endif
  FOR(j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    Mag0 = L_mac(Mag0, 1, EnvelopQ[j]);
  }

  FOR(j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    EnvelopQ_P[j] = EnvelopQ[j];
#if(WMOPS)
    move16();
#endif
  }

  G729EV_TDAC_PostModify(EnvelopQ_P, (Word16) G729EV_TDAC_NB_SB_PST, alfa);

  /* Energy compensation */
  Mag1 = (Word32) 1;
#if(WMOPS)
  move32();
#endif
  FOR(j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    Mag1 = L_mac(Mag1, 1, EnvelopQ_P[j]);
  }

  L_tmp = L_sub(Mag0, Mag1);
  IF(L_tmp > 0)
  {
    exp = norm_l(Mag1);
    g = extract_h(L_shl(Mag1, exp));
    temp = extract_h(L_shl(L_tmp, exp));
    g = div_s(temp, g);
  }
  ELSE
  {
    g = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }

  FOR(j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    EnvelopQ_P[j] = add(EnvelopQ_P[j], mult_r(g, EnvelopQ_P[j]));
#if(WMOPS)
    move16();
#endif
  }

  /* Normalize */
  FOR(j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    IF(sub(EnvelopQ_P[j], EnvelopQ[j]) >= 0)
    {
      EnvelopQ_P[j] = 32767;
    }
    ELSE
    {
      EnvelopQ_P[j] = div_s(EnvelopQ_P[j], EnvelopQ[j]);
    }
#if(WMOPS)
    move16();
#endif
  }

  /* ----------------------------------------------- */
  /*  Fine structure post-processing                */
  /* ----------------------------------------------- */

  i_s = (Word16) 0;
#if(WMOPS)
  move16();
#endif
  FOR(j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    G729EV_TDAC_PostModify(&ykr[i_s], (Word16) G729EV_TDAC_NB_SB_LEN, beta);
    i_s = add(i_s, (Word16) G729EV_TDAC_NB_SB_LEN);
  }

  /* ----------------------------------------------- */
  /*      Reconstruction                            */
  /* ----------------------------------------------- */
  i_s = (Word16) 0;
#if(WMOPS)
  move16();
#endif
  FOR(j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    FOR(i = i_s; i < i_s + G729EV_TDAC_NB_SB_LEN; i++)
    {
      ykr[i] = mult_r(ykr[i], EnvelopQ_P[j]);
      ykr[i] = mult(ykr[i], sign[i]);
#if(WMOPS)
      move16();
      move16();
#endif
    }
    i_s = add(i_s, (Word16) G729EV_TDAC_NB_SB_LEN);
  }

  /* ----------------------------------------------- */
  return;
}
