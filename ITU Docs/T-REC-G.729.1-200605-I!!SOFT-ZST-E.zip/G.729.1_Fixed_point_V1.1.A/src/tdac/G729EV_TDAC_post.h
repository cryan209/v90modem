/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDAC_POST_H__
#define __G729EV_TDAC_POST_H__

#include <stdio.h>
#include "stl.h"

/* Functions */
void      G729EV_TDAC_PostProcess(Word16 * ykr, Word16 nbits);
void      G729EV_TDAC_PostModify(Word16 * yq, Word16 n_yq, Word16 alfa);

#endif /* __G729EV_TDAC_POST_H__ */
