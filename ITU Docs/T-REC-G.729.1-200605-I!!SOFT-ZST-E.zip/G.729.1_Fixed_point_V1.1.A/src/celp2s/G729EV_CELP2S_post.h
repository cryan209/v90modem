/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_CELP2S_POST_H__
#define __G729EV_CELP2S_POST_H__

#include "stl.h"


/* functions */
void      G729EV_CELP2S_init_post_filter(G729EV_MAIN_PFSTAT * pfstat);/**< (i)   : core decoder parameters                */


void      G729EV_CELP2S_Post(G729EV_MAIN_PFSTAT * pfstat,   /* input/output stqtes strucure */
                             Word16 t0,                     /* input : pitch delay given by coder */
                             Word16 * signal_ptr,           /* input : input signal (pointer to current subframe */
                             Word16 * coeff,                /* input : LPC coefficients for current subframe */
                             Word16 * sig_out,              /* output: postfiltered output */
                             Word16 gamma1,                 /* input: short term postfilt. den. weighting factor */
                             Word16 gamma2,                 /* input: short term postfilt. num. weighting factor */
                             Word16 PostNB, Word16 Vad);

#endif /* __G729EV_CELP2S_POST_H__ */
