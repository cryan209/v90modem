/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_CELP2S_ACELP_CA_H__
#define __G729EV_CELP2S_ACELP_CA_H__

#include "stl.h"

#include "G729EV_G729_ld8k.h"
#include "G729EV_MAIN_OPER_32B.h"
#include "G729EV_MAIN_DSPFUNC.h"

/*
Functions
*/

void      G729EV_CELP2S_cor_h_OTH(Word16 * h, Word16 * rr, Word16 * y1);
void      G729EV_CELP2S_cor_h_x_OTH(Word16 h[], Word16 x[], Word16 d[], Word16 y1[]);
Word16    G729EV_CELP2S_d4i40_17_fast(Word16 layer, Word16 sp,
                                      Word16 b[], Word16 dn[], Word16 rr[], Word16 h0[],
                                      Word16 h[], Word16 cod[], Word16 y[], Word16 * sign);
Word16    G729EV_CELP2S_ACELP_code_A_OTH(Word16 x[], Word16 res2[], Word16 h[], Word16 T0,
                                         Word16 pitch_sharp, Word16 code[], Word16 y[], Word16 * sign, Word16 y1[]);
Word16    G729EV_CELP2S_ACELP_code_2NDLAYER(Word16 x[], Word16 res2[], Word16 h[], Word16 norm_voic_fac, Word16 code[],
                                            Word16 y[], Word16 * sign);
void      G729EV_CELP2S_Put4Patterns(Word16 pos[], Word16 si[], Word16 sp, Word16 cod[]);



#endif  /*__G729EV_G729_ACELP_CA_H__ */
