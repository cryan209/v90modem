/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDBWE_FIR_H__
#define __G729EV_TDBWE_FIR_H__


#include "stl.h"
#include "G729EV_MAIN_defines.h"


/* type definition TDBWE FIR filter state variable */
typedef struct
{

  Word16   *filter_coeffs;
  Word16    state[G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1];

} G729EV_TDBWE_fir_state;


/* prototypes for exported functions */

void      G729EV_TDBWE_fir_initialize(G729EV_TDBWE_fir_state * state, Word16 * filter_coeffs);

void      G729EV_TDBWE_fir(G729EV_TDBWE_fir_state * state, Word16 * input, Word16 * output, Word16 vector_size);


#endif
