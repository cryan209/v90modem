/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDBWE_VECTOR_QUANTIZATION_H__
#define __G729EV_TDBWE_VECTOR_QUANTIZATION_H__

#include "stl.h"


/* protoype for exported function */

void      G729EV_TDBWE_vector_quantization(Word16 * input,
                                           const Word16 * codebook,
                                           UWord16 * index, const Word16 vector_size, const Word16 codebook_size);


/* tables */

/* TDBWE table for mean time envelope quantization       */
extern const Word16 G729EV_TDBWE_MEAN_TIME_ENV_cb[32];

/* TDBWE tables for time envelope quantization           */
extern const Word16 G729EV_TDBWE_TIME_ENV_cb[1024];

/* TDBWE tables for frequency envelope quantization      */
extern const Word16 G729EV_TDBWE_FREQ_ENV_NUMBER_ENTRIES[3];
extern const Word16 G729EV_TDBWE_FREQ_ENV_BITS[3];
extern const Word16 *G729EV_TDBWE_FREQ_ENV_cb[3];
extern const Word16 G729EV_TDBWE_FREQ_ENV_cb1[128];
extern const Word16 G729EV_TDBWE_FREQ_ENV_cb2[128];
extern const Word16 G729EV_TDBWE_FREQ_ENV_cb3[64];

#endif
