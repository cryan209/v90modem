/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_TDBWE_TIME_ENVELOPE_SHAPING_H__
#define __G729EV_TDBWE_TIME_ENVELOPE_SHAPING_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"


/* prototype for exported function */

void      G729EV_TDBWE_time_envelope_shaping(Word16 * input,
                                             Word16 * envelope,
                                             Word16 * output, Word16 * prev_gain, Word16 * prev_norm);


/* tables */

extern const Word16 G729EV_TDBWE_TIME_ENVELOPE_SHAPING_WINDOW[G729EV_TDBWE_SUBFRAME_SIZE_2];


#endif
