/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#ifndef __G729EV_MAIN_PRM_H__
#define __G729EV_MAIN_PRM_H__

#include "stl.h"
#include "G729EV_MAIN_encod.h"
#include "G729EV_MAIN_decod.h"

/* Functions : */

void      G729EV_MAIN_param2bit(Word16 * coder_parameters,                  /* input */
                                Word16 nb_bits, Word16 * itu_192_bitstream, /* output */
                                CODSTATMAIN * codstat);

void      G729EV_MAIN_bit2param(Word16 * itu_192_bitstream, /* input */
                                Word16 nb_bits,             /* input / number of bits in bitstream */
                                Word16 * coder_parameters,  /* output */
                                Word16 * ind_FER,           /* output */
                                DECSTATMAIN * decstat);


#endif  /*__G729EV_MAIN_PRM_H__ */
