/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include "stl.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_encod.h"
#include "G729EV_MAIN_decod.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_int2bin()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Push bits of codeword (Word16) into bitstream array                     *
 *--------------------------------------------------------------------------*/

void G729EV_MAIN_int2bin(Word16 value,        /* (i)     value to be converted to binary      */
                         Word16 nb_bits,      /* (i)     number of bits associated with value */
                         Word16 * bitstream)  /* (o)     address where bits are written       */
{

  Word16    i, nb_bits_m1;
  Word16    mask;

  /* MSB -> LSB */
  nb_bits_m1 = sub(nb_bits, 1);
  FOR(i = nb_bits_m1; i >= 0; i--)
  {
    *bitstream = ITU_G192_BIT_1;
#if(WMOPS)
    move16();
#endif
    mask = (Word16) (shr(value, i) & 0x0001);
    if (mask == 0)
    {
      *bitstream = ITU_G192_BIT_0;
#if(WMOPS)
      move16();
#endif
    }

    bitstream++;
  }
  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_bin2int()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Get bits of codeword (Word16) from bitstream array                      *
 *--------------------------------------------------------------------------*/

Word16 G729EV_MAIN_bin2int(Word16 * bitstream,  /* (i)  adress where bits are read              */
                           Word16 nb_bits)      /* (i)  number of bits associated with value    */
{
  Word32    code_L;

  UWord16   code;
  UWord16   temp16;
  Word16    i;

  code_L = (Word32) 0;
#if(WMOPS)
  move32();
#endif

  FOR(i = 0; i < nb_bits; i++)
  {
    /* Need to use a 32 bits variable to avoid saturation problems caused by shl or L_shl */
    code_L = L_shl(code_L, 1);
    temp16 = (Word16) 1;

#if (WMOPS)
    move16();
#endif
    if (sub(*bitstream, ITU_G192_BIT_0) == 0)
    {
      temp16 = (Word16) 0;
#if (WMOPS)
      move16();
#endif
    }

    code_L = code_L | temp16;
#if (WMOPS)
    logic32();
#endif
    bitstream++;
  }
  code = extract_l(code_L);
  return (code);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_param2bit()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Write coder parameters into G.192 format bitstream                      *
 *--------------------------------------------------------------------------*/

void G729EV_MAIN_param2bit(Word16 * coder_parameters,   /* (i)      coder parameters            */
                           Word16 nb_bits,              /* (i)      number of bits for encoder  */
                           Word16 * itu_192_bitstream,  /* (o)      G.192 encoder bitstream     */
                           CODSTATMAIN * codstat)       /* (i)      coder states variables      */
{
  Word16   *bit_ptr;
  Word16   *prm_ptr;
  Word16    bit_FEC[2];

  /* Pointers initialization */
  bit_ptr = itu_192_bitstream;
  prm_ptr = coder_parameters;
#if(WMOPS)
  move16();
  move16();
#endif

#if(WMOPS)
  move16();
  move16();
#endif

  /* Generate 8k bistream */
  /* --> first subframe (80 bits) */
  G729EV_MAIN_int2bin(*prm_ptr++, 8, bit_ptr);
  bit_ptr += 8;
  G729EV_MAIN_int2bin(*prm_ptr++, 10, bit_ptr);
  bit_ptr += 10;
  G729EV_MAIN_int2bin(*prm_ptr++, 8, bit_ptr);
  bit_ptr += 8;
  G729EV_MAIN_int2bin(*prm_ptr++, 1, bit_ptr);
  bit_ptr += 1;
  G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
  bit_ptr += 13;
  G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
  bit_ptr += 4;
  G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
  bit_ptr += 7;
  G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
  bit_ptr += 5;
  G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
  bit_ptr += 13;
  G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
  bit_ptr += 4;
  G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
  bit_ptr += 7;
#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
#endif
  IF(sub(codstat->g729_bst, 1) == 0)
  {
    *bit_ptr++ = ITU_G192_SYNCWORD;
    *bit_ptr++ = 80;
  }
  /* --> second subframe (80 bits) */
  prm_ptr += 6;                 /* jump to beginning of 2nd 8k subframe coder parameters */
  G729EV_MAIN_int2bin(*prm_ptr++, 8, bit_ptr);
  bit_ptr += 8;
  G729EV_MAIN_int2bin(*prm_ptr++, 10, bit_ptr);
  bit_ptr += 10;
  G729EV_MAIN_int2bin(*prm_ptr++, 8, bit_ptr);
  bit_ptr += 8;
  G729EV_MAIN_int2bin(*prm_ptr++, 1, bit_ptr);
  bit_ptr += 1;
  G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
  bit_ptr += 13;
  G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
  bit_ptr += 4;
  G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
  bit_ptr += 7;
  G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
  bit_ptr += 5;
  G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
  bit_ptr += 13;
  G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
  bit_ptr += 4;
  G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
  bit_ptr += 7;
#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
#endif
  
  IF(sub(codstat->g729_bst, 1) != 0)
  {
      /* Generate 12k bitstream */
      /* --> first subframe (40 bits) */
      prm_ptr -= 17;                /* jump to the beginning of the 1st 12k subframe coder parameters */
      G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
      bit_ptr += 13;
      G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
      bit_ptr += 4;
      G729EV_MAIN_int2bin(*prm_ptr++, 3, bit_ptr);
      bit_ptr += 3;
      G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
      bit_ptr += 13;
      G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
      bit_ptr += 4;
      G729EV_MAIN_int2bin(*prm_ptr++, 3, bit_ptr);
      bit_ptr += 3;
      /* --> second subframe (40 bits) */
      prm_ptr += 11;
      G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
      bit_ptr += 13;
      G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
      bit_ptr += 4;
      G729EV_MAIN_int2bin(*prm_ptr++, 3, bit_ptr);
      bit_ptr += 3;
      G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
      bit_ptr += 13;
      G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
      bit_ptr += 4;
      G729EV_MAIN_int2bin(*prm_ptr++, 3, bit_ptr);
      bit_ptr += 3;
      /* Insert FEC information (bits 199 and 239) */
      prm_ptr += 7;                 /* jump to FEC 12k parameters */
      G729EV_MAIN_int2bin(*prm_ptr++, 2, bit_FEC);
      itu_192_bitstream[197] = bit_FEC[0];
      itu_192_bitstream[237] = bit_FEC[1];
#if(WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
#endif
      
      /* Generate 14k bitstream (33 bits + 7 bits - FEC -) */
      prm_ptr -= 8;                 /* jump to TDBWE coder parameters */
      G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
      bit_ptr += 5;
      G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
      bit_ptr += 7;
      G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
      bit_ptr += 7;
      G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
      bit_ptr += 5;
      G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
      bit_ptr += 5;
      G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
      bit_ptr += 4;
      /* Insert FEC information (7 bits) */
      G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
      bit_ptr += 7;
#if(WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
#endif
      
      /* Generate 16k+ bitstream (FEC : 5 bits ; norm_shift : 4 bits) */
      prm_ptr += 1;                 /* jump to 3rd coder parameter of FEC */
      G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
      bit_ptr += 5;
      G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
#if(WMOPS)
      move16();
      move16();
#endif
  }

  /* TDAC part is already in itu_192_bitstream */
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_bit2param()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Read coder parameters from G.192 format bitstream                      *
 *--------------------------------------------------------------------------*/

void G729EV_MAIN_bit2param(Word16 * itu_192_bitstream,  /* (i)  G.192 decoder bitstream     */
                           Word16 nb_bits,              /* (i)  number of bits available    */
                           Word16 * coder_parameters,   /* (o)  coder paramaters            */
                           Word16 * ind_FER,            /* (o)  FER parameters              */
                           DECSTATMAIN * decstat)       /* (i)  decoder states variables    */
{
  Word16   *bit_ptr;
  Word16   *prm_ptr;
  Word16    rate;
  Word16    bit_FEC[2];

  /* variable initialization */
  rate = i_mult(nb_bits, 50);

  /* Pointers initialization */
  bit_ptr = itu_192_bitstream;
  prm_ptr = coder_parameters;
#if(WMOPS)
  move16();
  move16();
#endif

  /* Get 8k bistream */
  /* --> first subframe (80 bits) */
  IF(sub(decstat->decStG729.g729b_bst, 1) != 0)
  {
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
    bit_ptr += 8;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 10);
    bit_ptr += 10;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
    bit_ptr += 8;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
    bit_ptr += 1;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
#if(WMOPS)
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
#endif
  } ELSE
  {                             /* G.729 mode */
    IF(sub(decstat->decStG729.ftyp[0], 1) == 0)
    {                           /* speech frame (80 bits) */
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
      bit_ptr += 8;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 10);
      bit_ptr += 10;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
      bit_ptr += 8;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
      bit_ptr += 1;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
      bit_ptr += 13;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
      bit_ptr += 7;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
      bit_ptr += 13;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
      bit_ptr += 7;
#if(WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
#endif
    } ELSE if (sub(decstat->decStG729.ftyp[0], 2) == 0)
    {                           /* SID frame (15 bits) */
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
      bit_ptr += 1;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      prm_ptr += 7;
#if(WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
#endif
    }
    ELSE if   (sub(decstat->decStG729.ftyp[0], 0) == 0)
    {                           /* not transmited frame (0 bit) */
      prm_ptr += 11;
#if(WMOPS)
      move16();
#endif
    }
  }

  if (sub(decstat->g729b_bst, 1) == 0)
  {
    bit_ptr += 2;               /* Bypass syncword and number of bits in g729 second frame */
#if(WMOPS)
    move16();
#endif
  }

  /* --> second subframe (80 bits) */
  prm_ptr += 6;                 /* jump to beginning of 2nd 8k subframe coder parameters */
#if(WMOPS)
  move16();
#endif
  IF(sub(decstat->decStG729.g729b_bst, 1) != 0)
  {
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
    bit_ptr += 8;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 10);
    bit_ptr += 10;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
    bit_ptr += 8;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
    bit_ptr += 1;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
#if(WMOPS)
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
#endif
  }
  ELSE
  {                             /* G.729B mode */
    IF(sub(decstat->decStG729.ftyp[1], 1) == 0)
    {                           /* speech frame (80 bits) */
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
      bit_ptr += 8;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 10);
      bit_ptr += 10;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
      bit_ptr += 8;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
      bit_ptr += 1;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
      bit_ptr += 13;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
      bit_ptr += 7;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
      bit_ptr += 13;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
      bit_ptr += 7;
#if(WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
#endif
    }
    ELSE if   (sub(decstat->decStG729.ftyp[1], 2) == 0)
    {                           /* SID frame (15 bits) */
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
      bit_ptr += 1;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      prm_ptr += 7;
#if(WMOPS)
      move16();
      move16();
      move16();
      move16();
#endif
    }
    ELSE if   (sub(decstat->decStG729.ftyp[1], 0) == 0)
    {                           /* not transmited frame (0 bit) */
      prm_ptr += 11;
#if(WMOPS)
      move16();
#endif
    }
  }

  IF(rate >= 12000)
  {
    /* Get 12k bitstream */
    /* --> first subframe (40 bits) */
    prm_ptr -= 17;              /* jump to the beginning of the 1st 12k subframe coder parameters */
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 3);
    bit_ptr += 3;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 3);
    bit_ptr += 3;
    /* --> second subframe (40 bits) */
    prm_ptr += 11;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 3);
    bit_ptr += 3;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 3);
    bit_ptr += 3;
    /* --> get FEC information */
    bit_FEC[0] = itu_192_bitstream[197];
    bit_FEC[1] = itu_192_bitstream[237];
    ind_FER[0] = G729EV_MAIN_bin2int(bit_FEC, 2);
#if(WMOPS)
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
#endif
  }

  IF(rate >= 14000)
  {
    /* Get 14k bitstream (33 bits) */
    /* prm_ptr -= 8;    jump to TDBWE coder parameters */
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    ind_FER[2] = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
#if(WMOPS)
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
#endif
  }

  IF(rate >= 16000)
  {
    ind_FER[1] = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
#if(WMOPS)
    move16();
    move16();
#endif

    /* TDAC bitstream is read in TDAC decoder */
  }
}
