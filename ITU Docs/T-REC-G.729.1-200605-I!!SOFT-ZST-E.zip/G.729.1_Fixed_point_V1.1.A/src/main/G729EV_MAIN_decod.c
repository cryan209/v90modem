/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729_DecStat.h"
#include "G729EV_CELP2S_decod.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_decod.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_TAB_ld8k.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_MAIN_EnvAdaption.h"
#include "G729EV_TDAC_decod.h"
#include "G729EV_TDAC_mdct.h"
#include "G729EV_TDAC_util.h"
#include "G729EV_MAIN_DSPFUNC.h"
#include "G729EV_MAIN_prm.h"
#include "G729EV_TDAC_post.h"
#include "G729EV_CELP2S_post.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_InitDecoder()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                     *
 *  Decoder Initializations                                                 *
 *--------------------------------------------------------------------------*/

void G729EV_MAIN_InitDecoder(DECSTATMAIN * decstat, /* (o)  decoder states variables    */
                             Word16 f8,             /* (i)  8kHz sampled input flag     */
                             Word16 g729b_bst,      /* (i)  G.729 bistream mode flag    */
                             Word16 low_delay)      /* (i)  Low-delay mode flag         */
{
  Word16    i;

  IF(decstat == NULL)
  {
    exit(-1);
  }

  memset(decstat, 0, sizeof(*decstat));

  /* set previous bad frame indicator */
  decstat->prev_bfi = (Word16) 0;
#if(WMOPS)
  move16();
#endif

  /* set the flag for 8kHz sampled output */
  decstat->f8 = f8;
#if (WMOPS)
  move16();
#endif

  /* set the flag for g729 bitstream mode */
  decstat->g729b_bst = g729b_bst;
#if(WMOPS)
  move16();
#endif

  decstat->low_delay = low_delay;
#if(WMOPS)
  move16();
#endif

  /* initialize QMF filterbank */
  G729EV_MAIN_initQMF_syn(&decstat->qmf_syn);

  /* initialize CELP decoder */
  G729EV_CELP2S_InitDecoder(&decstat->decStG729, g729b_bst);

  /* initialize memories for MDCT computation */
  G729EV_G729_Set_zero(decstat->mem_mdct_hi, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Set_zero(decstat->mem_inv_mdct_hi, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Set_zero(decstat->mem_inv_mdct_lo, G729EV_MAIN_L_FRAME2);

  G729EV_G729_Set_zero(decstat->sTdbweOld, G729EV_MAIN_L_FRAME2);

  decstat->vmhold = (Word16) 0x7fff;  /* Q.15, 1.0 */
  decstat->vmlold = (Word16) 0x7fff;  /* Q.15, 1.0 */
#if(WMOPS)
  move16();
  move16();
#endif

  /* initialize TDBWE decoder */
  G729EV_TDBWE_decoder_init(&decstat->tdbwe);

  /* initialize memory of previous CELP-decoded frame (for difference computation in lower band) */
  G729EV_G729_Set_zero(decstat->old_celp_output, G729EV_MAIN_L_FRAME2);

  /* postfiltering */
  G729EV_G729_Set_zero(decstat->mem_pf_in, G729EV_G729_M_LPC);
  G729EV_CELP2S_init_post_filter(&decstat->mem_pf);
  G729EV_G729_Set_zero(decstat->mem_Az, 4 * G729EV_G729_MP1);

  FOR(i = 0; i < (4 * G729EV_G729_MP1); i += G729EV_G729_MP1)
  {
    decstat->mem_Az[i] = (Word16) 4096;
#if(WMOPS)
    move16();
#endif
  }
  FOR(i = 0; i < 4; i++)
  {
    decstat->mem_t0[i] = (Word16) 60;
#if(WMOPS)
    move16();
#endif
  }

  /* post processing */
  IF(low_delay == 0) decstat->mem_postflag = (Word16) 0;
  ELSE decstat->mem_postflag = (Word16) 1;
#if(WMOPS)
  move16();
#endif
  G729EV_MAIN_init_iir2(&decstat->mem_postpro);

  /* perceptual weighting filter of lower band difference signal */
  G729EV_G729_Set_zero(decstat->mem_invWz_in, G729EV_G729_M);
  G729EV_G729_Set_zero(decstat->mem_invwsp, G729EV_G729_M);

  /* bitrate switching initialization */
  decstat->count_rcv = G729EV_MAIN_COUNT_RCV_MAX;
  decstat->first_frame = (Word16) 1;
  decstat->prev_nRcv_hi = (Word16) 0;
  decstat->prev_rate = (Word16) 0;
#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
#endif

  /* init FEC variables */
  decstat->lp_ener_FER = (Word16) (256 * 60); /* Q8 */
  decstat->lastgood = G729EV_FEC_UNVOICED;
  decstat->plast_good = G729EV_FEC_UNVOICED;
  decstat->old_enrLP = (Word16) 0;  /*Q4 */
#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
#endif
  G729EV_G729_Set_zero(decstat->synth_buf, G729EV_G729_PIT_MAX);

  /* initialize memory for median filter to smooth the gamma parameters of the postfilter */
  FOR(i = 0; i < G729EV_MAIN_NMAX; i++)
  {
    decstat->tab_Th[i] = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_Decode()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Main decoder routine                                                    *
 *--------------------------------------------------------------------------*/

void G729EV_MAIN_Decode(DECSTATMAIN * decstat,      /* (i)  decoder states variables        */
                        Word16 * itu_192_bitstream, /* (i)  G.192 bitstream to decode       */
                        Word16 * tabout,            /* (o)  20 ms  speech signal            */
                        Word16 rate,                /* (i)  Decoding rate                   */
                        Word16 bfi                  /* (i)  Bad Frame Indicator             */
)
{
  G729EV_CELP2S_PARAM nb_celp_param;
  G729EV_MAIN_PFSTAT *pfstat;

  Word32    Ltmp;
  Word32    L_enr_q;            /* Q0 */

  Word16    celp_output[G729EV_MAIN_L_FRAME2];
  Word16    output_lo[G729EV_MAIN_L_FRAME2];
  Word16    output_hi[G729EV_MAIN_L_FRAME2];
  Word16    output_hiTdbwe[G729EV_MAIN_L_FRAME2];
  Word16    diff_q[G729EV_MAIN_L_FRAME2];
  Word16    yq_lo[G729EV_MAIN_L_FRAME2];
  Word16    yq_hi[G729EV_MAIN_L_FRAME2];
  Word16    yt_hi[G729EV_MAIN_L_FRAME2];
  Word16    pst_in[G729EV_MAIN_L_FRAME2];
  Word16    parameters_tdbwe[G729EV_TDBWE_NB_PARAMETERS]; /* Q.10 */
  Word16    pf_in_buffer[G729EV_G729_M_LPC + G729EV_MAIN_L_FRAME2];
  Word16    coreExc[G729EV_MAIN_L_FRAME2], extExc[G729EV_MAIN_L_FRAME2], BfAq[4 * G729EV_G729_MP1];
  Word16    pitch_buf[G729EV_MAIN_NB_SUBFR];
  Word16    mem_syntmp[G729EV_G729_M];
  Word16    ind_fer[3];
  Word16    parm_FEC[13];
  Word16    coder_parameters[G729EV_G729_PRM_SIZE_MAX * 2 + 10];

  Word16   *ptr_Az;
  Word16   *pf_in;
  Word16   *coder_param_ptr;

  Word16    i_frame, i, j, ind;
  Word16    nb_bits_to_decode;
  Word16    nb_bits_left;
  Word16    nb_bits_used;
  Word16    nb_bits_max;
  Word16    norm_MDCT;
  Word16    norm_local;
  Word16    diff_norm;
  Word16    nRcv_hi;
  Word16    t0_first;           /* Pitch lag in 1st subframe   */
  Word16    ga1_post, ga2_post;
  Word16    tmp16;
  Word16    clas;
  Word16    FerPitch;
  Word16    begin_index_low, end_index_low, begin_index_high, end_index_high; /*beggining & end of the false alarm zone */


  /* set pointer to parameters */
  coder_param_ptr = coder_parameters;

  /* compute number of bits to decode */
  nb_bits_to_decode = rate / 50;

  /* set FEC variables */
  L_enr_q = (Word32) - 1;
  clas = decstat->lastgood;
  pitch_buf[0] = decstat->decStG729.pit_mem[0];
  pitch_buf[1] = decstat->decStG729.pit_mem[1];
  pitch_buf[2] = decstat->decStG729.pit_mem[2];
  pitch_buf[3] = decstat->decStG729.pit_mem[3];
#if(WMOPS)
  move32();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
#endif
  ind_fer[0] = (Word16) - 1000;
  ind_fer[1] = (Word16) - 1000;
  ind_fer[2] = (Word16) - 1000;
#if(WMOPS)
  move16();
  move16();
  move16();
#endif

  /* set frame type (ftyp) for G.729B decoding */
#if(WMOPS)
  test();
#endif
  IF((decstat->g729b_bst) && (bfi))
  {
    IF(decstat->decStG729.past_ftyp == 1)
    {
      decstat->decStG729.ftyp[0] = 1;
      decstat->decStG729.ftyp[1] = 1;
    } ELSE
    {
      decstat->decStG729.ftyp[0] = 0;
      decstat->decStG729.ftyp[1] = 0;
    }
#if(WMOPS)
    move16();
    move16();
#endif
  }


#if(WMOPS)
  test();
  test();
#endif
  IF((!bfi) || ((decstat->g729b_bst) && (decstat->decStG729.ftyp[0] == 0)))
  {
    /************************************ decode received frame (bfi=0) **************************/

    /***************************
     * Initialize bit counters *
     ***************************/

    /* set number of bits for 20-ms frame */
    nb_bits_max = G729EV_MAX_BITRATE / 50;  /* maximal bit allocation (-> 32 kbit/s) */
    nb_bits_left = nb_bits_to_decode;       /* number of bits available for decoder */
    nb_bits_used = (Word16) 0;              /* number of bits used */
#if(WMOPS)
    move16();
    move16();
    move16();
#endif

    /*******************************************
     * Read bitstream and demultiplex parameters
     *******************************************/

    G729EV_MAIN_bit2param(itu_192_bitstream, nb_bits_to_decode, coder_parameters, ind_fer, decstat);

    /*********************************************************
     * decode FEC information (clas, puslse offset and energy)
     *********************************************************/

    IF(sub(rate, 12000) >= 0)
    {
      clas = G729EV_FEC_dec(&(decstat->lastgood), decstat->plast_good, decstat->prev_bfi, ind_fer, &L_enr_q, rate);
    }

    /************************************************************************
     * Update decoder CELP parameters if previous frame was erased (recovery)
     ************************************************************************/

    IF((sub(decstat->prev_bfi, 1) == 0) && (decstat->low_delay == 0))
    {
      coder_parameters[3] = G729EV_G729_Check_Parity_Pitch(coder_parameters[2], coder_parameters[3]);
#if(WMOPS)
      move16();
#endif
      /* The new clas is already known with the 14 kbit/s bitstream */
      G729EV_FEC_dec_bf(coder_parameters, decstat->old_celp_output, BfAq, G729EV_FEC_SINGLE_FRAME,
                        &(decstat->lastgood), pitch_buf, decstat->old_enrLP,
                        decstat->decStG729.old_exc, &(decstat->decStG729), clas, ind_fer[2]);

      /* Update to be done before decoding a good frame */
      FerPitch = shr(add(pitch_buf[0], G729EV_FEC_QPIT2), G729EV_FEC_SQPIT);
      if (sub(FerPitch, G729EV_G729_PIT_MIN) < 0)
      {
        FerPitch = G729EV_G729_PIT_MIN;
#if(WMOPS)
        move16();
#endif
      }
      if (sub(FerPitch, G729EV_G729_PIT_MAX) > 0)
      {
        FerPitch = G729EV_G729_PIT_MAX;
#if(WMOPS)
        move16();
#endif
      }

      G729EV_G729_UpdateMemTam(&decstat->decStG729, decstat->decStG729.lp_gainp, FerPitch);
      G729EV_G729_UpdateMemTam(&decstat->decStG729, decstat->decStG729.lp_gainp, FerPitch);

      /* update memory of A(z) and t0_first */
      G729EV_G729_Copy(BfAq, decstat->mem_Az, 4 * G729EV_G729_MP1);
      FOR(i = 0; i < 4; i++)
      {
        decstat->mem_t0[i] = shr(add(pitch_buf[i], G729EV_FEC_QPIT2), G729EV_FEC_SQPIT);
#if(WMOPS)
        move16();
#endif
      }
    }

#if(WMOPS)
    test();
    test();
#endif
    IF((sub(clas, G729EV_FEC_SIN_ONSET) == 0) && (sub(rate, 14000) >= 0))
    {
      if (sub(rate, 16000) < 0)
      {
        /* Use reconstruct energy information when not present in bitstream */
        L_enr_q = decstat->decStG729.Lenr_old;
#if(WMOPS)
        move16();
#endif
      }

      IF(sub(decstat->decStG729.bfi_cnt, 1) == 0)
      {
        G729EV_FEC_mod_adapt_codebook(decstat->decStG729.old_exc, ind_fer[2], pitch_buf, L_enr_q,
                                      BfAq + 3 * G729EV_G729_MP1);
      }
      ELSE
      {
        G729EV_FEC_mod_adapt_codebook(decstat->decStG729.old_exc, ind_fer[2], pitch_buf, L_enr_q,
                                      decstat->mem_Az + 3 * G729EV_G729_MP1);
      }
    }

    G729EV_G729_Copy(decstat->decStG729.mem_syn, mem_syntmp, G729EV_G729_M);
    decstat->decStG729.lp_gainc = (Word16) 0;
    decstat->decStG729.lp_gainp = (Word16) 0;
    decstat->decStG729.i_subfr_cnt = (Word16) 0;

#if(WMOPS)
    move16();
    move16();
    move16();
#endif


    /**************************************************************
     * Decoding of lower band : 8k core and 12k enhancement layer *
     **************************************************************/

#if(WMOPS)
    move16();
#endif
    j = (Word16) 0;
    FOR(i_frame = 0; i_frame < G729EV_MAIN_L_FRAME2; i_frame += G729EV_G729_L_FRAME)
    {
      /* get synthesis of G729/12k decoder (without postfilter) */
      G729EV_CELP2S_decoder(&decstat->decStG729, coder_param_ptr, rate, j, &nb_celp_param,
                            &BfAq[j * 2 * G729EV_G729_MP1], &coreExc[i_frame], &extExc[i_frame],
                            pitch_buf, clas, bfi);

      j = add(j, 1);

      /* update bit counter */
      IF(sub(rate, 12000) >= 0)
      {
        nb_bits_used = add(nb_bits_used, 120);
      }
      ELSE
      {
        nb_bits_used = add(nb_bits_used, 80);
      }

      /* update pointer to coder parameters offset */
      coder_param_ptr += G729EV_G729_PRM_SIZE_MAX;
    }

    /* number of bits lefts for decoding after CELP decoding */
    nb_bits_left = sub(nb_bits_left, nb_bits_used);

    G729EV_G729_syn(coreExc, extExc, decstat->decStG729.old_exc, BfAq, celp_output, decstat->decStG729.mem_syn,
                    decstat->decStG729.rate);

    /* if clas is not tranmist */
    IF(sub(rate, 12000) < 0)
    {
      G729EV_FEC_clas_dec(&clas, pitch_buf, decstat->lastgood, celp_output, decstat->synth_buf,
                          &(decstat->lp_ener_FER));
    }

    G729EV_FEC_pit_updt(clas, pitch_buf, decstat->lastgood, &(decstat->decStG729.upd_cnt),
                        &(decstat->decStG729.old_fpitch), decstat->decStG729.fpitch);

    G729EV_FEC_scale_syn(nb_bits_left, clas, decstat->lastgood, celp_output, pitch_buf, L_enr_q,
                         decstat->prev_bfi, BfAq, &(decstat->old_enrLP), mem_syntmp, coreExc,
                         decstat->decStG729.Lenr_old, decstat->decStG729.old_exc, decstat->decStG729.mem_syn,
                         decstat->decStG729.bfi_cnt);

    /***************************************************
    * Decoding of higher band : 14k enhancement layer *
    ***************************************************/

    IF(sub(rate, 14000) >= 0)
    {
      /* decode TDBWE parameters */
      G729EV_TDBWE_dequantization(coder_param_ptr, parameters_tdbwe);
      G729EV_TDBWE_decoder(&decstat->tdbwe, &nb_celp_param, output_hiTdbwe, parameters_tdbwe);

      /* copy TDBWE parameters for FEC */
      G729EV_G729_Copy(parameters_tdbwe, decstat->prev_parameters_tdbwe, G729EV_TDBWE_NB_PARAMETERS);
      FOR(i = 0; i < G729EV_MAIN_NB_SUBFR; i++)
      {
        decstat->prev_nb_celp_param.t0[i] = nb_celp_param.t0[i];
        decstat->prev_nb_celp_param.t0_frac[i] = nb_celp_param.t0_frac[i];
        decstat->prev_nb_celp_param.power_fix[i] = nb_celp_param.power_fix[i];
        decstat->prev_nb_celp_param.power_ltp[i] = nb_celp_param.power_ltp[i];
#if(WMOPS)
        move16();
        move16();
        move16();
        move16();
#endif
      }

      /* update bits counter and number of bits left */
      nb_bits_used = add(nb_bits_used, 40);
      nb_bits_left = sub(nb_bits_left, 40);

      /* update pointer to coder parameters offset */
      coder_param_ptr += 6;
    }
    ELSE
    {
      /* if rate < 14000 TDBWE output is forced to 0 */
      G729EV_G729_Set_zero(output_hiTdbwe, G729EV_MAIN_L_FRAME2);
    }

    /*************************************************************
    * Decoding of full-band spectrum: 16-32k enhancement layers *
    *************************************************************/

    IF(decstat->low_delay == 0)
    {
      /* update maximum number of bits for encoding based on previous layers */
      nb_bits_max = sub(nb_bits_max, nb_bits_used);

      /* decode TDAC module - get norm_MDCT value */
      norm_MDCT = *coder_param_ptr;
#if(WMOPS)
      move16();
#endif
      /* compute MDCT of the TDBWE synthesis */
      norm_local = G729EV_TDAC_mdct(decstat->mem_mdct_hi, output_hiTdbwe, yt_hi, -15);
      G729EV_TDAC_mdct(decstat->mem_mdct_hi, output_hiTdbwe, yt_hi, norm_local);

      /* Update nb_bits (read FEC (5 bits) + norm_shift (4 bits)) */
      nb_bits_max = sub(nb_bits_max, 9);
      IF(sub(rate, 16000) >= 0)
      {
        nb_bits_left = sub(nb_bits_left, 9);
      }
      ELSE
      {
        nb_bits_left = (Word16) 0;
        norm_MDCT = norm_local;
#if(WMOPS)
        move16();
        move16();
#endif
      }

      /* rescale yt_hi to be norm_shift compliant */
      diff_norm = sub(norm_MDCT, norm_local);
      FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        yt_hi[i] = shl(yt_hi[i], diff_norm);
#if(WMOPS)
        move16();
#endif
      }

      /* TDAC decoder */
      G729EV_TDAC_decoder(&itu_192_bitstream[289], (Word16) nb_bits_left, (Word16) nb_bits_max,
                          yt_hi, yq_lo, yq_hi, norm_MDCT);

      /* post-process reconstructed higher-band spectrum */
      G729EV_TDAC_PostProcess(yq_hi, nb_bits_to_decode);

      /* inverse MDCT to obtain
         - reconstructed difference signal in lower band
         - reconstructed signal in higher band */
      G729EV_TDAC_inv_mdct(diff_q, yq_lo, decstat->mem_inv_mdct_lo, norm_MDCT);
      G729EV_TDAC_inv_mdct(output_hi, yq_hi, decstat->mem_inv_mdct_hi, norm_MDCT);

      /* compute false alarm zones for pre/post-echo reduction */
      G729EV_MAIN_PreechoFalseAlarm(diff_q, decstat->mem_inv_mdct_lo, &decstat->max_prev_lo,  
                                    &begin_index_low, &end_index_low);
      G729EV_MAIN_PreechoFalseAlarm(output_hi, decstat->mem_inv_mdct_hi, &decstat->max_prev_hi,
                                    &begin_index_high, &end_index_high);

      /* apply inverse weighting filter to the reconstructed lower-band difference signal */
      G729EV_MAIN_inverse_weighting_filter(decstat->mem_Az, decstat->mem_invWz_in, decstat->mem_invwsp, diff_q);

      /* signal upsampling */
      FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        decstat->old_celp_output[i] = shl(decstat->old_celp_output[i], 1);
#if(WMOPS)
        move16();
#endif
      }

      /* preecho reduction & add 12k output to reconstructed difference signal */
      G729EV_MAIN_envAdapt(output_lo, decstat->old_celp_output, diff_q, &decstat->vmlold,
                           output_hi, decstat->sTdbweOld, output_hi, &decstat->vmhold, (Word16) (rate > 14000),
                           begin_index_low, end_index_low, begin_index_high, end_index_high);
      FOR(j = 0; j < G729EV_MAIN_L_FRAME2; j++)
      {
        output_lo[j] = shr(output_lo[j], 1);
#if(WMOPS)
        move16();
#endif
      }

      /* update output for next frame */
      G729EV_G729_Copy(output_hiTdbwe, decstat->sTdbweOld, G729EV_MAIN_L_FRAME2);
      G729EV_G729_Copy(celp_output, decstat->old_celp_output, G729EV_MAIN_L_FRAME2);
    }
    ELSE
    {
      G729EV_G729_Copy(celp_output, output_lo, G729EV_MAIN_L_FRAME2);
      G729EV_G729_Copy(output_hiTdbwe, output_hi, G729EV_MAIN_L_FRAME2);
      G729EV_G729_Copy(celp_output, decstat->old_celp_output, G729EV_MAIN_L_FRAME2);
    }

    /********************************
     * Adapt bitrate switching gain *
     ********************************/

    /* count number of frames with same bandwidth */
    IF(sub(rate, 12000) <= 0)   /* 12 kbit/s */
    {
      nRcv_hi = (Word16) 1;
    }
    ELSE
    {
      nRcv_hi = (Word16) 0;
    }


#if(WMOPS)
    move16();
    test();
#endif
    IF((nRcv_hi == 0) && (decstat->prev_nRcv_hi == 0))
    {
      decstat->count_rcv = add(decstat->count_rcv, 1);
      if (sub(decstat->count_rcv, G729EV_MAIN_COUNT_RCV_MAX) > 0)
      {
        decstat->count_rcv = G729EV_MAIN_COUNT_RCV_MAX;
#if(WMOPS)
        move16();
#endif
      }
    }
    ELSE
    {
      IF(nRcv_hi != 0)
      {
#if(WMOPS)
        test();
        test();
        test();
#endif
        if ((decstat->first_frame != 0) ||
            (decstat->prev_nRcv_hi != 0) ||
            ((decstat->prev_nRcv_hi == 0) && (sub(decstat->count_rcv, G729EV_MAIN_COUNT_RCV_MAX) < 0)))
        {
          decstat->count_rcv = (Word16) 0;
#if(WMOPS)
          move16();
#endif
        }
      }
    }
    decstat->prev_nRcv_hi = nRcv_hi;
    decstat->first_frame = (Word16) 0;
#if(WMOPS)
    move16();
    move16();
#endif

    /*******************************
     * Postfiltering in lower-band *
     *******************************/

    /* set adaptive gamma parameters of postfilter */
    G729EV_MAIN_set_gamma(output_lo, decstat->tab_Th, rate, &ga1_post, &ga2_post);

    /* set post-filter input */
    pf_in = &pf_in_buffer[G729EV_G729_M_LPC];
#if(WMOPS)
    move16();
#endif
    G729EV_G729_Copy(decstat->mem_pf_in, &pf_in[-G729EV_G729_M_LPC], G729EV_G729_M_LPC);
    G729EV_G729_Copy(output_lo, pf_in, G729EV_MAIN_L_FRAME2);
    G729EV_G729_Copy(&output_lo[G729EV_MAIN_L_FRAME2 - G729EV_G729_M_LPC], decstat->mem_pf_in, G729EV_G729_M_LPC);

    /* postfilter */
    pfstat = &decstat->mem_pf;
    IF(decstat->low_delay == 0) ptr_Az = decstat->mem_Az;
    ELSE ptr_Az = nb_celp_param.Az;

#if(WMOPS)
    move16();
    move16();
#endif
    j = (Word16) 0;
#if(WMOPS)
    move16();
#endif
    FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i += G729EV_G729_L_SUBFR)
    {
      IF(decstat->low_delay == 0) t0_first = decstat->mem_t0[(j / 2) * 2];
      ELSE t0_first = nb_celp_param.t0[(j / 2) * 2];
#if(WMOPS)
      move16();
#endif
      G729EV_CELP2S_Post(pfstat, t0_first, &pf_in[i], ptr_Az, &output_lo[i],
                         ga1_post, ga2_post, G729EV_MAIN_switching_gain[decstat->count_rcv],
                         decstat->decStG729.ftyp[(int) (j / 2)]);

      ptr_Az += G729EV_G729_MP1;
      j = add(j, 1);
    }

    IF(decstat->low_delay == 0)
    {
      /* update memory of A(z) and t0_first */
      G729EV_G729_Copy(nb_celp_param.Az, decstat->mem_Az, 4 * G729EV_G729_MP1);
      G729EV_G729_Copy(nb_celp_param.t0, decstat->mem_t0, 4);
    }

    /**************************
     * Postprocess lower band *
     **************************/

    /* G729 postprocessing */
    G729EV_G729_Copy(output_lo, pst_in, G729EV_MAIN_L_FRAME2);

    G729EV_MAIN_iir2(&decstat->mem_postpro, output_lo, G729EV_MAIN_L_FRAME2, G729EV_MAIN_b100, G729EV_MAIN_a100, 0);

    /* cross-fade output_lo and pst_out if bit rate switching */
    IF(sub(rate, 12000) <= 0)   /* 12 kbit/s */
    {
      /* narrowband output (8, 12k modes) */
      /* cross-fade two narrowband outputs (without or with postprocessing) if previous decoded frame was not postprocessed */
      IF(decstat->mem_postflag == 0)
      {
        tmp16 = (Word16) 102;
#if(WMOPS)
        move16();
#endif
        FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i += 1)
        {
          /* output_lo[i] = (REAL)( i/(len-1.0)*output_lo[i]+ (1-(REAL)i/(len-1.0))*pst_in[i] ); */
          /* output_lo and pst_in both in Q14 */
          Ltmp = L_mult(tmp16, output_lo[i]);
          Ltmp = L_mac(Ltmp, pst_in[i], sub(16384, tmp16));
          output_lo[i] = round(L_shl(Ltmp, 2));
#if(WMOPS)
          move16();
#endif
          tmp16 = add(tmp16, 102);
        }
      }
      ELSE
      {
        /* put output_lo in Q15 */
        FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
        {
          output_lo[i] = shl(output_lo[i], 1);
#if(WMOPS)
          move16();
#endif
        }
      }

      /* declare this frame as postprocessed */
      decstat->mem_postflag = (Word16) 1;
#if(WMOPS)
      move16();
#endif
    }
    ELSE
    {
      /* wideband output (modes >= 14k) */
      /* cross-fade two narrowband outputs (without or with postprocessing) if previous decoded frame was postprocessed
         otherwise copy non postprocessed output */
      IF(decstat->mem_postflag == 1)
      {
        tmp16 = (Word16) 102;
#if(WMOPS)
        move16();
#endif
        FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i += 1)
        {
          /*output_lo[i] = (REAL)( i/(len-1.0)*pst_in[i]+ (1-(REAL)i/(len-1.0))*output_lo[i] ); */
          Ltmp = L_mult(tmp16, pst_in[i]);
          Ltmp = L_mac(Ltmp, output_lo[i], sub(16384, tmp16));
          output_lo[i] = round(L_shl(Ltmp, 2));
#if(WMOPS)
          move16();
#endif
          tmp16 = add(tmp16, 102);
        }
      }
      ELSE
      {
        /* put output_lo in Q15 */
        FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
        {
          output_lo[i] = shl(pst_in[i], 1);
#if(WMOPS)
          move16();
#endif
        }
      }
      decstat->mem_postflag = (Word16) 0;
#if(WMOPS)
      move16();
#endif
    }

    /*****************************************************************
    * Fold higher band and combine bands by QMF synthesis filterbank *
    ******************************************************************/

    IF(decstat->f8 == 0)
    {                           /* test if 8kHz sampled output */
      /* mirror signal prior to filterbank synthesis */
      G729EV_MAIN_QMF_mirror(output_hi, G729EV_MAIN_L_FRAME2);

      /* synthesis filterbank */
      G729EV_MAIN_QMF_syn(&decstat->qmf_syn, output_lo, output_hi, tabout, G729EV_MAIN_L_FRAME2,
                          G729EV_MAIN_switching_gain[decstat->count_rcv]);
    }
    ELSE
    {
      G729EV_G729_Copy(output_lo, tabout, G729EV_MAIN_L_FRAME2);
    }

    /*******************
     * Update memories *
     *******************/

    decstat->plast_good = decstat->lastgood;
    decstat->lastgood = clas;
    decstat->decStG729.bfi_cnt = (Word16) 0;
    decstat->prev_rate = rate;
#if(WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif

  }
  ELSE
  {

    /************************************************ FEC (bfi=1) ***********************************/


    /***********************
     * Decode 8-12k layers *
     ***********************/
#if(WMOPS)
    test();
#endif
    IF((decstat->decStG729.bfi_cnt > 0) || (decstat->low_delay > 0))
    {
      /* FEC decoder */
      G729EV_FEC_dec_bf(parm_FEC, decstat->old_celp_output, BfAq, bfi,
                        &(decstat->lastgood), pitch_buf, decstat->old_enrLP,
                        decstat->decStG729.old_exc, &(decstat->decStG729), clas, ind_fer[2]);

      /* Update to be done before decoding a good frame */
      FerPitch = shr(add(pitch_buf[0], G729EV_FEC_QPIT2), G729EV_FEC_SQPIT);
      if (sub(FerPitch, G729EV_G729_PIT_MIN) < 0)
      {
        FerPitch = G729EV_G729_PIT_MIN;
#if(WMOPS)
        move16();
#endif
      }
      if (sub(FerPitch, G729EV_G729_PIT_MAX) > 0)
      {
        FerPitch = G729EV_G729_PIT_MAX;
#if(WMOPS)
        move16();
#endif
      }

      /* taming */
      G729EV_G729_UpdateMemTam(&decstat->decStG729, decstat->decStG729.lp_gainp, FerPitch);
      G729EV_G729_UpdateMemTam(&decstat->decStG729, decstat->decStG729.lp_gainp, FerPitch);

      /* update memory of A(z) and t0_first */
      G729EV_G729_Copy(BfAq, decstat->mem_Az, 4 * G729EV_G729_MP1);

      FOR(i = 0; i < 4; i++)
      {
        decstat->mem_t0[i] = shr(add(pitch_buf[i], G729EV_FEC_QPIT2), G729EV_FEC_SQPIT);
#if(WMOPS)
        move16();
#endif
      }
    }

    IF(decstat->low_delay == 0)
    {
      ind = sub(G729EV_TDAC_L_WIN2, 1);
      FOR(i = 0; i < G729EV_TDAC_L_WIN2; i++)
      {
        output_lo[i] =
            mac_r(L_mult(decstat->old_celp_output[i], 32767), decstat->mem_inv_mdct_lo[i], G729EV_TDAC_h[ind]);
        ind = sub(ind, 1);
        decstat->mem_inv_mdct_lo[i] = (Word16) 0;
#if(WMOPS)
        move16();
        move16();
#endif
      }
    }
    ELSE
    {
      G729EV_G729_Copy(decstat->old_celp_output, output_lo, G729EV_MAIN_L_FRAME2);
    }

    /************************************
     * Decode 14-32k enhancement layers *
     ************************************/

    /* TDBWE decoder in FEC */
    IF(sub(decstat->prev_rate, 14000) >= 0) /* 14 kbit/s */
    {
      IF(sub(decstat->decStG729.bfi_cnt, 2) > 0)
      {
        FOR(i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++) {
          tmp16 = sub(decstat->prev_parameters_tdbwe[i], 1024); /* -3 dB */
          IF( sub(tmp16,(Word16)-1700)<0 ) {
            tmp16 = (Word16) -1700;
          }
          decstat->prev_parameters_tdbwe[i] = tmp16;
        }
        FOR(i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++) {
          tmp16 = sub(decstat->prev_parameters_tdbwe[i+G729EV_TDBWE_PAROFS_FREQ_ENVELOPE], 1024); /* -3 dB */
          IF( sub(tmp16,(Word16)-11264)<0 ) {
            tmp16 = (Word16) -11264;
          }
          decstat->prev_parameters_tdbwe[i+G729EV_TDBWE_PAROFS_FREQ_ENVELOPE] = tmp16;
        }
      }


      G729EV_TDBWE_decoder(&decstat->tdbwe, &decstat->prev_nb_celp_param,
                           output_hiTdbwe, decstat->prev_parameters_tdbwe);
    }
    ELSE
    {
      G729EV_G729_Set_zero(output_hiTdbwe, G729EV_MAIN_L_FRAME2);
    }

    /* TDAC decoder in FEC */
    IF(decstat->low_delay == 0)
    {
      /* set 3000-4000 Hz band of TDBWE synthesis to zero */
      norm_local = G729EV_TDAC_mdct(decstat->mem_mdct_hi, output_hiTdbwe, yq_hi, -15);
      G729EV_TDAC_mdct(decstat->mem_mdct_hi, output_hiTdbwe, yq_hi, norm_local);
      G729EV_G729_Set_zero(&yq_hi[G729EV_MAIN_L_FRAME2 - G729EV_G729_L_SUBFR], G729EV_G729_L_SUBFR);

      /* inverse MDCT to obtain reconstructed signal in higher band */
      G729EV_TDAC_inv_mdct(output_hi, yq_hi, decstat->mem_inv_mdct_hi, norm_local);
    }
    ELSE
    {
      G729EV_G729_Copy(output_hiTdbwe, output_hi, G729EV_MAIN_L_FRAME2);
    }

    /*************************
     * Postfilter lower band *
     *************************/

    /* set adaptive gamma paramaters of postfilter */
    G729EV_MAIN_set_gamma(output_lo, decstat->tab_Th, decstat->prev_rate, &ga1_post, &ga2_post);

    /* set post-filter input */
    pf_in = &pf_in_buffer[G729EV_G729_M_LPC];
#if(WMOPS)
    move16();
#endif
    G729EV_G729_Copy(decstat->mem_pf_in, &pf_in[-G729EV_G729_M_LPC], G729EV_G729_M_LPC);
    G729EV_G729_Copy(output_lo, pf_in, G729EV_MAIN_L_FRAME2);
    G729EV_G729_Copy(&output_lo[(G729EV_MAIN_L_FRAME2) - G729EV_G729_M_LPC], decstat->mem_pf_in, G729EV_G729_M_LPC);

    /* postfilter */
    pfstat = &decstat->mem_pf;
    ptr_Az = decstat->mem_Az;

#if(WMOPS)
    move16();
    move16();
#endif
    j = (Word16) 0;
#if(WMOPS)
    move16();
#endif
    FOR(i = 0; i < (G729EV_MAIN_L_FRAME2); i += G729EV_G729_L_SUBFR)
    {
      t0_first = decstat->mem_t0[(j / 2) * 2];
#if(WMOPS)
      move16();
#endif
      G729EV_CELP2S_Post(pfstat, t0_first, &pf_in[i], ptr_Az, &output_lo[i],
                         ga1_post, ga2_post, G729EV_MAIN_switching_gain[decstat->count_rcv],
                         decstat->decStG729.ftyp[(int) (j / 2)]);

      ptr_Az += G729EV_G729_MP1;
      j = add(j, 1);
    }

    /**************************
     * Postprocess lower band *
     **************************/

    /* G729 postprocessing */
    G729EV_G729_Copy(output_lo, pst_in, G729EV_MAIN_L_FRAME2);
    G729EV_MAIN_iir2(&decstat->mem_postpro, output_lo, G729EV_MAIN_L_FRAME2, G729EV_MAIN_b100, G729EV_MAIN_a100, 1);
    IF(decstat->mem_postflag == 0)
    {
      /* wideband bit rate -> leave lower-band unprocessed */
      FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        output_lo[i] = shl(pst_in[i], 1);
#if(WMOPS)
        move16();
#endif
      }
    }

    /******************************************************************
     * Fold higher band and combine bands by QMF synthesis filterbank *
     ******************************************************************/

    IF(decstat->f8 == 0)
    {                           /* test if 8kHz sampled output */
      /* mirror signal prior to filterbank synthesis */
      G729EV_MAIN_QMF_mirror(output_hi, G729EV_MAIN_L_FRAME2);

      /* synthesis filterbank */
      G729EV_MAIN_QMF_syn(&decstat->qmf_syn, output_lo, output_hi, tabout, G729EV_MAIN_L_FRAME2,
                          G729EV_MAIN_switching_gain[decstat->count_rcv]);
    }
    ELSE
    {
      G729EV_G729_Copy(output_lo, tabout, G729EV_MAIN_L_FRAME2);
    }

    /*******************
     * Update memories *
     *******************/

    /* Update to be done before decoding a good frame */
    decstat->decStG729.bfi_cnt = add(decstat->decStG729.bfi_cnt, 1);

    /* set buffer for W(z) */
    G729EV_G729_Set_zero(decstat->mem_invWz_in, G729EV_G729_M);
    G729EV_G729_Set_zero(decstat->mem_invwsp, G729EV_G729_M);
  }

  decstat->prev_bfi = bfi;
#if(WMOPS)
  move16();
#endif
}
