/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.1.a                                                          */
/* Revision Date: Dec 4, 2006                                                    */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
   All rights reserved
*/

#include <stdio.h>
#include <stdlib.h>
#include <string.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729_CodStat.h"
#include "G729EV_G729_DecStat.h"
#include "G729EV_CELP2S_encod.h"
#include "G729EV_CELP2S.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_encod.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_MAIN_prm.h"

#include "G729EV_FEC_fer.h"
#include "G729EV_FEC_tools.h"
#include "G729EV_TDAC_encod.h"
#include "G729EV_TDAC_util.h"
#include "G729EV_TDAC_mdct.h"
#include "G729EV_TDBWE_encoder.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_InitEncoder()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                     *
 *  Encoder Initializations                                                 *
 *--------------------------------------------------------------------------*/

void G729EV_MAIN_InitEncoder(CODSTATMAIN * codstat, /* (o)  Encoder states variables    */
                             Word16 rate,           /* (i)  Encoder rate                */
                             Word16 f8,             /* (i)  8kHz sampled input flag     */
                             Word16 g729_bst)       /* (i)  G.729 bistream mode flag    */
{
  IF(codstat == NULL)
  {
    exit(-1);
  }

  memset(codstat, 0, sizeof(*codstat));

  /* initialize QMF filterbank */
  G729EV_MAIN_initQMF_ana(&codstat->qmf_ana);

  /* initialize preprocessing of lower and higher bands */
  G729EV_MAIN_init_iir2(&codstat->mem_hp50);
  G729EV_MAIN_init_lp3k(&codstat->mem_lp3k);


  /* set the flag for 8kHz sampled input */
  codstat->f8 = f8;
#if (WMOPS)
  move16();
#endif

  /* set the flag for g729 bitstream mode */
  codstat->g729_bst = g729_bst;
#if(WMOPS)
  move16();
#endif

  /* initialize memories for MDCT computation */
  G729EV_G729_Set_zero(codstat->mem_mdct_lo, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Set_zero(codstat->mem_mdct_hi, G729EV_MAIN_L_FRAME2);
  /* initialize memory of previous CELP-decoded frame (for difference computation in lower band) */

  /* initialize G729 encoder */
  G729EV_CELP2S_InitEncoder(&codstat->codStG729, rate);

  /* initialize FEC variables */
  codstat->oldferclass = G729EV_FEC_UNVOICED;
  codstat->lp_speech = (Word16) (256 * 55);

  codstat->relE_hist = (Word16) 0;
  codstat->relE_var = (Word16) 0;
  codstat->old_pulspos = (Word16) 0;
#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
#endif

  /* initialize TDBWE encoder */
  G729EV_TDBWE_encoder_init(&codstat->tdbwe);

  /* perceptual weighting filter of lower band difference signal */
  G729EV_G729_Set_zero(codstat->mem_Wz_in, G729EV_G729_M);
  G729EV_G729_Set_zero(codstat->mem_wsp, G729EV_G729_M);

  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_Encode()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Main encoder routine                                                    *
 *--------------------------------------------------------------------------*/

void G729EV_MAIN_Encode(CODSTATMAIN * codstat,      /* (i)  Encoder states variables        */
                        Word16 * samples_in,        /* (i)  Frame of samples to be encoded  */
                        Word16 * itu_192_bitstream, /* (o)  G.192 bitstream                 */
                        Word16 rate                 /* (i)  Encoder rate                    */
    )
{
  Word16    input[G729EV_MAIN_L_FRAME];
  Word16    input_lo[G729EV_MAIN_L_FRAME2];
  Word16    input_hi[G729EV_MAIN_L_FRAME2];
  Word16    input_hi_delay[G729EV_MAIN_L_FRAME2];
  Word16    celp_output[G729EV_MAIN_L_FRAME2];
  Word16    diff[G729EV_MAIN_L_FRAME2];
  Word16    y_lo[G729EV_MAIN_L_FRAME2];
  Word16    y_hi[G729EV_MAIN_L_FRAME2];
  Word16    celp_Az[G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1];
  Word16    voicing[6];
  Word16    sync_speech[G729EV_MAIN_L_FRAME2], resBF8k[G729EV_MAIN_L_FRAME2];
  Word16    ee[2];
  Word16    pit[4];
  Word16    coder_parameters[G729EV_G729_PRM_SIZE_MAX * 2 + 10];
  Word16   *coder_param_ptr;

  Word16    i_frame, j;
  Word16    nb_bits_max;        /* maximal bit allocation (-> 32 kbps) */
  Word16    nb_bits_left;       /* number of bits left */
  Word16    nb_bits_used;       /* number of bits used */
  Word16    clas, t0, t0_frac, fst_pitch;
  Word16    norm_hi;
  Word16    norm_lo;
  Word16    norm_MDCT;

  /* set number of bits for 20-ms frame */
  nb_bits_max = G729EV_MAX_BITRATE / 50;  /* maximal bit allocation (-> 32 kbit/s) */
  nb_bits_left = rate / 50;     /* actual bit allocation  (-> actual encoding bit rate) */
#if(WMOPS)
  move16();
  move16();
#endif

  /* initialize number of bits */
  nb_bits_used = (Word16) 0;
  coder_param_ptr = coder_parameters;
#if(WMOPS)
  move16();
  move16();
#endif

   /*************
    * buffering *
    *************/
  IF(codstat->f8 == (Word16) 0)
  {                             /* test if 8kHz sampled input */
    G729EV_G729_Copy(samples_in, input, G729EV_MAIN_L_FRAME);
  } ELSE
  {
    FOR(j = 0; j < G729EV_MAIN_L_FRAME2; j++)
    {
      input_lo[j] = shr(samples_in[j], 1);
#if(WMOPS)
      move16();
#endif
    }
    G729EV_G729_Set_zero(input_hi, G729EV_MAIN_L_FRAME2);
  }

   /***************************
    * QMF analysis filterbank *
    ***************************/
  IF(codstat->f8 == (Word16) 0)
  {                             /* test if 8kHz sampled input */
    /* filter */
    G729EV_MAIN_QMF_ana(&codstat->qmf_ana, input, input_lo, input_hi, G729EV_MAIN_L_FRAME);

    /* fold higher band */
    G729EV_MAIN_QMF_mirror(input_hi, G729EV_MAIN_L_FRAME2);
  }

   /**************************************************************
    * Encoding of lower band : 8k core and 12k enhancement layer
    * - preprocessing (HPF)
    * - cascade CELP encoder
    **************************************************************/

  /* preprocessing of lower band (50 Hz high-pass) */
  G729EV_MAIN_iir2(&codstat->mem_hp50, input_lo, G729EV_MAIN_L_FRAME2, G729EV_MAIN_hp50_b, G729EV_MAIN_hp50_a, 0);

  j = (Word16) 0;
#if(WMOPS)
  move16();
#endif
  FOR(i_frame = 0; i_frame < G729EV_MAIN_L_FRAME2; i_frame += G729EV_G729_L_FRAME)
  {
    /* cascade CELP (10 ms frame) */
    G729EV_CELP2S_encoder(&codstat->codStG729,
                          &input_lo[i_frame],
                          coder_param_ptr,
                          &celp_output[i_frame],
                          j,
                          celp_Az,
                          &sync_speech[i_frame],
                          &resBF8k[i_frame], &(pit[2 * j]), &t0, &t0_frac, &voicing[j * 3], &ee[j], &diff[i_frame]);

    /* update bitscounter */
    IF(sub(rate, 12000) >= 0) nb_bits_used = add(nb_bits_used, 120);
    ELSE nb_bits_used = add(nb_bits_used, 80);

    j = add(j, 1);
    coder_param_ptr += G729EV_G729_PRM_SIZE_MAX;
  }

  fst_pitch = pit[3];
#if(WMOPS)
  move16();
#endif

  /* update number of bits left to encode frame */
  nb_bits_left = sub(nb_bits_left, nb_bits_used);


   /***************************************************
    * Encoding of higher band : 14k enhancement layer
    * - preprocessing (LPF)
    * - TDBWE encoder
    ***************************************************/

  /* perform time-domain BWE */
  IF(sub(rate, 14000) >= 0)
  {
    IF(codstat->f8 == 0)
    {
      /* preprocessing of higher band (3 kHz low-pass filter) */
      G729EV_MAIN_lp3k(&codstat->mem_lp3k, input_hi, G729EV_MAIN_L_FRAME2);

      G729EV_TDBWE_encoder(&codstat->tdbwe, input_hi, coder_param_ptr, input_hi_delay);
    }
    ELSE
    {
      coder_param_ptr[0] = (Word16) 28;
      coder_param_ptr[1] = (Word16) 71;
      coder_param_ptr[2] = (Word16) 71;
      coder_param_ptr[3] = (Word16) 30;
      coder_param_ptr[4] = (Word16) 26;
      coder_param_ptr[5] = (Word16) 1;
#if(WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
#endif
    }

    /* update bits counter and number of bits left */
    nb_bits_used = add(nb_bits_used, 40);
    nb_bits_left = sub(nb_bits_left, 40);
  }
  coder_param_ptr += 6;         /* 6 parameters in TDBWE */

   /***************************************************
    * FEC Encoder
    ***************************************************/

  IF(sub(rate, 12000) >= 0)
  {

    /* Should compute FER parameters of next frame here; before lag */
    G729EV_FEC_encod(codstat->oldferclass, voicing, input_lo, celp_output, pit,
                     ee, sync_speech, &clas, coder_param_ptr, t0, t0_frac,
                     resBF8k, &(codstat->lp_speech), &codstat->relE_hist, &codstat->relE_var, &(codstat->old_pulspos));

    coder_param_ptr += 3;       /* 3 parameters in FEC */

    /* Update FER parameters memory  */
    codstat->oldferclass = clas;
#if(WMOPS)
    move16();
#endif
  }

  /*************************************************************
   * Encoding of full-band spectrum: 16-32k enhancement layers
   * - perceptual weighting of difference signal
   * - MDCT of weighted difference signal
   * - MDCT of higher band signal
   * - TDAC encoder
   *************************************************************/

  IF(sub(rate, 16000) >= 0)
  {

    /* apply perceptual weighting filter */
    G729EV_MAIN_weighting_filter(celp_Az, codstat->mem_Wz_in, codstat->mem_wsp, diff);

    FOR(j = 0; j < G729EV_MAIN_L_FRAME2; j++)
    {
      diff[j] = shl(diff[j], 1);
#if(WMOPS)
      move16();
#endif
    }

    /* perform MDCT of difference signal in lower band */
    norm_lo = G729EV_TDAC_mdct(codstat->mem_mdct_lo, diff, y_lo, -15);
    G729EV_TDAC_mdct(codstat->mem_mdct_lo, diff, y_lo, norm_lo);

    /* compute MDCT of higher band */
    IF(codstat->f8 == 0)
    {
      norm_hi = G729EV_TDAC_mdct(codstat->mem_mdct_hi, input_hi_delay, y_hi, -15);
      G729EV_TDAC_mdct(codstat->mem_mdct_hi, input_hi_delay, y_hi, norm_hi);
    }
    ELSE
    {
      norm_hi = norm_lo;
      G729EV_G729_Set_zero(y_hi, G729EV_MAIN_L_FRAME2);
    }


    /* use same norm for y_hi and y_lo --> norm_MDCT */
    IF(sub(norm_hi, norm_lo) > 0) /* norm_hi > norm_lo */
    {
      norm_MDCT = norm_lo;
    }
    ELSE
    {
      norm_MDCT = norm_hi;
    }
#if(WMOPS)
    move16();
#endif

    /* update maximum number of bits for encoding based on previous layers */
    nb_bits_max = sub(nb_bits_max, nb_bits_used);
    nb_bits_max = sub(nb_bits_max, 9);  /* norm_shift + FEC */
    nb_bits_left = sub(nb_bits_left, 9);  /* norm_shift + FEC */
    if (nb_bits_left < 0)
    {
      nb_bits_left = (Word16) 0;
#if(WMOPS)
      move16();
#endif
    }

    /* encode in MDCT domain difference signal in lower band and original signal 
       in higher band, using: 
       - number of bits for encoding (nb_bits_left)
       - number of bits for allocation (nb_bits_max)
     */

    /* write norm_shift in coder_parameters */
    *coder_param_ptr++ = norm_MDCT;
#if(WMOPS)
    move16();
#endif

    /* apply TDAC */
    G729EV_TDAC_encoder(y_lo, y_hi, &itu_192_bitstream[289], (Word16) nb_bits_left, (Word16) nb_bits_max, norm_lo,
                        norm_hi, norm_MDCT);
  }

   /***************************************************
    * Multiplexer
    ***************************************************/

  IF(sub(rate, 14000) > 0)
  {
    /* number of bytes counted in 8, 12 and 14k layers 
       + number of bits for TDAC layer + 5 bit of FEC + 4 bit of norm_shift in MDCT */
    nb_bits_used = add(nb_bits_used, add(nb_bits_left, 9));
  }

  /* Create itu_192_bitstream */
  G729EV_MAIN_param2bit(coder_parameters, nb_bits_used, itu_192_bitstream, codstat);
}
