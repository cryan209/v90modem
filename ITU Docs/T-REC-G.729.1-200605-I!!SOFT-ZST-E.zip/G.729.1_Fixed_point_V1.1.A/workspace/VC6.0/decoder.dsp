# Microsoft Developer Studio Project File - Name="decoder" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=decoder - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "decoder.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "decoder.mak" CFG="decoder - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "decoder - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "decoder - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "decoder - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "../../Release"
# PROP Intermediate_Dir "../../Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /I "..\..\src\main" /I "..\..\src\g729" /I "..\..\src\tdac" /I "..\..\src\tdbwe" /I "..\..\src\celp2s" /I "..\..\src\stl2005_basop" /I "..\..\src\fec" /I "." /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /FR /YX /FD /c
# ADD BASE RSC /l 0x40c /d "NDEBUG"
# ADD RSC /l 0x40c /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386

!ELSEIF  "$(CFG)" == "decoder - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "decoder___Win32_Debug"
# PROP BASE Intermediate_Dir "decoder___Win32_Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "../../Debug"
# PROP Intermediate_Dir "../../Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /GZ /c
# ADD CPP /nologo /W3 /Gm /GX /ZI /Od /I "..\..\src\main" /I "..\..\src\g729" /I "..\..\src\tdac" /I "..\..\src\tdbwe" /I "..\..\src\celp2s" /I "..\..\src\stl2005_basop" /I "..\..\src\fec" /I "." /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /FR /YX /FD /GZ /c
# ADD BASE RSC /l 0x40c /d "_DEBUG"
# ADD RSC /l 0x40c /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "decoder - Win32 Release"
# Name "decoder - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Group "G729"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_DE_ACELP.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_DEC_GAIN.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_DEC_LAG3.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_ERROR.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_FILTER.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_GAINPRED.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_LPCFUNC.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_LSPDEC.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_LSPGETQ.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_P_PARITY.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_PRED_LT3.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_PST.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_TAB_LD8K.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_UTIL.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_calcexc.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_dec_sid.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_qsidgain.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_tab_dtx.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_util.c
# End Source File
# End Group
# Begin Group "TDBWE"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_compression.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_decoder.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_extract_frequency_envelope.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_extract_time_envelope.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_fft.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_fir.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_frequency_envelope_shaping.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_generate_excitation.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_time_envelope_shaping.c
# End Source File
# End Group
# Begin Group "TDAC"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_bitalloc.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_decod.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_lib_vq.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_mdct.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_post.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_spectenv.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_tfr.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_util.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_vq.c
# End Source File
# End Group
# Begin Group "MAIN"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_decod.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_Decoder.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_DSPFUNC.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_EnvAdaption.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_filt.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_OPER_32B.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_prm.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_Table.c
# End Source File
# End Group
# Begin Group "CELP2S"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_decod.c
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_post.c
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_put4pat.c
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_qua_gain.c
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2s_syn.c
# End Source File
# End Group
# Begin Group "STL2005_BASOP"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\stl2005_basop\basop32.c
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\control.c
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\count.c
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\enh1632.c
# End Source File
# End Group
# Begin Group "FEC"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_clasdec.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_decbfi.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_ferdec.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_ferutil.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_onset.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_pit_updt.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_tools.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_voicefac.c
# End Source File
# End Group
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Group "G729_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_decstat.h
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_defines.h
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_LD8K.H
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_TAB_LD8K.H
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_defines.h
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_dtx.h
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_sid.h
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_tab_dtx.h
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729B_util.h
# End Source File
# End Group
# Begin Group "TDBWE_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_compression.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_decoder.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_extract_frequency_envelope.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_extract_time_envelope.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_fft.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_fir.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_frequency_envelope_shaping.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_generate_excitation.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_time_envelope_shaping.h
# End Source File
# End Group
# Begin Group "TDAC_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_bitalloc.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_decod.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_lib_vq.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_mdct.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_post.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_spectenv.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_tfr.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_util.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_vq.h
# End Source File
# End Group
# Begin Group "MAIN_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_decod.h
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_defines.h
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_DSPFUNC.h
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_EnvAdaption.h
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_filt.h
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_OPER_32B.H
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_prm.h
# End Source File
# End Group
# Begin Group "CELP2S_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S.h
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_decod.h
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_post.h
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_qua_gain.h
# End Source File
# End Group
# Begin Group "STL2005_BASOP_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\stl2005_basop\basop32.h
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\control.h
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\count.h
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\enh1632.h
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\move.h
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\patch.h
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\stl.h
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\typedef.h
# End Source File
# Begin Source File

SOURCE=..\..\src\stl2005_basop\typedefs.h
# End Source File
# End Group
# Begin Group "FEC_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_fer.h
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_tools.h
# End Source File
# End Group
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# End Group
# End Target
# End Project
