/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.7                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_DEFINES_H__
#define __G729EV_MAIN_DEFINES_H__

#include "CodecTypedef.h"

/*************************
 * Constants for framing
 *************************/

#define G729EV_MAIN_L_FRAME         320
#define G729EV_MAIN_L_FRAME2        160
#define G729EV_MAIN_L_FRAME4         80
#define G729EV_MAIN_NB_SUBFR  4

/***********************************
 * Constants for DTX
 ***********************************/
#define PRM_SIZE_SID    4        /* Size of vector of analysis parameters.    */
#define RATE_SID        15      /* SID                           */
#define	RATE_SID_NB		9
#define	RATE_SID_WB		19
#define SIDRATE			(RATE_SID + RATE_SID_WB)*50
#define RATE_0          0       /* 0 bit/s rate                  */
/* TD-BWE DTX thresholds */
#define G729EV_TDBWE_THR_TD                (REAL)1.4      /* st change of signal energy in dB */
#define G729EV_TDBWE_THR_SD                (REAL)1.4
#define G729EV_TDBWE_THR_TC                (REAL)3.2      /* lt change of signal energy in dB */
#define G729EV_TDBWE_THR_SC                (REAL)3.2
// For learning phase of the noise
#define HANGOVER_RATIO (REAL)1./6. /* Hangover period           */
#define ALPHA_TENV     (REAL)0.25  /* time envelope filter      */
#define ALPHA_FENV     (REAL)0.25  /* frequency envelope filter */

/***********************************
 * Constants for bitstream packing
 ***********************************/

#define ITU_G192_SYNCWORD 0x6b21
#define ITU_G192_SYNCWORD_ERASURE 0x6b20
#define ITU_G192_BIT_0 0x007f
#define ITU_G192_BIT_1 0x0081

#define G729EV_MAX_BITRATE  32000
#define G729EV_MAX_BITS_BST 640
#define G729EV_MAIN_COUNT_RCV_MAX 50

/*****************************
 * constants for TDAC module  
 ******************************/

/* constants for MDCT and inverse MDCT */
#define G729EV_TDAC_L_WIN   320
#define G729EV_TDAC_L_WIN2  160
#define G729EV_TDAC_L_WIN4   80
#define G729EV_TDAC_NP        5
#define G729EV_TDAC_EXP_NPP   4
#define G729EV_TDAC_NB_REV    6
#define G729EV_TDAC_NPP     (1<<G729EV_TDAC_EXP_NPP)

/* constants for spectral envelope coding */
#define G729EV_TDAC_NB_SB          18
#define G729EV_TDAC_NB_SB_NB       10
#define G729EV_TDAC_NB_SB_WB        8
#define G729EV_TDAC_MAX_VQBITS    800

/* Constants for spectrum envelope quantization */
#define G729EV_TDAC_LOG2_INV (REAL)((REAL_DOUBLE)1.0/log((REAL_DOUBLE)2.0))
#define G729EV_TDAC_MAX_LONG_HUFF   16  /* longueur max code d'Huffman */
#define G729EV_TDAC_MAX_NB_PRM_FACT 6
#define G729EV_TDAC_MIN_RMS         -11
#define G729EV_TDAC_MAX_RMS         20
#define G729EV_TDAC_RMS_OFFSET      6
#define G729EV_TDAC_Q3db   (REAL)(0.5)  /* 3.01 dB, (3.01/20.0) * (REAL)(log(10.)/ log(2.)) */
#define G729EV_TDAC_Q3db_INV        ((REAL)1./G729EV_TDAC_Q3db)
#define G729EV_TDAC_N_NBC   16  /* Maximum number of coeff. (dim. of vectors)    */
#define G729EV_TDAC_N_NBC_T   24  /* Maximum number of coeff. (dim. of vectors)    */
#define G729EV_TDAC_NB_LEAD_H  84
#define G729EV_TDAC_NORM_MDCT_TRESH  4

/* Constants for bit allocation and VQ */
#define G729EV_TDAC_SORTED_IP (REAL)-1000.0

#define G729EV_TDAC_NB_SB_LEN     16
#define G729EV_TDAC_NB_SB_PST     (INT16)((G729EV_MAIN_L_FRAME/G729EV_TDAC_NB_SB_LEN)/2)

#define G729EV_TDAC_EPS1 ((REAL)5.960464477539063e-008) /* 2^-24 so that min(log_rms) = -12 in log2 (-71 dB in log10) */

/***************************
 * Constants for delay
 ***************************/
#define G729EV_MAIN_DELAY    143

/***************************
 * Constants for filtering
 ***************************/

/* QMF filterbank */
#define TRUE                 1
#define FALSE                0
#define G729EV_MAIN_S_QMF    32
#define G729EV_MAIN_S_QMF_FS (G729EV_MAIN_S_QMF/2)

/* preprocessing of higher band signal */
#define G729EV_MAIN_LP_ORD   4

/* perceptual weighting of lower band difference signal */
#define  G729EV_MAIN_GAMMA1     (REAL)0.94
#define  G729EV_MAIN_GAMMA2     (REAL)0.6

/* adaptation of gamma1 and gamma2 depending on frame energy */
#define G729EV_MAIN_MAX32  (REAL)0x7fffffff
#define G729EV_MAIN_NMAX   5

/****************************************
 * Constants for pre/post-echo reduction
 ****************************************/
#define G729EV_MAIN_PRE_SUBFRAME 40 /* block for energy comparison in 8khz-samples: 5msec */


/******************************
 * constants for CELP2S module
 ******************************/

/* tripulse parameters */
#define G729EV_CELP2S_SP          (REAL)   -0.34
#define G729EV_CELP2S_HP_FACT     (REAL)   -0.15

#define G729EV_CELP2S_FCB_REPEAT     4
#define G729EV_CELP2S_FCB_THRES   (REAL)  0.0

/******************************
 * constants for TDBWE module  
 ******************************/

/* for Encoder */
#define ONE_OVER_LOG2   ((REAL)(1.0/log(2.0)))

/* TD-BWE frame size constants */

#define G729EV_TDBWE_L_FRAME                   160
#define G729EV_TDBWE_L_FRAME2                   80
#define G729EV_TDBWE_L_FRAME4                   40
#define G729EV_TDBWE_EXCITATION_SUBFRAME_SIZE   80

/* TD-BWE buffering and pointer address constants */
#define G729EV_TDBWE_L_TOTAL                             232
#define G729EV_TDBWE_L_NEXT                              40
#define G729EV_TDBWE_MEM_SPEECH                          72
#define G729EV_TDBWE_DELTA_TIME_ENV                      16
#define G729EV_TDBWE_DELTA_FREQ_ENV                      -32
#define G729EV_TDBWE_L_TOTAL_EXC                         208
#define G729EV_TDBWE_MEM_EXC                             48

/* TD-BWE time envelope computation, shaping & postprocessing */

#define G729EV_TDBWE_NB_SUBFRAMES         16
#define G729EV_TDBWE_NB_SUBFRAMES_2       8
#define G729EV_TDBWE_NB_SUBFRAMES_2_M_1   7
#define G729EV_TDBWE_NB_SUBFRAMES_2_M_2   6
#define G729EV_TDBWE_SUBFRAME_SIZE        10
#define G729EV_TDBWE_SUBFRAME_SIZE_2      5

#define G729EV_TDBWE_COMP_LINEAR_LIM1     (REAL)1.0
#define G729EV_TDBWE_COMP_LINEAR_LIM2     (REAL)2.5
#define G729EV_TDBWE_COMP_SATURE_SLOPE1   (REAL)2.0
#define G729EV_TDBWE_COMP_SATURE_SLOPE2   (REAL)8.0

/* TD-BWE frequency envelope computation, shaping & postprocessing */

#define G729EV_TDBWE_FFT_NUM_STAGE     5
#define G729EV_TDBWE_FFT_SIZE2         (2 << (G729EV_TDBWE_FFT_NUM_STAGE+1))  /* 128 */
#define G729EV_TDBWE_FFT_SIZE          (2 << G729EV_TDBWE_FFT_NUM_STAGE)  /* 64  */
#define G729EV_TDBWE_FFT_SIZE_M_2      ((2 << G729EV_TDBWE_FFT_NUM_STAGE) - 2)  /* 62  */
#define G729EV_TDBWE_FFT_SIZE_BY_TWO   (2 << (G729EV_TDBWE_FFT_NUM_STAGE-1))  /* 32  */

#define G729EV_TDBWE_NB_SUBBANDS                          12
#define G729EV_TDBWE_FREQUENCY_ENVELOPE_WINDOW_SIZE       (G729EV_TDBWE_FFT_SIZE<<1)  /* 128 */
#define G729EV_TDBWE_FREQUENCY_ENVELOPE_WINDOW_SIZE_M_FS  ((G729EV_TDBWE_FFT_SIZE<<1)-G729EV_TDBWE_L_FRAME2)
#define G729EV_TDBWE_BINS_PER_SUBBAND                     3 /* 375 Hz */
#define G729EV_TDBWE_BINS_BTW_CENTER_BINS                 1

#define G729EV_TDBWE_BUFLEN_FIR (80+32)
#define G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH      17
#define G729EV_TDBWE_FREQ_ENV_SHAPING_GAIN_HIGHPASS       (REAL)0.1
#define G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH       33
#define G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1   32

/* TD-BWE parameter array offsets */

#define G729EV_TDBWE_PAROFS_TIME_ENVELOPE                  0
#define G729EV_TDBWE_PAROFS_FREQ_ENVELOPE (G729EV_TDBWE_PAROFS_TIME_ENVELOPE+G729EV_TDBWE_NB_SUBFRAMES)
#define G729EV_TDBWE_NB_PARAMETERS (G729EV_TDBWE_PAROFS_FREQ_ENVELOPE+G729EV_TDBWE_NB_SUBBANDS)

/* TD-BWE excitation generation */

#define G729EV_TDBWE_LENGTH_PULSE_SHAPE               57
#define G729EV_TDBWE_NUMBER_PULSE_SHAPES               6

/* TD-BWE quantization table constants */

#define G729EV_TDBWE_MEAN_TIME_ENV_BITS                5
#define G729EV_TDBWE_MEAN_TIME_ENV_NUMBER_ENTRIES     32
#define G729EV_TDBWE_TIME_ENV_BITS                     7
#define G729EV_TDBWE_TIME_ENV_NUMBER_ENTRIES         128
#define G729EV_TDBWE_TIME_ENV_SPLIT_VQ_NUMBER_SPLITS   2
#define G729EV_TDBWE_FREQ_ENV_SPLIT_VQ_NUMBER_SPLITS   3

/******************************
 * constants for FEC module  
 ******************************/

/* attenuation strategy in case of FER */
#define G729EV_FEC_ALPHA_S         (REAL)0.6
#define G729EV_FEC_ALPHA_V         (REAL)1.0
#define G729EV_FEC_ALPHA_VT        (REAL)0.4
#define G729EV_FEC_ALPHA_UT        (REAL)0.88
#define G729EV_FEC_ALPHA_U         (REAL)0.4
#define G729EV_FEC_ALPHA_U2        (REAL)0.95
#define G729EV_FEC_L_FIR_FER       5  /* impulse response length for low- & high-pass filters   */

#define G729EV_FEC_MAX_UPD_CNT     30
#define G729EV_FEC_SINGLE_FRAME    (-1)

#define G729EV_FEC_L_EXC_MEM       (G729EV_G729_PIT_MAX+G729EV_G729_L_INTERPOL)

/* signal classification for FER protection */
#define G729EV_FEC_UNVOICED          0  /* G729EV_FEC_UNVOICED, silence, noise, G729EV_FEC_VOICED offset   */
#define G729EV_FEC_UV_TRANSITION     1  /* Transition from G729EV_FEC_UNVOICED to G729EV_FEC_VOICED components - possible onset, but too small */
#define G729EV_FEC_V_TRANSITION      2  /* Transition from G729EV_FEC_VOICED - still G729EV_FEC_VOICED, but with very weak G729EV_FEC_VOICED characteristics     */
#define G729EV_FEC_VOICED            3  /* G729EV_FEC_VOICED frame, previous frame was also G729EV_FEC_VOICED or ONSET                   */
#define G729EV_FEC_ONSET             4  /* G729EV_FEC_VOICED onset sufficiently well built to follow with a G729EV_FEC_VOICED concealments    */
#define G729EV_FEC_SIN_ONSET         5  /* artificial harmonic+noise onset (used only in decoder)                       */

#define G729EV_FEC_GOOD_FRAME      0  /* Correct frame                   */
#define G729EV_FEC_BAD_FRAME       1  /* Bad frame                       */

#define G729EV_FEC_L_FRAME_FER     G729EV_MAIN_L_FRAME2
#define G729EV_FEC_L_FRAME2_FER    (G729EV_FEC_L_FRAME_FER/2)
#define G729EV_FEC_L_SUBFR         (G729EV_MAIN_L_FRAME2/G729EV_MAIN_NB_SUBFR)
#define G729EV_FEC_L_MEM           (G729EV_MAIN_L_FRAME2+G729EV_FEC_L_FIR_FER)
#define G729EV_FEC_AGC         (REAL)0.9604

#define G729EV_FEC_K_COR_DEC       2.857f
#define G729EV_FEC_C_COR_DEC       -1.286f
#define G729EV_FEC_K_TILT          0.8333f  /* <-0.35, 0.85>        */
#define G729EV_FEC_C_TILT          0.2917f
#define G729EV_FEC_K_ZC_DEC        (-0.067f)  /* <39, 24>             */
#define G729EV_FEC_C_ZC_DEC        2.613f
#define G729EV_FEC_K_ENR           (0.57143f) /* <-5, 2> => <-2, 2>            */
#define G729EV_FEC_C_ENR           0.85741f
#define G729EV_FEC_K_PC_DEC        (-0.0588f) /* <28, 11>             */
#define G729EV_FEC_C_PC_DEC        1.6468f

#define G729EV_FEC_K_COR_ENC           0.91743f /* <-0.29, 0.80>        */
#define G729EV_FEC_C_COR_ENC           0.26606f
#define G729EV_FEC_K_EE            2.5f
#define G729EV_FEC_C_EE            -1.25f
#define G729EV_FEC_K_ZC_ENC            (-0.067f)
#define G729EV_FEC_C_ZC_ENC            2.613f
#define G729EV_FEC_K_RELE          0.05f
#define G729EV_FEC_C_RELE          0.45f
#define G729EV_FEC_K_PC_ENC            (-0.1176f) /* <17, 8> */
#define G729EV_FEC_C_PC_ENC            2.0f
#define G729EV_FEC_K_SNR           0.09615f /*0.1111f */
#define G729EV_FEC_C_SNR           -.250f /*-0.3333f */
#define G729EV_FEC_PCHIST          3


#define G729EV_TDBWE_FADE_OUT_LENGTH 50
#define G729EV_TDBWE_FADE_IN_LENGTH  G729EV_TDBWE_FADE_OUT_LENGTH
#define ATTENUATION_CONST 150
#endif /*__G729EV_MAIN_DEFINES_H__ */
