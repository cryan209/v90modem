/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __CODEC_TYPEDEF_H__
#define __CODEC_TYPEDEF_H__


/* Manage the simple or double precision for floating variables */
// #define SINGLE                  /* Must be put in comment for double precision */

/* Must be defined if compilation target is a 32 bits platform */
#define _32_BITS_TARGET


/* Part use with TDAC, G.729... */
/*----------------------------- */

#if defined(__BORLANDC__) || defined (__WATCOMC__) || defined(_MSC_VER) || defined(__ZTC__) || defined(__HIGHC__) || defined (__ghs__)

#ifndef _32_BITS_TARGET
typedef long int INT32;
typedef unsigned long int UINT32;
#elif !defined(_BASETSD_H_)
typedef int INT32;
typedef unsigned int UINT32;
#endif
typedef short int INT16;
typedef unsigned short int UINT16;
typedef short int FLAG;
typedef double REAL_DOUBLE;
typedef float REAL_SINGLE;

#elif defined(__sun) || defined (__sun__)
typedef short INT16;
typedef long INT32;
typedef unsigned short UINT16;
typedef unsigned long UINT32;
typedef int FLAG;
typedef double REAL_DOUBLE;
typedef float REAL_SINGLE;

#elif defined (__osf__) &  defined (__alpha)
typedef short INT16;
typedef int INT32;
typedef unsigned short UINT16;
typedef unsigned int UINT32;
typedef int FLAG;
typedef double REAL_DOUBLE;
typedef float REAL_SINGLE;

#elif defined(VMS) || defined(__VMS) || defined(VAX)
typedef short INT16;
typedef long INT32;
typedef unsigned short UINT16;
typedef unsigned long UINT32;
typedef int FLAG;
typedef double REAL_DOUBLE;
typedef float REAL_SINGLE;

#elif defined (__unix__) || defined (__unix)
typedef short INT16;
typedef int INT32;
typedef unsigned short UINT16;
typedef unsigned int UINT32;
typedef int FLAG;
typedef double REAL_DOUBLE;
typedef float REAL_SINGLE;


#else
#error  COMPILER NOT TESTED CodecTypedef.h needs to be updated !!!
#endif

#ifdef SINGLE
typedef REAL_SINGLE REAL;
#else
typedef REAL_DOUBLE REAL;
#endif

#endif /*__CODEC_TYPEDEF_H__ */
