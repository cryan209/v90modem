/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <stdlib.h>
#include <math.h>

#include "G729EV_G729_defines.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_bitalloc.h"
#include "G729EV_TDAC_lib_vq.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_calc_nbit_total()                                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Compute bit_alloc(j)=SelectCbk(nb_coef(j)*(ip(j)-lam)) and              *
 *          nbit_total = sum_j bit_alloc(j)                                 *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_calc_nbit_total(int nb_sb,             /* (i)     number of subbands */
                                 const INT16 * nb_coef, /* (i)     number of coefficients per subband */
                                 REAL * ip,             /* (i)     perceptual importance per subband */
                                 REAL lam,              /* (i)     water level */
                                 int *nbit_total,       /* (o)     total number of bits */
                                 int *bit_alloc         /* (o)     number of bits per subband */
    )
{
  int       j, n;
  REAL      nbit_estim;

  /* compute bit allocation for each subband */
  *nbit_total = 0;
  for (j = 0; j < nb_sb; j++)
  {
    /* compute estimated bit allocation = estimed rate per sample * dimension */
    nbit_estim = (ip[j] - lam) * (REAL) nb_coef[j];

    /* find codebook rate which is closest to target rate */
    n = (int) (nbit_estim + (REAL) 0.5);
    n = G729EV_TDAC_SelectCbk(n, nb_coef[j]);

    /* save bit allocation */
    bit_alloc[j] = n;

    /* accumulate bit counter */
    *nbit_total += n;
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_allocbit()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Compute bit_alloc(j)=SelectCbk(nb_coef(j)*(ip(j)-lam)) and              *
 *          nbit_total = sum_j bit_alloc(j)                                 *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_allocbit(int *bit_alloc,         /* (o)     number of bits per subband */
                          int nbit_max,           /* (i)     bit budget to TDAC vq */
                          REAL * ip,              /* (i)  perceptual importance per subband */
                          int nb_sb,              /* (i)     number of subbands */
                          const INT16 * nb_coef,  /* (i)     number of coefficients per subband */
                          int *ord_b              /* (i)     ordering of subbands */
    )
{
  REAL      min_ip, max_ip;
  int       j, new_bit_alloc[G729EV_TDAC_NB_SB], bit_cnt, bit_cnt0, bit_cnt1;
  REAL      lam0, lam1, lam;
  int       iter;

  /* initialize bit allocation to subbands */
  for (j = 0; j < nb_sb; j++)
    bit_alloc[j] = 0;

  /* find min and max */
  max_ip = ip[ord_b[0]];
  min_ip = ip[ord_b[G729EV_TDAC_NB_SB - 1]];

  /* set range for bisection search */
  lam0 = max_ip;
  bit_cnt0 = 0;

  lam1 = min_ip - (REAL) 4.0;
  G729EV_TDAC_calc_nbit_total(nb_sb, nb_coef, ip, lam1, &bit_cnt1, new_bit_alloc);

  /* bisection search */
  iter = 0;
  while (iter < 10)
  {
    iter++;

    /* try middle value */
    lam = (lam0 + lam1) / (REAL) 2.0;
    G729EV_TDAC_calc_nbit_total(nb_sb, nb_coef, ip, lam, &bit_cnt, new_bit_alloc);

    /* update solution if total bit allocation is inferior and closer to bit budget */
    if (bit_cnt <= nbit_max)
    {
      lam0 = lam;
      for (j = 0; j < nb_sb; j++)
        bit_alloc[j] = new_bit_alloc[j];
      bit_cnt0 = bit_cnt;
    }
    else
    {
      lam1 = lam;
      bit_cnt1 = bit_cnt;
    }
  }

  /* add bits if needed */
  for (j = 0; (j < G729EV_TDAC_NB_SB) && (bit_cnt0 < nbit_max); j++)
  {
    int       i, n, add_b, add_b_max, new_bi, diff;

    i = ord_b[j];
    n = nb_coef[i];
    /* add bits to subband i (try to sature bit allocation) */
    add_b = *(G729EV_MAIN_adRate[n] + G729EV_MAIN_NbDic[n] - 1) - bit_alloc[i];
    add_b_max = nbit_max - bit_cnt0;
    if (add_b > add_b_max)
      add_b = add_b_max;
    new_bi = G729EV_TDAC_SelectCbk(bit_alloc[i] + add_b, n);
    diff = new_bi - bit_alloc[i];
    if (bit_cnt0 + diff > nbit_max)
    {
      new_bi = G729EV_TDAC_SearchPrev(new_bi, n);
      diff = new_bi - bit_alloc[i];
    }
    bit_cnt0 += diff;
    bit_alloc[i] += diff;
  }
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_sort_ip()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  Order subbands by decreasing perceptual importance                      *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_sort_ip(REAL * ip,   /* (i)  perceptual importance per subband */
                         int nb_ssb,  /* (i)     number of subband */
                         int *pos     /* (o)     subband order */
    )
{
  REAL      tab_ip[G729EV_TDAC_NB_SB], max;
  int       i, j, jmax, k;

  /* copy ip */
  for (i = 0; i < G729EV_TDAC_NB_SB; i++)
    tab_ip[i] = ip[i];

  /* sort ip in decreasing order and save positions */
  for (i = 0, k = 0; i < G729EV_TDAC_NB_SB; i++, k++)
  {
    jmax = 0;                   /* to avoid warning */
    max = G729EV_TDAC_SORTED_IP;
    for (j = 0; j < G729EV_TDAC_NB_SB; j++)
      if (tab_ip[j] > max)
      {
        jmax = j;
        max = tab_ip[j];
      }
    pos[k] = jmax;
    tab_ip[jmax] = G729EV_TDAC_SORTED_IP;
  }
}
