/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.7                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729_TAB_LD8K_H__
#define __G729EV_G729_TAB_LD8K_H__

#include "CodecTypedef.h"
#include "G729EV_G729_defines.h"

extern REAL hamwindow[G729EV_G729_L_WINDOW];
extern REAL lwindow[G729EV_G729_M + 2];
extern REAL lspcb1[G729EV_G729_NC0][G729EV_G729_M]; /*First Stage Codebook */
extern REAL lspcb2[G729EV_G729_NC1][G729EV_G729_M]; /*Second Stage Codebook */
extern REAL fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M]; /*MA prediction coef.  */
extern REAL fg_sum[G729EV_G729_MODE][G729EV_G729_M];  /*present MA prediction coef. */
extern REAL fg_sum_inv[G729EV_G729_MODE][G729EV_G729_M];  /*inverse coef. */
extern REAL grid[G729EV_G729_GRID_POINTS + 1];
extern REAL inter_3l[G729EV_G729_FIR_SIZE_SYN];
extern REAL inter_3[G729EV_G729_FIR_SIZE_ANA];
extern REAL gbk1[G729EV_G729_NCODE1][2];
extern REAL gbk2[G729EV_G729_NCODE2][2];
extern REAL coef[2][2];
extern REAL thr1[G729EV_G729_NCODE1 - G729EV_G729_NCAN1];
extern REAL thr2[G729EV_G729_NCODE2 - G729EV_G729_NCAN2];
extern int map1[G729EV_G729_NCODE1];
extern int map2[G729EV_G729_NCODE2];
extern int imap1[G729EV_G729_NCODE1];
extern int imap2[G729EV_G729_NCODE2];
extern REAL pred[4];
extern REAL tab_hup_l[G729EV_G729_SIZ_TAB_HUP_L];
extern REAL tab_hup_s[G729EV_G729_SIZ_TAB_HUP_S];
extern REAL freq_prev_reset[G729EV_G729_M];
extern REAL ph_imp_low[G729EV_G729_L_SUBFR];
extern REAL ph_imp_mid[G729EV_G729_L_SUBFR];
extern REAL ph_imp_high[G729EV_G729_L_SUBFR];
#endif /* __G729EV_G729_TAB_LD8K_H__ */
