/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.7                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
#ifndef __G729EV_G729_DECSTAT_H__
#define __G729EV_G729_DECSTAT_H__

#include <stdio.h>
#include "CodecTypedef.h"
#include "G729EV_G729_defines.h"
#include "G729EV_MAIN_defines.h"

/* Structure of the decoder status variables */

typedef struct
{
  REAL      old_exc[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];  /* Excitation vector          */
  REAL      lsp_old[G729EV_G729_M];     /* Lsp (Line spectral pairs)  */
  REAL      mem_syn[G729EV_G729_M_LPC]; /* Filter's memory            */
  REAL      freq_prev[G729EV_G729_MA_NP][G729EV_G729_M];  /* previous LSP vector        */
  REAL      prev_lsp[G729EV_G729_M];    /* previous LSP vector        */
  REAL      past_qua_en[4];             /* Past quantized energies    */
  INT16     rate;                       /* Rate                               */
  INT16     seed_fer;
  REAL      sharp;                      /* pitch sharpening of previous frame */
  REAL      gain_code;                  /* Code gain                          */
  REAL      gain_pitch;                 /* Pitch gain                         */
  INT16     prev_ma;                    /* previous MA prediction coef.       */
  REAL      lp_gainp;
  REAL      lp_gainc;
  INT16     i_subfr_cnt;
  REAL      tilt_code;
  REAL      stab_fac;
  INT16     upd_cnt;
  REAL      enr_old;
  REAL      fpitch[2];
  REAL      old_fpitch;
  INT16     bfi_cnt;
  REAL      pit_mem[5];
  INT16     bfi_mem;
  REAL      MemTam[G729EV_G729_MEM_LEN_TAM];

  /* G.729B mode */
  int       g729b_bst;
  INT16     ftyp[2];
  INT16     past_ftyp;
  INT16     seed;
  REAL      sid_sav;
  REAL      sid_gain;
		
  INT16 sid_nb;
  INT16 counter_k;
  INT16 counter_n;

  INT16 seed2;
  REAL pre_gain;
  REAL pre_lsp[G729EV_G729_M];
  REAL sid_lsp[G729EV_G729_M];
  INT16 old_pitch;
  REAL old_gp;
  REAL bfi_factor;
  REAL lsp_mean[G729EV_G729_M];       
  REAL Ga_gain_mean;
  REAL Gf_gain_mean;
 int step_counter;
 int VAD_flag_change_counter;
 REAL VAD_flag_change_counter_move;
 int  gain_change_hangover;    
  INT16 transition_flag;
  int prev_type;
  INT16 subfr_num;
  REAL filt_temp[FILTERORDER];
  REAL counter_n_lt;

} G729EV_G729_DECSTAT;




#endif  /*__G729EV_G729_DECSTAT_H__ */
