/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.7                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
#ifndef __G729EV_G729B_DEFINES_H__
#define __G729EV_G729B_DEFINES_H__

/*--------------------------------------------------------------------------*
 * Constants for DTX/CNG                                                    *
 *--------------------------------------------------------------------------*/

#define G729EV_G729B_RATE_8000       80 /* Full rate  (8000 bit/s)       */
#define G729EV_G729B_RATE_SID        15 /* SID                           */
#define G729EV_RATE_SID_WB			 19 /* SID                           */
#define G729EV_RATE_SID_NB			 9
#define G729EV_G729B_RATE_0           0 /* 0 bit/s rate                  */

/* DTX constants */
#define INIT_SEED       11111
#define NB_GAIN         4
#define MIN_ENER        (REAL)0.1588489319   /* <=> - 8 dB      */
#define A_GAIN0         (REAL)0.875
#define A_GAIN1         ((REAL)1. - A_GAIN0)
#define FLAG_DEC        0

/* Bitrate switching constants */
#define AGC_FAC         (REAL)0.9875             /* gain adjustment factor             */
#define AGC_FAC1        ((REAL)1. - AGC_FAC)    /* gain adjustment factor  */
#define G729EV_MAIN_COUNT_RCV_DTX_MAX 5
#define WB_STAT_COEFF	(REAL)0.5

/* CNG excitation generation constant */
                                            /* alpha = 0.5 */
#define NORM_GAUSS      (REAL)3.16227766    /* sqrt(40)xalpha */
#define K0              (REAL)3.            /* 4 x (1 - alpha ** 2) */
#define G_MAX           (REAL)5000.

#define G729EV_G729B_ATTEN_COEFF 0.999
#define G729EV_G729B_3rdCB_LEN    64
#define G729EV_G729B_3rdRAT_LEN   8

/*--------------------------------------------------------------------------*
 * Constants for DTX/CNG                                                    *
 *--------------------------------------------------------------------------*/

/* DTX constants */
#define FLAG_COD        1
#define FLAG_DEC        0


#define FR_SID_MIN      6
#define FR_SID_MAX      25 // default maximum distance between SID frames = 25 G.729.1 frames
#define NB_CURACF       4

#define NB_SUMACF       5
#define NB_GAIN         4



#define DTX_HANG_CONST 6 /* Hangover Period */ 
#define NB_ACCACF       2

#define THRESH1         (REAL)1.3426513671875
#define THRESH2         (REAL)1.09661865234375

#define SIZ_SUMACF      (NB_SUMACF * G729EV_G729_MP1)
#define SIZ_ACF         (NB_CURACF * G729EV_G729_MP1)

#define GAIN_SHAPING_FILTER           (REAL)0.997 
#endif  /*__G729EV_G729_DEFINES_H__ */
