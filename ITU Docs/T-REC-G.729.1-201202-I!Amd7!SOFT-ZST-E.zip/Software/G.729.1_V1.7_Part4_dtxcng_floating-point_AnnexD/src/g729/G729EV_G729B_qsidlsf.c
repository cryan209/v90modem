/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.7                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      

   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/

/*
 File : QSIDLSF.C
*/
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729B_defines.h"
#include "G729EV_G729B_enc_sid.h"
#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729_TAB_LD8K.H"


/* local functions */
static void Qnt_e(
    REAL *errlsf,    /* (i)  : error lsf vector             */
    REAL *weight,    /* (i)  : weighting vector             */
    int DIn,        /* (i)  : number of input candidates   */
    REAL *qlsf,      /* (o)  : quantized error lsf vector   */
    int *Pptr,      /* (o)  : predictor index              */
    int DOut,       /* (i)  : number of quantized vectors  */
    int *cluster,   /* (o)  : quantizer indices            */
    int *MS,        /* (i)  : size of the quantizers       */
	REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
	REAL *lsf, 
	REAL *new_errlsf
);
static void Qnt_e_stage3(
    REAL *errlsf,    /* (i)  : error lsf vector             */
    REAL *weight,    /* (i)  : weighting vector             */
    REAL *qlsf,      /* (i/o)  : quantized error lsf vector   */
    int *Pptr,      /* (o)  : predictor index              */
    int *cluster   /* (o)  : quantizer indices            */
			,int sid_gain
);
static void New_ML_search_1(
    REAL *d_data,    /* (i) : error vector             */
    int J,          /* (i) : number of input vectors  */
    REAL *new_d_data,/* (o) : output vector            */
    int K,          /* (i) : number of candidates     */
    int *best_indx, /* (o) : best indices             */
    int *ptr_back,  /* (o) : pointer for backtracking */
    int *PtrTab,    /* (i) : quantizer table          */
    int MQ          /* (i) : size of quantizer        */
);

static void New_ML_search_2(
    REAL *d_data,    /* (i) : error vector             */
    REAL *weight,    /* (i) : weighting vector         */
    int J,          /* (i) : number of input vectors  */
    REAL *new_d_data,/* (o) : output vector            */
    int K,          /* (i) : number of candidates     */
    int *best_indx, /* (o) : best indices             */
    int *ptr_prd,   /* (i) : pointer for backtracking */
    int *ptr_back,  /* (o) : pointer for backtracking */
    int PtrTab[2][16],/* (i) : quantizer table        */
    int MQ          /* (i) : size of quantizer        */
);
static void New_ML_search_3(
    REAL *d_data,    /* (i) : error vector             */
    REAL *weight,    /* (i) : weighting vector         */
    //REAL *new_d_data,/* (o) : output vector            */
    int *best_indx, /* (o) : best indices             */
    int *ptr_prd,   /* (i) : pointer for backtracking */
    int PtrTab[2][G729EV_G729B_3rdCB_LEN],/* (i) : quantizer table        */
    int MQ,          /* (i) : size of quantizer        */
	int ratio_index
);

/*-----------------------------------------------------------------*
 * Functions lsfq_noise                                            *
 *           ~~~~~~~~~~                                            *
 * Input:                                                          *
 *   lsp[]         : unquantized lsp vector                        *
 *   freq_prev[][] : memory of the lsf predictor                   *
 *                                                                 *
 * Output:                                                         *
 *                                                                 *
 *   lspq[]        : quantized lsp vector                          * 
 *   ana[]         : indices                                       *
 *                                                                 *
 *-----------------------------------------------------------------*/
void lsfq_noise(REAL noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M], 
				REAL *lsp, REAL *lspq, REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], int *ana, int sid_gain)
{
    int i, MS[G729EV_G729_MODE]={32, 16}, Clust[G729EV_G729_MODE+1], mode;
    REAL  lsf[G729EV_G729_M], lsfq[G729EV_G729_M], weight[G729EV_G729_M], tmpbuf[G729EV_G729_M], errlsf[G729EV_G729_M*G729EV_G729_MODE];
	REAL d_data[G729EV_G729_M];
	REAL tmpbuf1[G729EV_G729_M];
    /* convert lsp to lsf */
    for (i=0; i<G729EV_G729_M; i++ )
        lsf[i] = (REAL)acos(lsp[i]);
    
    /* spacing to ~100Hz */
    if (lsf[0] < G729EV_G729_L_LIMIT)
        lsf[0] = G729EV_G729_L_LIMIT;
    for (i=0 ; i < G729EV_G729_M-1 ; i++) {
        if (lsf[i+1]- lsf[i] < 2*G729EV_G729_GAP3) lsf[i+1] = lsf[i]+ 2*G729EV_G729_GAP3;
    }
    if (lsf[G729EV_G729_M-1] > G729EV_G729_M_LIMIT)
        lsf[G729EV_G729_M-1] = G729EV_G729_M_LIMIT;
    if (lsf[G729EV_G729_M-1] < lsf[G729EV_G729_M-2]) 
        lsf[G729EV_G729_M-2] = lsf[G729EV_G729_M-1]- G729EV_G729_GAP3;
    
    /* get the lsf weighting */
    G729EV_G729_Get_wegt(lsf, weight);
    
    /**********************/
    /* quantize the lsf's */
    /**********************/
    /* get the prediction error vector */
    for (mode=0; mode<G729EV_G729_MODE; mode++)
        G729EV_G729_Lsp_prev_extract(lsf, errlsf+mode*G729EV_G729_M, noise_fg[mode], freq_prev, 
        noise_fg_sum_inv[mode]);
    
    /* quantize the lsf and get the corresponding indices */
	Qnt_e(errlsf, weight, G729EV_G729_MODE, tmpbuf, &mode, 1, Clust, MS, freq_prev, lsf, &d_data[0]);
	G729EV_G729_Copy(tmpbuf, tmpbuf1, G729EV_G729_M);
	Qnt_e_stage3(&d_data[0], weight, tmpbuf, &mode, Clust, sid_gain);
    ana[0] = (int) mode;
    ana[1] = (int) Clust[0];
    ana[2] = (int) Clust[1];
	ana[4] = (int) Clust[2];
    
    /* guarantee minimum distance of 0.0012 between tmpbuf[j]
    and tmpbuf[j+1] */
    G729EV_G729_Lsp_expand_1_2(tmpbuf, (REAL)0.0012);
    
    /* compute the quantized lsf vector */
    G729EV_G729_Lsp_prev_compose(tmpbuf, lsfq, noise_fg[mode], freq_prev, noise_fg_sum[mode]);
    /* update the prediction memory */
    G729EV_G729_Lsp_prev_update(tmpbuf1, freq_prev);
    /* lsf stability check */
    G729EV_G729_Lsp_stability(lsfq);
    
    /* convert lsf to lsp */
    for (i=0; i<G729EV_G729_M; i++ )
        lspq[i] = (REAL)cos(lsfq[i]);
    
    return; 
}

static void Qnt_e(
    REAL *errlsf,    /* (i)  : error lsf vector             */
    REAL *weight,    /* (i)  : weighting vector             */
    int DIn,        /* (i)  : number of input candidates   */
    REAL *qlsf,      /* (o)  : quantized error lsf vector   */
    int *Pptr,      /* (o)  : predictor index              */
    int DOut,       /* (i)  : number of quantized vectors  */
    int *cluster,   /* (o)  : quantizer indices            */
    int *MS,         /* (i)  : size of the quantizers       */
	REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
	REAL *lsf, 
	REAL *new_errlsf
)
{
    int best_indx[2][R_LSFQ];
    int ptr_back[2][R_LSFQ], ptr, i;
    REAL d_data0[4*G729EV_G729_M];
    REAL d_data1[G729EV_G729_M];

    New_ML_search_1(errlsf, DIn, d_data0, 4, best_indx[0], ptr_back[0],
        PtrTab_1, MS[0]);
    New_ML_search_2(d_data0, weight, 4, d_data1, DOut, best_indx[1], 
        ptr_back[0], ptr_back[1], PtrTab_2, MS[1]);

	G729EV_G729_Copy(d_data1, new_errlsf, G729EV_G729_M);
    /* backward path for the indices */
    cluster[1] = best_indx[1][0];
    ptr = ptr_back[1][0];
    cluster[0] = best_indx[0][ptr];
    
    /* this is the pointer to the best predictor */
    *Pptr = ptr_back[0][ptr];
    
    /* generating the quantized vector */
    G729EV_G729_Copy(lspcb1[PtrTab_1[cluster[0]]], qlsf, G729EV_G729_M);
    for (i=0; i<G729EV_G729_M/2; i++)
        qlsf[i] = qlsf[i]+ lspcb2[PtrTab_2[0][cluster[1]]][i];
    for (i=G729EV_G729_M/2; i<G729EV_G729_M; i++)
        qlsf[i] = qlsf[i]+ lspcb2[PtrTab_2[1][cluster[1]]][i];
}
static void Qnt_e_stage3(
    REAL *errlsf,    /* (i)  : error lsf vector             */
    REAL *weight,    /* (i)  : weighting vector             */
    REAL *qlsf,      /* (i/o)  : quantized error lsf vector   */
    int *Pptr,      /* (o)  : predictor index              */
    int *cluster,   /* (o)  : quantizer indices            */
	int sid_gain
)
{
    int i;

    int index3;
	int ratio_index;
	ratio_index = sid_gain >> 2;
    /* the third stage quantization of lsf */
	{
		New_ML_search_3(errlsf, weight, /*d_data[2],*/ &index3, Pptr, PtrTab_3, G729EV_G729B_3rdCB_LEN, ratio_index);
		/* generating the quantized vector */
		cluster[2] = index3;
		for (i=0; i<G729EV_G729_M/2; i++)
		    qlsf[i] = qlsf[i]+ ratio_cb2[ratio_index] * lspcb2[PtrTab_3[0][cluster[2]]][i];
		for (i=G729EV_G729_M/2; i<G729EV_G729_M; i++)
		    qlsf[i] = qlsf[i]+ ratio_cb2[ratio_index] * lspcb2[PtrTab_3[1][cluster[2]]][i];
	}
}
static void New_ML_search_1(
    REAL *d_data,    /* (i) : error vector             */
    int J,          /* (i) : number of input vectors  */
    REAL *new_d_data,/* (o) : output vector            */
    int K,          /* (i) : number of candidates     */
    int *best_indx, /* (o) : best indices             */
    int *ptr_back,  /* (o) : pointer for backtracking */
    int *PtrTab,    /* (i) : quantizer table          */
    int MQ          /* (i) : size of quantizer        */
)
{
	int m, l, p, q, min_indx_p[4], min_indx_m[4];
	REAL  sum[64], min[4];
    
    for (q=0 ; q < K ; q++) {
        min[q] = G729EV_G729_FLT_MAX_G729;
    }
    
    /* compute the errors */
    for (p=0 ; p < J ; p++) {
        for(m=0 ; m < MQ ; m++) {
            sum[p*MQ+m] = (REAL)0.0;
            for (l=0 ; l < G729EV_G729_M ; l++) {
                sum[p*MQ+m] +=
                    sqr(d_data[p*G729EV_G729_M+l]-lspcb1[PtrTab[m]][l]);
            }
            sum[p*MQ+m] *= Mp[p];
        }
    }
    
    /* select the candidates */
    for (q=0 ; q < K ; q++) {
		min_indx_p[q] = min_indx_m[q] = 0; 
        for (p=0 ; p < J ; p++) {
            for (m=0 ; m < MQ ; m++) {
                if (sum[p*MQ+m] < min[q]) {
                    min[q] = sum[p*MQ+m];
                    min_indx_p[q] = p;
                    min_indx_m[q] = m;
                }
            }
        }
        sum[min_indx_p[q]*MQ+min_indx_m[q]] = G729EV_G729_FLT_MAX_G729;
    }
    
    for (q=0 ; q < K ; q++) {
        for (l=0 ; l < G729EV_G729_M ; l++) {
            new_d_data[q*G729EV_G729_M+l] =
                d_data[min_indx_p[q]*G729EV_G729_M+l]-lspcb1[PtrTab[min_indx_m[q]]][l];
        }
        ptr_back[q] = min_indx_p[q];
        best_indx[q] = min_indx_m[q];
    }
    
    return;
}

static void New_ML_search_2(
    REAL *d_data,    /* (i) : error vector             */
    REAL *weight,    /* (i) : weighting vector         */
    int J,          /* (i) : number of input vectors  */
    REAL *new_d_data,/* (o) : output vector            */
    int K,          /* (i) : number of candidates     */
    int *best_indx, /* (o) : best indices             */
    int *ptr_prd,   /* (i) : pointer for backtracking */
    int *ptr_back,  /* (o) : pointer for backtracking */
    int PtrTab[2][16],/* (i) : quantizer table        */
    int MQ          /* (i) : size of quantizer        */
)
{
    int   m,l,p,q;
	int   min_indx_p[1];
    int   min_indx_m[1];
    REAL   sum[64];
    REAL   min[1];
    
    for (q=0; q<K; q++)
        min[q] = G729EV_G729_FLT_MAX_G729;
    
    /* compute the errors */
    for (p=0 ; p < J ; p++) {
        for(m=0 ; m < MQ ; m++) {
            sum[p*MQ+m] = (REAL)0.0;
            for (l=0 ; l < G729EV_G729_M/2 ; l++) {
                sum[p*MQ+m] +=
                    weight[l]*sqr(noise_fg_sum[ptr_prd[p]][l])*sqr(d_data[p*G729EV_G729_M+l]-lspcb2[PtrTab[0][m]][l]);
            }
            for (l=G729EV_G729_M/2 ; l < G729EV_G729_M ; l++) {
                sum[p*MQ+m] +=
                    weight[l]*sqr(noise_fg_sum[ptr_prd[p]][l])*sqr(d_data[p*G729EV_G729_M+l]-lspcb2[PtrTab[1][m]][l]);
            }
        }
    }
    
    /* select the candidates */
    for (q=0 ; q < K ; q++) {
		min_indx_p[q] = min_indx_m[q] = 0; 
        for (p=0 ; p < J ; p++) {
            for (m=0 ; m < MQ ; m++) {
                if (sum[p*MQ+m] < min[q]) {
                    min[q] = sum[p*MQ+m];
                    min_indx_p[q] = p;
                    min_indx_m[q] = m;
                }
            }
        }
        sum[min_indx_p[q]*MQ+min_indx_m[q]] = G729EV_G729_FLT_MAX_G729;
    }
    
    /* compute the candidates */
    for (q=0 ; q < K ; q++) {
        for (l=0 ; l < G729EV_G729_M/2 ; l++) {
            new_d_data[q*G729EV_G729_M+l] =
                d_data[min_indx_p[q]*G729EV_G729_M+l]-lspcb2[PtrTab[0][min_indx_m[q]]][l];
        }
        for (l=G729EV_G729_M/2 ; l < G729EV_G729_M ; l++) {
            new_d_data[q*G729EV_G729_M+l] = d_data[min_indx_p[q]*G729EV_G729_M+l]-
                lspcb2[PtrTab[1][min_indx_m[q]]][l];
        }
        ptr_back[q] = min_indx_p[q];
        best_indx[q] = min_indx_m[q];
    }
    return; 
}

static void New_ML_search_3(
    REAL *d_data,    /* (i) : error vector             */
    REAL *weight,    /* (i) : weighting vector         */
    int *best_indx, /* (o) : best indices             */
    int *ptr_prd,   /* (i) : pointer for backtracking */
    int PtrTab[2][G729EV_G729B_3rdCB_LEN],/* (i) : quantizer table        */
    int MQ,          /* (i) : size of quantizer        */
	int ratio_index
)
{
    int   m,l;
    int   min_indx_m;
	REAL   sum[G729EV_G729B_3rdCB_LEN];
    REAL   min;
    
    min = G729EV_G729_FLT_MAX_G729;
    
    /* compute the errors */
    for(m=0 ; m < MQ ; m++) {
        sum[m] = (REAL)0.0;
        for (l=0 ; l < G729EV_G729_M/2 ; l++) {
            sum[m] +=
		            weight[l]*sqr(noise_fg_sum[ptr_prd[0]][l])*sqr(d_data[l]-ratio_cb2[ratio_index] * lspcb2[PtrTab[0][m]][l]);
        }
        for (l=G729EV_G729_M/2 ; l < G729EV_G729_M ; l++) {
            sum[m] +=
		            weight[l]*sqr(noise_fg_sum[ptr_prd[0]][l])*sqr(d_data[l]-ratio_cb2[ratio_index] * lspcb2[PtrTab[1][m]][l]);
        }
    }
    
    /* select the candidates */
    for (m=0 ; m < MQ ; m++) {
        if (sum[m] < min) {
            min = sum[m];
            min_indx_m = m;
        }
    }
    
    best_indx[0] = min_indx_m;
    return; 
}
