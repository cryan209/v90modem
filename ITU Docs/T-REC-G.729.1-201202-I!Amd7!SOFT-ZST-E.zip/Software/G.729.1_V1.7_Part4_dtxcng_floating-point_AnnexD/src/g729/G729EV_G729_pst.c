/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.7                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"


/************************************************************************/
/*      Post - filtering : short term + long term                       */
/************************************************************************/

/*----------------------------------------------------------------------------
 *  Function G729EV_G729_pst_ltp - harmonic postfilter
 *----------------------------------------------------------------------------
*/
void G729EV_G729_pst_ltp(int t0,              /* input : pitch delay given by coder */
                         REAL * ptr_sig_in,   /* input : postfilter input filter (residu2) */
                         REAL * ptr_sig_pst0  /* output: harmonic postfilter output */
    )
{

  /**** Declare variables                                 */
  int       ltpdel, phase;
  REAL      num_gltp, den_gltp;
  REAL      num2_gltp, den2_gltp;
  REAL      gain_plt;
  REAL      y_up[G729EV_G729_SIZ_Y_UP];
  REAL     *ptr_y_up;
  int       off_yup;

  /* Sub optimal delay search */
  G729EV_G729_search_del(t0, ptr_sig_in, &ltpdel, &phase, &num_gltp, &den_gltp, y_up, &off_yup);

  if (num_gltp == (REAL) 0.)
  {
    G729EV_G729_Copy(ptr_sig_in, ptr_sig_pst0, G729EV_G729_L_SUBFR);
  }
  else
  {
    if (phase == 0)
    {
      ptr_y_up = ptr_sig_in - ltpdel;
    }
    else
    {
      /* Filtering with long filter */
      G729EV_G729_compute_ltp_l(ptr_sig_in, ltpdel, phase, ptr_sig_pst0, &num2_gltp, &den2_gltp);

      if (G729EV_G729_select_ltp(num_gltp, den_gltp, num2_gltp, den2_gltp) == 1)
      {

        /* select short filter */
        ptr_y_up = y_up + ((phase - 1) * G729EV_G729_L_SUBFRP1 + off_yup);
      }
      else
      {
        /* select long filter */
        num_gltp = num2_gltp;
        den_gltp = den2_gltp;
        ptr_y_up = ptr_sig_pst0;
      }

    }

    if (num_gltp >= den_gltp)
    {
      /* beta bounded to 1 */
      gain_plt = G729EV_G729_MIN_GPLT;
    }
    else
    {
      gain_plt = den_gltp / (den_gltp + ((REAL) 0.5) * num_gltp);
    }

    /* filtering by H0(z) = harmonic filter */
    G729EV_G729_filt_plt(ptr_sig_in, ptr_y_up, ptr_sig_pst0, gain_plt);

  }

  return;
}

/*--------------------------------------------------------------------------------------------
 * Function G729EV_G729_search_del: computes best (shortest) integer LTP delay + fine search
 *--------------------------------------------------------------------------------------------
 */
void G729EV_G729_search_del(int t0,             /* input : pitch delay given by coder       */
                            REAL * ptr_sig_in,  /* input : input signal (with delay line)   */
                            int *ltpdel,        /* output: delay = *ltpdel - *phase / f_up  */
                            int *phase,         /* output: phase                            */
                            REAL * num_gltp,    /* output: numerator of LTP gain            */
                            REAL * den_gltp,    /* output: denominator of LTP gain          */
                            REAL * y_up,        /* output: LT delayed signal if fract. delay */
                            int *off_yup        /* output: offset in y_up                   */
    )
{
  /* pointers on tables of constants */
  const REAL *ptr_h;

  /* Variables and local arrays */
  REAL      tab_den0[G729EV_G729_F_UP_PST - 1], tab_den1[G729EV_G729_F_UP_PST - 1];
  REAL     *ptr_den0, *ptr_den1;
  REAL     *ptr_sig_past, *ptr_sig_past0;
  REAL     *ptr1;

  int       i, n, ioff, i_max;
  REAL      ener, num, numsq, den0, den1;
  REAL      den_int, num_int;
  REAL      den_max, num_max, numsq_max;
  int       phi_max;
  int       lambda, phi;
  REAL      temp0, temp1;
  REAL     *ptr_y_up;

  /*****************************************/
  /* Compute energy of current signal      */
  /*****************************************/

  ener = (REAL) 0.;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    ener += ptr_sig_in[i] * ptr_sig_in[i];
  }
  if (ener < (REAL) 0.1)
  {
    *num_gltp = (REAL) 0.;
    *den_gltp = (REAL) 1.;
    *ltpdel = 0;
    *phase = 0;
    return;
  }

  /*************************************/
  /* Selects best of 3 integer delays  */
  /* Maximum of 3 numerators around t0 */
  /* coder LTP delay                   */
  /*************************************/
  lambda = t0 - 1;

  ptr_sig_past = ptr_sig_in - lambda;

  num_int = (REAL) - 1.0e30;

  /* initialization used only to suppress Microsoft Visual C++ warnings */
  i_max = 0;
  for (i = 0; i < 3; i++)
  {
    num = (REAL) 0.;
    for (n = 0; n < G729EV_G729_L_SUBFR; n++)
    {
      num += ptr_sig_in[n] * ptr_sig_past[n];
    }
    if (num > num_int)
    {
      i_max = i;
      num_int = num;
    }
    ptr_sig_past--;
  }
  if (num_int <= (REAL) 0.)
  {
    *num_gltp = (REAL) 0.;
    *den_gltp = (REAL) 1.;
    *ltpdel = 0;
    *phase = 0;
    return;
  }

  /* Calculates denominator for i_max */
  lambda += i_max;
  ptr_sig_past = ptr_sig_in - lambda;
  den_int = (REAL) 0.;
  for (n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
    den_int += ptr_sig_past[n] * ptr_sig_past[n];
  }
  if (den_int < (REAL) 0.1)
  {
    *num_gltp = (REAL) 0.;
    *den_gltp = (REAL) 1.;
    *ltpdel = 0;
    *phase = 0;
    return;
  }
  /***********************************/
  /* Select best phase around lambda */
  /***********************************/

  /* Compute y_up & denominators */
  /*******************************/
  ptr_y_up = y_up;
  den_max = den_int;
  ptr_den0 = tab_den0;
  ptr_den1 = tab_den1;
  ptr_h = tab_hup_s;
  ptr_sig_past0 = ptr_sig_in + G729EV_G729_LH_UP_S - 1 - lambda;  /* points on lambda_max+1 */

  /* loop on phase  */
  for (phi = 1; phi < G729EV_G729_F_UP_PST; phi++)
  {

    /* Computes criterion for (lambda+1) - phi/G729EV_G729_F_UP_PST     */
    /* and lambda - phi/G729EV_G729_F_UP_PST                            */
    ptr_sig_past = ptr_sig_past0;
    /* computes y_up[n] */
    for (n = 0; n <= G729EV_G729_L_SUBFR; n++)
    {
      ptr1 = ptr_sig_past++;
      temp0 = (REAL) 0.;
      for (i = 0; i < G729EV_G729_LH2_S; i++)
      {
        temp0 += ptr_h[i] * ptr1[-i];
      }
      ptr_y_up[n] = temp0;
    }

    /* compute den0 (lambda+1) and den1 (lambda) */

    /* part common to den0 and den1 */
    temp0 = (REAL) 0.;
    for (n = 1; n < G729EV_G729_L_SUBFR; n++)
    {
      temp0 += ptr_y_up[n] * ptr_y_up[n];
    }

    /* den0 */
    den0 = temp0 + ptr_y_up[0] * ptr_y_up[0];
    *ptr_den0++ = den0;

    /* den1 */
    den1 = temp0 + ptr_y_up[G729EV_G729_L_SUBFR] * ptr_y_up[G729EV_G729_L_SUBFR];
    *ptr_den1++ = den1;

    if (fabs(ptr_y_up[0]) > fabs(ptr_y_up[G729EV_G729_L_SUBFR]))
    {
      if (den0 > den_max)
      {
        den_max = den0;
      }
    }
    else
    {
      if (den1 > den_max)
      {
        den_max = den1;
      }
    }
    ptr_y_up += G729EV_G729_L_SUBFRP1;
    ptr_h += G729EV_G729_LH2_S;
  }
  if (den_max < (REAL) 0.1)
  {
    *num_gltp = (REAL) 0.;
    *den_gltp = (REAL) 1.;
    *ltpdel = 0;
    *phase = 0;
    return;
  }
  /* Computation of the numerators                */
  /* and selection of best num*num/den            */
  /* for non null phases                          */

  /* Initialize with null phase */
  num_max = num_int;
  den_max = den_int;
  numsq_max = num_max * num_max;
  phi_max = 0;
  ioff = 1;

  ptr_den0 = tab_den0;
  ptr_den1 = tab_den1;
  ptr_y_up = y_up;

  /* if den_max = 0 : will be selected and declared unvoiced */
  /* if num!=0 & den=0 : will be selected and declared unvoiced */
  /* degenerated seldom cases, switch off LT is OK */

  /* Loop on phase */
  for (phi = 1; phi < G729EV_G729_F_UP_PST; phi++)
  {

    /* computes num for lambda+1 - phi/G729EV_G729_F_UP_PST */
    num = (REAL) 0.;
    for (n = 0; n < G729EV_G729_L_SUBFR; n++)
    {
      num += ptr_sig_in[n] * ptr_y_up[n];
    }
    if (num < (REAL) 0.)
      num = (REAL) 0.;
    numsq = num * num;

    /* selection if num/sqrt(den0) max */
    den0 = *ptr_den0++;
    temp0 = numsq * den_max;
    temp1 = numsq_max * den0;
    if (temp0 > temp1)
    {
      num_max = num;
      numsq_max = numsq;
      den_max = den0;
      ioff = 0;
      phi_max = phi;
    }

    /* computes num for lambda_max - phi/G729EV_G729_F_UP_PST */
    ptr_y_up++;
    num = (REAL) 0.;
    for (n = 0; n < G729EV_G729_L_SUBFR; n++)
    {
      num += ptr_sig_in[n] * ptr_y_up[n];
    }
    if (num < (REAL) 0.)
      num = (REAL) 0.;
    numsq = num * num;

    /* selection if num/sqrt(den1) max */
    den1 = *ptr_den1++;
    temp0 = numsq * den_max;
    temp1 = numsq_max * den1;
    if (temp0 > temp1)
    {
      num_max = num;
      numsq_max = numsq;
      den_max = den1;
      ioff = 1;
      phi_max = phi;
    }
    ptr_y_up += G729EV_G729_L_SUBFR;
  }

  /***************************************************************/
  /*** test if normalised crit0[iopt] > G729EV_G729_THRESCRIT  ***/
  /***************************************************************/

  if ((num_max == (REAL) 0.) || (den_max <= (REAL) 0.1))
  {
    *num_gltp = (REAL) 0.;
    *den_gltp = (REAL) 1.;
    *ltpdel = 0;
    *phase = 0;
    return;
  }

  /* comparison num * num                         */
  /* with ener * den x G729EV_G729_THRESCRIT      */
  temp1 = den_max * ener * G729EV_G729_THRESCRIT;
  if (numsq_max >= temp1)
  {
    *ltpdel = lambda + 1 - ioff;
    *off_yup = ioff;
    *phase = phi_max;
    *num_gltp = num_max;
    *den_gltp = den_max;
  }
  else
  {
    *num_gltp = (REAL) 0.;
    *den_gltp = (REAL) 1.;
    *ltpdel = 0;
    *phase = 0;
  }

  return;
}

/*---------------------------------------------------------------------------
 *  Function G729EV_G729_filt_plt -  ltp  postfilter
 *----------------------------------------------------------------------------
 */
void G729EV_G729_filt_plt(REAL * s_in,  /* (i) : input signal with past      */
                          REAL * s_ltp, /* (i) : filtered signal with gain 1 */
                          REAL * s_out, /* (o): output signal                */
                          REAL gain_plt /* (i) : filter gain                 */
    )
{
  /* Local variables */
  int       n;
  REAL      gain_plt_1;

  gain_plt_1 = (REAL) 1. - gain_plt;

  for (n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
    s_out[n] = gain_plt * s_in[n] + gain_plt_1 * s_ltp[n];
  }

  return;
}

/*---------------------------------------------------------------------------
 *  Function G729EV_G729_compute_ltp_l : compute delayed signal,
 *                  num & den of gain for fractional delay
 *                  with long interpolation filter
 *----------------------------------------------------------------------------
 */
void G729EV_G729_compute_ltp_l(REAL * s_in, /* (i) : input signal with past */
                               int ltpdel,  /* (i) : delay factor */
                               int phase,   /* (i) : phase factor */
                               REAL * y_up, /* (o) : delayed signal */
                               REAL * num,  /* (o) : numerator of LTP gain */
                               REAL * den   /* (o) : denominator of LTP gain */
    )
{
  /* Pointer on table of constants */
  const REAL *ptr_h;

  /* Local variables */
  int       n, i;
  REAL     *ptr2, temp;

  /* Filtering with long filter */
  ptr_h = tab_hup_l + (phase - 1) * G729EV_G729_LH2_L;
  ptr2 = s_in - ltpdel + G729EV_G729_LH_UP_L;

  /* Compute y_up */
  for (n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
    temp = (REAL) 0.;
    for (i = 0; i < G729EV_G729_LH2_L; i++)
    {
      temp += ptr_h[i] * *ptr2--;
    }
    y_up[n] = temp;
    ptr2 += G729EV_G729_LH2_L_P1;
  }

  /* Compute num */
  *num = (REAL) 0.;
  for (n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
    *num += y_up[n] * s_in[n];
  }
  if (*num < (REAL) 0.0)
    *num = (REAL) 0.0;

  /* Compute den */
  *den = (REAL) 0.;
  for (n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
    *den += y_up[n] * y_up[n];
  }

  return;
}

/*----------------------------------------------------------------------------
 *  Function G729EV_G729_select_ltp : selects best of (gain1, gain2)
 *  with gain1 = num1 / den1
 *  and  gain2 = num2 / den2
 *----------------------------------------------------------------------------
 */
int G729EV_G729_select_ltp(             /* (o) : 1 = 1st gain, 2 = 2nd gain */
                            REAL num1,  /* (i) : numerator of gain1   */
                            REAL den1,  /* (i) : denominator of gain1 */
                            REAL num2,  /* (i) : numerator of gain2   */
                            REAL den2   /* (i) : denominator of gain2 */
    )
{
  if (den2 == (REAL) 0.)
  {
    return (1);
  }
  if (num2 * num2 * den1 > num1 * num1 * den2)
  {
    return (2);
  }
  else
  {
    return (1);
  }
}

/*-------------------------------------------------------------------------------------------
 *   Function G729EV_G729_calc_st_filt -  computes impulse response of A(gamma2) / A(gamma1)
 *   controls gain : computation of energy impulse response as
 *                    SUMn  (abs (h[n])) and computes parcor0
 *-------------------------------------------------------------------------------------------
 */
void G729EV_G729_calc_st_filt(REAL * apond2,      /* (i)   : coefficients of numerator */
                              REAL * apond1,      /* (i)   : coefficients of denominator */
                              REAL * parcor0,     /* (o)   : 1st parcor calcul. on composed filter */
                              REAL * sig_ltp_ptr, /* (i/o) : input of 1/A(gamma1) : scaled by 1/g0 */
                              REAL * mem_zero)
{
  REAL      h[G729EV_G729_LONG_H_ST];
  REAL      g0, temp;
  int       i;

  /* compute i.r. of composed filter apond2 / apond1 */
  G729EV_G729_Syn_filt(apond1, apond2, h, G729EV_G729_LONG_H_ST, mem_zero, 0);

  /* compute 1st parcor */
  G729EV_G729_calc_rc0_h(h, parcor0);

  /* compute g0 */
  g0 = (REAL) 0.;
  for (i = 0; i < G729EV_G729_LONG_H_ST; i++)
  {
    g0 += (REAL) fabs(h[i]);
  }

  /* Scale signal input of 1/A(gamma1) */
  if (g0 > (REAL) 1.)
  {
    temp = (REAL) 1. / g0;
    for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      sig_ltp_ptr[i] = sig_ltp_ptr[i] * temp;
    }
  }

  return;
}

/*---------------------------------------------------------------------------------------------
 * Function G729EV_G729_calc_rc0_h - computes 1st parcor from composed filter impulse response
 *---------------------------------------------------------------------------------------------
 */
void G729EV_G729_calc_rc0_h(REAL * h,   /* (i)  : impulse response of composed filter */
                            REAL * rc0  /* (o)  : 1st parcor */
    )
{
  REAL      acf0, acf1;
  REAL      temp, temp2;
  REAL     *ptrs;
  int       i;

  /* computation of the autocorrelation function acf */
  temp = (REAL) 0.;
  for (i = 0; i < G729EV_G729_LONG_H_ST; i++)
  {
    temp += h[i] * h[i];
  }
  acf0 = temp;

  temp = (REAL) 0.;
  ptrs = h;
  for (i = 0; i < G729EV_G729_LONG_H_ST - 1; i++)
  {
    temp2 = *ptrs++;
    temp += temp2 * (*ptrs);
  }
  acf1 = temp;

  /* Initialisation of the calculation */
  if (acf0 == (REAL) 0.)
  {
    *rc0 = (REAL) 0.;
    return;
  }

  /* Compute 1st parcor */
  /**********************/
  if (acf0 < (REAL) fabs(acf1))
  {
    *rc0 = (REAL) 0.0;
    return;
  }
  *rc0 = -acf1 / acf0;

  return;
}

/*--------------------------------------------------------------------------------
 * Function G729EV_G729_filt_mu - tilt filtering with : (1 + mu z-1) * (1/1-|mu|)
 *   computes y[n] = (1/1-|mu|) (x[n]+mu*x[n-1])
 *--------------------------------------------------------------------------------
 */
void G729EV_G729_filt_mu(REAL * sig_in,   /* (i) : input signal (beginning at sample -1) */
                         REAL * sig_out,  /* (o) : output signal                         */
                         REAL parcor0     /* (i) : parcor0 (mu = parcor0 * gamma3)       */
    )
{
  int       n;
  REAL      mu, ga, temp;
  REAL     *ptrs;

  if (parcor0 > (REAL) 0.)
  {
    mu = parcor0 * G729EV_G729_GAMMA3_PLUS;
  }
  else
  {
    mu = parcor0 * G729EV_G729_GAMMA3_MINUS;
  }
  ga = (REAL) 1. / ((REAL) 1. - (REAL) fabs(mu));

  ptrs = sig_in;                /* points on sig_in(-1) */
  for (n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
    temp = mu * (*ptrs++);
    temp += (*ptrs);
    sig_out[n] = ga * temp;
  }

  return;
}

/*------------------------------------------------------------------------------------
 *   Function G729EV_G729_scale_st  - control of the subframe gain
 *   gain[n] = G729EV_G729_AGC_FAC * gain[n-1] + (1 - G729EV_G729_AGC_FAC) g_in/g_out
 *------------------------------------------------------------------------------------
 */
void G729EV_G729_scale_st(REAL * sig_in,    /* (i)   : postfilter input signal         */
                          REAL * sig_out,   /* (i/o) : postfilter output signal        */
                          REAL * gain_prec, /* (i/o) : last value of gain for subframe */
                          REAL parcor0, REAL PostNB, REAL * Level_in_sm,
						  INT16 indication) /*input: indicatate for noise or not*/
{
  int       i;
  short     Cond;
  REAL      gain_in, gain_out;
  REAL      g0, gain;
  REAL      k1, tmp;

  /* compute input gain */
  gain_in = (REAL) 0.;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    gain_in += (REAL) fabs(sig_in[i]);
  }

  /* Smooth level */
  *Level_in_sm = (REAL) 0.75 *(*Level_in_sm) + (REAL) 0.25 *(gain_in);

  /* Detect silence */
  if(!indication)
	  Cond = (*Level_in_sm < 2048.) && (gain_in < (*Level_in_sm * 2.)) && (parcor0 < 0.015625);
  else
	  Cond = (*Level_in_sm < 512.) && (gain_in < (*Level_in_sm * 1.1)) && (parcor0 < 0.015625);

  /* If silence is detected, replace the original level with smoothed level */
  if ((Cond == 1) && (*Level_in_sm < gain_in))
    gain_in = *Level_in_sm;

  if (gain_in == (REAL) 0.)
  {
    g0 = (REAL) 0.;
  }
  else
  {
    /* Compute output gain */
    gain_out = (REAL) 0.;
    for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      gain_out += (REAL) fabs(sig_out[i]);
    }
    if (gain_out == (REAL) 0.)
    {
      *gain_prec = (REAL) 0.;
      return;
    }

    g0 = gain_in / gain_out;

	indication = indication << 1;
    if (Cond == 1)
    {                           /* Apply a gain reduction for silence; the gain is defined as
                                   gain = (Level_in_sm/MAX_SILENCE_LEVEL)*k1  +  (1-k1);
                                   k1 (0=<k1<=1) is a function of PARCOR0 */

      /*k1 */
      k1 = (REAL) (512. / 32768) - parcor0;
	  tmp = (REAL) (2048 >> indication);
	  tmp = (tmp - 1.0) / 32768.0;
      if (k1 > tmp)
        k1 = tmp;
      k1 /= tmp;

      /* gain = (Level_in_sm/MAX_SILENCE_LEVEL) */
      if (*Level_in_sm > ((2048 >> indication) - 1))
        gain = 1.;
      else
        gain = *Level_in_sm / (REAL) (2048 >> indication);

      gain = gain * k1 + 1 - k1;
      gain = gain * ((REAL) 1. - PostNB) + PostNB;

      g0 *= gain;
    }

    g0 *= G729EV_G729_AGC_FAC1;
  }

  /* compute gain(n) = G729EV_G729_AGC_FAC gain(n-1) + (1-G729EV_G729_AGC_FAC)gain_in/gain_out */
  /* sig_out(n) = gain(n) sig_out(n)                                                           */
  gain = *gain_prec;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    gain *= G729EV_G729_AGC_FAC;
    gain += g0;
    sig_out[i] *= gain;
  }
  *gain_prec = gain;

  return;
}

