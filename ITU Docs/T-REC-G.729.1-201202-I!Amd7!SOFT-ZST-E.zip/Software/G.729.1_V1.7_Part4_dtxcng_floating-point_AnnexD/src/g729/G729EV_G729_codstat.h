/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.7                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
#ifndef __G729EV_G729_CODSTAT_H__
#define __G729EV_G729_CODSTAT_H__

#include <stdio.h>
#include "CodecTypedef.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729B_defines.h"

/* Structure of the encoder status variables */

typedef struct
{

  REAL      exc_err[4];                         /* to tame coder */
  REAL      old_speech[G729EV_G729_MEM_SPEECH]; /* Speech vector          */
  REAL      old_wsp[G729EV_G729_PIT_MAX];       /* Weighted speech vector */
  REAL      old_exc[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];  /* Excitation vector      */
  REAL      lsp_old[G729EV_G729_M];             /* Line Spectral Pairs  */
  REAL      lsp_old_q[G729EV_G729_M];           /* Quantified LSP       */
  REAL      mem_syn[G729EV_G729_M_LPC];         /* Filter's memory      */
  REAL      mem_w0[G729EV_G729_M_LPC];
  REAL      mem_w[G729EV_G729_M_LPC];
  REAL      mem_err[G729EV_G729_M_LPC];
  REAL      old_A[G729EV_G729_MP1];             /* Last LPC coefs       */
  REAL      old_rc[2];
  REAL      freq_prev[G729EV_G729_MA_NP][G729EV_G729_M];  /* previous LSP vector       */
  REAL      past_qua_en[4];                     /* Past quantized energies */
  REAL      lar_old[2];
  INT16     rate;                               /* Rate */
  REAL      pit_sharp;
  INT16     smooth;
  REAL      mem_w0_2[G729EV_G729_M_LPC];
  REAL      mem_err2[G729EV_G729_M_LPC];
  REAL      mem_synth[G729EV_G729_M_LPC];       /* Memory for output synthesis  */
  INT16     pit_old;
/* For G.729B */
/* DTX variables */
  INT16 pastVad;
  int ppastVad;
  REAL lsp_mean[G729EV_G729_M];       
  REAL Ga_gain_mean;
  REAL Gf_gain_mean;
  INT16 seed;
  INT16 Vad;
  INT16 hangover_count;
  INT16 cng_nb;
  INT16 dtx_max_fr;
  INT16 flag_chang_wb;
  INT16 counter_k;
  INT16 counter_n;
  INT16 seed2;
  REAL pastCoeff[G729EV_G729_MP1];
  REAL RCoeff[G729EV_G729_MP1];
  REAL Acf[SIZ_ACF];
  REAL sumAcf[SIZ_SUMACF];
  REAL ener[NB_GAIN];
  int fr_cur;
  REAL pre_gain;
  int nb_ener;
  REAL sid_gain;
  REAL prev_energy;
  int count_fr0;
  REAL pre_lsp[G729EV_G729_M];
  REAL sid_lsp[G729EV_G729_M];
  INT16 old_pitch;
  REAL old_gp;
  int  Nb_First_change_flag;                         
  int  Nb_Second_change_flag;                        
  REAL   SuperFrame_CurAcf[2][G729EV_G729_MP1];      
  REAL   SuperFrame_Ener[2];                         
  REAL energy_lt;
 int step_counter;
 int VAD_flag_change_counter;
 REAL VAD_flag_change_counter_move;
 int  gain_change_hangover;    
  INT16 transition_flag;
  INT16 subfr_num;
  int       g729_bst;
  REAL filt_temp[FILTERORDER];
  REAL counter_n_lt;
} G729EV_G729_CODSTAT;

#endif  /*__G729EV_G729_CODSTAT_H__ */
