/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"


/*-------------------------------------------------------------------*
 * Function  G729EV_G729_Convolve:                                   *
 *           ~~~~~~~~~~~~~~~~~~~~~                                   *
 *-------------------------------------------------------------------*
 * Perform the convolution between two vectors x[] and h[] and       *
 * write the result in the vector y[].                               *
 * All vectors are of length L.                                      *
 *-------------------------------------------------------------------*/

void G729EV_G729_Convolve(REAL x[], /*(i) : input vector                            */
                          REAL h[], /*(i) : impulse response                        */
                          REAL y[], /*(o) : output vector                           */
                          int L     /*(i) : vector size                             */
    )
{
  REAL      temp;
  int       i, n;

  for (n = 0; n < L; n++)
  {
    temp = (REAL) 0.0;
    for (i = 0; i <= n; i++)
      temp += x[i] * h[n - i];
    y[n] = temp;
  }

  return;
}

/*-----------------------------------------------------*
 * procedure G729EV_G729_Syn_filt:                     *
 *           ~~~~~~~~~~~~~~~~~~~~                      *
 * Do the synthesis filtering 1/A(z).                  *
 *-----------------------------------------------------*/

void G729EV_G729_Syn_filt(REAL a[],   /* (i)     : a[m] prediction coefficients   (m=10)    */
                          REAL x[],   /* (i)     : input signal                             */
                          REAL y[],   /* (i)     : output signal                            */
                          int lg,     /* (i)     : size of filtering                        */
                          REAL mem[], /* (i/o)   : memory associated with this filtering.   */
                          int update  /* (i)     : 0=no update, 1=update of memory.         */
    )
{
  int       i, j;

  /* This is usually done by memory allocation (l+m) */
  REAL      tmp[80];
  REAL      s, *yy, *py, *pa;

  /* Copy mem[] to yy[] */
  yy = tmp;
  for (i = 0; i < G729EV_G729_M; i++)
    *yy++ = *mem++;

  /* Filtering */
  for (i = 0; i < lg; i++)
  {
    py = yy;
    pa = a;
    s = *x++;
    for (j = 0; j < G729EV_G729_M; j++)
      s -= (*++pa) * (*--py);
    *yy++ = s;
    *y++ = s;
  }

  /* Update of memory if update==1 */
  if (update != 0)
  {
    for (i = 0; i < G729EV_G729_M; i++)
      *--mem = *--yy;
  }

  return;
}

/*-----------------------------------------------------------------------*
 * procedure G729EV_G729_Residu:                                         *
 *           ~~~~~~~~~~~~~~~~~~~                                         *
 * Compute the LPC residual  by filtering the input speech through A(z)  *
 *-----------------------------------------------------------------------*/

void      G729EV_G729_Residu(REAL * a,  /* (i)     : prediction coefficients                     */
                             REAL * x,  /* (i)     : speech (values x[-m..-1] are needed         */
                             REAL * y,  /* (o)     : residual signal                             */
                             int lg     /* (i)     : size of filtering                           */
    )
{
  REAL      s;
  int       i, j;

  for (i = 0; i < lg; i++)
  {
    s = x[i];
    for (j = 1; j <= G729EV_G729_M; j++)
      s += a[j] * x[i - j];
    *y++ = s;
  }
  return;
}
