/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __G729EV_G729_STAGE2_ENHA_GAINS_H__
#define __G729EV_G729_STAGE2_ENHA_GAINS_H__

#include <stdio.h>
#include "CodecTypedef.h"
#include "G729EV_MAIN_defines.h"



extern const REAL G729EV_MAIN_tab_gain_enha[8];

int       G729EV_CELP2S_qua_gain_Stage2(REAL gain_code, REAL xn[], REAL y1[], int l_subfr, INT16 i_subfr);
REAL      G729EV_CELP2S_dec_gain_Stage2(REAL gain_code, int index, INT16 i_subfr);



#endif  /*__G729EV_G729_STAGE2_ENHA_GAINS_H__ */
