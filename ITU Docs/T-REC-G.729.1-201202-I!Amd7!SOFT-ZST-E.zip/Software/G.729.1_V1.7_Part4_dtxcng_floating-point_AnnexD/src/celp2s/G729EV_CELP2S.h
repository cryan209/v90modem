/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_CELP2S_H__
#define __G729EV_CELP2S_H__

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"

typedef struct
{
  REAL      Az[G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1];

  int       t0[G729EV_MAIN_NB_SUBFR];
  int       t0_frac[G729EV_MAIN_NB_SUBFR];

  REAL      power_fix[G729EV_MAIN_NB_SUBFR];
  REAL      power_ltp[G729EV_MAIN_NB_SUBFR];

} G729EV_CELP2S_PARAM;

#endif
