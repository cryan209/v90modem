/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_CELP2S_ACELP_CA_H__
#define __G729EV_CELP2S_ACELP_CA_H__

#include "CodecTypedef.h"
#include "G729EV_G729_ld8k.h"

int       G729EV_CELP2S_ACELP_code_A_OTH(REAL x[], REAL res2[], REAL h[], int T0,
                                         REAL pitch_sharp, REAL code[], REAL y[], int *sign, REAL y1[]);
int       G729EV_CELP2S_ACELP_code_2NDLAYER(REAL x[], REAL res2[], REAL h[],
                                            REAL voiced_fac, REAL code[], REAL y[], int *sign);

void      G729EV_CELP2S_Put4Patterns(int ip[], int sign_pat[], REAL sp, REAL cod[]);

#endif  /*__G729EV_G729_ACELP_CA_H__ */
