/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*----------------------------------------------------------------------------------*
*  Supplementary information for FER concealment                       
*----------------------------------------------------------------------------------*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_FEC_tools.h"
#include "G729EV_G729_ld8k.h"

/*----------------------------------------------------------------------------------*
 * G729EV_FEC_energy()                                                              *
 * ~~~~~~~~~~~                                                                      *
 * Estimation of pitch-synchronous (VOICED sounds) or half-frame energy             *
 *----------------------------------------------------------------------------------*/
void G729EV_FEC_energy(const INT16 clas,    /* i:   frame classification                     */
                       const REAL * synth,  /* i:   synthesized speech                       */
                       const REAL pitch,    /* i:   pitch period                             */
                       REAL * enr_q,        /* o:   pitch-synchronous or half_frame energy   */
                       const INT16 offset   /* i:   speech pointer offset (0 or L_FRAME)     */
    )
{
  INT16     len, tmpS;
  int       pos;
  const REAL *pt_synth;

  if (clas >= G729EV_FEC_VOICED)  /* G729EV_FEC_VOICED current frame */
  {
    len = (INT16) (pitch + (REAL) 0.5); /* pitch value */

    if (len < G729EV_G729_L_SUBFR)
    {
      len *= 2;                 /* Take 2 pitch periods if pitch is too short */
    }

    if (offset == 0)
    {
      pt_synth = synth;
    }
    else
    {
      pt_synth = synth + G729EV_FEC_L_FRAME_FER - len;
    }
    tmpS = G729EV_Emaximum2(pt_synth, len, enr_q);  /* pitch synchronous E */
  }
  else
  {
    pos = 0;
    if (offset)
    {
      pos = G729EV_FEC_L_FRAME2_FER;
    }
    pt_synth = synth + pos;
    /* enr2 = 1.0f/L_FRAME2 * dot_product( synth, synth, L_FRAME2 ); */
    *enr_q = G729EV_Dot_product(pt_synth, pt_synth, G729EV_FEC_L_FRAME2_FER);
    *enr_q /= G729EV_FEC_L_FRAME2_FER;
  }

  return;
}

REAL G729EV_FEC_Lsf_stab(                     /* o:   LP filter stability */
                          const REAL * Lsf,   /* i:   LSF vector          */
                          const REAL * Lsfold /* i:   old LSF vector      */
    )
{
  int       i;
  REAL      stab_fac, tmp, tmp1;

  tmp = (REAL) 0.0;
  for (i = 0; i < G729EV_G729_M; i++)
  {
    tmp1 = Lsf[i] - Lsfold[i];
    tmp += tmp1 * tmp1;
  }
  stab_fac = (REAL) ((REAL) 1.25 - (tmp / (REAL) 0.14));
  if (stab_fac > (REAL) 1.0)
  {
    stab_fac = (REAL) 1.0;
  }

  if (stab_fac < (REAL) 0.0)
  {
    stab_fac = (REAL) 0.0;
  }

  return stab_fac;
}

/*----------------------------------------------------------------------------------*
 *  procedure G729EV_FEC_findpulse:                                       
 *            ~~~~~~~~~~                              
 *  Find first pitch pulse of the frame           
 *-----------------------------------------------------------------------------------*/
INT16     G729EV_FEC_findpulse(                   /* o:   pulse position        */
                                const REAL res[], /* i:   residual signal       */
                                INT16 T0,         /* i:   integer pitch         */
                                const INT16 enc   /* i:  enc = 1 -> encoder side; enc = 0 -> decoder side */
    )
{
  const REAL *ptr;
  REAL      val, maxval, tmp;
  int       i, maxi;
  REAL      resf[G729EV_FEC_L_FRAME_FER]; /* Low pass filtered residual */
  INT16     sign, sign_in;

  sign = sign_in = 0;;          /* positive case */

 /*-----------------------------------------------------------------*
  * 1. Very simple LP filter
  *-----------------------------------------------------------------*/
  if (enc == 1)
  {
    resf[0] = (REAL) 0.50 *res[0] + (REAL) 0.25 *res[1];

    for (i = 1; i < G729EV_FEC_L_FRAME_FER - 1; i++)
    {
      resf[i] = (REAL) 0.25 *res[i - 1] + (REAL) 0.5 *res[i] + (REAL) 0.25 *res[i + 1];
    }
    resf[G729EV_FEC_L_FRAME_FER - 1] =
        (REAL) 0.25 *res[G729EV_FEC_L_FRAME_FER - 2] + (REAL) 0.50 *res[G729EV_FEC_L_FRAME_FER - 1];

  /*-----------------------------------------------------------------*
   * 2. Find "biggest" pitch pulse 
   *-----------------------------------------------------------------*/
    /* Find the biggest last pulse from the end of the vector */
    ptr = resf + G729EV_FEC_L_FRAME_FER - 1;
    val = *ptr--;
    maxval = (REAL) fabs(val);
    maxi = 0;
    if (val < (REAL) 0)
      sign = 1;
    else
      sign = 0;
    for (i = 1; i < T0; i++)
    {
      val = *ptr--;
      tmp = (REAL) fabs(val);
      if (tmp > maxval)
      {
        maxval = tmp;
        maxi = i;
        if (val < (REAL) 0)
          sign = 1;
        else
          sign = 0;

      }
    }
    if (sign)
      maxi += 256;
  }
  else
  {
    if (T0 < 0)
    {
      T0 = -T0;
      sign_in = 1;
    }

    /*if the decoded maximum pulse position is positive */
    ptr = res;

    if (sign_in == 0)
    {
      maxval = (REAL) 0.;
      maxi = 0;
      for (i = 1; i <= T0; i++)
      {
        val = *ptr++;
        if (val > maxval)
        {
          maxval = val;
          maxi = i;
        }
      }
    }
    else
    {                           /*if the decoded maximum pulse position is negative */
      maxval = (REAL) 0.;
      maxi = 0;
      for (i = 1; i <= T0; i++)
      {
        val = *ptr++;

        if (val < maxval)
        {
          maxval = val;
          maxi = i;
        }
      }
    }
  }
  return (maxi);
}

/*-----------------------------------------------------------------*
 *   Pitch prediction for frame erasure                            *
 *-----------------------------------------------------------------*/
void G729EV_FEC_pitch_pred(INT16 bfi,       /* i: Bad frame ?                     */
                           int *T,          /* i/o: Pitch                         */
                           int *T_fr,       /* i/o: fractionnal pitch             */
                           REAL * pit_mem,  /* i/o: Pitch memories                */
                           INT16 * bfi_mem  /* i/o: Memory of bad frame indicator */
    )
{
  REAL      pit, a, b, sum0, sum1;
  INT16     i;

 /*------------------------------------------------------------*/

  if (bfi != 0)
  {
    /* Correct pitch */
    if (*bfi_mem == 0)
      for (i = 3; i >= 0; i--)
        if (fabs(pit_mem[i] - pit_mem[i + 1]) > 4)
          pit_mem[i] = pit_mem[i + 1];

    /* Linear prediction (estimation) of pitch */
    sum0 = 0;
    sum1 = 0;
    for (i = 0; i < 5; i++)
    {
      sum0 += pit_mem[i];
      sum1 += i * pit_mem[i];
    }
    a = ((REAL) 3. * sum0 - sum1) / (REAL) 5.;
    b = (sum1 - (REAL) 2. * sum0) / (REAL) 10.;
    pit = a + b * (REAL) 5.;
    if (pit > G729EV_G729_PIT_MAX)
      pit = G729EV_G729_PIT_MAX;
    if (pit < G729EV_G729_PIT_MIN)
      pit = G729EV_G729_PIT_MIN;
    *T = (int) (pit + (REAL) 0.5);  /*rounding */
    if (pit >= *T)
      *T_fr = (int) ((pit - *T) * (REAL) 3. + (REAL) 0.5);
    else
      *T_fr = (int) ((pit - *T) * (REAL) 3. - (REAL) 0.5);
  }
  else
    pit = *T + *T_fr / (REAL) 3.0;

  /* Update memory */
  for (i = 0; i < 4; i++)
    pit_mem[i] = pit_mem[i + 1];
  pit_mem[4] = pit;
  *bfi_mem = bfi;

 /*------------------------------------------------------------*/
  return;
}
