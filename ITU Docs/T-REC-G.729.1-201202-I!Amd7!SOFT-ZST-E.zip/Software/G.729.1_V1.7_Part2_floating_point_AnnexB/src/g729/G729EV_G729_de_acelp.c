/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"



/*-----------------------------------------------------------*
 *  Function  G729EV_G729_Decod_ACELP()                      *
 *  ~~~~~~~~~~~~~~~~~~~~~~~                                  *
 *   Algebraic codebook decoder.                             *
 *-----------------------------------------------------------*/

void G729EV_G729_Decod_ACELP(int sign,  /*(i) : signs of 4 pulses                     */
                             int index, /*(i) : positions of 4 pulses                 */
                             REAL cod[] /*(o) : algebraic (fixed) codebook excitation */
    )
{
  int       pos[4];
  int       i, j;

  /* decode the positions of 4 pulses */
  i = index & 7;
  pos[0] = i * 5;

  index >>= 3;
  i = index & 7;
  pos[1] = i * 5 + 1;

  index >>= 3;
  i = index & 7;
  pos[2] = i * 5 + 2;

  index >>= 3;
  j = index & 1;
  index >>= 1;
  i = index & 7;
  pos[3] = i * 5 + 3 + j;

  /* find the algebraic codeword */

  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    cod[i] = 0;

  /* decode the signs of 4 pulses */

  for (j = 0; j < 4; j++)
  {

    i = sign & 1;
    sign >>= 1;

    if (i != 0)
    {
      cod[pos[j]] = (REAL) 1.0;
    }
    else
    {
      cod[pos[j]] = (REAL) - 1.0;
    }
  }

  return;
}
