/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>
#include <math.h>
#include <assert.h>


#include "G729EV_G729_ld8k.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_set_gamma()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Set adaptive gamma parameters of lower-band postfilter                  *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_set_gamma(REAL * output_lo,  /* (i)    lower-band synthesis prior to postfiltering */
                           REAL * tab_Th,     /* (i/o)  median filter memory */
                           int rate,          /* (i)    decoder bit rate */
                           REAL * ga1_post,   /* (o)    gamma parameter */
                           REAL * ga2_post    /* (o)    gamma parameter */
    )
{
  REAL      ener;

  int       i, j;
  REAL      Th;

  /* set gammas */
  if (rate >= 14000)            /* >= 14 kbit/s */
  {
    *ga1_post = G729EV_G729_GAMMA1_PST12K;
    *ga2_post = G729EV_G729_GAMMA2_PST12K;
  }
  else
  {
    if (rate == 12000)          /* == 12 kbit/s */
    {
      /* compute frame energy */
      ener = (REAL) 0.0;
      for (i = 0; i < (G729EV_MAIN_L_FRAME2); i++)
        ener += output_lo[i] * output_lo[i];

      /* compute Th */
      Th = ener * (REAL) (1 << 17);
      if (Th >= (REAL) G729EV_MAIN_MAX32)
        Th = (REAL) 1.0;
      else
        Th /= (REAL) G729EV_MAIN_MAX32;

      /* smooth Th */
      j = G729EV_MAIN_NMAX - 1;
      for (i = 0; i < j; i++)
      {
        tab_Th[i] = tab_Th[i + 1];
      }
      tab_Th[j] = Th;
      Th = G729EV_MAIN_gmed_n(tab_Th, G729EV_MAIN_NMAX);

      /* set gamma = Th * gamma_12k + (1-Th)*gamma_8k */
      *ga1_post = Th * G729EV_G729_GAMMA1_PST12K + ((REAL) 1.0 - Th) * G729EV_G729_GAMMA1_PST;
      *ga2_post = Th * G729EV_G729_GAMMA2_PST12K + ((REAL) 1.0 - Th) * G729EV_G729_GAMMA2_PST;
    }
    else                        /* == 8 kbit/s */
    {
      /* at 8 kbit/s use gammas from G729 */
      *ga1_post = G729EV_G729_GAMMA1_PST;
      *ga2_post = G729EV_G729_GAMMA2_PST;
    }
  }
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_gmed_n()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                            *
 *  Median filter for sequence of odd length                                *
 *--------------------------------------------------------------------------*/
REAL G729EV_MAIN_gmed_n(              /* o : median value                              */
                         REAL ind[],  /* i : Current and past values */
                         int n        /* i : number of values (valid for an odd number of gains <= NMAX) */
    )
{
  int       tmp[G729EV_MAIN_NMAX];
  REAL      tmp2[G729EV_MAIN_NMAX];

  int       i, j, ix;
  REAL      max;
  int       medianIndex;

  ix = 0;
  for (i = 0; i < n; i++)
  {
    tmp2[i] = ind[i];
  }

  for (i = 0; i < n; i++)
  {
    max = (REAL) - 1.0;
    for (j = 0; j < n; j++)
    {
      if (tmp2[j] >= max)
      {
        max = tmp2[j];
        ix = j;
      }
    }
    tmp2[ix] = (REAL) - 1.0;
    tmp[i] = ix;
  }

  medianIndex = tmp[n / 2];
  return (ind[medianIndex]);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_weighting_filter()                                *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                            *
 *  Weighting filter of lower-band difference signal including an adaptive  *
 *  gain compensation                                                       *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_weighting_filter(REAL * Az,        /* (i)   LPC coefficients from CELP local decoder  */
                                  REAL * mem_Wz_in, /* (i)   memory of input  */
                                  REAL * mem_wsp,   /* (i)   memory of output  */
                                  REAL * diff)      /* (i/o) difference signal before and after weighting */
{
  REAL      wsp[G729EV_MAIN_L_FRAME2];
  REAL      Ap1[G729EV_G729_MP1];
  REAL      Ap2[G729EV_G729_MP1];
  REAL      Wz_in_buffer[G729EV_MAIN_L_FRAME2 + G729EV_G729_M];

  REAL     *Wz_in;
  REAL     *ptr_Az;

  int       i_subfr, i, j;
  REAL      num, den, fac;

  /* set buffer for W(z) */
  Wz_in = Wz_in_buffer + G729EV_G729_M;
  G729EV_G729_Copy(mem_Wz_in, &Wz_in[-G729EV_G729_M], G729EV_G729_M);
  G729EV_G729_Copy(diff, Wz_in, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Copy(&diff[G729EV_MAIN_L_FRAME2 - G729EV_G729_M], mem_Wz_in, G729EV_G729_M);

  /* apply W(z)= fac*A(z/gamma1)/A(z/gamma2) */
  ptr_Az = Az;
  for (i = 0, i_subfr = 0; i < 4; i++, i_subfr += G729EV_G729_L_SUBFR)
  {
    /* weight A(z) */
    G729EV_G729_Weight_Az(ptr_Az, G729EV_MAIN_GAMMA1, G729EV_G729_M, Ap1);
    G729EV_G729_Weight_Az(ptr_Az, G729EV_MAIN_GAMMA2, G729EV_G729_M, Ap2);

    /* compute gain */
    den = Ap1[0];
    num = Ap2[0];
    fac = -1.0;
    for (j = 1; j <= G729EV_G729_M; j++)
    {
      den += Ap1[j] * fac;
      num += Ap2[j] * fac;
      fac = -fac;
    }
    fac = num / den;
    if (fac < 0)
      fac = -fac;

    /* filter by A(z/gamma) * 1/A(z/gamma2) */
    G729EV_G729_Residu(Ap1, &Wz_in[i_subfr], &wsp[i_subfr], G729EV_G729_L_SUBFR);
    G729EV_G729_Syn_filt(Ap2, &wsp[i_subfr], &wsp[i_subfr], G729EV_G729_L_SUBFR, mem_wsp, 0);
    for (j = 0; j < G729EV_G729_M; j++)
      mem_wsp[j] = wsp[i_subfr + G729EV_G729_L_SUBFR - G729EV_G729_M + j];

    /* scale */
    for (j = i_subfr; j < (i_subfr + G729EV_G729_L_SUBFR); j++)
      wsp[j] *= fac;

    ptr_Az += G729EV_G729_MP1;
  }
  G729EV_G729_Copy(wsp, diff, G729EV_MAIN_L_FRAME2);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_inverse_weighting_filter()                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                          *
 *  Inverse weighting filter of lower-band difference signal including      *
 * an adaptive gain compensation                                            *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_inverse_weighting_filter(REAL * Az,            /* (i)   LPC coefficients from CELP local decoder  */
                                          REAL * mem_invWz_in,  /* (i)   memory of input  */
                                          REAL * mem_invwsp,    /* (i)   memory of output  */
                                          REAL * diff_q)        /* (i/o) difference signal before and after weighting */
{
  REAL      invWz_in_buffer[G729EV_MAIN_L_FRAME2 + G729EV_G729_M];
  REAL      wsp[G729EV_MAIN_L_FRAME2];
  REAL      Ap1[G729EV_G729_MP1];
  REAL      Ap2[G729EV_G729_MP1];

  REAL     *invWz_in;
  REAL     *ptr_Az;

  int       i_subfr, i, j;
  REAL      num, den, fac;

  /* set buffer for W(z) */
  invWz_in = invWz_in_buffer + G729EV_G729_M;
  G729EV_G729_Copy(mem_invWz_in, &invWz_in[-G729EV_G729_M], G729EV_G729_M);
  G729EV_G729_Copy(diff_q, invWz_in, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Copy(&diff_q[G729EV_MAIN_L_FRAME2 - G729EV_G729_M], mem_invWz_in, G729EV_G729_M);

  /* apply W(z)= fac*A(z/gamma2)/A(z/gamma1) */
  ptr_Az = Az;
  for (i = 0, i_subfr = 0; i < 4; i++, i_subfr += G729EV_G729_L_SUBFR)
  {
    /* weight A(z) */
    G729EV_G729_Weight_Az(ptr_Az, G729EV_MAIN_GAMMA1, G729EV_G729_M, Ap1);
    G729EV_G729_Weight_Az(ptr_Az, G729EV_MAIN_GAMMA2, G729EV_G729_M, Ap2);

    /* compute gain */
    den = Ap2[0];
    num = Ap1[0];
    fac = -1.0;
    for (j = 1; j <= G729EV_G729_M; j++)
    {
      den += Ap2[j] * fac;
      num += Ap1[j] * fac;
      fac = -fac;
    }
    fac = num / den;
    if (fac < 0)
      fac = -fac;

    /* filter by A(z/gamma2) * 1/A(z/gamma1) */
    G729EV_G729_Residu(Ap2, &invWz_in[i_subfr], &wsp[i_subfr], G729EV_G729_L_SUBFR);
    G729EV_G729_Syn_filt(Ap1, &wsp[i_subfr], &wsp[i_subfr], G729EV_G729_L_SUBFR, mem_invwsp, 0);
    for (j = 0; j < G729EV_G729_M; j++)
      mem_invwsp[j] = wsp[i_subfr + G729EV_G729_L_SUBFR - G729EV_G729_M + j];

    /* scale */
    for (j = i_subfr; j < (i_subfr + G729EV_G729_L_SUBFR); j++)
      wsp[j] *= fac;

    ptr_Az += G729EV_G729_MP1;
  }
  G729EV_G729_Copy(wsp, diff_q, G729EV_MAIN_L_FRAME2);
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_initQMF_ana()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Reset the signal memory                                                 *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_initQMF_ana(G729EV_MAIN_QMFCODSTAT * qmf)
{
  int       i;

  for (i = 0; i < (2 * G729EV_MAIN_S_QMF - 1); i++)
    qmf->mem[i] = (REAL) 0.0;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_initQMF_syn()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Reset the sum and difference memory                                     *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_initQMF_syn(G729EV_MAIN_QMFDECSTAT * qmf)
{
  int       i;

  for (i = 0; i < (2 * G729EV_MAIN_S_QMF_FS - 1); i++)
  {
    qmf->mem_add[i] = (REAL) 0.0;
    qmf->mem_sub[i] = (REAL) 0.0;
  }
}                               /*end of QMF_initQMFfilter() */



/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_QMF_ana()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  Two-channel filter bank analysis                                        *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_QMF_ana(G729EV_MAIN_QMFCODSTAT * qmf, REAL * input, REAL * bf, REAL * hf, int size)
{
  int       i;
  REAL      signal_buffer[(2 * G729EV_MAIN_S_QMF - 1) + G729EV_MAIN_L_FRAME];
  REAL     *signal_ptr;
  REAL     *x1, *x2;
  const REAL *c;
  REAL      A, B;

  signal_ptr = signal_buffer;
  /* copy memory */
  for (i = 0; i < (2 * G729EV_MAIN_S_QMF - 1); i++)
  {
    *signal_ptr++ = qmf->mem[i];
  }

  /* copy input signal */
  for (i = 0; i < size; i++)
  {
    *signal_ptr++ = input[i];
  }

  /* update memory of signal */
  for (i = 0; i < (2 * G729EV_MAIN_S_QMF - 1); i++)
  {
    qmf->mem[i] = signal_buffer[i + size];
  }

  /* efficient QMF implementation with joint computation of (decimated)
     low-band and high-band signal */

  signal_ptr = &signal_buffer[G729EV_MAIN_S_QMF - 1];
  for (i = 0; i < size; i += 2)
  {
    x1 = signal_ptr++;
    x2 = signal_ptr++;

    A = (REAL) 0.0;
    B = (REAL) 0.0;
    for (c = &G729EV_MAIN_qmf_J64D[0]; c < &G729EV_MAIN_qmf_J64D[G729EV_MAIN_S_QMF]; c += 2)
    {
      B += c[0] * *x1--;
      A += c[0] * *x2++;
      A += c[1] * *x1--;
      B += c[1] * *x2++;
    }

    *bf++ = A + B;
    *hf++ = A - B;
  }
  return;
}

/***************************************************************************
FUNCTION:
QMF_twoChannelSynthesis()

DESCRIPTION:
 Two-channel filter bank Analysis
***************************************************************************/
void G729EV_MAIN_QMF_syn(G729EV_MAIN_QMFDECSTAT * qmf,  /* (i/o)       filter states */
                         REAL * inputBF,                /* (i)         lower-band */
                         REAL * inputHF,                /* (i)         higher-band */
                         REAL * output,                 /* (o)         output */
                         int size,                      /* (i)         number of samples */
                         REAL gain_switching)           /* (i)         higher-band attenuation factor for bit-rate switching */
{
  REAL      A, B;

  REAL      add_buffer[(2 * G729EV_MAIN_S_QMF_FS - 1) + G729EV_MAIN_L_FRAME];
  REAL      sub_buffer[(2 * G729EV_MAIN_S_QMF_FS - 1) + G729EV_MAIN_L_FRAME];

  REAL     *add_ptr;
  REAL     *sub_ptr;
  REAL     *x1a, *x1b, *x2a, *x2b;
  const REAL *c;

  int       i;

  /* Joint computation of base-band and high-band now avoids recalculation of the sums and
     differences for previous input signals. They are stored in the memories.
     Stack usage was also reduced by eliminating the two buffers. */

  add_ptr = add_buffer;
  sub_ptr = sub_buffer;

  /* copy the memories of the sums and differences */
  for (i = 0; i < 2 * G729EV_MAIN_S_QMF_FS - 1; i++)
  {
    *add_ptr++ = qmf->mem_add[i];
    *sub_ptr++ = qmf->mem_sub[i];
  }

  /* copy the input signals and calculate the sums and differences */
  for (i = 0; i < size; i++)
  {
    *add_ptr++ = inputBF[i] + gain_switching * inputHF[i];
    *sub_ptr++ = inputBF[i] - gain_switching * inputHF[i];;
  }

  /* add zeroes (no sum and difference to calculate) */
  for (i = size; i < G729EV_MAIN_L_FRAME; i++)
  {
    *add_ptr++ = 0.0;
    *sub_ptr++ = 0.0;
  }

  /* update memories of the sums and differences */
  for (i = 0; i < (2 * G729EV_MAIN_S_QMF_FS - 1); i++)
  {
    qmf->mem_add[i] = add_buffer[i + size];
    qmf->mem_sub[i] = sub_buffer[i + size];
  }

  add_ptr = &add_buffer[G729EV_MAIN_S_QMF_FS - 1];
  sub_ptr = &sub_buffer[G729EV_MAIN_S_QMF_FS - 1];

  for (i = 0; i < size; i++)
  {
    x1a = add_ptr++;
    x2a = x1a;
    x1b = sub_ptr++;
    x2b = x1b;

    A = (REAL) 0.0;
    B = (REAL) 0.0;
    for (c = &G729EV_MAIN_qmf_J64D[0]; c < &G729EV_MAIN_qmf_J64D[G729EV_MAIN_S_QMF]; c += 2)
    {
      A += c[0] * *x1a--;
      A += c[1] * *++x2a;
      B += c[0] * *++x2b;
      B += c[1] * *x1b--;
    }
    *output++ = (REAL) 2.0 *A;
    *output++ = (REAL) 2.0 *B;
  }

  return;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_QMF_mirror()                                      *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  Spectral folding, i.e. multiply by (-1)^n                               *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_QMF_mirror(REAL * s, /* (i/o)   signal */
                            int l     /* (i)     number of samples */
    )
{
  int       i;

  for (i = 0; i < l; i += 2)
  {
    s[i] *= (REAL) - 1.0;
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_init_iir2()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  memory initialization                                                   *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_init_iir2(G729EV_MAIN_IIR2STAT * stat  /* (io) : filter states */
    )
{
  /* memory initialization */
  stat->x0 = (REAL) 0.0;
  stat->x1 = (REAL) 0.0;
  stat->y1 = (REAL) 0.0;
  stat->y2 = (REAL) 0.0;
  return;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_iir2()                                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~                                              *
 *  50 Hz HP preprocessing                                                  *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_iir2(G729EV_MAIN_IIR2STAT * exStat,  /* (io)  filter states */
                      REAL signal[],                  /* (i/o) signal        */
                      int lg,                         /* (i)   length of signal */
                      const REAL * b,                 /* (i)   Filter coefficients */
                      const REAL * a                  /* (i)   Filter coefficients */
    )
{
  int       i;
  REAL      x0, x1, x2;
  REAL      y0, y1, y2;

  x0 = exStat->x0;
  x1 = exStat->x1;
  y2 = exStat->y2;
  y1 = exStat->y1;

  for (i = 0; i < lg; i++)
  {
    x2 = x1;
    x1 = x0;
    x0 = signal[i];

    y0 = y1 * a[1] + y2 * a[2] + x0 * b[0] + x1 * b[1] + x2 * b[2];

    signal[i] = y0;
    y2 = y1;
    y1 = y0;
  }
  exStat->x0 = x0;
  exStat->x1 = x1;
  exStat->y2 = y2;
  exStat->y1 = y1;

  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_init_lp3k()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  50 Hz HP preprocessing                                                  *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_init_lp3k(G729EV_MAIN_IIRN_STAT * stat /* (i/o)   filter states */
    )
{
  int       i;

  /* memory initialization */
  for (i = 0; i < G729EV_MAIN_LP_ORD; i++)
  {
    stat->x[i] = (REAL) 0.0;
    stat->y[i] = (REAL) 0.0;
  }
  return;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_lp3k()                                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  3kHz LP filtering                                                       *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_lp3k(G729EV_MAIN_IIRN_STAT * stat, /* (i/o)   filter states */
                      REAL signal[],                /* (i/o)   signal */
                      int lg                        /* (i)     number of samples */
    )
{
  REAL      acc;
  REAL      x[G729EV_MAIN_LP_ORD + 1];
  REAL      y[G729EV_MAIN_LP_ORD + 1];
  int       i, j;

  for (j = 0; j < G729EV_MAIN_LP_ORD; j++)
  {
    x[j] = stat->x[j];
    y[j + 1] = stat->y[j];
  }

  for (i = 0; i < lg; i++)
  {
    for (j = G729EV_MAIN_LP_ORD; j >= 1; j--)
      x[j] = x[j - 1];
    x[0] = signal[i];

    acc = (REAL) 0.0;
    for (j = 1; j <= G729EV_MAIN_LP_ORD; j++)
      acc += y[j] * G729EV_MAIN_lp3k_a[j];

    for (j = 0; j <= G729EV_MAIN_LP_ORD; j++)
      acc += x[j] * G729EV_MAIN_lp3k_b[j];

    y[0] = acc;
    signal[i] = y[0];

    for (j = G729EV_MAIN_LP_ORD; j >= 1; j--)
      y[j] = y[j - 1];
  }

  for (j = 0; j < G729EV_MAIN_LP_ORD; j++)
  {
    stat->x[j] = x[j];
    stat->y[j] = y[j + 1];
  }
}





/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_CONVOLVE_2Tap()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  convolution with 2-tap pattern                                          *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_CONVOLVE_2Tap(REAL Input[], REAL Output[], REAL Coef, int Length)
{
  REAL      x0, x1;
  int       i;

  x0 = 0;
  for (i = 0; i < Length - 1; i++)
  {
    x1 = Input[i];
    Output[i] = Coef * x0 + x1;
    x0 = x1;
  }
  Output[Length - 1] = Input[Length - 1] + Coef * x0;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_CONVOLVE_2Tap()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  convolution with 3-tap pattern                                          *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_CONVOLVE_3Tap(REAL Input[], REAL Output[], REAL Coef, int Length)
{
  REAL      x0, x1;
  int       i;

  x0 = 0;
  for (i = 0; i < Length - 1; i++)
  {
    x1 = Input[i];
    Output[i] = Coef * x0 + x1 + Coef * Input[i + 1];
    x0 = x1;
  }
  Output[Length - 1] = Input[Length - 1] + Coef * x0;
}
