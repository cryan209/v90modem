/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_time_envelope_shaping.h"
#include "G729EV_TDBWE_extract_time_envelope.h"

#include <math.h>



/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_time_envelope_shaping()                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                          *
 *  TDBWE time envelope shaping module,                                     *
 *  shape time envelope of input[] according to envelope[]                  *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_time_envelope_shaping(REAL * input,     /* (i)   excitation input signal */
                                        REAL * envelope,  /* (i)   desired time envelope   */
                                        REAL * output,    /* (o)   shaped output signal    */
                                        REAL * prev_gain) /* (i/o) memory                  */
{
  int       l, i, start;
  REAL      gain, smoothed_gain, ratio;
  REAL      actual_envelope[G729EV_TDBWE_NB_SUBFRAMES >> 1];


  /* get the subframe energies of the excitation signal */
  G729EV_TDBWE_extract_time_envelope(input, 0,  /* nls */
                                     actual_envelope, G729EV_TDBWE_NB_SUBFRAMES_2);

  /* compute and apply (smoothed) gain */
  for (l = 0; l < G729EV_TDBWE_NB_SUBFRAMES_2; l++)
  {
    start = l * G729EV_TDBWE_SUBFRAME_SIZE;
    gain = (REAL) pow(2.0, envelope[l] - actual_envelope[l]);

    /* iterate over 1st half of current subframe */
    for (i = 0; i < G729EV_TDBWE_SUBFRAME_SIZE_2; i++)
    {
      ratio = G729EV_TDBWE_TIME_ENVELOPE_SHAPING_WINDOW[i];
      smoothed_gain = ratio * gain + ((REAL) 1.0 - ratio) * *prev_gain;

      /* apply gain */
      output[start + i] = smoothed_gain * input[start + i];
    }

    /* iterate over 2nd half of current subframe, no smoothing here (flat-top window)! */
    for (i = G729EV_TDBWE_SUBFRAME_SIZE_2; i < G729EV_TDBWE_SUBFRAME_SIZE; i++)
    {
      /* apply gain */
      output[start + i] = gain * input[start + i];
    }
    /* memory update */
    *prev_gain = gain;
  }
}
