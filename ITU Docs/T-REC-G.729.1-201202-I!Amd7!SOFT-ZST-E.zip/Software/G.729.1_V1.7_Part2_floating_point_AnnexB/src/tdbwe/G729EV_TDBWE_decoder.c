/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_decoder.h"

#include <math.h>

#include "G729EV_TDBWE_compression.h"
#include "G729EV_TDBWE_time_envelope_shaping.h"
#include "G729EV_TDBWE_frequency_envelope_shaping.h"
#include "G729EV_G729_ld8k.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_dequantization()                                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                 *
 *  TDBWE parameter lookup and mean value reconstruction                    *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_dequantization(int *coder_parameters, REAL * parameters_tdbwe)
{
  int       i;
  REAL      mu_q;
  int       vq_index;
  REAL     *parameters;
  int      *param_ptr;
  const REAL *tab_ptr;

  param_ptr = coder_parameters;

  /* retrieve the time envelope's mean from the bitstream */
  mu_q = G729EV_TDBWE_MEAN_TIME_ENV_cb[*param_ptr++];

  /* retrieve from the bitstream and de-normalize the time envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  for (i = 0; i < G729EV_TDBWE_TIME_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {
    vq_index = *param_ptr++;

    G729EV_G729_Copy((REAL *) & G729EV_TDBWE_TIME_ENV_cb[vq_index * 8], &parameters[i * 8], 8);
  }

  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  for (i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++)
    parameters[i] += mu_q;

  /* retrieve the frequency envelope from the bitstream and de-normalize */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  for (i = 0; i < G729EV_TDBWE_FREQ_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {
    tab_ptr = G729EV_TDBWE_FREQ_ENV_cb[i];

    vq_index = *param_ptr++;

    G729EV_G729_Copy((REAL *) & tab_ptr[vq_index * 4], &parameters[i * 4], 4);
  }

  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  for (i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
    parameters[i] += mu_q;

}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_decoder_init()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Initialization of TDBWE decoder                                         *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_decoder_init(G729EV_TDBWE_DECSTAT * state)  /* (o) */
{
  state->prev_gain_time_envelope_shaping = (REAL) 0.0;

  G729EV_TDBWE_generate_excitation_initialize(&state->generate_excitation);
  G729EV_TDBWE_frequency_envelope_shaping_initialize(&state->frequency_envelope_shaping);

  G729EV_G729_Set_zero(state->old_excitation_1, G729EV_TDBWE_MEM_EXC);

  G729EV_G729_Set_zero(state->mem_freq_env, G729EV_TDBWE_NB_SUBBANDS);

  state->mem_time_env[0] = (REAL) 0.0;
  state->mem_time_env[1] = (REAL) 0.0;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_decoder()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 *  TDBWE decoder (highband synthesis),                                     *
 *  generates the exication signal, shape time & frequency envelope and     *
 *  invokes postprocessing                                                  *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_decoder(G729EV_TDBWE_DECSTAT * state,         /* (i/o) */
                          G729EV_CELP2S_PARAM * nb_celp_param,  /* (i)   information from narrowband G.729A+ codec (8k/12k layers) */
                          REAL * signal_highband,               /* (o)   synthesized output signal  */
                          REAL * parameters)                    /* (i)   the quantized TDBWE parameter set */
{

  int       i, j;
  G729EV_TDBWE_g729_info excparam[2];
  REAL      excitation[G729EV_TDBWE_L_FRAME2];
  REAL     *excitation_1;
  REAL      interp[G729EV_TDBWE_NB_SUBBANDS];
  REAL     *tenv, *out;
  REAL     *fenv;
  REAL      old_excitation_1[G729EV_TDBWE_L_TOTAL_EXC];

  /* rearrange information on G729 NB excitation */
  for (j = 0; j < 2; j++)
  {
    for (i = 0; i < 2; i++)
    {
      excparam[j].lag[i] = (REAL) nb_celp_param->t0[2 * j + i];
      excparam[j].frac_lag[i] = (REAL) nb_celp_param->t0_frac[2 * j + i];
      excparam[j].power_ltp[i] = nb_celp_param->power_ltp[2 * j + i];
      excparam[j].power_fix[i] = nb_celp_param->power_fix[2 * j + i];
    }
  }

  /* set pointers */
  excitation_1 = old_excitation_1 + G729EV_TDBWE_MEM_EXC;
  G729EV_G729_Copy(state->old_excitation_1, old_excitation_1, G729EV_TDBWE_MEM_EXC);

  fenv = &parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
  tenv = &parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE];

  /* Interpolate frequency envelope for the first 10ms frame */
  for (i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
    interp[i] = (state->mem_freq_env[i] + fenv[i]) / (REAL) 2.0;

  /* generate and shape synthetic excitation */
  out = signal_highband;
  for (i = 0; i < 2; i++)
  {
    G729EV_TDBWE_generate_excitation(&state->generate_excitation, &excparam[i], excitation);

    G729EV_TDBWE_time_envelope_shaping(excitation, tenv, excitation_1, &(state->prev_gain_time_envelope_shaping));
    if (i == 0)
    {
      G729EV_TDBWE_frequency_envelope_shaping(&state->frequency_envelope_shaping, excitation_1, out, interp);
    }
    else
    {
      G729EV_TDBWE_frequency_envelope_shaping(&state->frequency_envelope_shaping, excitation_1, out, fenv);
    }

    /* invoke post-processing */
    G729EV_TDBWE_compression(state->mem_time_env, out, tenv);

    out += G729EV_TDBWE_L_FRAME2;
    tenv += G729EV_TDBWE_NB_SUBFRAMES_2;
    excitation_1 += G729EV_TDBWE_L_FRAME2;
  }

  /* memory update */
  G729EV_G729_Copy(fenv, state->mem_freq_env, G729EV_TDBWE_NB_SUBBANDS);
  G729EV_G729_Copy(&old_excitation_1[G729EV_TDBWE_L_FRAME], state->old_excitation_1, G729EV_TDBWE_MEM_EXC);
}
