/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_extract_frequency_envelope.h"

#include "G729EV_TDBWE_fft.h"
#include "G729EV_G729_ld8k.h"

#include <math.h>


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_extract_frequency_envelope()                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                     *
 *  TDBWE frequency envelope (sub-band energy) computation                  *
 *                                                                          *
 *  (note, that for calls operating on the same state the nls of signal[]   *
 *   must always be the same!)                                              *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_extract_frequency_envelope(REAL * signal,   /* (i) framing memory                  */
                                             int nls,         /* (i)   normalization of input signal */
                                             REAL * envelope) /* (o)  frequency envelope parameters  */
{
  int       i, j;
  REAL      sum;
  REAL      fft_in[G729EV_TDBWE_FFT_SIZE];
  REAL      re_fft_out[G729EV_TDBWE_FFT_SIZE];
  REAL      im_fft_out[G729EV_TDBWE_FFT_SIZE];
  REAL      power_spectrum[G729EV_TDBWE_FFT_SIZE];

  /* apply windowing */
  for (i = 0; i < G729EV_TDBWE_FFT_SIZE; i++)
  {
    fft_in[i] = (signal[i] * G729EV_TDBWE_frequency_envelope_window[i]) +
        (signal[G729EV_TDBWE_FFT_SIZE + i] * G729EV_TDBWE_frequency_envelope_window[G729EV_TDBWE_FFT_SIZE + i]);
  }

  /* half-length DFT "trick": compute even short-term power spectrum bins */
  G729EV_TDBWE_fft(fft_in, re_fft_out, im_fft_out, G729EV_TDBWE_FFT_SIZE, &nls);

  /* compute necessary power spectrum bins only */
  for (i = 0; i < 25; i++)
  {
    power_spectrum[i] = (re_fft_out[i] * re_fft_out[i] + im_fft_out[i] * im_fft_out[i]) / (REAL) G729EV_TDBWE_FFT_SIZE;
  }

  /* accumulate sub-band powers */
  for (i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
  {
    sum = (REAL) 0.0;
    for (j = 0; j < G729EV_TDBWE_BINS_PER_SUBBAND; j++)
    {
      sum += power_spectrum[G729EV_TDBWE_center_bins[i] - G729EV_TDBWE_BINS_BTW_CENTER_BINS + j] *
          G729EV_TDBWE_subband_window[j];
    }

    envelope[i] = (REAL) 0.5 *(REAL) log(sum + 1.0e-8) * ONE_OVER_LOG2;
  }
}
