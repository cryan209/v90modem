/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_COMPRESSION_H__
#define __G729EV_TDBWE_COMPRESSION_H__

#include "G729EV_MAIN_defines.h"

/* prototype for exported function */

void      G729EV_TDBWE_compression(REAL * mem_time_env, REAL * signal, REAL * energy_log2);

#endif
