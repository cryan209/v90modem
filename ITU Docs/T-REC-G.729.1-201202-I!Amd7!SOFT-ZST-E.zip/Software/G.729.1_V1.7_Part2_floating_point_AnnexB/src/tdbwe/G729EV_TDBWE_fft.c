/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_fft.h"
#include "G729EV_G729_ld8k.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_c_fft()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 * FFT function for complex sequences                                       *
 *                                                                          *
 * The decimation-in-time complex FFT is implemented below.                 *
 * The input complex numbers are presented as the real part followed by     *
 * the imaginary part for each sample.  The counters are therefore          *
 * incremented by two to access the complex valued samples.                 *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_c_fft(REAL * fz,  /* (i/o) complex input signal / complex output FFT bins */
                        int *nls)   /* (i)   normalization shift amount                     */
{
  int       i, k, k1, k2, k3, k4, kx;
  REAL     *fi, *fn, *gi;

  G729EV_TDBWE_fft_TRIG_VARS;

  for (k1 = 1, k2 = 0; k1 < G729EV_TDBWE_FFT_SIZE; k1++)
  {
    REAL      a;

    for (k = G729EV_TDBWE_FFT_SIZE >> 1; (!((k2 ^= k) & k)); k >>= 1) ;
    if (k1 > k2)
    {
      a = fz[k1];
      fz[k1] = fz[k2];
      fz[k2] = a;
    }
  }
  for (k = 0; (1 << k) < G729EV_TDBWE_FFT_SIZE; k++) ;
  k &= 1;
  if (k == 0)
  {
    for (fi = fz, fn = fz + G729EV_TDBWE_FFT_SIZE; fi < fn; fi += 4)
    {
      REAL      f0, f1, f2, f3;

      f1 = fi[0] - fi[1];
      f0 = fi[0] + fi[1];
      f3 = fi[2] - fi[3];
      f2 = fi[2] + fi[3];
      fi[2] = (f0 - f2);
      fi[0] = (f0 + f2);
      fi[3] = (f1 - f3);
      fi[1] = (f1 + f3);
    }
  }
  else
  {
    for (fi = fz, fn = fz + G729EV_TDBWE_FFT_SIZE, gi = fi + 1; fi < fn; fi += 8, gi += 8)
    {
      REAL      s1, c1, s2, c2, s3, c3, s4, c4, g0, f0, f1, g1, f2, g2, f3, g3;

      c1 = fi[0] - gi[0];
      s1 = fi[0] + gi[0];
      c2 = fi[2] - gi[2];
      s2 = fi[2] + gi[2];
      c3 = fi[4] - gi[4];
      s3 = fi[4] + gi[4];
      c4 = fi[6] - gi[6];
      s4 = fi[6] + gi[6];
      f1 = (s1 - s2);
      f0 = (s1 + s2);
      g1 = (c1 - c2);
      g0 = (c1 + c2);
      f3 = (s3 - s4);
      f2 = (s3 + s4);
      g3 = G729EV_TDBWE_fft_SQRT2 * c4;
      g2 = G729EV_TDBWE_fft_SQRT2 * c3;
      fi[4] = f0 - f2;
      fi[0] = f0 + f2;
      fi[6] = f1 - f3;
      fi[2] = f1 + f3;
      gi[4] = g0 - g2;
      gi[0] = g0 + g2;
      gi[6] = g1 - g3;
      gi[2] = g1 + g3;
    }
  }
  if (G729EV_TDBWE_FFT_SIZE < 16)
    return;

  do
  {
    REAL      s1, c1;

    k += 2;
    k1 = 1 << k;
    k2 = k1 << 1;
    k4 = k2 << 1;
    k3 = k2 + k1;
    kx = k1 >> 1;
    fi = fz;
    gi = fi + kx;
    fn = fz + G729EV_TDBWE_FFT_SIZE;
    do
    {
      REAL      g0, f0, f1, g1, f2, g2, f3, g3;

      f1 = fi[0] - fi[k1];
      f0 = fi[0] + fi[k1];
      f3 = fi[k2] - fi[k3];
      f2 = fi[k2] + fi[k3];
      fi[k2] = f0 - f2;
      fi[0] = f0 + f2;
      fi[k3] = f1 - f3;
      fi[k1] = f1 + f3;
      g1 = gi[0] - gi[k1];
      g0 = gi[0] + gi[k1];
      g3 = G729EV_TDBWE_fft_SQRT2 * gi[k3];
      g2 = G729EV_TDBWE_fft_SQRT2 * gi[k2];
      gi[k2] = g0 - g2;
      gi[0] = g0 + g2;
      gi[k3] = g1 - g3;
      gi[k1] = g1 + g3;
      gi += k4;
      fi += k4;
    }
    while (fi < fn);
    G729EV_TDBWE_fft_TRIG_INIT(k, c1, s1);
    for (i = 1; i < kx; i++)
    {
      REAL      c2, s2;

      G729EV_TDBWE_fft_TRIG_NEXT(k, c1, s1);
      c2 = c1 * c1 - s1 * s1;
      s2 = 2 * (c1 * s1);
      fn = fz + G729EV_TDBWE_FFT_SIZE;
      fi = fz + i;
      gi = fz + k1 - i;
      do
      {
        REAL      a, b, g0, f0, f1, g1, f2, g2, f3, g3;

        b = s2 * fi[k1] - c2 * gi[k1];
        a = c2 * fi[k1] + s2 * gi[k1];
        f1 = fi[0] - a;
        f0 = fi[0] + a;
        g1 = gi[0] - b;
        g0 = gi[0] + b;
        b = s2 * fi[k3] - c2 * gi[k3];
        a = c2 * fi[k3] + s2 * gi[k3];
        f3 = fi[k2] - a;
        f2 = fi[k2] + a;
        g3 = gi[k2] - b;
        g2 = gi[k2] + b;
        b = s1 * f2 - c1 * g3;
        a = c1 * f2 + s1 * g3;
        fi[k2] = f0 - a;
        fi[0] = f0 + a;
        gi[k3] = g1 - b;
        gi[k1] = g1 + b;
        b = c1 * g2 - s1 * f3;
        a = s1 * g2 + c1 * f3;
        gi[k2] = g0 - a;
        gi[0] = g0 + a;
        fi[k3] = f1 - b;
        fi[k1] = f1 + b;
        gi += k4;
        fi += k4;
      }
      while (fi < fn);
    }
    G729EV_TDBWE_fft_TRIG_RESET(k, c1, s1);
  }
  while (k4 < G729EV_TDBWE_FFT_SIZE);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_r_fft()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 * FFT function for real sequences                                          *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_r_fft(REAL * real,  /* (i/o) input signal / output FFT bins */
                        int *nls)     /* (i)   normalization shift amount     */
{
  REAL      a, b;
  int       i, j, k;

  /* Perform the complex FFT */
  G729EV_TDBWE_c_fft(real, nls);

  for (i = 1, j = G729EV_TDBWE_FFT_SIZE - 1, k = G729EV_TDBWE_FFT_SIZE / 2; i < k; i++, j--)
  {
    a = real[i];
    b = real[j];
    real[j] = (a - b) * (REAL) 0.5;
    real[i] = (a + b) * (REAL) 0.5;
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_fft()                                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                            *
 *  TDBWE FFT implementation                                                *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_fft(REAL * x,         /* (i)   input sequency                     */
                      REAL * reX,       /* (o)   real part of the FFT spectrum      */
                      REAL * imX,       /* (o)   imaginary part of the FFT spectrum */
                      int vector_size,  /* (i)   number of elements in x[]          */
                      int *nls)         /* (i/o) normalization shift amount         */
{
  int       h, i;
  REAL      buffer[G729EV_TDBWE_FFT_SIZE];

  G729EV_G729_Copy(x, buffer, vector_size);

  G729EV_TDBWE_r_fft(buffer, nls);

  /* compute only the used bins of the spectrum */
  h = vector_size / 2;

  imX[0] = 0.0;
  imX[h] = 0.0;
  for (i = 1; i < h; i++)
  {
    imX[h - i] = -buffer[h + i];
    imX[h + i] = buffer[h + i];
  }

  for (i = 0; i < h; i++)
  {
    reX[i] = buffer[i];
    reX[h + i] = buffer[h - i];
  }
}
