/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __G729EV_TDAC_MDCT_H__
#define __G729EV_TDAC_MDCT_H__

#include <stdio.h>
#include "CodecTypedef.h"

/* Functions : */
void      G729EV_TDAC_mdct(REAL * mem, REAL * xin, REAL * ykr);
void      G729EV_TDAC_inv_mdct(REAL * xr, REAL * ykq, REAL * ycim1);
int       G729EV_TDAC_mdct_norm(REAL * mem, REAL * input);

/* Tables : */

extern const REAL G729EV_TDAC_h[G729EV_TDAC_L_WIN];
extern const REAL G729EV_TDAC_wcos[G729EV_TDAC_L_WIN4];
extern const REAL G729EV_TDAC_wsin[G729EV_TDAC_L_WIN4];
extern const REAL G729EV_TDAC_weti[G729EV_TDAC_L_WIN4];
extern const REAL G729EV_TDAC_wetr[G729EV_TDAC_L_WIN4];
extern const REAL G729EV_TDAC_wetrm1[G729EV_TDAC_L_WIN4];
extern const REAL G729EV_TDAC_wetim1[G729EV_TDAC_L_WIN4];
extern const REAL G729EV_TDAC_win[G729EV_TDAC_L_WIN2];

#endif  /*__G729EV_TDAC_MDCT_H__ */
