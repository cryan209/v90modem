/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>
#include <stdio.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_FEC_tools.h"
#include "G729EV_G729_ld8k.h"
#include "stl.h"
#include "G729EV_MAIN_oper_32b.h"
#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_G729EVDTX_sp2no_trans.h"

static void G729EV_FEC_synchro_exc(Word16 * exc, Word16 true_puls_pos, Word16 desire_puls_pos, Word16 Old_pitch);
static Word16 G729EV_FEC_enr_1_Az(  /* o:   impulse response energy */
                                   Word16 Aq[], /* i:   LP filter coefs         */
                                   Word16 len   /* i:   impulse response length */
    );
static void G729EV_FEC_syn_bfi(Word16 last_good, Word16 bfi_cnt, const Word16 stab_fac, Word16 * lp_gainp,
                               Word16 * lp_gainc, Word16 * exc_mem, Word16 * exc2, const Word16 T3,
                               const Word16 tilt_code, const Word16 Ts, Word16 * pitch_buf, const Word16 Tcnt,
                               Word16 * Aq, Word16 * synth, Word16 * mem_syn2, Word32 * Lenr_old, Word16 * seed,
                               Word16 * exc, Word16 puls_pos, Word16 new_pit);

/******************************************************************************/
/* G729EV_FEC_dec_bf : Frame erasure concealment                              */
/* Find LPC coefficient, pitch and reconstruct lost synthesis                 */
/******************************************************************************/
void G729EV_FEC_dec_bf(Word16 parm[],        /* (i)   : vector of synthesis parameters       */
                       Word16 synth[],       /* (i/o) : synthesis speech                     */
                       Word16 Az_dec[],      /* (o)   : decoded LP filter in 2 subframes     */
                       Word16 bfi,           /* (i)   : Bad Frame Indicator                  */
                       Word16 * last_good,   /* (i)   : last good frame classification       */
                       Word16 * pitch_buf,   /* (i/o) : Pitch memory                         */
                       Word16 old_enr,       /* (i)   : Energy at the end of the last frame  */
                       Word16 * old_exc,     /* (i/o) : excitiation memory                   */
                       G729EV_G729_DECSTAT * st,  /* (i)   : Decoder structure                    */
                       Word16 new_clas,      /* (i)   : present frame classification         */
                       Word16 puls_pos       /* (i)   : Position of the last pulse           */
    )
{

  Word16    A[G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1];
  Word16    lsp_new[G729EV_G729_M];
  Word16   *exc, T3;
  Word16    exc2[G729EV_MAIN_L_FRAME2 + G729EV_FEC_L_FIR_FER - 1];
  Word16    exc_buf[G729EV_MAIN_L_FRAME2 + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL + G729EV_G729_L_SUBFR];
  Word16    T0, T0_frac;
  Word16    t0, t0_frac;
  Word16    index;

  T0 = (Word16) 0;
  T0_frac = (Word16) 0;
#if(WMOPS)
  move16();
  move16();
#endif
  exc = exc_buf + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL;

  G729EV_G729_Copy(old_exc, exc_buf, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);

  /* Decode the LSPs */
  G729EV_G729_D_lsp(st->freq_prev, st->prev_lsp, &(st->prev_ma), parm, lsp_new, bfi);
  parm += 2;


  IF(sub(bfi, G729EV_FEC_SINGLE_FRAME) == 0)
  {
    index = *parm++;            /* pitch index */
#if(WMOPS)
    move16();
    move16();
#endif
    /* decode future pitch */
    G729EV_G729_Dec_lag3(index, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX, 0, &t0, &t0_frac);

    G729EV_G729_Int_qlpc_bfi(st->lsp_old, lsp_new, A, interpol_frac1);
    G729EV_G729_Copy(A, Az_dec, G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1);

    /* update the LSFs for the next frame */
    G729EV_G729_Copy(lsp_new, st->lsp_old, G729EV_G729_M);
    G729EV_FEC_pitch_pred(1, &T0, &T0_frac, st->pit_mem, &(st->bfi_mem));
    T3 = st->pit_mem[3];
    /*t0 = true future pitch */
  }
  ELSE
  {
    /* Interpolation of LPC for the 4 subframes */
    G729EV_G729_Int_qlpc_bfi(st->lsp_old, lsp_new, A, interpol_frac1);
    G729EV_G729_Copy(A, Az_dec, G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1);

    /* update the LSFs for the next frame */
    G729EV_G729_Copy(lsp_new, st->lsp_old, G729EV_G729_M);
    G729EV_FEC_pitch_pred(1, &T0, &T0_frac, st->pit_mem, &(st->bfi_mem));
    T3 = st->pit_mem[3];
    t0 = T0;                    /* t0 = predicted pitch */
#if(WMOPS)
    move16();
    move16();
#endif
  }


   /*-------------------------------------------------*
    * Find the excitation and synthesize speech
    *-------------------------------------------------*/
  G729EV_FEC_syn_bfi(*last_good, st->bfi_cnt, st->stab_fac, &st->lp_gainp, &st->lp_gainc, st->old_exc, exc2,
                     T3, st->tilt_code, st->old_fpitch, pitch_buf, st->upd_cnt,
                     A, synth, st->mem_syn, &(st->Lenr_old), &(st->seed_fer), exc, puls_pos, t0);



   /*------------------------------------------------*
    Others updates
    --------------------------------------------------*/

  G729EV_G729_Copy(&exc[G729EV_MAIN_L_FRAME2 - G729EV_G729_PIT_MAX - G729EV_G729_L_INTERPOL], st->old_exc,
                   G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  st->upd_cnt = add(st->upd_cnt, 1);  /* counter of the age of the last update */
  if (sub(st->upd_cnt, G729EV_FEC_MAX_UPD_CNT) > 0)
  {
    st->upd_cnt = G729EV_FEC_MAX_UPD_CNT;
#if(WMOPS)
    move16();
#endif
  }
   /*----------------------------------------------------------------------*
    * Update for next frame.                           
    *----------------------------------------------------------------------*/
}

/******************************************************************************/
/* G729EV_FEC_syn_bfi : Reconstruction of erased frame                        */
/* - Find pitch                                                               */
/* - Estimate damping factor                                                  */
/* - Construct and synchronize periodic part of excitation                    */
/* - Construct random part of excitation                                      */
/* - Apply gain to excitation                                                 */
/* - Do synthesis filtering to recover lost synthesis                         */
/******************************************************************************/
static void G729EV_FEC_syn_bfi(Word16 last_good,       /* i:   last good frame clas                    */
                               Word16 bfi_cnt,         /* i:   counter of consecutive bfi frames       */
                               const Word16 stab_fac,  /* i:   ISF stability measure                   */
                               Word16 * lp_gainp,      /* i/o: damped pitch gain                       */
                               Word16 * lp_gainc,      /* i/o: damped code gain                        */
                               Word16 * exc_mem,       /* o:   excitation memory (st->old_exc)         */
                               Word16 * exc2,          /* o:   excitation buffer (for synthesis)       */
                               const Word16 T3,        /* i:   floating pitch                          */
                               const Word16 tilt_code, /* i:   spectral tilt                           */
                               const Word16 Ts,        /* i:   previous pitch for hr G729EV_FEC_VOICED */
                               Word16 * pitch_buf,     /* o:   floating pitch for every subfr          */
                               const Word16 Tcnt,      /* i:   counter of the last bfi pitch updt.     */
                               Word16 * Aq,            /* i    LP filter coefs                         */
                               Word16 * synth,         /* o    synthesized speech at Fs = 16kHz        */
                               Word16 * mem_syn2,      /* i/o  initial synthesis filter states         */
                               Word32 * Lenr_old,      /* o    energy update at the end for next frame */
                               Word16 * seed,          /* i/o: random generator seed                   */
                               Word16 * exc,           /* i/o: pointer to present exc                  */
                               Word16 puls_pos,        /* i  : Pulse position                          */
                               Word16 new_pit          /* i  : Pitch of the first future frame         */
    )
{
  Word16    i, i_subfr;
  Word16    pit_subfr;
  Word16    nb_pusles, pulse_chosen, Terr;
  Word16    P0 = 0, pit_search, diff_pit, sign;
  Word32    L_tmp, L_tmp2, L_step;
  Word16    hp_filt[5], tmp2, *p_Az, exp_alpha, exp_gain, j;
  Word16    delta, fT0, pos, total_pit_lag = 0;
  Word16   *pt_exc, *pt1_exc, alpha, step, gain_inov, gain, tmp16, tmp_Tc, Tc;
  Word16    dist_Plast, Plast, Tlist[10];

   /*------------------------------------------------------------------------------------------*
    * Find secure pitch estimation for FERs
    * The new_pit is always known 
    * in single FER, new_pit is the futur pitch else new_pit is predict from past pitch
    *------------------------------------------------------------------------------------------*/
  sign = 0;
#if(WMOPS)
  move16();
  move16();
  test();
  test();
#endif

  IF(((sub(Ts, shl(mult(29491, T3), 1)) < 0) && (sub(Ts, mult(19661, T3)) > 0)) ||  /* last pitch coherent with the past  */
     (sub(Tcnt, G729EV_FEC_MAX_UPD_CNT) >= 0))  /* or last update too far in the past */
  {
    tmp_Tc = T3;                /*pitch period of the 4th subframe of the last good frame */
  }
  ELSE
  {
    tmp_Tc = Ts;                /* pitch period of the 4th subframe of the last good STABLE VOICED */
  }

  IF(new_pit > 0)
  {
#if(WMOPS)
    move16();
#endif
    fT0 = tmp_Tc;
    delta = shr(sub(shl(new_pit, G729EV_FEC_SQPIT), fT0), 2); /* 4 sub-frames */
    FOR(i = 0; i < 4; i++)     /* subframe pitch values */
    {
      fT0 = add(fT0, delta);
      pitch_buf[i] = shl(shr(add(fT0, G729EV_FEC_QPIT2), G729EV_FEC_SQPIT), G729EV_FEC_SQPIT);
#if(WMOPS)
      move16();
#endif
    }
  }
  ELSE                          /* Should never happen in normal processing condition */
  {
    FOR(i = 0; i < 4; i++)
    {
      pitch_buf[i] = tmp_Tc;
#if(WMOPS)
      move16();
#endif
    }
  }

   /*-------------------------------------------------*
    * hp filter random part and add to excitation   
    *-------------------------------------------------*/
  tmp2 = sub(32767, tilt_code);
  FOR(i = 0; i < G729EV_FEC_L_FIR_FER; i++)
  {
    /*hp_filt[i] = (1.0f - tilt_code) * G729EV_FEC_h_high[i]; */
    hp_filt[i] = mult_r(tmp2, G729EV_FEC_h_high[i]);
#if(WMOPS)
    move16();
#endif
  }

   /*-------------------------------------------------*
    * Estimate damping factor                         *
    *-------------------------------------------------*/
#if(WMOPS)
  move16();
#endif
  alpha = G729EV_calc_alpha(last_good, bfi_cnt, mult_r(stab_fac, (32767 - G729EV_FEC_ALPHA_U)));
  IF(sub(last_good, G729EV_FEC_VOICED) >= 0)
  {
    IF(sub(bfi_cnt, 1) == 0)    /* if first erased frame in a block, reset harmonic gain */
    {
      /*gain = (float)sqrt( *lp_gainp ); *//* move pitch gain towards 1 for G729EV_FEC_VOICED to remove energy fluctuations */
      if(*lp_gainp == 0)
      {
        *lp_gainp = 1;
      }
      exp_alpha = norm_s(*lp_gainp);
      tmp2 = shl(*lp_gainp, exp_alpha);
      tmp2 = div_s(16384, tmp2);
      L_tmp = L_deposit_h(tmp2);
      Isqrt_n(&L_tmp, &exp_alpha);

      gain = extract_h(L_shl(L_tmp, exp_alpha));
#if(WMOPS)
      move16();
      move32();
#endif
      IF(sub(gain, 32113) > 0)  /*.98 */
      {
        gain = (Word16) 32113;
#if(WMOPS)
        move16();
#endif
      }
      ELSE if   (sub(gain, 27853) < 0)  /*0.85 */
      {
        gain = (Word16) 27853;
#if(WMOPS)
        move16();
#endif
      }
      alpha = mult_r(alpha, gain);
    }
    ELSE      IF(sub(bfi_cnt,3) <= 0)
    {
      /* in Q15 */
      alpha = shl(*lp_gainp, 1);
    }
    ELSE
    {
      alpha = G729EV_FEC_ALPHA_VT;
    }
  }
  IF(sub(last_good, G729EV_FEC_UV_TRANSITION) >= 0)
  {
    /* Tc = (short)(bfi_pitch + 0.5f); */
    Tc = shr(add(tmp_Tc, G729EV_FEC_QPIT2), G729EV_FEC_SQPIT);
#if(WMOPS)
    move16();
#endif
       /*-------------------------------------------------*
        * Construct the periodic part of excitation       *
        *-------------------------------------------------*/
    pt_exc = exc;
    pt1_exc = exc - Tc;
    pos = (Word16) 0;
    IF(sub(bfi_cnt, 1) == 0)    /* if 1st erased frame after a good frame */
    {
      FOR(i = 0; i < Tc; i++)  /* pitch cycle is first low-pass filtered */
      {
        /* *pt_exc++ = ( 0.18f * pt1_exc[-1] + 0.64f * pt1_exc[0] + 0.18f * pt1_exc[1] ); */
        L_tmp = L_mult(5898, pt1_exc[-1]);
        L_tmp = L_mac(L_tmp, 20972, pt1_exc[0]);
        L_tmp = L_mac(L_tmp, 5898, pt1_exc[1]);
        *pt_exc = round(L_tmp);
        pt_exc++;
        pt1_exc++;
#if(WMOPS)
        move16();
#endif
      }
#if(WMOPS)
      move16();
#endif
      pos = Tc;
    }
    /* last pitch cycle of the previous frame is repeatedly copied up to an extra subframe */
    FOR(i = pos; i < G729EV_MAIN_L_FRAME2 + G729EV_G729_L_SUBFR; i++)
    {
      *pt_exc++ = *pt1_exc++;
      move16();
#if(WMOPS)
      move16();
#endif
    }
    IF(new_pit > 0)
    {

      pit_subfr = (Word16) 0;
#if(WMOPS)
      move16();
#endif

      IF(sub(puls_pos, -1000) == 0) /* Information of pulse position is not present */
      {
        /* Only possible when more than 1 frame erasure or with bitrate < 14 kbps */

        i = 1;
        tmp2 = pitch_buf[0];
        tmp16 = (Word16) 0;
#if(WMOPS)
        move16();
        move16();
        move16();
#endif

             /*------------------------------------------------------------
              * Total delay of all pitch cycles in the concealed frame is computed 
              * for both Tc used in concealment and future (or estimated)
              *------------------------------------------------------------*/
        WHILE(sub(tmp2, (G729EV_MAIN_L_FRAME2 - G729EV_G729_PIT_MIN) * G729EV_FEC_QPIT) < 0)
        {
          tmp16 = mult(shr(tmp2, G729EV_FEC_SQPIT), 819);
          tmp2 = add(pitch_buf[tmp16], tmp2);
          i = add(i, 1);
        }
             /*------------------------------------------------------------
              * Find estimated pitch lags per subframe 
              * estimation of the difference between the last concealed 
              * maximum glottal pulse in the frame and the estimated pulse  
              *------------------------------------------------------------*/
        total_pit_lag = sub(i_mult(i, Tc), shr(add(tmp2, G729EV_FEC_QPIT2), G729EV_FEC_SQPIT));

        /* have to play safe when we extrapolate a pulse position */
        if (sub(total_pit_lag, 35) > 0)
        {
          total_pit_lag = (Word16) 0;
#if(WMOPS)
          move16();
#endif
        }
        if (sub(total_pit_lag, -35) < 0)
        {
          total_pit_lag = (Word16) 0;
#if(WMOPS)
          move16();
#endif
        }

      }
      ELSE
      {
#if(WMOPS)
        move16();
#endif
             /*------------------------------------------------------------
              * Decode phase information transmitted in the bitstream
              * (The position of the absolute maximum glottal pulse from 
              * the end of the frame and its sign)
              *------------------------------------------------------------*/
        P0 = puls_pos;
        IF(sub(P0, 64) >= 0) /* take sign */
        {
          P0 = (Word16) (P0 & 0x3F);
          sign = (Word16) 1;
#if(WMOPS)
          move16();
          move16();
          logic16();
#endif
        }

        IF(sub(Tc, 128) >= 0)
        {
          P0 = shl(P0, 2);
          P0 = add(P0, 2);
        }
        ELSE if   (sub(Tc, 64) >= 0)
        {
          P0 = shl(P0, 1);
          P0 = add(P0, 1);
        }
        if (sub(P0, 160) > 0)
        {
          P0 = (Word16) 160;    /* Should never be the case, however... */
#if(WMOPS)
          move16();
#endif
        }
      }
#if(WMOPS)
      move16();
#endif
      pit_search = Tc;

      if (sign)                 /* Take sign in account to find right pulse */
      {
        pit_search = negate(pit_search);
      }

      /* Find the position of the first the maximum(minimum) lp_filtered pulse */
      /* <----- Mem --->|<--------------------- L_FRAME ------------>|<----- L_SUBFR --->| */
      /*                |<-------pit_search---->                     |                   | */
      Tlist[0] = G729EV_FEC_findpulse(exc, pit_search, 0);

      /*nb_pusles =  (G729EV_MAIN_L_FRAME2 / Tc) + 1; */
      tmp2 = shl(Tc, 7);
      tmp2 = div_s(1280, tmp2);
      nb_pusles = add(shr(tmp2, 11), 1);

      /* Extrapolate the position of all the other pulses */
      /* puls_list contains realtive pulse position  P = Pulse TL = Puls_list */
      /* |<--------------------- L_FRAME --------------------->|<----- L_SUBFR --->| */
      /* |    P                 p                 p            |    p              | */
      /* |   TL[0]             TL[1]             TL[2]         |   TL[x]           | */
#if(WMOPS)
      move16();
#endif
      FOR(i = 1; i < nb_pusles; i++)
      {
        Tlist[i] = add(Tlist[i - 1], Tc);
#if(WMOPS)
        move16();
#endif
      }
      IF(sub(puls_pos, -1000) == 0) /* Information of pulse position is not present */
      {
        IF(sub(G729EV_MAIN_L_FRAME2, Tlist[nb_pusles - 1]) >= 0)  /* We try to find the right pulse pos */
        {
          P0 = add(sub(G729EV_MAIN_L_FRAME2, Tlist[nb_pusles - 1]), total_pit_lag);
        }
        ELSE
        {
          P0 = add(sub(G729EV_MAIN_L_FRAME2, Tlist[nb_pusles - 2]), total_pit_lag);
        }
      }
#if(WMOPS)
      move16();
      move16();
#endif
      /* Choose on wich pulse to start the correction in function of pulse position sent by the encoder */
      pulse_chosen = (Word16) 0;
      Terr = (Word16) 200;
      Plast = sub(G729EV_MAIN_L_FRAME2, P0);
      FOR(i = 0; i < nb_pusles; i++)
      {
        tmp16 = abs_s(sub(Plast, Tlist[i]));
        if (sub(tmp16, Terr) < 0)
        {
          Terr = tmp16;
          pulse_chosen = i;
#if(WMOPS)
          move16();
          move16();
#endif
        }
      }
      diff_pit = abs_s(sub(new_pit, Tc));
      tmp16 = shl(Tc, 7);
      tmp16 = shr(add(div_s(1280, tmp16), 1024), 11);
      dist_Plast = sub(G729EV_MAIN_L_FRAME2, Tlist[pulse_chosen]);

#if(WMOPS)
      test();
      test();
#endif
      IF(((Terr <= i_mult(diff_pit, tmp16))) && (Terr != 0) /*   If Terr = 0, no resynchronization required */
         && (sub(Terr, G729EV_G729_L_SUBFR) < 0)) /* prevent catastrophy search */
      {
        /* performe excitation resynchronization here */
        G729EV_FEC_synchro_exc(exc, P0, dist_Plast, Tc);
      }

    }
    IF((sub(last_good, G729EV_FEC_UV_TRANSITION) == 0))
    {
      gain = (Word16) 24576;
      *lp_gainp = shr(alpha, 2);  /*lp_gainp in Q14 */
#if(WMOPS)
      move16();
      move16();
#endif
    }
    ELSE
    {
      gain = (Word16) 32767;    /* start-of-the-frame gain */
      *lp_gainp = shr(alpha, 1);  /* end-of-the-frame gain, save attenuation factor for the next frame */
#if(WMOPS)
      move16();
      move16();
#endif
    }
    /* step = (1.0f/L_FRAME) * (gain - *lp_gainp); */
    step = mult_r(sub(shr(gain, 1), *lp_gainp), 410);

    FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
    {
      /* Linearly attenuate the gain through the frame */
      /*exc[i] *= gain; */
      exc[i] = mult_r(exc[i], gain);  /* in Q_exc */
      /*gain -= step; */
      gain = sub(gain, step);
#if(WMOPS)
      move16();

#endif
    }
    /* Update old_exc without random part   */
    G729EV_G729_Copy(&exc[G729EV_MAIN_L_FRAME2 - G729EV_FEC_L_EXC_MEM], exc_mem, G729EV_FEC_L_EXC_MEM);
  }                             /* end of "if last_good >= G729EV_FEC_V_TRANSITION"  */

   /*-------------------------------------------------*
    * Construct the random part of excitation         *
    *-------------------------------------------------*/
  FOR(i = 0; i < G729EV_MAIN_L_FRAME2 + G729EV_FEC_L_FIR_FER - 1; i++)
  {
    /*exc2[i] = (float)G729EV_G729_random_g729c( seed ); */
    exc2[i] = shr(G729EV_G729_Random(seed), 3); /*Q-3 */
#if(WMOPS)
    move16();
#endif
  }
#if(WMOPS)
  test();
  test();
#endif
  if ((sub(last_good, G729EV_FEC_V_TRANSITION) > 0) ||
      ((sub(last_good, G729EV_FEC_UV_TRANSITION) > 0) && sub(bfi_cnt, 1) > 0))
  {
    *lp_gainc = shr(*lp_gainc, 1);
#if(WMOPS)
    move16();
#endif
  }
#if(WMOPS)
  move16();
  move16();
#endif
  gain = *lp_gainc;             /*Q3 *//* start-of-the-frame gain */
  *lp_gainc = mult_r(alpha, *lp_gainc);

  if ((sub(last_good, G729EV_FEC_UV_TRANSITION) == 0))
  {
    *lp_gainc = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }

  /* To avoid saturation split the L_FRAME dot product into 4 L_SUBFR dot products
     and scale down before adding */

  /*pt_exc = exc2 + G729EV_FEC_L_FIR_FER/2; */
  /*gain_inov = 1.0f / (float)sqrt(G729EV_FEC_dproduct( pt_exc, pt_exc, G729EV_MAIN_L_FRAME2 ) / G729EV_MAIN_L_FRAME2 + 0.01f); */
#if(WMOPS)
  move32();
#endif
  pt_exc = exc2 + G729EV_FEC_L_FIR_FER / 2;
  L_tmp = (Word32) 0;
  FOR(i = 0; i < 4; i++)
  {
    L_tmp2 = (Word32) 0;
    FOR(j = 0; j < G729EV_G729_L_SUBFR; j++)
    {
      L_tmp2 = L_mac(L_tmp2, pt_exc[j], pt_exc[j]); /* Q-5 */
    }
#if(WMOPS)
    move32();
#endif
    pt_exc = pt_exc + G729EV_G729_L_SUBFR;
    L_tmp = L_add(L_tmp, L_shr(L_tmp2, 2)); /* Q-7          */
  }
  L_tmp = L_mls(L_tmp, 26214);  /* multiply by 0.8 and remove 7 from exponent to achive a divsion by 160 */
  exp_gain = norm_l(L_tmp);
  L_tmp = L_shl(L_tmp, exp_gain); /* Normalize                  */
  /* Q0, 7 ->divide by 128      */
  exp_gain = sub(31, exp_gain); /* For Denormalization in Q31 */
  Isqrt_n(&L_tmp, &exp_gain);   /* in Q31                     */
  gain_inov = round(L_tmp);     /* In Q15 - exp_gain */
#if(WMOPS)
  move32();
  move16();
#endif
  if (sub(last_good, G729EV_FEC_UNVOICED) == 0) /* Attenuate somewhat on unvoiced   */
  {
    gain_inov = mult_r(gain_inov, 13107);
  }

  pt_exc = exc2;                /* non-causal ringing of the FIR filter         */
#if(WMOPS)
  move16();
#endif
  step = sub(gain, *lp_gainc);  /* divide by L_FRAME done later */

  L_step = L_mls(L_mult(gain_inov, step), 205);
  L_tmp2 = L_mult(gain_inov, gain); /* Q15 * Q3 -> Q3         */
  tmp2 = round(L_tmp2);
  exp_gain = add(exp_gain, 16); /* 3+Q_exc+15 -> Q_exc+18 */

  FOR(i = 0; i < G729EV_FEC_L_FIR_FER / 2; i++)
  {
    /* *pt_exc++ *= (gain_inov * gain); */
    L_tmp = L_mult(tmp2, *pt_exc);  /* Q_exc+18 * Q-3 -> Q_exc+16 */
    *pt_exc++ = round(L_shl(L_tmp, exp_gain));
#if(WMOPS)
    move16();
#endif
  }

  FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)  /* Actual filtered random part of excitation */
  {
    /* *pt_exc++ *= (gain_inov * gain); */
    L_tmp = L_mult(tmp2, *pt_exc);
    *pt_exc++ = round(L_shl(L_tmp, exp_gain));
    /* gain -= step; */
    L_tmp2 = L_sub(L_tmp2, L_step);
    tmp2 = round(L_tmp2);
#if(WMOPS)
    move16();
#endif
  }

  FOR(i = 0; i < G729EV_FEC_L_FIR_FER / 2; i++)  /* causal ringing of the FIR filter   */
  {
    /* *pt_exc++ *= (gain_inov * gain); */
    L_tmp = L_mult(tmp2, *pt_exc);
    *pt_exc++ = round(L_shl(L_tmp, exp_gain));
#if(WMOPS)
    move16();
#endif
  }

   /*-------------------------------------------------*
    * Construct the total excitation         
    *-------------------------------------------------*/
  IF(sub(last_good, G729EV_FEC_UV_TRANSITION) >= 0)
  {
       /*-------------------------------------------------*
        * innovation excitation is filtered through 
        * a linear phase FIR high-pass filter
        *-------------------------------------------------*/
    pt_exc = exc2;
    FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
    {
      L_tmp = 0;
      move32();
      L_tmp = L_mac(L_tmp, hp_filt[0], pt_exc[0]);
      L_tmp = L_mac(L_tmp, hp_filt[1], pt_exc[1]);
      L_tmp = L_mac(L_tmp, hp_filt[2], pt_exc[2]);
      L_tmp = L_mac(L_tmp, hp_filt[3], pt_exc[3]);
      L_tmp = L_mac(L_tmp, hp_filt[4], pt_exc[4]);
      pt_exc++;
      exc[i] = add(exc[i], round(L_tmp));
      move16();
#if(WMOPS)
      move16();
#endif
    }
  }
  ELSE
  {
    G729EV_G729_Copy(exc2 + G729EV_FEC_L_FIR_FER / 2, exc, G729EV_MAIN_L_FRAME2); /* For purely G729EV_FEC_UNVOICED, just G729EV_G729_copy the random part */
    G729EV_G729_Copy(&exc[G729EV_MAIN_L_FRAME2 - G729EV_FEC_L_EXC_MEM], exc_mem, G729EV_FEC_L_EXC_MEM); /* Update old_exc                                 */
  }

  G729EV_G729_Copy(exc, exc2, G729EV_MAIN_L_FRAME2);  /* Update exc2       */


   /*------------------------------------------------------------*
     Speech synthesis 
    *------------------------------------------------------------*/
  p_Az = Aq;
  FOR(i_subfr = 0; i_subfr < G729EV_MAIN_L_FRAME2; i_subfr += G729EV_G729_L_SUBFR)
  {
    G729EV_G729_Syn_filt2(p_Az, &exc2[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn2, 1);
    p_Az += (G729EV_G729_M + 1);
  }

   /*------------------------------------------------------------------*
    * estimate the pitch-synchronous speech energy per sample          *
    * to be used when normal operation recovers                        *
    *------------------------------------------------------------------*/

  tmp16 = G729EV_FEC_energy(last_good, synth, shr(add(tmp_Tc, G729EV_FEC_QPIT2), G729EV_FEC_SQPIT), Lenr_old, 1);
  IF(sub(last_good, G729EV_FEC_VOICED) < 0)
  {
    /* Convert energy to Q0 */
    *Lenr_old = L_mls(*Lenr_old, 26214);
    tmp16 = add(tmp16, 6 + 1);
    *Lenr_old = L_shr_r(*Lenr_old, tmp16);
#if(WMOPS)
    move32();
    move32();
#endif
  }
  return;
}

/*************************************************************************************/
/* G729EV_FEC_scale_syn : Smooth energy transition between lost frame and good frame */
/* - Find energy at frame end                                                        */
/* - Find energy at frame beginning                                                  */
/* - smooth excitation energy over all the frame                                     */
/* - redo synthesis (if needed)                                                      */
/*************************************************************************************/
void G729EV_FEC_scale_syn(Word16 extrate,          /* i: indicate decoded bit rate                 */
                          Word16 clas,             /* i/o: frame classification                    */
                          const Word16 last_good,  /* i:   last good frame classification          */
                          Word16 * synth,          /* i/o: synthesized speech                      */
                          const Word16 * pitch,    /* i:   pitch values for each subframe          */
                          Word32 Lenr_q,           /* i:   transmitted energy for current frame    */
                          const Word16 prev_bfi,   /* i:   previous frame BFI                      */
                          Word16 Aq[],             /* i/o: LP filter coefs (can be modified if BR) */
                          Word16 * old_enr_LP,     /* i/o: LP filter E of last good G729EV_FEC_VOICED frame   Q4 */
                          Word16 * mem_tmp,        /* i/o: temporary synthesis memory              */
                          Word16 * exc_tmp,        /* i/o: temporary excitation                    */
                          Word32 Lenr_old,         /* i  : energy at the end of the last frame     */
                          Word16 * old_exc,        /* i/o: excitation buffer                       */
                          Word16 * mem_syn,        /* i/o: synthesis memory                        */
                          Word16 bfi_cnt           /* i  : Number of bad frame                     */
    )
{
  Word16    i, scale_flag;
  Word16    gain1, gain2, tmp, exp_enr, exp2, tmp2;
  Word32    Lenr1, Lenr2, L_tmp;
  Word16    enr_LP /*Q4 */ ;
  Word16    i_subfr, *p_Az;


  scale_flag = (Word16) 0;
  enr_LP = (Word16) 0;
  gain2 = (Word16) 0;
  gain1 = (Word16) 0;

#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
  move32();
#endif
  if (Lenr_old == 0)
  {
    Lenr_old = (Word16) 1;
  }
   /*-----------------------------------------------------------------*
    * Find the synthesis filter impulse response on G729EV_FEC_VOICED     
    *-----------------------------------------------------------------*/

  IF(sub(clas, G729EV_FEC_V_TRANSITION) >= 0)
  {
    enr_LP = G729EV_FEC_enr_1_Az(Aq + 3 * (G729EV_G729_M + 1), G729EV_G729_L_SUBFR);  /*Q4 */
  }
#if (WMOPS)
  test();
  test();
#endif
  IF(sub(prev_bfi, G729EV_FEC_GOOD_FRAME) != 0  /* previous frame erased */
     && (sub(last_good, G729EV_FEC_SIN_ONSET) < 0 || sub(extrate, 40) > 0)  /* Do not scale if onset and energy doesnt sent by the encoder */
      )
  {
       /*-----------------------------------------------------------------*
        * Find the energy at the end of the frame 
        *-----------------------------------------------------------------*/
#if(WMOPS)
    move32();
#endif
    tmp = G729EV_FEC_energy(clas, synth, shr(add(pitch[3], G729EV_FEC_QPIT2), G729EV_FEC_SQPIT), &Lenr2, 1);
    IF(sub(clas, G729EV_FEC_VOICED) < 0)
    {
      /* Convert energy to Q0 */
      Lenr2 = L_mls(Lenr2, 26214);
      tmp = add(tmp, 6 + 1);
      Lenr2 = L_shr_r(Lenr2, tmp);
    }

    IF(sub(extrate, 40) <= 0)   /* < 16 kbps  use the nergy estimation from the decoder */
    {
      Lenr_q = Lenr2;
#if(WMOPS)
      move32();
      test();
#endif
      IF((sub(last_good, G729EV_FEC_V_TRANSITION) >= 0) && (sub(clas, G729EV_FEC_V_TRANSITION) >= 0)) /* G729EV_FEC_VOICED-G729EV_FEC_VOICED recovery */
      {
        IF(sub(enr_LP, *old_enr_LP) > 0)
        {

          /*enr_q /= enr_LP; */
          /*enr_q *= *old_enr_LP; */

          exp_enr = norm_l(Lenr_q);
          tmp = extract_h(L_shl(Lenr_q, exp_enr));

          exp2 = norm_s(enr_LP);
          tmp2 = shl(enr_LP, exp2);

          exp_enr = sub(exp2, exp_enr);

          IF(sub(tmp, tmp2) > 0)
          {
            tmp = shr(tmp, 1);
            exp_enr = add(exp_enr, 1);
          }

          tmp = div_s(tmp, tmp2);

          /* L_enr_q *= *old_enr_LP; */
          Lenr_q = L_shl(L_mult(tmp, *old_enr_LP), exp_enr);

          if (sub(bfi_cnt, 1) <= 0)
          {
            Lenr_q = L_shl(Lenr_q, 2);
          }

        }

        IF(sub(enr_LP, *old_enr_LP) < 0)
        {
          IF(L_sub(Lenr_q, L_shl(Lenr_old, 2)) > 0) /* Prevent energy to increase on G729EV_FEC_VOICED */
          {
            /*enr_q = 4*enr_old; */
            Lenr_q = L_shl(Lenr_old, 2);
          }
        }
        ELSE if   (L_sub(Lenr_q, Lenr_old) > 0)
        {
          /*enr_q = enr_old; */
          Lenr_q = Lenr_old;
#if(WMOPS)
          move32();
#endif
        }
      }
    }

    if (Lenr_q == 0)
    {
      Lenr_q = (Word32) 1;
#if(WMOPS)
      move32();
#endif
    }
    exp_enr = norm_l(Lenr_q);
    tmp = extract_h(L_shl(Lenr_q, exp_enr));

    exp2 = norm_l(Lenr2);
    tmp2 = extract_h(L_shl(Lenr2, exp2));

    exp2 = sub(exp_enr, exp2);  /* Denormalize and substract */


    IF(sub(tmp2, tmp) > 0)
    {
      tmp2 = shr(tmp2, 1);
      exp2 = add(exp2, 1);
    }

    tmp = div_s(tmp2, tmp);

    L_tmp = L_deposit_h(tmp);
    Isqrt_n(&L_tmp, &exp2);
    gain2 = round(L_shl(L_tmp, sub(exp2, 1)));  /* in Q14 */

    /*gain2 = (float)sqrt( enr_q / enr2 ); */


       /*-----------------------------------------------------------------*
        * Clipping of the smoothing gain at the frame end
        *-----------------------------------------------------------------*/

    IF((L_sub(Lenr_q, 1) <= 0)) /* Do not allow E increase if enr_q index==0 (lower end Q clipping) */
    {
      if (sub(gain2, 16384) > 0)
      {
        gain2 = (Word16) 16384; /* Gain modification clipping */
#if(WMOPS)
        move16();
#endif
      }
    }
    ELSE
    {
      if (sub(gain2, 19661) > 0)
      {
        gain2 = (Word16) 19661; /* Gain modification clipping */
#if(WMOPS)
        move16();
#endif
      }
    }

        /*-----------------------------------------------------------------*
        * Find the energy at the beginning of the frame to ensure smooth 
        * transition after erasure     
        *-----------------------------------------------------------------*/

    IF(sub(clas, G729EV_FEC_SIN_ONSET) == 0)  /* slow increase */
    {
      gain1 = mult_r(gain2, 16384);
      scale_flag = (Word16) 1;
#if(WMOPS)
      move16();
      move16();
#endif
    }
    ELSE if   (((sub(last_good, G729EV_FEC_V_TRANSITION) >= 0) && (sub(clas, G729EV_FEC_UNVOICED) == 0)))
    {
      gain1 = gain2;
      scale_flag = (Word16) 0;
#if(WMOPS)
      move16();
      move16();
#endif
    }
    ELSE
    {
#if(WMOPS)
      move32();
#endif
      /* Find the energy at the end of the frame */
      tmp = G729EV_FEC_energy(clas, synth, shr(add(pitch[0], G729EV_FEC_QPIT2), G729EV_FEC_SQPIT), &Lenr1, 0);
      IF(sub(clas, G729EV_FEC_VOICED) < 0)
      {
        /* Convert energy to Q0 */
        Lenr1 = L_mls(Lenr1, 26214);
        tmp = add(tmp, 6 + 1);
        Lenr1 = L_shr_r(Lenr1, tmp);
      }

      /* gain1 = (float)sqrt( *L_enr_old / L_enr1 ); */
      exp_enr = norm_l(Lenr_old);
      tmp = extract_h(L_shl(Lenr_old, exp_enr));
      exp2 = norm_l(Lenr1);
      tmp2 = extract_h(L_shl(Lenr1, exp2));

      exp2 = sub(exp_enr, exp2);  /* Denormalize and substract */
      IF(sub(tmp2, tmp) > 0)
      {
        tmp2 = shr(tmp2, 1);
        exp2 = add(exp2, 1);
      }

      tmp = div_s(tmp2, tmp);

      /* exp_enr = sub(exp2, exp_enr); */
      L_tmp = L_deposit_h(tmp);
      Isqrt_n(&L_tmp, &exp2);
      gain1 = round(L_shl(L_tmp, sub(exp2, 1)));  /* in Q14 */
#if(WMOPS)
      move32();
      move16();
      move16();
#endif
      if (sub(gain1, 19661) > 0)
      {
        /*gain1 = 1.2f; */
        gain1 = (Word16) 19661; /* Gain modification clipping   */
#if(WMOPS)
        move16();
        test();
#endif
      }
      IF((sub(clas, G729EV_FEC_ONSET) == 0) && (sub(gain1, gain2) > 0)) /* Prevent a catastrophy in case of offset followed by G729EV_FEC_ONSET */
      {
#if(WMOPS)
        move16();
#endif
        gain1 = gain2;
      }
      scale_flag = (Word16) 1;
    }

  }

   /*-----------------------------------------------------------------*
    * Smooth the energy evolution by exponentially evolving from 
    * gain1 to gain2        
    *-----------------------------------------------------------------*/

  IF(scale_flag != 0)
  {
    /*gain2 *= ( 1.0f - G729EV_FEC_AGC ); */
    gain2 = mult_r(gain2, (Word16) (32768 - G729EV_FEC_AGC));

    FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
    {
      /*gain1 = gain1 * G729EV_FEC_AGC + gain2; */
      gain1 = mac_r(L_shl(gain2, 16), gain1, G729EV_FEC_AGC); /* in Q14 */

      /*exc_tmp[i] *= gain1; */
      exc_tmp[i] = round(L_shl(L_mult(exc_tmp[i], gain1), 1));
#if(WMOPS)
      move16();
#endif
    }

    /* Update excitation memory with new excitation */
    G729EV_G729_Copy(&exc_tmp[G729EV_MAIN_L_FRAME2 - (G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL)], old_exc,
                     G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  }
    /*-----------------------------------------------------------------*
    * Update the LP filter energy for G729EV_FEC_VOICED frames
    *-----------------------------------------------------------------*/
  if (sub(clas, G729EV_FEC_V_TRANSITION) >= 0)
  {
    *old_enr_LP = enr_LP;       /* Update */
#if(WMOPS)
    move16();
#endif
  }
    /*-----------------------------------------------------------------*
    * smoothing is done in excitation domain, so redo synthesis
    *-----------------------------------------------------------------*/

  IF((sub(prev_bfi, G729EV_FEC_GOOD_FRAME) != 0))
  {
       /*------------------------------------------------------------*
        * Speech synthesis at 8 kHz sampling rate                  *
        *------------------------------------------------------------*/
    G729EV_G729_Copy(mem_tmp, mem_syn, G729EV_G729_M);
#if(WMOPS)
    move16();
#endif
    p_Az = Aq;
    FOR(i_subfr = 0; i_subfr < G729EV_MAIN_L_FRAME2; i_subfr += G729EV_G729_L_SUBFR)
    {
      G729EV_G729_Syn_filt2(p_Az, &exc_tmp[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn, 1);
#if(WMOPS)
      move16();
#endif
      p_Az += (G729EV_G729_M + 1);
    }
  }
  return;
}

/******************************************************************************/
/* G729EV_FEC_enr_1_Az : To find impulse response energy                      */
/******************************************************************************/
static Word16 G729EV_FEC_enr_1_Az(  /* o:   impulse response energy */
                                   Word16 Aq[], /* i:   LP filter coefs         */
                                   Word16 len   /* i:   impulse response length */
    )
{
  Word16    i, enr_LP, h1[2 * G729EV_G729_L_SUBFR], mem[G729EV_G729_M];
  Word32    L_tmp;

  /* Find the impulse response */
  G729EV_G729_Set_zero(h1, len);
  G729EV_G729_Set_zero(mem, G729EV_G729_M);
  h1[0] = 1024;                 /* h1_in Q10, h1_out Q10 */
  G729EV_G729_Syn_filt(Aq, h1, h1, len, mem, 0);

#if(WMOPS)
  move16();
  move32();
#endif
  /* Find the impulse response energy */
  L_tmp = (Word32) 0;
  FOR(i = 0; i < len; i++)
  {
    L_tmp = L_mac0(L_tmp, h1[i], h1[i]);
  }
  enr_LP = round(L_tmp);        /* Q21 to Q5 */

  return enr_LP;
}

/******************************************************************************/
/* G729EV_FEC_synchro_exc : To resynchronize concealed                        */
/* - Find number of minimum energy region                                     */
/* - Find location of minimum energy region                                   */
/* - Find number of sample to add/remove by minimum energy region             */
/* - Synchronisation (sample deletion/addition)                               */
/******************************************************************************/
static void G729EV_FEC_synchro_exc(Word16 * exc,           /* i/o : exc vector to modify */
                                   Word16 desire_puls_pos, /* Pulse position send by the encoder */
                                   Word16 true_puls_pos,   /* Present pulse location */
                                   Word16 Old_pitch        /* Pitch use to create temporary adaptive codebook */
    )
{

  Word16    exc_tmp[G729EV_MAIN_L_FRAME2 + G729EV_G729_L_SUBFR], *pt_exc, *pt_exc1, tmp16, fact;
  Word32    L_tmp, L_tmp1;
  Word16    remaining_len;
  Word16    i, j, k, point_to_remove, point_to_add, nb_min, points_by_pos[10], total_point;
  Word16   *pt_pos, pos, start_search, tmp_len;
  Word16    min_pos[10];

  point_to_add = -1;
#if(WMOPS)
  move16();
#endif
  FOR(i = 0; i < 10; i++)
  {
    min_pos[i] = (Word16) - 10000;
    points_by_pos[i] = (Word16) 0;
#if(WMOPS)
    move16();
    move16();
#endif
  }

  /* Find number of point to remove and number of minimum */
  point_to_remove = sub(true_puls_pos, desire_puls_pos);  /* if it is negative it means remove point else it means add point */

  /* Find number of minimum energy region */
  tmp16 = shl(Old_pitch, 7);
  tmp_len = sub(G729EV_MAIN_L_FRAME2, true_puls_pos);
  tmp16 = div_s(shl(tmp_len, 3), tmp16);
  nb_min = shr(tmp16, 11);

  /* if Old pitch < 80, must have at least 2 min */
#if (WMOPS)
  test();
#endif
  if (sub(Old_pitch, 80) <= 0 && sub(nb_min, 2) < 0)
  {
    nb_min = (Word16) 2;
#if(WMOPS)
    move16();
#endif
  }
  /* Must have at least 1 min */
  if (nb_min == 0)
  {
    nb_min = (Word16) 1;
#if(WMOPS)
    move16();
#endif
  }
#if(WMOPS)
  move16();
  move16();
#endif

  pos = tmp_len;
  pt_exc = exc + pos;

  /* Find starting point for minimum energy search */
  start_search = shr_r(i_mult(-3, Old_pitch), 2);
  IF(add(start_search, pos) < 0)
  {
    start_search = negate(pos);
    if (sub(abs_s(start_search), shr(Old_pitch, 3)) < 0)
    {
      /* it's not safe to remove/add point inside 1/8 of the pulse position */
      return;
    }
  }

  /* Find min energy in the first pitch section */
#if(WMOPS)
  move32();
#endif
  /* --------------------------------------------------------------------
   * The minimum energy regions are determined by the computing the energy 
   * using a sliding 5-sample window. The minimum energy position is set 
   * at the middle of the window at which the energy is at minimum
   * --------------------------------------------------------------------*/
  L_tmp = MAX_32;
  L_tmp1 = L_mult(pt_exc[start_search], pt_exc[start_search]);
  L_tmp1 = L_mac(L_tmp1, pt_exc[start_search + 1], pt_exc[start_search + 1]);
  L_tmp1 = L_mac(L_tmp1, pt_exc[start_search + 2], pt_exc[start_search + 2]);
  L_tmp1 = L_mac(L_tmp1, pt_exc[start_search + 3], pt_exc[start_search + 3]);
  L_tmp1 = L_mac(L_tmp1, pt_exc[start_search + 4], pt_exc[start_search + 4]);

  IF(L_sub(L_tmp1, L_tmp) < 0)
  {
    L_tmp = L_tmp1;
    min_pos[0] = add(add(pos, start_search), 2);
#if(WMOPS)
    move32();
    move16();
#endif
  }
  FOR(i = start_search; i < -5; i++)
  {
    L_tmp1 = L_msu(L_tmp1, pt_exc[i], pt_exc[i]);
    L_tmp1 = L_mac(L_tmp1, pt_exc[i + 5], pt_exc[i + 5]);
    IF(L_sub(L_tmp1, L_tmp) < 0)
    {
      L_tmp = L_tmp1;
      min_pos[0] = add(add(pos, i), 2);
#if(WMOPS)
      move32();
      move16();
#endif
    }
  }

  FOR(j = 1; j < nb_min; j++)
  {
#if(WMOPS)
    move16();
#endif
    min_pos[j] = sub(min_pos[j - 1], Old_pitch);
    /* If the first minimum is in the past, forget this minimum */
    if (min_pos[j] < 0)
    {
      min_pos[j] = -10000;
      nb_min = sub(nb_min, 1);
#if(WMOPS)
      move16();
#endif
    }
  }
  /* --------------------------------------------------------------------
   * Determine the number of samples to be added or removed at each pitch 
   * cycle whereby less samples are added/removed at the beginning and 
   * more towards the end of the frame
   * --------------------------------------------------------------------*/
#if(WMOPS)
  test();
#endif
  IF(sub(nb_min, 1) == 0 || sub(abs_s(point_to_remove), 1) == 0)
  {
    nb_min = 1;
    points_by_pos[0] = abs_s(point_to_remove);
    total_point = points_by_pos[0];
#if(WMOPS)
    move16();
    move16();
    move16();
#endif
  }
  ELSE
  {
    /* First position */
    /*fact = (float)fabs(point_to_remove) / sqi[nb_min-2]; (nb_min*nb_min); */
    fact = mult_r(shl(abs_s(point_to_remove), 7), inv_sqi[nb_min - 2]); /*Q7 */
    points_by_pos[0] = shr(add(fact, 64), 7); /*Q7 */
    total_point = points_by_pos[0];
#if(WMOPS)
    move16();
    move16();
#endif
    FOR(i = 2; i <= nb_min; i++)
    {
      /*points_by_pos[i-1] = (Word16)(fact*(sqi[i-2]) - total_point+0.5) ; */
#if(WMOPS)
      move16();
#endif
      points_by_pos[i - 1] = sub(shr(add(i_mult(fact, sqi[i - 2]), 64), 7), total_point);
      total_point = add(total_point, points_by_pos[i - 1]);
      /* ensure a constant increase */
      IF(sub(points_by_pos[i - 1], points_by_pos[i - 2]) < 0)
      {
#if(WMOPS)
        move16();
        move16();
        move16();
#endif
        tmp16 = points_by_pos[i - 2];
        points_by_pos[i - 2] = points_by_pos[i - 1];
        points_by_pos[i - 1] = tmp16;
      }
    }
  }
  /* --------------------------------------------------------------------
   * Sample deletion or insertion is performed in minimum energy regions. 
   * At the end of this section the last maximum pulse in the concealed 
   * excitation is forced to align to the actual maximum pulse position 
   * at the end of the frame which is transmitted in the future frame.
   * --------------------------------------------------------------------*/
  if (point_to_remove > 0)
  {
    point_to_add = point_to_remove;
#if(WMOPS)
    move16();
#endif
  }

  pt_exc = exc_tmp;
  pt_exc1 = exc;
  pt_pos = min_pos + sub(nb_min, 1);

#if(WMOPS)
  move16();
  move16();
#endif

  i = 0;
  k = 0;
  pt_pos = min_pos + sub(nb_min, 1);
  IF(point_to_add > 0)          /* Samples insertion */
  {
    remaining_len = G729EV_MAIN_L_FRAME2;
#if(WMOPS)
    move16();
#endif
    FOR(i = 0; i < nb_min; i++)
    {
      if (i == 0)
      {
        /*Compute len to copy */
        tmp_len = *pt_pos;
#if(WMOPS)
        move16();
#endif
      }
      IF(i > 0)
      {
        /*Compute len to copy */
        tmp_len = sub(sub(*pt_pos, *(pt_pos + 1)), points_by_pos[i - 1]);
      }
      /*Copy section */
      G729EV_G729_Copy(pt_exc1, pt_exc, tmp_len);
      remaining_len = sub(remaining_len, tmp_len);
#if(WMOPS)
      move16();
      move16();
#endif
      pt_exc1 += tmp_len;
      pt_exc += tmp_len;

      /*Find point to add and Add points */
      tmp16 = mult_r(*pt_exc1, -1638);
      FOR(j = 0; j < points_by_pos[i]; j++)
      {
        *pt_exc++ = tmp16;      /* repeat last point  */
        tmp16 = negate(tmp16);
#if(WMOPS)
        move16();
#endif
      }

      remaining_len = sub(remaining_len, points_by_pos[i]);
      pt_pos--;
    }
    /* Copy remaining data */
    G729EV_G729_Copy(pt_exc1, pt_exc, remaining_len);
    /* Update excitation vector */
    G729EV_G729_Copy(exc_tmp, exc, G729EV_MAIN_L_FRAME2);
  }
  ELSE                          /* Samples deletion */
  {
    remaining_len = G729EV_MAIN_L_FRAME2;
#if(WMOPS)
    move16();
#endif
    FOR(i = 0; i < nb_min; i++)
    {
      if (i == 0)
      {
        /*Compute len to copy */
        tmp_len = *pt_pos;
#if(WMOPS)
        move16();
#endif
      }
      IF(i > 0)
      {
        /*Compute len to copy */
        tmp_len = sub(sub(*pt_pos, *(pt_pos + 1)), points_by_pos[i - 1]);
      }
      G729EV_G729_Copy(pt_exc1, pt_exc, tmp_len);
      remaining_len = sub(remaining_len, tmp_len);
      pt_exc1 += tmp_len;
      pt_exc += tmp_len;
#if(WMOPS)
      move16();
      move16();
#endif
      /* Remove points */
      FOR(j = 0; j < points_by_pos[i]; j++)
      {
        pt_exc1++;
      }
      pt_pos--;
    }
    /* Copy remaining data */
    G729EV_G729_Copy(pt_exc1, pt_exc, remaining_len);
    /* Update excitation vector */
    G729EV_G729_Copy(exc_tmp, exc, G729EV_MAIN_L_FRAME2);
  }
  return;
}
