/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_util.h"
#include "stl.h"
#include "G729EV_MAIN_oper_32b.h"



/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_pushBit()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Push bits of codeword (UWord16) into bitstream array                    *
 *--------------------------------------------------------------------------*/

void G729EV_TDAC_pushBit(UWord16 code,    /* (i)      codeword                        */
                         Word16 ** pBit,  /* (i/o)    pointer on adress of next bit   */
                         Word16 nbit)     /* (i)      number of bits of code          */
{
  Word16    i, nbitm1;
  Word16    mask;

  /* MSB -> LSB */
  nbitm1 = sub(nbit, 1);
  FOR(i = nbitm1; i >= 0; i--)
  {

    *(*pBit) = ITU_G192_BIT_1;
#if(WMOPS)
    move16();
#endif
    mask = (Word16) (shr(code, i) & 0x0001);
#if(WMOPS)
    logic16();
#endif
    if (mask == 0)
    {
      *(*pBit) = ITU_G192_BIT_0;
#if(WMOPS)
      move16();
#endif
    }

    (*pBit)++;
  }
  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_pushBitL()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 *  Push bits of codeword (UWord32) into bitstream array                    *
 *--------------------------------------------------------------------------*/

void G729EV_TDAC_pushBitL(UWord32 code,   /* (i)      codeword                        */
                          Word16 ** pBit, /* (i/o)    pointer on adress of next bit   */
                          Word16 nbit)    /* (i)      number of bits of code          */
{
  UWord32   t, bit;

  Word16    i, temp;


  /* write bits sequentially */
  temp = sub(nbit, (Word16) 1);

  FOR(i = temp; i >= 0; i--)
  {
    *(*pBit) = (Word16) ITU_G192_BIT_1;
    t = L_shr(code, i);
    bit = t & 0x01;
#if(WMOPS)
    logic16();
    move16();
    move16();
#endif
    if (bit == 0)
    {
      *(*pBit) = (Word16) ITU_G192_BIT_0;
#if(WMOPS)
      move16();
#endif
    }
    (*pBit)++;
  }
  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_getBit()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Get bits of codeword (UWord16) from bitstream array                     *
 *--------------------------------------------------------------------------*/

UWord16 G729EV_TDAC_getBit(Word16 ** pBit,  /* (i/o)    pointer on adress of next bit   */
                           Word16 nbit)     /* (i)      number of bits of code          */
{
  Word32    code_L;

  UWord16   code;
  UWord16   temp16;

  Word16    i;

  code_L = (Word32) 0;
#if(WMOPS)
  move32();
#endif

  FOR(i = 0; i < nbit; i++)
  {
    /* Need to use a 32 bits variable to avoid saturation problems caused by shl or L_shl */
    code_L = L_shl(code_L, 1);
    temp16 = (Word16) 1;

#if (WMOPS)
    move16();
#endif
    if (sub(**pBit, ITU_G192_BIT_0) == 0)
    {
      temp16 = (Word16) 0;
#if (WMOPS)
      move16();
#endif
    }

    code_L = code_L | temp16;
#if (WMOPS)
    logic32();
#endif
    (*pBit)++;
  }
  code = extract_l(code_L);
  return (code);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_getBitL()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Get bits of codeword (UWord32) from bitstream array                     *
 *--------------------------------------------------------------------------*/

UWord32 G729EV_TDAC_getBitL(Word16 ** pBit, /* (i/o)    pointer on adress of next bit   */
                            Word16 nbit)    /* (i)      number of bits of code          */
{
  UWord32   code;

  Word16    i;

/* --------------> switch to unsigned aritmetic for this routine */
  code = (UWord32) 0;
#if(WMOPS)
  move32();
#endif

  FOR(i = 0; i < nbit; i++)
  {
    code = UL_shl(code, 1);
    if (sub(**pBit, ITU_G192_BIT_1) == 0)
    {
      code = code | 0x00000001; /* code = UL_add(code, (Word32) 1); */
#if(WMOPS)
      logic32();
#endif
    }
    (*pBit)++;
  }
  return (code);
}
