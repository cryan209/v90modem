/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_QUANTIF_H__
#define __G729EV_TDAC_QUANTIF_H__

#include <stdio.h>
#include "stl.h"


/* Functions : */

void      G729EV_TDAC_quantif(Word16 * ykr, Word16 ** bit, Word16 * nb_niv, Word16 nb_ssb);
void      G729EV_TDAC_dec_VQcoef(UWord32 code, Word16 dim, Word16 * yq);
void      G729EV_TDAC_decod_VQ(Word16 ** bit, Word16 * ykr, Word16 * nb_niv, Word16 * rmsq, Word16 nb_ssb);


/* Tables : */

extern const Word16 G729EV_TDAC_nb_coef_sqrt[G729EV_TDAC_NB_SB];

extern const Word16 G729EV_TDAC_sb_bound[G729EV_TDAC_NB_SB + 1];
extern const Word16 G729EV_TDAC_nb_coef[G729EV_TDAC_NB_SB];

#endif /* __G729EV_TDAC_QUANTIF_H__ */
