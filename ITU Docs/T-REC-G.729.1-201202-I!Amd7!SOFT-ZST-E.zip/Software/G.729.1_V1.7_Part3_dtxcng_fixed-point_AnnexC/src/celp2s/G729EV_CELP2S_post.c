/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#include "stl.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_G729_ld8k.h"

/* Function G729EV_CELP2S_init_post_filter -  Initialize postfilter functions
*----------------------------------------------------------------------------
*/

/*--------------------------------------------------------------------------*
 *  Function  G729EV_CELP2S_init_post_filter()                              *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                              *
 *  CELP2S post filter initialization                                       *
 *--------------------------------------------------------------------------*/

void G729EV_CELP2S_init_post_filter(G729EV_MAIN_PFSTAT * pfstat
                                                              /* (i)   : core decoder parameters    */
    )
{
  /* Initialize arrays and pointers */

  /* res2 =  A(gamma2) residual */
  G729EV_G729_Set_zero(pfstat->mem_res2, G729EV_G729_MEM_RES2);

  /* 1/A(gamma1) memory */
  G729EV_G729_Set_zero(pfstat->mem_stp, G729EV_G729_M_LPC);

  /* null memory to compute i.r. of A(gamma2)/A(gamma1) */
  G729EV_G729_Set_zero(pfstat->mem_zero, G729EV_G729_M_LPC);

  /* null memory to compute i.r. of A(gamma2)/A(gamma1) */
  G729EV_G729_Set_zero(pfstat->apond2, G729EV_G729_LONG_H_ST);

  /* for gain adjustment */
#if (WMOPS)
  move16();
  move16();
  move32();
#endif
  pfstat->gain_prec = 16384;
  pfstat->Level_in_sm = (Word32) 1024;
  pfstat->parcor0_old=pfstat->PostNB_old=0;

  return;
}

/************************************************************************/
/****   Short term postfilter :                                     *****/
/*      Hst(z) = Hst0(z) Hst1(z)                                        */
/*      Hst0(z) = 1/g0 A(gamma2)(z) / A(gamma1)(z)                      */
/*      if {hi} = i.r. filter A(gamma2)/A(gamma1) (truncated)           */
/*      g0 = SUM(|hi|) if > 1                                           */
/*      g0 = 1. else                                                    */
/*      Hst1(z) = 1/(1 - |mu|) (1 + mu z-1)                             */
/*      with mu = k1 * gamma3                                           */
/*      k1 = 1st parcor calculated on {hi}                              */
/*      gamma3 = gamma3_minus if k1<0, gamma3_plus if k1>0              */
/****   Long term postfilter :                                      *****/
/*      harmonic postfilter :   H0(z) = gl * (1 + b * z-p)              */
/*      b = gamma_g * gain_ltp                                          */
/*      gl = 1 / 1 + b                                                  */
/*      computation of delay p on A(gamma2)(z) s(z)                     */
/*      sub optimal search                                              */
/*      1. search around 1st subframe delay (3 integer values)          */
/*      2. search around best integer with fract. delays (1/8)          */
/************************************************************************/

/*----------------------------------------------------------------------------
 * Post - adaptive postfilter main function
 *----------------------------------------------------------------------------
 */

void      G729EV_CELP2S_Post(G729EV_MAIN_PFSTAT * pfstat, /* (i/o)  stqtes strucure */
                             Word16 t0,                   /* (i)    pitch delay given by coder */
                             Word16 * signal_ptr,         /* (i)    input signal (pointer to current subframe */
                             Word16 * coeff,              /* (i)    LPC coefficients for current subframe */
                             Word16 * sig_out,            /* (o)    postfiltered output */
                             Word16 gamma1,               /* (i)    short term postfilt. den. weighting factor */
                             Word16 gamma2,               /* (i)    short term postfilt. num. weighting factor */
                             Word16 PostNB,               /* (i)    Narrow Band flag    */ 
                             Word16 Vad)                  /* (i)    VAD flag            */
{
  /* Local variables and arrays */
  Word16    apond1[G729EV_G729_MP1];  /* s.t. denominator coeff.      */
  Word16    sig_ltp[G729EV_G729_L_SUBFRP1]; /* H0 output signal             */
  Word16    res2[G729EV_G729_SIZ_RES2];

  Word16   *sig_ltp_ptr;
  Word16   *res2_ptr;
  Word16   *ptr_mem_stp;

  Word16    parcor0;



  /* Init pointers and restore memories */
  res2_ptr = res2 + G729EV_G729_MEM_RES2;
  ptr_mem_stp = pfstat->mem_stp + G729EV_G729_M_LPC - 1;


  G729EV_G729_Copy(pfstat->mem_res2, res2, G729EV_G729_MEM_RES2);

  /* Compute weighted LPC coefficients */
  G729EV_G729_Weight_Az(coeff, gamma1, G729EV_G729_M, apond1);
  G729EV_G729_Weight_Az(coeff, gamma2, G729EV_G729_M, pfstat->apond2);

  /* Compute A(gamma2) residual */
  G729EV_G729_Residu(pfstat->apond2, signal_ptr, res2_ptr, G729EV_G729_L_SUBFR);

  /* Harmonic filtering */
  sig_ltp_ptr = sig_ltp + 1;
  IF(sub(Vad, 1) == 0)	G729EV_G729_pst_ltp(t0, res2_ptr, sig_ltp_ptr);
  ELSE    G729EV_G729_Copy(res2_ptr, sig_ltp_ptr, G729EV_G729_L_SUBFR);

  /* Save last output of 1/A(gamma1)  */
  /* (from preceding subframe)        */
#if (WMOPS)
  move16();
#endif
  sig_ltp[0] = *ptr_mem_stp;

  /* Controls short term pst filter gain and compute parcor0   */
  G729EV_G729_calc_st_filt(pfstat->apond2, apond1, &parcor0, sig_ltp_ptr, pfstat->mem_zero);

  /* 1/A(gamma1) filtering, mem_stp is updated */
  G729EV_G729_Syn_filt(apond1, sig_ltp_ptr, sig_ltp_ptr, G729EV_G729_L_SUBFR, pfstat->mem_stp, 1);

  /* Tilt filtering */
  G729EV_G729_filt_mu(sig_ltp, sig_out, parcor0);

  /* Gain control */
  IF(sub(Vad, 1) == 0)
  {
	  G729EV_G729_scale_st(signal_ptr, sig_out, &pfstat->gain_prec, parcor0, PostNB, &pfstat->Level_in_sm, 0);
	  pfstat->parcor0_old=parcor0;
	  pfstat->PostNB_old=PostNB;
#if (WMOPS)
  move16();
  move16();
#endif
  }
  ELSE
      G729EV_G729_scale_st(signal_ptr, sig_out, &pfstat->gain_prec, parcor0, PostNB, &pfstat->Level_in_sm, 1);
    /**** Update for next subframe */
  G729EV_G729_Copy(&res2[G729EV_G729_L_SUBFR], pfstat->mem_res2, G729EV_G729_MEM_RES2);

  return;
}
