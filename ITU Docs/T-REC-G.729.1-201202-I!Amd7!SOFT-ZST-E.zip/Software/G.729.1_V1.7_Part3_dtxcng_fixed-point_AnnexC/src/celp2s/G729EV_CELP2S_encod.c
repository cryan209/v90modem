/* 
      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008-09

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: August 29, 2009
	  
	                     
*/

/* From code version:                                                            */

/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/



#include <stdlib.h>

#include "G729EV_CELP2S_encod.h"
#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729B_dtx.h"
#include "G729EV_G729B_enc_sid.h"
#include "G729EV_G729EVDTX_sp2no_trans.h"


/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_InitEncoder()                    *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *   Variables initialisation for the G.729 coder            *
 *-----------------------------------------------------------*/

void G729EV_CELP2S_InitEncoder(G729EV_G729_CODSTAT * pCodStat,  /* (o)  Core coder parameters   */
                               Word16 rate,                      /* (i)  coder rate              */
                               Word16 dtx_max_fr)              /* (i)  maximum number of consecutive zero-frames (0 = infinite) */
{
  Word16    i;

  pCodStat->rate = rate;
#if (WMOPS)
  move16();
#endif

  /* Static vectors to zero */

  G729EV_G729_Set_zero(pCodStat->old_speech, G729EV_G729_MEM_SPEECH);
  G729EV_G729_Set_zero(pCodStat->old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  G729EV_G729_Set_zero(pCodStat->old_wsp, G729EV_G729_PIT_MAX);

  G729EV_G729_Set_zero(pCodStat->mem_syn, G729EV_G729_M);
  G729EV_G729_Set_zero(pCodStat->mem_w, G729EV_G729_M);
  G729EV_G729_Set_zero(pCodStat->mem_w0, G729EV_G729_M);
  G729EV_G729_Set_zero(pCodStat->mem_w0_2, G729EV_G729_M_LPC);
  G729EV_G729_Set_zero(pCodStat->mem_err2, G729EV_G729_M_LPC);
  G729EV_G729_Set_zero(pCodStat->mem_err, G729EV_G729_M);

  G729EV_G729_Set_zero(pCodStat->mem_synth, G729EV_G729_M_LPC);

  pCodStat->pit_sharp = G729EV_G729_SHARPMIN;
#if (WMOPS)
  move16();
#endif

  /* Initialize past_qua_en */
  pCodStat->past_qua_en[0] = (Word16) (-14336);
  pCodStat->past_qua_en[1] = (Word16) (-14336);
  pCodStat->past_qua_en[2] = (Word16) (-14336);
  pCodStat->past_qua_en[3] = (Word16) (-14336);
#if (WMOPS)
  move16();
  move16();
  move16();
  move16();
#endif

  /* Initialize lsp_old[] */
  G729EV_G729_Copy(G729EV_DTX_LSP_INIT, pCodStat->lsp_old, G729EV_G729_M);

  /* Initialize lsp_old_q[] */
  G729EV_G729_Copy(pCodStat->lsp_old, pCodStat->lsp_old_q, G729EV_G729_M);

  G729EV_G729_Lsp_encw_reset(pCodStat->freq_prev);

  FOR(i = 0; i < 4; i++)
  {
    pCodStat->L_exc_err[i] = (Word32) 0x00004000L;  /* Q14 */
#if (WMOPS)
    move32();
#endif
  }

  pCodStat->smooth = (Word16) 1;
#if (WMOPS)
  move16();
#endif

  pCodStat->lar_old[0] = (Word16) 0;
  pCodStat->lar_old[1] = (Word16) 0;
#if (WMOPS)
  move16();
  move16();
#endif

  G729EV_G729_Set_zero(pCodStat->old_A, G729EV_G729_MP1);
  pCodStat->old_A[0] = (Word16) 4096;
#if (WMOPS)
  move16();
#endif
  G729EV_G729_Set_zero(pCodStat->old_rc, 2);

  pCodStat->pit_old = (Word16) 40;
#if (WMOPS)
  move16();
#endif
  /* For G.729B */
  /* Initialize VAD/DTX parameters */
  pCodStat->pastVad = pCodStat->ppastVad = 1;
#if (WMOPS)
  move16();
  move16();
#endif
  G729EV_G729_Copy(pCodStat->lsp_old, pCodStat->lsp_mean, G729EV_G729_M);
  pCodStat->seed = INIT_SEED;
  pCodStat->dtx_max_fr = dtx_max_fr;
#if (WMOPS)
  move16();
  move16();
#endif 
    pCodStat->seed2 = INIT_SEED;
#if(WMOPS)
  move16();
#endif
  return;
}



/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_encoder()                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *  Core Codec Encoder                                       *
 *-----------------------------------------------------------*/

void G729EV_CELP2S_encoder(G729EV_G729_CODSTAT * pCodStat,  /* (i)  core coder states vaiables  */ 
                           Word16 * DataIn,                 /* (i)  data to encode              */
                           Word16 * coder_parameters,       /* (o)  coder parameters            */
                           Word16 * DataSynth,                /* (o)  : Output synthesis                        */
                           Word16 SubFrNum,                 /* (i)  Subframe number             */
                           Word16 * celp_Az,                /* (i)  Az buffer                   */
                           Word16 * sp_sync,                /* (0) weighted synthesis           */
                           Word16 * resBF8k,                /* (o)  residual signal frame       */
                           Word16 * pit,                    /* (o)  open loop pitch             */
                           Word16 * t0_out,                 /* (o)  close loop integer pitch    */
                           Word16 * t0_fout,                /* (o)  close loop fract. pitch     */
                           Word16 * voicing,                /* (o)  frame voicing               */
                           Word16 * ee,                     /* (o)  spectral tilt info.         */
                           Word16 * diff,                   /* (o)  difference signal between   */
						   Word16 *SID_tdbwe_parameters,	/* Q10*/
						   Word16 *tdbwe_parameters		    /* Q10*/
                                                            /*     synthesis at 12 kbit/s       */
                            )
{
  Word32    L_temp;

  Word16    r_l[G729EV_G729_MP1], r_h[G729EV_G729_MP1]; /* Autocorrelations low and hi */
  Word16    rc[G729EV_G729_M];  /* Reflection coefficients. */
  Word16    A_t[(G729EV_G729_MP1) * 2]; /* A(z) unquantized for the 2 subframes */
  Word16    Aq_t[(G729EV_G729_MP1) * 2];  /* A(z) quantized for the 2 subframes */
  Word16    Ap1[G729EV_G729_MP1]; /* A(z) with spectral expansion */
  Word16    Ap2[G729EV_G729_MP1]; /* A(z) with spectral expansion */
  Word16    lsp_new[G729EV_G729_M];
  Word16    lsp_new_q[G729EV_G729_M];
  Word16    lsf_int[G729EV_G729_M]; /* Interpolated LSF 1st subframe */
  Word16    lsf_new[G729EV_G729_M];
  Word16    gamma1[2], gamma2[2]; /* Weighting factor for the 2 subframes  */
  Word16    synth_buf[G729EV_G729_L_FRAME]; /* Synthesis signal */
  Word16    old_wsp[G729EV_G729_L_FRAME + G729EV_G729_PIT_MAX];
  Word16    old_exc[G729EV_G729_L_FRAME + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];
  Word16    ai_zero[G729EV_G729_L_SUBFR + G729EV_G729_M_LPC1];
  Word16    mem_err[G729EV_G729_M_LPC + G729EV_G729_L_SUBFR]; /* Filter memory */
  Word16    h1[G729EV_G729_L_SUBFR];  /* Impulse response h1[]               */
  Word16    xn[G729EV_G729_L_SUBFR];  /* Target vector for pitch search      */
  Word16    xn2[G729EV_G729_L_SUBFR]; /* Target vector for codebook search   */
  Word16    code[G729EV_G729_L_SUBFR];  /* Fixed codebook excitation           */
  Word16    y1[G729EV_G729_L_SUBFR];  /* Filtered adaptive excitation        */
  Word16    y2[G729EV_G729_L_SUBFR];  /* Filtered fixed codebook excitation  */
  Word16    g_coeff[4];         /* Correlations between xn & y1       */
  Word16    g_coeff_cs[5];      /* Corelations between xn, y1, & y2, <y1,y1> */
  Word16    exp_g_coeff_cs[5];  /* -2<xn,y1>, <y2,y2>, -2<xn,y2>, 2<y1,y2> */
  Word16    old_speech[G729EV_G729_L_TOTAL];

  Word16	*A, *Aq;             /* Pointer on A_t and Aq_t         */
  Word16	*ana;                /* Pointer on analysis parameters */
  Word16	*synth_ptr;          /* Pointer on synthesis buffer */
  Word16	*new_speech;         /* Pointer on new speech */
  Word16	*speech;             /* Pointer on speech */
  Word16	*p_window;           /* Pointer on p_window; */
  Word16	*wsp;                /* Pointer on old_wsp */
  Word16	*exc;                /* Pointer on old_exc, exitation vector */
  Word16	*zero;               /* Pointer on ai_zero */
  Word16	*error;              /* Pointer on mem_err, filter's memory */
  Word16    i, k, i_subfr, i_gamma, i0;
  Word16    T_op, T0, T0_min, T0_max, T0_frac;
  Word16    gain_pit, gain_code, index;
  Word16    temp;
  Word16	*ana2;
  Word16    index_enha, ii;
  Word16    gain_code_enha = 0;
  Word16    exc2[G729EV_G729_L_FRAME];
  Word16    mem_err2[G729EV_G729_M_LPC + G729EV_G729_L_SUBFR], *error2;
  Word16    xn_enha[G729EV_G729_L_SUBFR]; /* Target vector for codebook search  */
  Word16    code_enha[G729EV_G729_L_SUBFR]; /* Fixed codebook excitation          */
  Word16    y2_enha[G729EV_G729_L_SUBFR]; /* Filtered fixed codebook excitation */
  Word16    exc_enha[G729EV_G729_L_FRAME];
  Word16    res1[G729EV_G729_L_SUBFR];
  Word16    norm_voiced_fac, voice_fac;
  Word16	*ptr, *ptr2;
  

  /*----------------------------------------------------------------------*
  *      Initialize pointers to speech vector.                            *
  *                                                                       *
  *                                                                       *
  *   |--------------------|-------------|-------------|------------|     *
  *     previous speech           sf1           sf2         L_NEXT        *
  *                                                                       *
  *   <----------------  Total speech vector (L_TOTAL)   ----------->     *
  *   <----------------  LPC analysis window (L_WINDOW)  ----------->     *
  *   |                   <-- present frame (L_FRAME) -->                 *
  * old_speech            |              <-- new speech (L_FRAME) -->     *
  * p_window              |              |                                *
  *                     speech           |                                *
  *                             new_speech                                *
  *-----------------------------------------------------------------------*/

  new_speech = old_speech + G729EV_G729_MEM_SPEECH; /* New speech     */
  p_window = old_speech + G729EV_G729_L_TOTAL - G729EV_G729_L_WINDOW; /* For LPC window */
  speech = new_speech - G729EV_G729_L_NEXT; /* Present frame  */
  synth_ptr = synth_buf;

  G729EV_G729_Copy(pCodStat->old_speech, old_speech, G729EV_G729_MEM_SPEECH);
  G729EV_G729_Copy(DataIn, new_speech, G729EV_G729_L_FRAME);

  wsp = old_wsp + G729EV_G729_PIT_MAX;

  G729EV_G729_Copy(pCodStat->old_wsp, old_wsp, G729EV_G729_PIT_MAX);

  exc = old_exc + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL;

  G729EV_G729_Copy(pCodStat->old_exc, old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);

  error = mem_err + G729EV_G729_M;
  error2 = mem_err2 + G729EV_G729_M_LPC;

  G729EV_G729_Copy(pCodStat->mem_err, mem_err, G729EV_G729_M_LPC);
  G729EV_G729_Copy(pCodStat->mem_err2, mem_err2, G729EV_G729_M_LPC);

  zero = ai_zero + G729EV_G729_M_LPC1;
  ana = coder_parameters;
  ana2 = coder_parameters + G729EV_G729_PRM_SIZE;

  G729EV_G729_Set_zero(ai_zero, (G729EV_G729_L_SUBFR + G729EV_G729_M_LPC1));

  /*------------------------------------------------------------------------*
  *  - Perform LPC analysis:                                               *
  *       * autocorrelation + lag windowing                                *
  *       * Levinson-durbin algorithm to find a[]                          *
  *       * convert a[] to lsp[]                                           *
  *       * quantize and code the LSPs                                     *
  *       * find the interpolated LSPs and convert to a[] for the 2        *
  *         subframes (both quantized and unquantized)                     *
  *------------------------------------------------------------------------*/

  /* LP analysis */

  G729EV_G729_AutocorrLPC(p_window, G729EV_G729_M, r_h, r_l, &voice_fac); 	/* Autocorrelations */
  G729EV_G729_Copy(r_h, Ap2, G729EV_G729_MP1);	/* Ap2, MSB of frame autocorrelation */
  G729EV_G729_Lag_window(G729EV_G729_M, r_h, r_l);  /* Lag windowing    */

  /* Levinson Durbin  */
  gain_code = G729EV_G729_Levinson(r_h, r_l, &A_t[G729EV_G729_MP1], rc, pCodStat->old_A, pCodStat->old_rc);
  /*rc[0] = -R1/R0; in Q15 */
  *ee = shr(negate(rc[0]), 1);  /*Q14 output */
#if (WMOPS)
  move16();
#endif
  G729EV_G729_Az_lsp(&A_t[G729EV_G729_MP1], lsp_new, pCodStat->lsp_old);  /* From A(z) to lsp */

  /* LSP quantization */
  /* For G.729B */
  /* ------ VAD ------- */
  IF (sub(pCodStat->Vad, 1) != 0)
	  G729EV_update_cng(pCodStat, Ap2, voice_fac, pCodStat->Vad);
  /*--------------------------------------------------------------------*
  * Find interpolated LPC parameters in all subframes (both quantized  *
  * and unquantized).                                                  *
  * The interpolated parameters are in array A_t[] of size (M+1)*4     *
  * and the quantized interpolated parameters are in array Aq_t[]      *
  *--------------------------------------------------------------------*/

  G729EV_G729_Int_lpc(pCodStat->lsp_old, lsp_new, lsf_int, lsf_new, A_t);
  /* update the LSPs for the next frame */

  G729EV_G729_Copy(lsp_new, pCodStat->lsp_old, G729EV_G729_M);
  /*----------------------------------------------------------------------*
  * - Find the weighting factors                                         *
  *----------------------------------------------------------------------*/

  G729EV_G729_perc_var(gamma1, gamma2, lsf_int, lsf_new, rc, &pCodStat->smooth, pCodStat->lar_old);

  /*----------------------------------------------------------------------*
  * - Find the weighted input speech w_sp[] for the whole speech frame   *
  * - Find the open-loop pitch delay                                     *
  *----------------------------------------------------------------------*/
  G729EV_G729_Weight_Az(&A_t[0], gamma1[0], G729EV_G729_M, Ap1);
  G729EV_G729_Weight_Az(&A_t[0], gamma2[0], G729EV_G729_M, Ap2);
  G729EV_G729_Residu(Ap1, &speech[0], &wsp[0], G729EV_G729_L_SUBFR);
  G729EV_G729_Syn_filt(Ap2, &wsp[0], &wsp[0], G729EV_G729_L_SUBFR, pCodStat->mem_w, 1);

  G729EV_G729_Weight_Az(&A_t[G729EV_G729_MP1], gamma1[1], G729EV_G729_M, Ap1);
  G729EV_G729_Weight_Az(&A_t[G729EV_G729_MP1], gamma2[1], G729EV_G729_M, Ap2);
  G729EV_G729_Residu(Ap1, &speech[G729EV_G729_L_SUBFR], &wsp[G729EV_G729_L_SUBFR], G729EV_G729_L_SUBFR);
  G729EV_G729_Syn_filt(Ap2, &wsp[G729EV_G729_L_SUBFR], &wsp[G729EV_G729_L_SUBFR], G729EV_G729_L_SUBFR, pCodStat->mem_w,
                       1);
  /* ---------------------- */
  /* Case of Inactive frame */
  /* ---------------------- */
  /* Vad is based on AMR-WB VAD and uses 20 ms frame length */ 
  IF (pCodStat->Vad == 0)
  {
	  Word16 lsfq_mem[G729EV_G729_MA_NP][G729EV_G729_M];
	  Word16 coreExc[G729EV_G729_L_SUBFR];
	  Word16 prev_exc[G729EV_MAIN_L_FRAME2];

#if(WMOPS)
  test();
#endif
	  IF(pCodStat->transition_flag != 0)
		  G729EV_Pitch_copy(pCodStat->old_exc, prev_exc, pCodStat->old_pitch);		

	  FOR (i = 0; i < G729EV_G729_MA_NP; i++) 
		  G729EV_G729_Copy(&pCodStat->freq_prev[i][0], &lsfq_mem[i][0], G729EV_G729_M);

	  G729EV_cod_cng (pCodStat, SubFrNum, exc, Aq_t, ana, lsfq_mem, SID_tdbwe_parameters,tdbwe_parameters);
	  G729EV_post_cng(pCodStat->transition_flag, prev_exc, exc, &(pCodStat->subfr_num));

	  FOR (i = 0; i < G729EV_G729_MA_NP; i++) 
		  G729EV_G729_Copy(&lsfq_mem[i][0], &pCodStat->freq_prev[i][0], G729EV_G729_M);
	  
      pCodStat->ppastVad = pCodStat->pastVad;
	  pCodStat->pastVad = pCodStat->Vad;
#if (WMOPS)
    move16();
    move16();
#endif

	  /* UPDATE wsp, mem_w, mem_syn, mem_err, and mem_w0 */
	  A  = A_t;     /* pointer to interpolated LPC parameters           */
	  Aq = Aq_t;    /* pointer to interpolated quantized LPC parameters */
	  i_gamma = 0;
#if (WMOPS)
    move16();
    move16();
    move16();
#endif
  	  FOR(i0 = 0; i0 < G729EV_G729_L_FRAME / G729EV_G729_L_SUBFR; i0++)
  	  {
    	  i_subfr = i_mult(i0, G729EV_G729_L_SUBFR);
		  
		  G729EV_G729_Weight_Az(A, gamma1[i_gamma], G729EV_G729_M, Ap1);
		  G729EV_G729_Weight_Az(A, gamma2[i_gamma], G729EV_G729_M, Ap2);
		  i_gamma = add(i_gamma, 1);
		  IF(pCodStat->g729_bst == 0)
		  {
			  G729EV_G729_Copy(&exc[i_subfr], coreExc, G729EV_G729_L_SUBFR);
			  G729EV_fir_filt(coreExc, 0, pCodStat->filt_temp, G729EV_G729_L_SUBFR);

		  }  
		  /* update mem_syn */
		
		  IF(pCodStat->g729_bst == 0)
			  G729EV_G729_Syn_filt(Aq, coreExc, &synth_ptr[i_subfr], G729EV_G729_L_SUBFR, pCodStat->mem_syn, 1);
		  ELSE
			  G729EV_G729_Syn_filt(Aq, &exc[i_subfr], &synth_ptr[i_subfr], G729EV_G729_L_SUBFR, pCodStat->mem_syn, 1);
		  /* update mem_w0 */
		  FOR (i = 0; i < G729EV_G729_L_SUBFR; i++)
			  error[i] = sub(speech[i_subfr+i], synth_ptr[i_subfr+i]);
		  G729EV_G729_Residu(Ap1, error, xn, G729EV_G729_L_SUBFR);
		  G729EV_G729_Syn_filt(Ap2, xn, xn, G729EV_G729_L_SUBFR, pCodStat->mem_w0, 1);
		  
		  /* update mem_err */
		  G729EV_G729_Copy(&error[G729EV_G729_L_SUBFR-G729EV_G729_M], mem_err, G729EV_G729_M);
		  A += G729EV_G729_MP1;
		  Aq += G729EV_G729_MP1; 
	  }
	  
      pCodStat->pit_sharp = G729EV_G729_SHARPMIN;
#if (WMOPS)
    move16();
#endif
	  
	  /* Update memories for next frames */
	  G729EV_G729_Copy(mem_err, pCodStat->mem_err, G729EV_G729_M_LPC);
	  G729EV_G729_Copy(mem_err, pCodStat->mem_err2, G729EV_G729_M_LPC);
      G729EV_G729_Copy(&old_speech[G729EV_G729_L_FRAME], &pCodStat->old_speech[0], G729EV_G729_L_TOTAL-G729EV_G729_L_FRAME);
      G729EV_G729_Copy(&old_wsp[G729EV_G729_L_FRAME], &pCodStat->old_wsp[0], G729EV_G729_PIT_MAX);
      G729EV_G729_Copy(&old_exc[G729EV_G729_L_FRAME], &pCodStat->old_exc[0], G729EV_G729_PIT_MAX+G729EV_G729_L_INTERPOL);
      G729EV_G729_Copy(synth_ptr, DataSynth, G729EV_G729_L_FRAME);
	  G729EV_G729_Copy(pCodStat->mem_syn, pCodStat->mem_synth, G729EV_G729_M);
	  return;
  }  /* End of inactive frame case */

  pCodStat->seed = pCodStat->seed2 = INIT_SEED;

  pCodStat->ppastVad = pCodStat->pastVad;
#if (WMOPS)
    move16();
	move16();
	move16();
#endif
  pCodStat->pastVad = pCodStat->Vad;
  /* LSP quantization */

  {Word16 fact1, fact2;

  IF (sub(pCodStat->Vad, 2) == 0) fact1=16384;
  ELSE                    fact1=29491;
#if (WMOPS)
	move16();
#endif

  fact2 = (Word16)L_sub(32768L, fact1);

  ii = negate(add(16, voice_fac));
  temp=norm_s(gain_code);
  gain_code=shl(gain_code, temp);
  ii=add(ii, temp);

  G729EV_linear_compose(&gain_code, &ii,  &pCodStat->energy_lt, &pCodStat->sh_energy_lt, fact1, fact2);
}
  G729EV_G729_Qua_lsp (lsp_new, lsp_new_q, ana, pCodStat->freq_prev);
  ana += 2;
  G729EV_G729_Int_qlpc (pCodStat->lsp_old_q, lsp_new_q, Aq_t);
  G729EV_G729_Copy (Aq_t, &celp_Az[2 * SubFrNum * G729EV_G729_MP1], 2*G729EV_G729_MP1);
  G729EV_G729_Copy (lsp_new_q, pCodStat->lsp_old_q, G729EV_G729_M);
  /* long term spectrum parameters */
  FOR(i = 0; i < G729EV_G729_M; i++)
      pCodStat->lsp_mean[i] = extract_l(L_shr(L_add((Word32)pCodStat->lsp_mean[i], (Word32)lsp_new_q[i]), 1));
  /* Find open loop pitch lag */
  T_op = G729EV_G729_Pitch_ol(wsp, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX,
                              G729EV_G729_L_FRAME, voicing, &(pCodStat->pit_old));

  /* Range for closed loop pitch search in 1st subframe */

  T0_min = sub(T_op, 3);

  if (sub(T0_min, G729EV_G729_PIT_MIN) < 0)
  {
    T0_min = G729EV_G729_PIT_MIN;
#if (WMOPS)
    move16();
#endif
  }

  T0_max = add(T0_min, 6);

  IF(sub(T0_max, G729EV_G729_PIT_MAX) > 0)
  {
    T0_max = G729EV_G729_PIT_MAX;
    T0_min = sub(T0_max, 6);
#if (WMOPS)
    move16();
#endif
  }

   /*------------------------------------------------------------------------*
    *          Loop for every subframe in the analysis frame                 *
    *------------------------------------------------------------------------*
    *  To find the pitch and innovation parameters. The subframe size is     *
    *  G729EV_G729_L_SUBFR and the loop is repeated 2 times.                 *
    *     - find the weighted LPC coefficients                               *
    *     - find the LPC residual signal res[]                               *
    *     - compute the target signal for pitch search                       *
    *     - compute impulse response of weighted synthesis filter (h1[])     *
    *     - find the closed-loop pitch parameters                            *
    *     - encode the pitch delay                                           *
    *     - update the impulse response h1[] by including fixed-gain pitch   *
    *     - find target vector for codebook search                           *
    *     - codebook search                                                  *
    *     - encode codebook address                                          *
    *     - VQ of pitch and codebook gains                                   *
    *     - find synthesis speech                                            *
    *     - update states of weighting filter                                *
    *------------------------------------------------------------------------*/
  A = A_t;                      /* pointer to interpolated LPC parameters           */
  Aq = Aq_t;                    /* pointer to interpolated quantized LPC parameters */

  i_gamma = 0;

#if (WMOPS)
  move16();
#endif

  FOR(i0 = 0; i0 < G729EV_G729_L_FRAME / G729EV_G729_L_SUBFR; i0++)
  {
    i_subfr = i_mult(i0, G729EV_G729_L_SUBFR);

    /*---------------------------------------------------------------*
     * Find the weighted LPC coefficients for the weighting filter.  *
     *---------------------------------------------------------------*/

    G729EV_G729_Weight_Az(A, gamma1[i_gamma], G729EV_G729_M, Ap1);
    G729EV_G729_Weight_Az(A, gamma2[i_gamma], G729EV_G729_M, Ap2);
    i_gamma = add(i_gamma, 1);

    /*---------------------------------------------------------------*
    * Compute impulse response, h1[], of weighted synthesis filter  *
    *---------------------------------------------------------------*/

    G729EV_G729_Copy(Ap1, ai_zero, G729EV_G729_MP1);

    G729EV_G729_Syn_filt(Aq, ai_zero, h1, G729EV_G729_L_SUBFR, zero, 0);
    G729EV_G729_Syn_filt(Ap2, h1, h1, G729EV_G729_L_SUBFR, zero, 0);

    /*------------------------------------------------------------------------*
    *                                                                        *
    *          Find the target vector for pitch search:                      *
    *          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                       *
    *                                                                        *
    *              |------|  res[n]                                          *
    *  speech[n]---| A(z) |--------                                          *
    *              |------|       |   |--------| error[n]  |------|          *
    *                    zero -- (-)--| 1/A(z) |-----------| W(z) |-- target *
    *                    exc          |--------|           |------|          *
    *                                                                        *
    * Instead of subtracting the zero-input response of filters from         *
    * the weighted input speech, the above configuration is used to       *
    * compute the target vector. This configuration gives better performance *
    * with fixed-point implementation. The memory of 1/A(z) is updated by    *
    * filtering (res[n]-exc[n]) through 1/A(z), or simply by subtracting     *
    * the synthesis speech from the input speech:                            *
    *    error[n] = speech[n] - syn[n].                                      *
    * The memory of W(z) is updated by filtering error[n] through W(z),      *
    * or more simply by subtracting the filtered adaptive and fixed          *
    * codebook excitations from the target:                                  *
    *     target[n] - gain_pit*y1[n] - gain_code*y2[n]                       *
    * as these signals are already available.                                *
    *                                                                        *
    *------------------------------------------------------------------------*/


    /* Input signal is in Q0 and the output residual signal is in Q1 */
    /* Since the input signal has been downscaled by two during pre-processing and
       because the LP filter is expected to produce a prediction gain, no saturation is
       expected when setting the excitation in Q1 */
    G729EV_G729_Residu2(Aq, &speech[i_subfr], &exc[i_subfr], G729EV_G729_L_SUBFR);  /* LPC residual */

    IF(sub(pCodStat->rate, 12000) >= 0)
    {
      /* Save residual. This input will be needed to compute the error signal in the residual domain */
      G729EV_G729_Copy(&exc[i_subfr], &exc2[i_subfr], G729EV_G729_L_SUBFR);
    }
    G729EV_G729_Syn_filt2(Aq, &exc[i_subfr], error, G729EV_G729_L_SUBFR, mem_err, 0);

    G729EV_G729_Residu2(Ap1, error, xn, G729EV_G729_L_SUBFR);

    /* xn is in Q1 prior to the synthesis filter and in Q0 after... */
    G729EV_G729_Syn_filt2(Ap2, xn, xn, G729EV_G729_L_SUBFR, pCodStat->mem_w0, 0); /* target signal xn[] */


    /* Save residual signal (will be needed to compute second second stage target */
    G729EV_G729_Copy(exc + i_subfr, res1, G729EV_G729_L_SUBFR);

    /*----------------------------------------------------------------------*
    *                 Closed-loop fractional pitch search                  *
    *----------------------------------------------------------------------*/

    /* function G729EV_G729_Convolve (used in G729EV_G729_Pitch_fr3) has been modified
       from the original G.729 standard to account for the new Q1 format used for the excitation */

    T0 = G729EV_G729_Pitch_fr3(&exc[i_subfr], xn, h1, G729EV_G729_L_SUBFR, T0_min, T0_max, i_subfr, &T0_frac);

    index = G729EV_G729_Enc_lag3(T0, T0_frac, &T0_min, &T0_max, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX, i_subfr);

    *ana++ = index;
#if (WMOPS)
    move16();
#endif
    IF(i_subfr == 0)
    {
      *ana++ = G729EV_G729_Parity_Pitch(index);
#if (WMOPS)
      move16();
#endif
    }
    *pit++ = T0;
#if (WMOPS)
    move16();
#endif
	pCodStat->old_pitch = T0;
#if (WMOPS)
    move16();
#endif
    /*-----------------------------------------------------------------*
    *   - find unity gain pitch excitation (adaptive codebook entry)  *
    *     with fractional interpolation.                              *
    *   - find filtered pitch exc. y1[]=exc[] convolve with h1[])     *
    *   - compute pitch gain and limit between 0 and 1.2              *
    *   - update target vector for codebook search                    *
    *   - find LTP residual.                                          *
    *-----------------------------------------------------------------*/


    G729EV_G729_Pred_lt_3(&exc[i_subfr], T0, T0_frac, G729EV_G729_L_SUBFR);

    /* function G729EV_G729_Convolve has been modified
       from the original G.729 standard to account for the new Q1 format used for the excitation 
       Therefore, exc is in Q1 but y1 remains in Q12 */

    G729EV_G729_Convolve(&exc[i_subfr], h1, y1, G729EV_G729_L_SUBFR);

    gain_pit = G729EV_G729_G_pitch(xn, y1, g_coeff, G729EV_G729_L_SUBFR);

    /* clip pitch gain if taming is necessary */
    temp = G729EV_G729_test_err(pCodStat, T0, T0_frac);


    IF(sub(temp, 1) == 0)
    {
      if (sub(gain_pit, G729EV_G729_GPCLIP) > 0)
      {
        gain_pit = G729EV_G729_GPCLIP;
#if (WMOPS)
        move16();
#endif
      }
    }

    /* xn2[i]   = xn[i] - y1[i] * gain_pit  */

    ptr = xn2;
    FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      L_temp = L_mult(y1[i], gain_pit);
      L_temp = L_shl(L_temp, 1);  /* gain_pit in Q14 */
      *ptr++ = sub(xn[i], extract_h(L_temp));
#if (WMOPS)
      move16();
#endif
    }


    /*-----------------------------------------------------*
    * - Innovative codebook search.                       *
    *-----------------------------------------------------*/
    {
      Word16    h[G729EV_G729_L_SUBFR];

      /* The impulse respond h1 should not be modified by the codebook search routine because           
         it will be used as an input to the second inovative codebook search. h1 is therefore                         
         duplicated into a temporary memory space before calling G729EV_G729_ACELP_code_A_OTH */

      G729EV_G729_Copy(h1, h, G729EV_G729_L_SUBFR);

      /* Compute residual after long term prediction */
      FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
      {
        L_temp = L_mult(res1[i], 16384);
        L_temp = L_msu(L_temp, exc[i + i_subfr], gain_pit); /* gain_pit in Q14 */
        L_temp = L_shl(L_temp, 1);
        res1[i] = round(L_temp);
      }

      index = G729EV_CELP2S_ACELP_code_A_OTH(xn2, res1, h, T0, pCodStat->pit_sharp, code, y2, &i, y1);

      *ana++ = index;           /* Positions index */
      *ana++ = i;               /* Signs index     */
#if (WMOPS)
      move16();
      move16();
#endif
    }

     /*-----------------------------------------------------*
      * - Quantization of gains.                            *
      *-----------------------------------------------------*/
    g_coeff_cs[0] = g_coeff[0]; /* <y1,y1> */
    exp_g_coeff_cs[0] = negate(g_coeff[1]); /* Q-Format:XXX -> JPN  */
    g_coeff_cs[1] = negate(g_coeff[2]); /* (xn,y1) -> -2<xn,y1> */
    exp_g_coeff_cs[1] = negate(add(g_coeff[3], 1)); /* Q-Format:XXX -> JPN  */
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif

    G729EV_G729_Corr_xy2(xn, y1, y2, g_coeff_cs, exp_g_coeff_cs); /* Q0 Q0 Q12 ^Qx ^Q0 */

#if (WMOPS)
    move16();
#endif
    *ana++ = G729EV_G729_Qua_gain(code, g_coeff_cs, exp_g_coeff_cs,
                                  G729EV_G729_L_SUBFR, &gain_pit, &gain_code, temp, pCodStat->past_qua_en);

    voice_fac = G729EV_FEC_voice_factor(exc + i_subfr, gain_pit, code, gain_code);
    norm_voiced_fac = extract_l(L_shr(L_add(voice_fac, 32768), 1));

	pCodStat->old_gp = gain_pit;	/* Q14 */
#if (WMOPS)
    move16();
#endif
     /*------------------------------------------------------*
      * - Find the total excitation                          *
      * - find synthesis speech corresponding to exc[]       *
      * - update filters memories for finding the target     *
      *   vector in the next subframe                        *
      *   (update error[-m..-1] and mem_w_err[])             *
      *   update error function for taming process           *
      *------------------------------------------------------*/
    ptr = exc + i_subfr;
    FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      /* exc[i] = gain_pit*exc[i] + gain_code*code[i]; */
      /* exc[i]  in Q1   gain_pit in Q14               */
      /* code[i] in Q13  gain_cod in Q1                */

      L_temp = L_mult(code[i], gain_code);  /* Q13 * Q1 -> Q15 */
      L_temp = L_shl(L_temp, 1);  /* Q15 -> Q16  */
      L_temp = L_mac(L_temp, exc[i + i_subfr], gain_pit); /* Q1 * Q14 -> Q16 */
      L_temp = L_shl(L_temp, 1);  /* Q16 -> Q17  */
      *ptr++ = round(L_temp);   /* exc in Q1   */
#if (WMOPS)
      move16();
#endif
    }

    /* G729EV_G729_Syn_filt2 takes into account that exc is in Q1 to produce Q0 outputs */
    G729EV_G729_Syn_filt2(Aq, &exc[i_subfr], &synth_ptr[i_subfr], G729EV_G729_L_SUBFR, pCodStat->mem_syn, 1);



    /* Addition of a second fixed codebook (12Kbit/s mode)   */
    IF(sub(pCodStat->rate, 12000) >= 0)
    {

      Word16    i;
      Word16    res2[G729EV_G729_L_SUBFR];


      /* Compute the error signal (input to the second stage) in the residual domain */
      /* exc  -> residual of the 1st stage output signal                             */
      /* exc2 -> residual of the input signal                                        */
      ptr = res2;
      FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
      {
        *ptr++ = sub(exc2[i + i_subfr], exc[i + i_subfr]);
#if (WMOPS)
        move16();
#endif
      }
      /* exc2 -> residual of the error signal                                        */


      /*--------------------------------------------------------*        
      * Find the target vector for the second fixed codebook   *
      *--------------------------------------------------------*/


      G729EV_G729_Syn_filt2(Aq, res2, error2, G729EV_G729_L_SUBFR, mem_err2, 0);
      G729EV_G729_Residu2(Ap1, error2, xn_enha, G729EV_G729_L_SUBFR);
      /* xn_enha is in Q1 as an input to G729EV_G729_Syn_filt2 and in Q0 as an output */
      G729EV_G729_Syn_filt2(Ap2, xn_enha, xn_enha, G729EV_G729_L_SUBFR, pCodStat->mem_w0_2, 0); /* target signal xn_enha[] */


                                                     /*-----------------------------------------------------*
                                                     * - Innovative codebook search.                       *
      *-----------------------------------------------------*/


      /* search in fixed-codebook:  */
      index_enha = G729EV_CELP2S_ACELP_code_2NDLAYER(xn_enha, res2, h1, norm_voiced_fac, code_enha, y2_enha, &ii);

      *ana2++ = index_enha;     /* Positions index */
      *ana2++ = ii;             /* Signs index     */
#if (WMOPS)
      move16();
      move16();
#endif

      i = add(i0, shl(SubFrNum, 1));


      {
        /* quantize second fixed codebook gain */
        index = G729EV_CELP2S_qua_gain_Stage2(gain_code, xn_enha, y2_enha, G729EV_G729_L_SUBFR, i);

        /* Save Gain index */
        *ana2++ = index;
#if (WMOPS)
        move16();
#endif

        /* Get Quantized gain value */
        gain_code_enha = G729EV_CELP2S_dec_gain_Stage2(gain_code, index, i);

      }


      /*-----------------------------------------------------*
      *   Find final output excitation                      *
      * exc_enha =  exc[] + gain_code_enha * code_enha[]    *
      *    exc[] = gain_pit * exc[-T] + gain_code * code [] * 
      *-----------------------------------------------------*/


      ptr = exc_enha + i_subfr;
      FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
      {
        /* exc_enha[i+i_subfr] = gain_code_enha * code_enha[i] + exc[i+i_subfr] */
        /* exc[i]  in Q1                                            */
        /* code_enha[i] in Q13  gain_code_enha in Q1                */

        L_temp = L_mult(code_enha[i], gain_code_enha);  /* Q13 * Q1 -> Q15  */
        L_temp = L_shl(L_temp, 1);  /* Q15 -> Q16       */
        L_temp = L_mac(L_temp, exc[i + i_subfr], 16384);  /* Q1 * Q_14 -> Q16 */
        L_temp = L_shl(L_temp, 1);  /* Q16 -> Q17 */
        *ptr++ = round(L_temp); /* exc_enha in Q1 */
#if (WMOPS)
        move16();
#endif

      }


      /* Compute synthesis signal. exc_enha[] / A(z)    */
      /* G729EV_G729_Syn_filt2 takes into account that exc_enha is in Q1 to produce Q0 outputs */
      G729EV_G729_Syn_filt2(Aq, &exc_enha[i_subfr], &DataSynth[i_subfr], G729EV_G729_L_SUBFR, pCodStat->mem_synth, 1);

      /* compute difference signal between input and local synthesis */
      FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
      {
        diff[i_subfr + i] = sub(speech[i_subfr + i], DataSynth[i_subfr + i]);
#if(WMOPS)
        move16();
#endif

      }
    }

	/* long term energy */
	G729EV_adjust_gain(&pCodStat->Ga_gain_mean, &pCodStat->Gf_gain_mean, gain_pit, gain_code, gain_code_enha);
     /*------------------------------------------------------------*
      * - Update pitch sharpening "sharp" with quantized gain_pit  *
      *------------------------------------------------------------*/

    pCodStat->pit_sharp = gain_pit;
#if (WMOPS)
    move16();
#endif

    if (sub(pCodStat->pit_sharp, G729EV_G729_SHARPMAX) > 0)
    {
      pCodStat->pit_sharp = G729EV_G729_SHARPMAX;
#if (WMOPS)
      move16();
#endif
    }

    if (sub(pCodStat->pit_sharp, G729EV_G729_SHARPMIN) < 0)
    {
      pCodStat->pit_sharp = G729EV_G729_SHARPMIN;
#if (WMOPS)
      move16();
#endif
    }

    G729EV_G729_update_exc_err(pCodStat->L_exc_err, gain_pit, T0);




    ptr = mem_err;
    ptr2 = pCodStat->mem_w0;
    FOR(i = G729EV_G729_L_SUBFR - G729EV_G729_M; i < G729EV_G729_L_SUBFR; i++)
    {
      *ptr++ = sub(speech[i_subfr + i], synth_ptr[i_subfr + i]);
      temp = extract_h(L_shl(L_mult(y1[i], gain_pit), 1));
      k = extract_h(L_shl(L_mult(y2[i], gain_code), 2));
      *ptr2++ = sub(xn[i], add(temp, k));
#if (WMOPS)
      move16();
      move16();
#endif
    }


    IF(sub(pCodStat->rate, 12000) >= 0)
    {
      ptr = mem_err2;
      ptr2 = pCodStat->mem_w0_2;
      FOR(i = G729EV_G729_L_SUBFR - G729EV_G729_M; i < G729EV_G729_L_SUBFR; i++)
      {
        *ptr++ = sub(speech[i_subfr + i], DataSynth[i_subfr + i]);
        k = extract_h(L_shl(L_mult(y2_enha[i], gain_code_enha), 2));
        *ptr2++ = sub(xn_enha[i], k);
#if (WMOPS)
        move16();
        move16();
#endif
      }
    }

    A += G729EV_G729_MP1;       /* interpolated LPC parameters for next subframe */
    Aq += G729EV_G729_MP1;


  }


  /* at this stage DataSynth comprises the synthesis at 12k while synth_ptr comprises
     the synthesis at 8k if the rate is 8k, overwrite DataSynth */
	IF (sub(pCodStat->rate, 8000) == 0)
	{
		G729EV_G729_Copy(synth_ptr, DataSynth, G729EV_G729_L_FRAME);
		G729EV_G729_Copy(pCodStat->mem_syn, pCodStat->mem_synth, G729EV_G729_M);
	}


  IF(pCodStat->g729_bst == 0)
	  G729EV_G729_Copy(&exc[G729EV_G729_L_FRAME-FILTERORDER], pCodStat->filt_temp, FILTERORDER);

    /*-------------------------------------------------*
    * Update signal for next frame.                    *
    * -> shift to the left by G729EV_G729_L_FRAME:     *
    *     speech[], wsp[], exc[] and exc2[]            *
    *--------------------------------------------------*/

  G729EV_G729_Copy(mem_err, pCodStat->mem_err, G729EV_G729_M_LPC);
  G729EV_G729_Copy(&old_wsp[G729EV_G729_L_FRAME], &pCodStat->old_wsp[0], G729EV_G729_PIT_MAX);
  G729EV_G729_Copy(&old_exc[G729EV_G729_L_FRAME], &pCodStat->old_exc[0], G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  G729EV_G729_Copy(&old_speech[G729EV_G729_L_FRAME], &pCodStat->old_speech[0], G729EV_G729_MEM_SPEECH);
  G729EV_G729_Copy(mem_err2, pCodStat->mem_err2, G729EV_G729_M_LPC);

  /* Find wsyn *//* 0.268 WMOPS should validate a another domain to compute SNR tv */
  *t0_out = T0;
  *t0_fout = T0_frac;
#if (WMOPS)
  move16();
  move16();
#endif

  G729EV_G729_Copy(exc2, resBF8k, G729EV_G729_L_FRAME);
  G729EV_G729_Copy(speech, sp_sync, G729EV_G729_L_FRAME);
  return;
}
