/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

/*------------------------------------------------------------------------*/
/* From Original Version :                                                */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B Floating point ANSI C source code      */
/*   Copyright (C) 1999, AT&T, France Telecom, NTT, University of         */
/*   Sherbrooke, Conexant, Ericsson.                                      */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B - Reference C code for Floating point  */
/*                         implementation of G.729 Annex AB               */
/*                                                                        */
/*========================================================================*/


#ifndef __G729EV_G729_DECSTAT_H__
#define __G729EV_G729_DECSTAT_H__

#include <stdio.h>
#include "stl.h"
#include "G729EV_G729_defines.h"
#include "G729EV_MAIN_defines.h"

#include "typedef.h"

/* Structure of the decoder status variables */

typedef struct
{
  Word16    old_exc[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];  /* Excitation vector */
  Word16    lsp_old[G729EV_G729_M];                                 /* Line Spectral Pairs */
  Word16    mem_syn[G729EV_G729_M_LPC];                             /* Filter's memory */
  Word16    freq_prev[G729EV_G729_MA_NP][G729EV_G729_M];            /* Q13  previous LSP vector        */
  Word16    prev_lsp[G729EV_G729_M];                                /* Q13 previous LSP vector  */
  Word16    past_qua_en[4];                                         /* Q10 Past quantized energies */
  Word16    mem_zero[G729EV_G729_M_LPC];    /* null memory to compute h_st */
  Word16    apond2[G729EV_G729_LONG_H_ST];  /* s.t.numerator coef */
  Word16    mem_res2[G729EV_G729_SIZ_RES2]; /* memory of A(gamma2) residual */

  Word16    rate;               /* Rate */
  Word16    seed_fer;
  Word16    sharp;              /* Pitch sharpening of previous frame */
  Word16    gain_code;          /* Q1 Code gain */
  Word16    gain_pitch;         /* Q14 pitch gain   */
  Word16    prev_ma;            /* Previous MA prediction coef */

  Word16    lp_gainp;			/* Q14 */
  Word16    lp_gainc;			/* Q3 */
  Word16    i_subfr_cnt;
  Word16    tilt_code;          /* Q15 */
  Word16    stab_fac;			/* Q15 */
  Word16    upd_cnt;
  Word32    Lenr_old;
  Word16    fpitch[2];          /* Q5  */
  Word16    old_fpitch;         /* Q5 */
  Word16    bfi_cnt;

  Word16    pit_mem[5];			/* Q5 */
  Word16    bfi_mem;            /* Q0 */
  Word16    MemTam[G729EV_G729_MEM_LEN_TAM]; /* Q7 */

  /* G.729B mode */
  Word16    g729b_bst;
  Word16    ftyp[2];
  Word16    sid_sav;
  Word16    sh_sid_sav;
  Word16    sid_gain;           /* Q2 */
  Word16    past_ftyp;
  Word16    seed;
  Word16 sid_nb;				
  Word16 counter_k;
  Word16 counter_n;
  Word16 seed2;
  Word16 pre_gain;		/* Q2 */
  Word16 pre_lsp[G729EV_G729_M];	/* Q15 */
  Word16 sid_lsp[G729EV_G729_M];	/* Q15 */
  Word16 old_pitch;                 /* Q5  */
  Word16 old_gp;					/* Q14 */
  Word16 bfi_factor;                /* Q8  */
  Word16 lsp_mean[G729EV_G729_M];   /* Q15 */    
  Word16 Ga_gain_mean;				/* Q14 */
  Word16 Gf_gain_mean;				/* Q1  */
  Word16 step_counter;				/* int */
  Word16 VAD_flag_change_counter;
  Word16 VAD_flag_change_counter_move;	/* Q1 */
  Word16  gain_change_hangover;    
  Word16 transition_flag;
  Word16 prev_type;
  Word16 subfr_num;
  Word16 filt_temp[FILTERORDER];
  Word16 counter_n_lt;

} G729EV_G729_DECSTAT;




#endif  /*__G729EV_G729_DECSTAT_H__ */
