/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

/*
   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/

/*
**
**
** Description:     Comfort noise generation
**                  performed at the decoder part
**
*/

#include "G729EV_G729_tab_ld8k.h"
#include "G729EV_G729B_sid.h"
#include "G729EV_G729B_dtx.h"
#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_MAIN_oper_32b.h"


/*-----------------------------------------------------------*
 * procedure Dec_cng:                                        *
 *           ~~~~~~~~                                        *
 *                     Receives frame type                   *
 *                     0  :  for untransmitted frames        *
 *                     2  :  for SID frames                  *
 *                     Decodes SID frames                    *
 *                     Computes current frame excitation     *
 *                     Computes current frame LSPs
 *-----------------------------------------------------------*/
void G729EV_G729B_Dec_cng(G729EV_G729_DECSTAT * pDecStat, 
                          Word16 past_ftyp,   /* (i)   : past frame type                      */
                          Word16 sid_sav,     /* (i)   : energy to recover SID gain           */
                          Word16 sh_sid_sav,  /* (i)   : corresponding scaling factor         */
                          Word16 * parm,      /* (i)   : coded SID parameters                 */
                          Word16 * exc,       /* (i/o) : excitation array                     */
                          Word16 * lspOld,    /* (i/o) : previous lsp                         */
                          Word16 * A_t,       /* (o)   : set of interpolated LPC coefficients */
                          Word16 * seed,      /* (i/o) : random generator seed                */
                          Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                              /* (i/o) : previous LPS for quantization        */
                          Word16 ftyp,
						  Word16 bfi
)
{
	Word16    temp, ind, i, hi, lo, tmp_gain;
	Word16 dist, dist_lsp;       /* Q15 */
	Word16 cur_lsf[G729EV_G729_M];
	Word32 tmp_exc_err[4], L_temp;
	Word16 Ratio_3rd_idx = 0;

  G729EV_G729_Set_zero(exc, G729EV_MAIN_L_FRAME4);    	   

  /* SID Frame */
  /*************/
#if(WMOPS)
  test();
  test();
  test();
  test();
#endif
  /*pDecStat->old_gain,*sid_gain in Q2.  */
	IF(((pDecStat->g729b_bst == 0)&&(sub(past_ftyp, 1) > 0)&&(ftyp == 0))
		||((sub(pDecStat->g729b_bst, 1) == 0)&&(ftyp != 0)))
	{
		if(pDecStat->g729b_bst == 0)
		{
#if(WMOPS)
    move16();
#endif
			parm -= G729EV_G729_PRM_SIZE_MAX;
		}

    pDecStat->counter_n = pDecStat->counter_k;
    pDecStat->counter_k = 0;
#if(WMOPS)
    move16();
    move16();
#endif
	L_temp = L_mult(pDecStat->counter_n_lt, (Word16)31130); /* 31130(Q15) = 0.95 */
	pDecStat->counter_n_lt = round(L_mac(L_temp, pDecStat->counter_n, (Word16)1638)); /* 1638(Q15) = 0.05 */
        
    pDecStat->sid_gain = tab_Sidgain[parm[3]];            /* Q2 */
#if(WMOPS)
    move16();
#endif
    IF(pDecStat->sid_nb)
    {
		IF(sub(parm[3], 6)<0) 
			pDecStat->sid_gain =round(L_shl(L_mult(pDecStat->sid_gain, tab_Sidgain2[parm[5]]), 1));
		ELSE  
			pDecStat->sid_gain =round(L_shl(L_mult(pDecStat->sid_gain, tab_Sidgain3[parm[5]]), 1));
    }
	
    Ratio_3rd_idx = shr(parm[3], 2);

    /* Inverse quantization of the LSP */
    sid_lsfq_decode(&parm[0], pDecStat->sid_lsp, freq_prev, noise_fg, pDecStat->sid_nb,Ratio_3rd_idx);
  }

	/* generate energe and Az of nodata frame   */
	/* D  = (Psid - Pk-1)/(|k-N|+1)             */
	/* Pk = Pk-1+D+rand(-D/2,D/2)               */
	/* P0 = Psid_old                            */

		/* pDecStat->cur_lsp must be in Q15.pDecStat->old_gain,*sid_gain in Q2. */
		ind = extract_h(Inv_x((Word32)add(abs_s(sub(pDecStat->counter_k, pDecStat->counter_n)), 1)));
		dist = mult_r(sub(pDecStat->sid_gain, pDecStat->pre_gain), ind);            /* dist -> Q2 */
		pDecStat->pre_gain = add(pDecStat->pre_gain, dist);
		FOR(i = 0; i < G729EV_G729_M; i++)
		{
			dist_lsp = mult_r(sub(pDecStat->sid_lsp[i], pDecStat->pre_lsp[i]), ind);   /* Q15 */
			temp = shr(mult_r(G729EV_G729_Random(&pDecStat->seed2), dist_lsp), 1);
			pDecStat->pre_lsp[i] =add(add(pDecStat->pre_lsp[i], dist_lsp), temp);
		}

    IF(sub(past_ftyp, 1) == 0) 
	{
		/* initial spectrum and energy paramters */
		G729EV_G729_Copy(pDecStat->lsp_mean, pDecStat->pre_lsp, G729EV_G729_M);  
		pDecStat->counter_k = 2*DTX_HANG_CONST-1;
#if(WMOPS)
    move16();
#endif
		pDecStat->pre_gain = round(L_mult(pDecStat->Gf_gain_mean, (Word16)26214));
		/* 26214(Q16) = 0.4 */
	}

	/* check the stabilty */
	G729EV_G729_Lsp_lsf2(pDecStat->pre_lsp ,cur_lsf, G729EV_G729_M);
	G729EV_G729_Lsp_expand_1_2(cur_lsf, G729EV_G729_GAP1);
	G729EV_G729_Lsp_expand_1_2(cur_lsf, G729EV_G729_GAP2);
	G729EV_G729_Lsp_stability(cur_lsf);
	G729EV_G729_Lsf_lsp2(cur_lsf, pDecStat->pre_lsp, G729EV_G729_M);

	if(bfi)
		pDecStat->sid_gain = mult(pDecStat->sid_gain, G729EV_G729B_ATTEN_COEFF);

	/* Compute new excitation */
	IF(sub(pDecStat->counter_n_lt, 40) > 0)
	{
		temp = mult(30720, shl(pDecStat->VAD_flag_change_counter_move, 4));		/* temp-> Q0  */
		ind = add(add(temp,  ATTENUATION_CONST), pDecStat->counter_n);			/* ind -> Q0  */
		L_Extract(L_shr(Inv_x(L_deposit_l(ind)), 1), &hi, &lo);
		temp = mult(extract_l(Mpy_32_16(hi, lo, add(temp, pDecStat->gain_change_hangover))), 3277);					/* temp[Q15] < 1 */						
		tmp_gain = mult_r(pDecStat->pre_gain, add(29491,temp));                                 /* tmp_gain -> Q2 */
	}
	ELSE
	{
#if(WMOPS)
    move16();
#endif
		tmp_gain = pDecStat->pre_gain;
	}


	G729EV_calc_exc_rand(tmp_gain, exc, seed, FLAG_DEC, tmp_exc_err,
		pDecStat->past_ftyp, &(pDecStat->old_pitch), &(pDecStat->old_gp), 
		&(pDecStat->pre_gain), &(pDecStat->i_subfr_cnt), &(pDecStat->lp_gainp),
		&(pDecStat->lp_gainc), &(pDecStat->tilt_code));
	
#if(WMOPS)
  test();
#endif
	IF((pDecStat->g729b_bst == 0) && (past_ftyp == 1))
	{
		pDecStat->sid_gain = pDecStat->pre_gain;
#if(WMOPS)
    move16();
#endif
		G729EV_G729_Copy(pDecStat->pre_lsp, pDecStat->sid_lsp, G729EV_G729_M);  
	} 
     /* Interpolate the Lsp vectors */
    G729EV_G729_Int_qlpc(lspOld, pDecStat->pre_lsp, A_t);
    G729EV_G729_Copy(pDecStat->pre_lsp, lspOld, G729EV_G729_M);
    pDecStat->counter_k = add(pDecStat->counter_k, 1);

  return;
}
void sid_lsfq_decode(Word16 * index,  /* (i) : quantized indices    */
                     Word16 * lspq,   /* (o) : quantized lsp vector */
                     Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i) : memory of predictor  */
                     Word16 noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M],
                     Word16 sid_nb,
			         Word16 Ratio_3rd_idx
					 )
{
  Word16    lsfq[G729EV_G729_M], tmpbuf[G729EV_G729_M];
  Word16    i;
  
  	Word16 tmpbuf1[G729EV_G729_M];       /* Q13 */
  /* get the lsf error vector */
  G729EV_G729_Copy(lspcb1[PtrTab_1[index[1]]], tmpbuf, G729EV_G729_M);
  FOR(i = 0; i < G729EV_G729_M / 2; i++)
  {
    tmpbuf[i] = add(tmpbuf[i], lspcb2[PtrTab_2[0][index[2]]][i]); /* Q13 */
#if(WMOPS)
    move16();
#endif
  }
  FOR(i = G729EV_G729_M / 2; i < G729EV_G729_M; i++)
  {
    tmpbuf[i] = add(tmpbuf[i], lspcb2[PtrTab_2[1][index[2]]][i]); /* Q13 */
#if(WMOPS)
    move16();
#endif
  }
  
    /*the tmpbuf[] in Q13,ratio_cb2[] in Q14, lspcb2[][] in Q13;*/
	G729EV_G729_Copy(tmpbuf, tmpbuf1, G729EV_G729_M);

	IF(sid_nb)
	{
		FOR (i=0; i<G729EV_G729_M/2; i++)
		{
			tmpbuf[i] = add(tmpbuf[i], mult_r(ratio_cb2[Ratio_3rd_idx] , shl(lspcb2[PtrTab_3[0][index[4]]][i], 1)));
              #if(WMOPS)
                      move16();
              #endif      
		}
		FOR (i=G729EV_G729_M/2; i<G729EV_G729_M; i++)
		{
			tmpbuf[i] = add(tmpbuf[i], mult_r(ratio_cb2[Ratio_3rd_idx] , shl(lspcb2[PtrTab_3[1][index[4]]][i], 1)));
              #if(WMOPS)
                      move16();
              #endif    
		}

	}
  /* guarantee minimum distance of 0.0012 (~10 in Q13) between tmpbuf[j] and tmpbuf[j+1]*/
  G729EV_G729_Lsp_expand_1_2(tmpbuf, 10);
  /* compute the quantized lsf vector */
  G729EV_G729_Lsp_prev_compose(tmpbuf, lsfq, noise_fg[index[0]], freq_prev, noise_fg_sum[index[0]]);

  /* update the prediction memory */
  G729EV_G729_Lsp_prev_update(tmpbuf1, freq_prev);

  /* lsf stability check */
  G729EV_G729_Lsp_stability(lsfq);

  /* convert lsf to lsp */
  G729EV_G729_Lsf_lsp2(lsfq, lspq, G729EV_G729_M);
}
