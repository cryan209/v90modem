/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"


/* Constants defined in ld8a.h */
/* G729EV_G729_L_SUBFR   -> Length of subframe.                                        */
/* G729EV_G729_NB_POS    -> Number of positions for each pulse.                        */
/* G729EV_G729_STEP      -> Step between position of the same pulse.                   */
/* G729EV_G729_MSIZE     -> Size of vectors for cross-correlation between two pulses.  */


/*--------------------------------------------------------------------------*
 *  Function  Corr_h_X()                                                    *
 *  ~~~~~~~~~~~~~~~~~~~~                                                    *
 * Compute  correlations of input response h[] with the target vector X[].  *
 *--------------------------------------------------------------------------*/

void G729EV_G729_Cor_h_X(Word16 h[],  /* (i) Q12 :Impulse response of filters      */
                         Word16 X[],  /* (i)     :Target vector                    */
                         Word16 D[],  /* (o)     :Correlations between h[] and D[] */
                                      /*          Normalized to 13 bits            */
                         Word16 stp   /* (i): starting point              */
    )
{
  Word32    y32[G729EV_G729_L_SUBFR];
  Word32    s, max, L_temp;
  Word16    i, j;



  /* first keep the result on 32 bits and find absolute maximum */

#if (WMOPS)
  move32();
#endif
  max = 0;

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
#if (WMOPS)
    move32();
#endif
    s = 0;

    FOR(j = sub(i, stp); j < G729EV_G729_L_SUBFR; j++)
    {
      s = L_mac(s, X[j], h[j - i]);
    }

#if (WMOPS)
    move32();
#endif
    y32[i] = s;

    s = L_abs(s);
    L_temp = L_sub(s, max);

    if (L_temp > 0L)
    {
#if (WMOPS)
      move32();
#endif
      max = s;
    }
  }

  /* Find the number of right shifts to do on y32[]  */
  /* so that maximum is on 13 bits                   */

  j = norm_l(max);

  if (sub(j, 16) > 0)
  {
#if (WMOPS)
    move16();
#endif
    j = 16;
  }

  j = sub(18, j);

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    D[i] = extract_l(L_shr(y32[i], j));
#if (WMOPS)
    move16();
#endif
  }

  return;

}


/*--------------------------------------------------------------------------*
 *  Function  Cor_h()                                                       *
 *  ~~~~~~~~~~~~~~~~~                                                       *
 * Compute  correlations of h[]  needed for the codebook search.            *
 *--------------------------------------------------------------------------*/

void G729EV_G729_Cor_h(Word16 * H,  /* (i) Q12 :Impulse response of filters */
                       Word16 * rr  /* (o)     :Correlations of H[]         */
    )
{
  Word32    cor;
  Word16    tmp1;

  Word16    h1[G729EV_G729_L_SUBFR + 1], *h;

  Word16   *rri0i0, *rri1i1, *rri2i2, *rri3i3, *rri4i4;
  Word16   *rri0i1, *rri0i2, *rri0i3, *rri0i4;
  Word16   *rri1i2, *rri1i3, *rri1i4;
  Word16   *rri2i3, *rri2i4;
  Word16   *p0, *p1, *p2, *p3, *p4;
  Word16   *ptr_hd, *ptr_hf, *ptr_h1, *ptr_h2;

  Word16    i, k, ldec, l_fin_sup, l_fin_inf;


  /* Scaling h[] for maximum precision */

#if (WMOPS)
  move32();
#endif
  h = h1 + 1;
  cor = 0;


  FOR(i = -1; i < G729EV_G729_L_SUBFR; i++)
    cor = L_mac(cor, H[i], H[i]);

  IF(sub(extract_h(cor), 32000) > 0)
  {
    FOR(i = -1; i < G729EV_G729_L_SUBFR; i++)
    {
#if (WMOPS)
      move16();
#endif
      h[i] = shr(H[i], 1);
    }
  }
  ELSE
  {
    k = norm_l(cor);
    k = shr(k, 1);

    FOR(i = -1; i < G729EV_G729_L_SUBFR; i++)
    {
#if (WMOPS)
      move16();
#endif
      h[i] = shl(H[i], k);
    }
  }


 /*------------------------------------------------------------*
  * Compute rri0i0[], rri1i1[], rri2i2[], rri3i3 and rri4i4[]  *
  *------------------------------------------------------------*/
  /* Init pointers */
  rri0i0 = rr;
  rri1i1 = rri0i0 + G729EV_G729_NB_POS;
  rri2i2 = rri1i1 + G729EV_G729_NB_POS;
  rri3i3 = rri2i2 + G729EV_G729_NB_POS;
  rri4i4 = rri3i3 + G729EV_G729_NB_POS;
  rri0i1 = rri4i4 + G729EV_G729_NB_POS;
  rri0i2 = rri0i1 + G729EV_G729_MSIZE;
  rri0i3 = rri0i2 + G729EV_G729_MSIZE;
  rri0i4 = rri0i3 + G729EV_G729_MSIZE;
  rri1i2 = rri0i4 + G729EV_G729_MSIZE;
  rri1i3 = rri1i2 + G729EV_G729_MSIZE;
  rri1i4 = rri1i3 + G729EV_G729_MSIZE;
  rri2i3 = rri1i4 + G729EV_G729_MSIZE;
  rri2i4 = rri2i3 + G729EV_G729_MSIZE;

  p0 = rri0i0 + G729EV_G729_NB_POS - 1; /* Init pointers to last position of rrixix[] */
  p1 = rri1i1 + G729EV_G729_NB_POS - 1;
  p2 = rri2i2 + G729EV_G729_NB_POS - 1;
  p3 = rri3i3 + G729EV_G729_NB_POS - 1;
  p4 = rri4i4 + G729EV_G729_NB_POS - 1;


  ptr_h1 = h - 1;
  cor = L_mult(*ptr_h1, *ptr_h1);
  ptr_h1++;
  tmp1 = round(cor);

  FOR(i = 0; i < G729EV_G729_NB_POS; i++)
  {
    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p4-- = extract_h(cor);

    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p3-- = extract_h(cor);

    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p2-- = extract_h(cor);

    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p1-- = extract_h(cor);

    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p0-- = extract_h(cor);

#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
    move16();
#endif
  }

#if (WMOPS)
  move16();
#endif
  *(p0 + 1) = sub(*(p0 + 1), tmp1);

 /*-----------------------------------------------------------------*
  * Compute elements of: rri2i3[], rri1i2[], rri0i1[] and rri0i4[]  *
  *-----------------------------------------------------------------*/

#if (WMOPS)
  move16();
  move16();
  move16();
#endif
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - (Word16) 1;
  ldec = G729EV_G729_NB_POS + 1;

  ptr_hd = h;
  ptr_hf = ptr_hd + 1;

  FOR(k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p3 = rri2i3 + l_fin_sup;
    p2 = rri1i2 + l_fin_sup;
    p1 = rri0i1 + l_fin_sup;
    p0 = rri0i4 + l_fin_inf;

    ptr_h1 = ptr_hd - 1;
    ptr_h2 = ptr_hf - 1;
    cor = L_mult(*ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;


    FOR(i = k + (Word16) 1; i < G729EV_G729_NB_POS; i++)
    {

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p3 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p2 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p1 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p0 = extract_h(cor);

      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;

#if (WMOPS)
      move16();
      move16();
      move16();
      move16();
#endif
    }
    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p3 = extract_h(cor);

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p2 = extract_h(cor);

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p1 = extract_h(cor);
#if (WMOPS)
    move16();
    move16();
    move16();
#endif

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

 /*---------------------------------------------------------------------*
  * Compute elements of: rri2i4[], rri1i3[], rri0i2[], rri1i4[], rri0i3 *
  *---------------------------------------------------------------------*/

#if (WMOPS)
  move16();
  move16();
#endif
  ptr_hd = h;
  ptr_hf = ptr_hd + 2;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - (Word16) 1;

  FOR(k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p4 = rri2i4 + l_fin_sup;
    p3 = rri1i3 + l_fin_sup;
    p2 = rri0i2 + l_fin_sup;
    p1 = rri1i4 + l_fin_inf;
    p0 = rri0i3 + l_fin_inf;

    ptr_h1 = ptr_hd - 1;
    ptr_h2 = ptr_hf - 1;
    cor = L_mult(*ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;

    FOR(i = k + (Word16) 1; i < G729EV_G729_NB_POS; i++)
    {

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p4 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p3 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p2 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p1 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p0 = extract_h(cor);

#if (WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
#endif

      p4 -= ldec;
      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p4 = extract_h(cor);

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p3 = extract_h(cor);

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p2 = extract_h(cor);

#if (WMOPS)
    move16();
    move16();
    move16();
#endif

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

 /*----------------------------------------------------------------------*
  * Compute elements of: rri1i4[], rri0i3[], rri2i4[], rri1i3[], rri0i2  *
  *----------------------------------------------------------------------*/

#if (WMOPS)
  move16();
  move16();
#endif
  ptr_hd = h;
  ptr_hf = ptr_hd + 3;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - (Word16) 1;

  FOR(k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p4 = rri1i4 + l_fin_sup;
    p3 = rri0i3 + l_fin_sup;
    p2 = rri2i4 + l_fin_inf;
    p1 = rri1i3 + l_fin_inf;
    p0 = rri0i2 + l_fin_inf;

    ptr_h1 = ptr_hd - 1;
    ptr_h2 = ptr_hf - 1;
    cor = L_mult(*ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;


    FOR(i = k + (Word16) 1; i < G729EV_G729_NB_POS; i++)
    {

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p4 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p3 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p2 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p1 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p0 = extract_h(cor);

#if (WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
#endif

      p4 -= ldec;
      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p4 = extract_h(cor);

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p3 = extract_h(cor);

#if (WMOPS)
    move16();
    move16();
#endif

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

 /*----------------------------------------------------------------------*
  * Compute elements of: rri0i4[], rri2i3[], rri1i2[], rri0i1[]          *
  *----------------------------------------------------------------------*/

#if (WMOPS)
  move16();
  move16();
#endif
  ptr_hd = h;
  ptr_hf = ptr_hd + 4;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - (Word16) 1;


  FOR(k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p3 = rri0i4 + l_fin_sup;
    p2 = rri2i3 + l_fin_inf;
    p1 = rri1i2 + l_fin_inf;
    p0 = rri0i1 + l_fin_inf;

    ptr_h1 = ptr_hd - 1;
    ptr_h2 = ptr_hf - 1;
    cor = L_mult(*ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;


    FOR(i = k + (Word16) 1; i < G729EV_G729_NB_POS; i++)
    {

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p3 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p2 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p1 = extract_h(cor);

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p0 = extract_h(cor);

#if (WMOPS)
      move16();
      move16();
      move16();
      move16();
#endif

      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p3 = extract_h(cor);
#if (WMOPS)
    move16();
#endif

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }
  return;
}
