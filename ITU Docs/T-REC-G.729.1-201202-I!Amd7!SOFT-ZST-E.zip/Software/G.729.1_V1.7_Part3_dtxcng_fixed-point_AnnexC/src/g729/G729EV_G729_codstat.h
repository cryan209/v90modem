/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

/*------------------------------------------------------------------------*/
/* From Original Version :                                                */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B Floating point ANSI C source code      */
/*   Copyright (C) 1999, AT&T, France Telecom, NTT, University of         */
/*   Sherbrooke, Conexant, Ericsson.                                      */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B - Reference C code for Floating point  */
/*                         implementation of G.729 Annex AB               */
/*                                                                        */
/*========================================================================*/


#ifndef __G729EV_G729_CODSTAT_H__
#define __G729EV_G729_CODSTAT_H__

#include <stdio.h>
#include "stl.h"
#include "typedef.h"
#include "basop32.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729B_defines.h"

/* Structure of the encoder status variables */


typedef struct
{
  Word32    L_exc_err[4];                       /* To tame the coder */

  Word16    old_speech[G729EV_G729_MEM_SPEECH]; /* Speech vector */
  Word16    old_wsp[G729EV_G729_PIT_MAX];       /* Weighted speech vector */
  Word16    old_exc[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];  /* Excitation vector */
  Word16    lsp_old[G729EV_G729_M];             /* Line Spectral Pairs */
  Word16    lsp_old_q[G729EV_G729_M];           /* Quantified LSP */
  Word16    mem_syn[G729EV_G729_M_LPC];         /* Filter's memory */
  Word16    mem_w0[G729EV_G729_M_LPC];
  Word16    mem_w[G729EV_G729_M_LPC];
  Word16    mem_err[G729EV_G729_M_LPC];
  Word16    old_A[G729EV_G729_MP1];             /* Q12, Last LPC coefs  */
  Word16    old_rc[2];							/* Q15 */
  Word16    freq_prev[G729EV_G729_MA_NP][G729EV_G729_M];  /* previous LSP vector  */
  Word16    past_qua_en[4];                     /* Past quantized energies */
  Word16    lar_old[2];

  Word16    rate;               /* Rate */
  Word16    pit_sharp;
  Word16    smooth;

  /* Excitation vector */
  Word16    mem_w0_2[G729EV_G729_M_LPC];
  Word16    mem_err2[G729EV_G729_M_LPC];
  Word16    mem_synth[G729EV_G729_M_LPC];      /* Filter's memory */

  Word16    pit_old;
	/* For G.729B */
	/* DTX variables */
	Word16 pastVad;		
	Word16 ppastVad;	
	Word16 lsp_mean[G729EV_G729_M];	/* Q15 */      
	Word16 Ga_gain_mean;            /* Q14 */			
	Word16 Gf_gain_mean;            /* Q1  */
	Word16 seed;
	Word16 Vad;
	Word16 hangover_count;
	Word16 cng_nb;
	Word16 dtx_max_fr;
	Word16 flag_chang_wb;
	Word16 counter_k;
	Word16 counter_n;
	Word16 seed2;
	Word16 pastCoeff[G729EV_G729_MP1];	/* Q12 */
	Word16 RCoeff[G729EV_G729_MP1];
	Word16 sh_RCoeff;					
	Word16 Acf[SIZ_ACF];
	Word16 sh_Acf[NB_CURACF];			
	Word16 sumAcf[SIZ_SUMACF];
    Word16 sh_sumAcf[NB_SUMACF];		
	Word16 ener[NB_GAIN];
	Word16 sh_ener[NB_GAIN];			
	Word16 fr_cur;


	Word16 pre_gain;	/* Q2 */
	Word16 nb_ener;		/* Q0 */
	Word16 sid_gain;	/* Q2 */
	Word16 prev_energy; /* Q2 */
	Word16 count_fr0;		/* Q0 */
	Word16 pre_lsp[G729EV_G729_M];	/* Q15 */
	Word16 sid_lsp[G729EV_G729_M];	/* Q15 */
	Word16 old_pitch;               /* Q0 */
	Word16 old_gp;                  /* Q14 */
	Word16  Nb_First_change_flag;                      
	Word16  Nb_Second_change_flag;                      
	Word16 SuperFrame_CurAcf[2][G729EV_G729_MP1];      
	Word16 sh_SuperFrame_CurAcf[2]; 
	Word32 SuperFrame_Ener[2]; 
	Word16 sh_SuperFrame_Ener[2];	
	Word16 energy_lt;
	Word16 sh_energy_lt;			
	Word16 step_counter;
	Word16 VAD_flag_change_counter;
	Word16 VAD_flag_change_counter_move;
	Word16  gain_change_hangover;    
	Word16 transition_flag;
	Word16 subfr_num;
	Word16 g729_bst;
	Word16 filt_temp[FILTERORDER];
	Word16 counter_n_lt;	/* Q0 */
} G729EV_G729_CODSTAT;




#endif  /*__G729EV_G729_CODSTAT_H__ */
