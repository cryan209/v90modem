/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#include "G729EV_TDBWE_encoder.h"

#include "G729EV_TDBWE_extract_time_envelope.h"
#include "G729EV_TDBWE_extract_frequency_envelope.h"
#include "G729EV_TDBWE_vector_quantization.h"
#include "G729EV_G729_ld8k.h"



/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_quantization()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Quantization of the TDBWE parameter set by "mean removed VQ"            *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_quantization(Word16 Vad,                /* (i) Vad classifier */
                               Word16 * parameters_tdbwe, /* (i) Q.10, the unquantized parameter set */
                               Word16 * coder_parameters) /* (o) codebook indices */
{
  Word16    i;
  UWord16   vq_index;
  Word16    mu, mu_q;
  Word16   *parameters;
  Word16   *coder_param_ptr;

  /* initialize pointer to TDBWE parameters */
  coder_param_ptr = coder_parameters;

  /* compute mean time envelope */
  mu = (Word16) 0;
#ifdef WMOPS
  move16();
#endif
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++)
  {
    mu = add(mu, shr(parameters[i], 3));
  }
  mu = shr(mu, 1);

  /* quantize mean */
  IF (Vad == 0)
    G729EV_TDBWE_vector_quantization(&mu,G729EV_TDBWE_MEAN_TIME_ENV_cb_DTX,
                                     &vq_index, 1, G729EV_TDBWE_MEAN_TIME_ENV_NUMBER_ENTRIES);
  ELSE
    G729EV_TDBWE_vector_quantization(&mu,G729EV_TDBWE_MEAN_TIME_ENV_cb,
                                     &vq_index, 1, G729EV_TDBWE_MEAN_TIME_ENV_NUMBER_ENTRIES);

  /* write vq_index to coder_parameters */
  *coder_param_ptr++ = vq_index;
#ifdef WMOPS
  move16();
#endif

  /* reconstruct quantized mean (table look-up) */
  IF (Vad == 0)
    mu_q = G729EV_TDBWE_MEAN_TIME_ENV_cb_DTX[vq_index];
  ELSE
    mu_q = G729EV_TDBWE_MEAN_TIME_ENV_cb[vq_index];
#ifdef WMOPS
  move16();
#endif
  /* remove quantized mean from time envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;  /* parameters_tdbwe + 0 */
  IF (Vad == 0)
    G729EV_G729_Set_zero(parameters, G729EV_TDBWE_NB_SUBFRAMES);
  ELSE
  {
    FOR(i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++)
    {
      parameters[i] = sub(parameters[i], mu_q);
#ifdef WMOPS
      move16();
#endif
    }
  }

  /* quantize mean-removed time envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_TIME_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {

    G729EV_TDBWE_vector_quantization(&parameters[i * 8],
                                     G729EV_TDBWE_TIME_ENV_cb, &vq_index, 8, G729EV_TDBWE_TIME_ENV_NUMBER_ENTRIES);

    /* write vq_index to coder_parameters */
    *coder_param_ptr++ = vq_index;
#ifdef WMOPS
    move16();
#endif

  }

  /* remove quantized mean from frequency envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
  {
    parameters[i] = sub(parameters[i], mu_q);
#ifdef WMOPS
    move16();
#endif
  }

  /* quantize mean-removed frequency envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_FREQ_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {

    G729EV_TDBWE_vector_quantization(&parameters[i * 4],
                                     G729EV_TDBWE_FREQ_ENV_cb[i],
                                     &vq_index, 4, G729EV_TDBWE_FREQ_ENV_NUMBER_ENTRIES[i]);

    /* write vq_index to coder_parameters */
    *coder_param_ptr++ = vq_index;
#ifdef WMOPS
    move16();
#endif
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_encoder_init()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Initialization of the TDBWE encoder                                     *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_encoder_init(G729EV_TDBWE_CODSTAT * state)  /* (o) */
{
  G729EV_G729_Set_zero(state->old_speech, G729EV_TDBWE_MEM_SPEECH);
  G729EV_G729_Set_zero(state->mem_parameters, G729EV_TDBWE_NB_PARAMETERS);
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_update_ltx_parameters()                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                          *
 *  save TDBWE encoder parameter last transmitted                           *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_update_ltx_parameters(G729EV_TDBWE_CODSTAT * state) /* (i/o)  */
{
  G729EV_G729_Copy(state->mem_parameters, state->ltx_parameters, G729EV_TDBWE_NB_PARAMETERS);
}

void G729EV_TDBWE_cngpar_extract(G729EV_TDBWE_CODSTAT * state, /* (i/o)  */
                                 Word16 * parameters,          /* (i/o)    Q.10, the unquantized parameter set */
                                 Word16 * flag_chang_wb,       /* (o)    indicate upper-band parameter change */
                                 Word16 * par_ptr)             /* (i)    delayed input */
{
	Word16    mean_NRJ, i, factor;
	Word16    temp_d, temp_ch;
	Word32    ACC0 = 0;

	IF(state->Vad == 0)
		factor = 0x1000;
	ELSE
		factor = 0x02ab;
#ifdef WMOPS
      move16();
#endif

	FOR (i=0; i<G729EV_TDBWE_NB_SUBFRAMES; i++)
    {
      /* const is HANGOVER_RATIO/NB_SUBFRAMES = 1/(6*16) = 1/96 = 0.010416666 in Q16 */
      ACC0 = L_mac0(ACC0, *par_ptr, factor);
      par_ptr++;
    }
    mean_NRJ = round(ACC0);
	IF (state->Vad == 0)
	{
		ACC0 = L_mult(mean_NRJ, ALPHA_TENV);
		ACC0 = L_mac(ACC0, state->mem_parameters[0], ONE_M_ALPHA_TENV);
		mean_NRJ = round(ACC0);
		temp_d = abs_s(sub(mean_NRJ, state->mem_parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE]));
		if (temp_d > G729EV_TDBWE_THR_TD)
			*flag_chang_wb = 1;
		temp_ch = abs_s(sub(mean_NRJ, state->ltx_parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE]));
		if (temp_ch > G729EV_TDBWE_THR_TC)
			*flag_chang_wb = 1;
	}
	ELSE if(state->Vad == 2)
		mean_NRJ = add(mean_NRJ, state->mem_parameters[0]);
    FOR (i=0; i<G729EV_TDBWE_NB_SUBFRAMES; i++)
    {
      state->mem_parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE+i] = mean_NRJ;
	  if(state->Vad == 0)
	  {
		  parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE+i] = mean_NRJ;
#ifdef WMOPS
      move16();
#endif
	  }

#ifdef WMOPS
      move16();
#endif
    }
}
/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_encoder_stage1()                                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                 *
 *  TDBWE encoder (parameter extraction),                                   *
 *  computes time/frequency envelopes                                       *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_encoder_stage1(G729EV_TDBWE_CODSTAT * state, /* (i/o)  */
                                 Word16 * input_hi,            /* (i)    Q.0, high band input signal @ 8kHz */
                                 Word16 * parameters,          /* (i)    Q.10, the unquantized parameter set */
                                 Word16 * flag_chang_wb,       /* (o)    indicate upper-band parameter change */
                                 Word16 * input_hi_delay)      /* (o)    delayed input */
{
  Word16   *new_speech;
  Word16   *speech;
  Word16    old_speech[G729EV_TDBWE_L_TOTAL];
  Word32    ACC0, ACC1;
  Word16    i;
  Word16    temp;                         /* Q10 */
  Word16    spec_d;
  Word16    spec_ch;
  Word16   *mem_ptr, *par_ptr, *ltx_ptr;

  /*-------------*
  * set pointers *
  *--------------*/

  new_speech = old_speech + G729EV_TDBWE_MEM_SPEECH;  /* New speech     */
  speech = new_speech - G729EV_TDBWE_L_NEXT;  /* Present frame  */
#if (WMOPS)
  move16();
  move16();
#endif

  /*--------------*
  * update buffer *
  *---------------*/

  G729EV_G729_Copy(state->old_speech, old_speech, G729EV_TDBWE_MEM_SPEECH);
  G729EV_G729_Copy(input_hi, new_speech, G729EV_TDBWE_L_FRAME);


  /*--------------------------------*
  * extract and quantize envelopes  *
  *---------------------------------*/

  /* time envelope extraction */
  G729EV_TDBWE_extract_time_envelope(speech + G729EV_TDBWE_DELTA_TIME_ENV, 0, /* nls */
                                     &parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE], G729EV_TDBWE_NB_SUBFRAMES);
    
  par_ptr = &parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE];
  ACC0 = 0;
#ifdef WMOPS
    move32();
#endif
	G729EV_TDBWE_cngpar_extract(state, parameters, flag_chang_wb, par_ptr);

	G729EV_TDBWE_extract_frequency_envelope(speech + (G729EV_TDBWE_L_FRAME2 + G729EV_TDBWE_DELTA_FREQ_ENV), 0,  /* nls */
                                          &parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE]);
  IF (sub(state->Vad, 3) == 0)
  {
    par_ptr = &parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
    mem_ptr = &state->mem_parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
    FOR (i=0; i<G729EV_TDBWE_NB_SUBBANDS; i++)
    {
      /* const is HANGOVER_RATIO = 1/6 in Q16 */
      ACC0 = L_mult0(*par_ptr, 0x2aab);
      *mem_ptr=round(ACC0);
      par_ptr++;
      mem_ptr++;
	  }
  }
  IF (sub(state->Vad, 2) == 0)
  {
    par_ptr = &parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
    mem_ptr = &state->mem_parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
    FOR (i=0; i<G729EV_TDBWE_NB_SUBBANDS; i++)
    {
      ACC0 = L_deposit_h(*mem_ptr);
      /* const is HANGOVER_RATIO = 1/6 in Q16 */
      ACC0 = L_mac0(ACC0, *par_ptr, 0x2aab);
      *mem_ptr=round(ACC0);
      par_ptr++;
      mem_ptr++;
    }
  }
  IF (state->Vad == 0)
  {
    par_ptr = &parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
    mem_ptr = &state->mem_parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
    FOR (i=0; i<G729EV_TDBWE_NB_SUBBANDS; i++)
    {
      ACC0 = L_mult(*par_ptr, ALPHA_FENV);
      ACC0 = L_mac(ACC0, *mem_ptr, ONE_M_ALPHA_FENV);
      *par_ptr = round(ACC0);
      par_ptr++;
      mem_ptr++;
    }
    ACC0 = (Word32) 0;
    ACC1 = (Word32) 0;
#ifdef WMOPS
    move32();
    move32();
#endif
    par_ptr = &parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
    mem_ptr = &state->mem_parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
    ltx_ptr = &state->ltx_parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
    FOR (i=0; i<G729EV_TDBWE_NB_SUBBANDS; i++)
    {
      /* const is 1/G729EV_TDBWE_NB_SUBBANDS = 1/12 = 0.0833 in Q16 */
      temp=abs_s(sub(*par_ptr,*mem_ptr));
      ACC0 = L_mac0(ACC0, temp, 0x1555);
      temp=abs_s(sub(*par_ptr,*ltx_ptr));
      ACC1 = L_mac0(ACC1, temp, 0x1555);
      *mem_ptr = *par_ptr;
      par_ptr++;
      mem_ptr++;
      ltx_ptr++;
    }
    spec_d = round(ACC0);
    if (spec_d > G729EV_TDBWE_THR_SD)
      *flag_chang_wb = 1;
    spec_ch = round(ACC1);
    if (spec_ch > G729EV_TDBWE_THR_SC)
      *flag_chang_wb = 1;
  }
  IF (sub(state->Vad, 2) == 0)
    G729EV_TDBWE_update_ltx_parameters(state);

  /*--------------*
  * update memory *
  *---------------*/
  G729EV_G729_Copy(&old_speech[G729EV_TDBWE_L_FRAME], state->old_speech, G729EV_TDBWE_MEM_SPEECH);
  G729EV_G729_Copy(speech, input_hi_delay, G729EV_TDBWE_L_FRAME);
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_encoder_stage2()                                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                 *
 *  TDBWE quantizer (parameter quantization),                               *
 *  quantize time/frequency envelopes                                       *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_encoder_stage2(G729EV_TDBWE_CODSTAT * state, /* (i/o)  */
                                 Word16 * parameters,          /* (i)    Q.10, the unquantized parameter set */
                                 Word16 * coder_parameters)    /* (o)    quantized parameter set (codebook indices) */
{
  /* quantize the parameter set and write bitstream */
  G729EV_TDBWE_quantization(state->Vad, parameters, coder_parameters);
}
