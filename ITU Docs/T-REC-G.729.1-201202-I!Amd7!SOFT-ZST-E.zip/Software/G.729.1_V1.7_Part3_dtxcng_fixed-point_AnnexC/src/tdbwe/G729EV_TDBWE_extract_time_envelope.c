/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#include "G729EV_TDBWE_extract_time_envelope.h"

#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_MAIN_oper_32b.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_extract_time_envelope()                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                     *
 *  TDBWE time envelope (segment energy) computation                        *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_extract_time_envelope(Word16 * signal,          /* (i) Q.nls, original highband input signal */
                                        Word16 nls,               /* (i) normalization of input signal */
                                        Word16 * envelope,        /* (o) Q.10, time envelope parameters */
                                        Word16 number_subframes)  /* (i) number of consecutive subframes in signal[] */
{
  Word32    ACC0;
  Word16   *ptr_signal;
  Word16    i, k;
  Word16    log_int, log_frac;
  Word16    norm;

  ptr_signal = signal;

  /* loop over all segments */
  FOR(i = 0; i < number_subframes; i++)
  {
    ACC0 = (Word32) 0;
#ifdef WMOPS
    move32();
#endif

    /* accumulate square sample values */
    FOR(k = 0; k < G729EV_TDBWE_SUBFRAME_SIZE; k++)
    {
      ACC0 = L_mac0(ACC0, *ptr_signal, *ptr_signal);
      ptr_signal++;
    }


    /* compute (1/2)log2 of segment energies */

    /* Normalize ACC0 before Log2 for max precision */
    norm = norm_l(ACC0);
    ACC0 = L_shl(ACC0, norm);

    Log2(ACC0, &log_int, &log_frac);
    norm = add(norm, shl(nls, 1));
    ACC0 = L_Comp(sub(log_int, norm), log_frac);  /* ACC0 = envelope[i] in Q17 */

    envelope[i] = extract_h(L_shl(ACC0, 9));  /* envelope[i] in Q10 */
    envelope[i] = sub(envelope[i], 0x6A4);  /* log2(10)/2 = 0x6A4 in Q10 */
#ifdef WMOPS
    move16();
    move16();
#endif
  }
}
