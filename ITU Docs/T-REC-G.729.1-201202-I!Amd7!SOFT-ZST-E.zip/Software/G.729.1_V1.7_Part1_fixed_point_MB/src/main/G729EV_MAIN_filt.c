/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>

#include "stl.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_decod.h"
#include "G729EV_MAIN_oper_32b.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_set_gamma()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Set adaptive gamma parameters of lower-band postfilter                  *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_set_gamma(Word16 * output_lo,  /* (i)    lower-band synthesis prior to postfiltering */
                           Word16 * tab_Th,     /* (i/o)  median filter memory */
                           Word16 rate,         /* (i)    decoder bit rate */
                           Word16 * ga1_post,   /* (o)    gamma parameter */
                           Word16 * ga2_post    /* (o)    gamma parameter */
    )
{
  /* Variables declarations */
  Word32    L_temp;

  Word16    i, j;
  Word16    Th;

  /* set gammas */
  IF(sub(rate, 14000) >= 0)     /* >= 14 kbit/s */
  {
    *ga1_post = G729EV_G729_GAMMA1_PST12K;
    *ga2_post = G729EV_G729_GAMMA2_PST12K;
#if(WMOPS)
    move16();
    move16();
#endif
  }
  ELSE
  {
    IF(sub(rate, 12000) == 0)   /* == 12 kbit/s */
    {
      /* compute frame energy */
      L_temp = (Word32) 0;
#if(WMOPS)
      move32();
#endif
      FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        L_temp = L_mac(L_temp, output_lo[i], output_lo[i]);
      }

      /* compute Th */
      L_temp = L_shl(L_temp, 16);
      Th = extract_h(L_temp);

      /* smooth Th */
      j = sub(G729EV_MAIN_NMAX, 1);
      FOR(i = 0; i < j; i++)
      {
        tab_Th[i] = tab_Th[i + 1];
#if(WMOPS)
        move16();
#endif
      }
      tab_Th[j] = Th;
#if(WMOPS)
      move16();
#endif
      Th = G729EV_MAIN_gmed_n(tab_Th, G729EV_MAIN_NMAX);

      /* set gamma = Th * gamma_12k + (1-Th)*gamma_8k */
      L_temp = L_mult(Th, G729EV_G729_GAMMA1_PST12K);
      L_temp = L_mac(L_temp, sub(MAX_16, Th), G729EV_G729_GAMMA1_PST);
      *ga1_post = round(L_temp);

      L_temp = L_mult(Th, G729EV_G729_GAMMA2_PST12K);
      L_temp = L_mac(L_temp, sub(MAX_16, Th), G729EV_G729_GAMMA2_PST);
      *ga2_post = round(L_temp);
    }
    ELSE                        /* == 8 kbit/s */
    {
      /* at 8 kbit/s use gammas from G729 */
      *ga1_post = G729EV_G729_GAMMA1_PST;
      *ga2_post = G729EV_G729_GAMMA2_PST;
#if(WMOPS)
      move16();
      move16();
#endif
    }
  }


}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_gmed_n()                                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                            *
 *  Median filter for sequence of odd length                                *
 *--------------------------------------------------------------------------*/
/*  */
Word16 G729EV_MAIN_gmed_n(      /* (o) median value  */
                           Word16 ind[],  /* (i) Current and past values */
                           Word16 n       /* (i) number of values (valid for an odd number of gains <= G729EV_MAIN_NMAX) */
    )
{
  Word16    tmp[G729EV_MAIN_NMAX];
  Word16    tmp2[G729EV_MAIN_NMAX];

  Word16    i, j, ix;
  Word16    max;
  Word16    medianIndex;


  ix = (Word16) 0;
#if(WMOPS)
  move16();
#endif

  FOR(i = 0; i < n; i++)
  {
    tmp2[i] = ind[i];
#if(WMOPS)
    move16();
#endif
  }

  FOR(i = 0; i < n; i++)
  {
    max = (Word16) - 1;
#if(WMOPS)
    move16();
#endif
    FOR(j = 0; j < n; j++)
    {
      if (sub(tmp2[j], max) >= 0)
      {
        max = tmp2[j];
        ix = j;
#if(WMOPS)
        move16();
        move16();
#endif
      }
    }
    tmp2[ix] = (Word16) - 1;
    tmp[i] = ix;
#if(WMOPS)
    move16();
    move16();
#endif
  }

  medianIndex = tmp[shr(n, 1)]; /* account for complex addressing */
#if(WMOPS)
  move16();
#endif
  return (ind[medianIndex]);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_weighting_filter()                                *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                            *
 *  Weighting filter of lower-band difference signal including an adaptive  *
 *  gain compensation                                                       *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_weighting_filter(Word16 * Az,        /* (i)   LPC coefficients from CELP local decoder  */
                                  Word16 * mem_Wz_in, /* (i)   memory of input  */
                                  Word16 * mem_wsp,   /* (i)   memory of output  */
                                  Word16 * diff       /* (i/o) difference signal before and after weighting */
    )
{
  Word32    L_temp, L_num, L_den;

  Word16    wsp[G729EV_MAIN_L_FRAME2];
  Word16    Ap1[G729EV_G729_MP1];
  Word16    Ap2[G729EV_G729_MP1];
  Word16    Wz_in_buffer[G729EV_MAIN_L_FRAME2 + G729EV_G729_M];

  Word16   *Wz_in;
  Word16   *ptr_Az;

  Word16    i_subfr, i, j, end_loop;
  Word16    fac;
  Word16    e_den, frac_den, e_num, frac_num, e_fac;

  /* set buffer for W(z) */
  Wz_in = Wz_in_buffer + G729EV_G729_M;
#if(WMOPS)
  move16();
#endif
  G729EV_G729_Copy(mem_Wz_in, &Wz_in[-G729EV_G729_M], G729EV_G729_M);
  G729EV_G729_Copy(diff, Wz_in, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Copy(&diff[(G729EV_MAIN_L_FRAME2) - G729EV_G729_M], mem_Wz_in, G729EV_G729_M);

  /* apply W(z)= fac*A(z/gamma1)/A(z/gamma2) */
  ptr_Az = Az;
  i_subfr = (Word16) 0;
#if(WMOPS)
  move16();
  move16();
#endif
  FOR(i = 0; i < 4; i++)
  {
    /* weight A(z) */
    G729EV_G729_Weight_Az(ptr_Az, G729EV_MAIN_GAMMA1, G729EV_G729_M, Ap1);
    G729EV_G729_Weight_Az(ptr_Az, G729EV_MAIN_GAMMA2, G729EV_G729_M, Ap2);

    /* compute gain  */
    L_den = L_deposit_h(shr(Ap1[0], 1));  /* (Word32)Q12>>1 -> Q27 = 1^27 */
    L_num = L_deposit_h(shr(Ap2[0], 1));  /* (Word32)Q12>>1 -> Q27 = 1^27 */
    fac = (Word16) - 16384;     /* Q13 */
#if(WMOPS)
    move16();
#endif
    FOR(j = 1; j <= G729EV_G729_M; j++)
    {
      /*                     Q12 x Q13<<1 -> Q26 */
      L_den = L_mac(L_den, Ap1[j], fac);  /* den += Ap1[j] << 14 */
      L_num = L_mac(L_num, Ap2[j], fac);  /* num += Ap2[j] << 14 */
      fac = negate(fac);
    }

    /* decompose L_den into exponent (e_den) and fraction (frac_den) */
    if (L_den < 0)
    {
      L_den = L_negate(L_den);  /* force den > 0 (needed by div_s) */
    }
    if (L_den == 0)
    {
      L_den = (Word32) 1;
#if(WMOPS)
      move32();
#endif
    }
    e_den = norm_l(L_den);
    frac_den = extract_h(L_shl(L_den, e_den));

    /* decompose L_num into exponent (e_den) and fraction (frac_den) */
    if (L_num < 0)
    {
      L_num = L_negate(L_num);
    }
    if (L_num == 0)
    {
      L_num = (Word32) 1;
#if(WMOPS)
      move32();
#endif
    }
    e_num = norm_l(L_num);
    frac_num = extract_h(L_shl(L_num, e_num));

    /* compute fac = div_s(frac_num, frac_den) * exponent */
    IF(sub(frac_num, frac_den) > 0)
    {
      frac_num = shr(frac_num, 1);
      e_num = sub(e_num, 1);
    }
    fac = div_s(frac_num, frac_den);

    e_fac = sub(e_num, e_den);
    e_fac = add(e_fac, 2);      /* shift by 2 ---> Q13 */
    fac = shr(fac, e_fac);      /* Q13 */

    /* filter by A(z/gamma) * 1/A(z/gamma2) */
    G729EV_G729_Residu(Ap1, &Wz_in[i_subfr], &wsp[i_subfr], G729EV_G729_L_SUBFR);
    G729EV_G729_Syn_filt(Ap2, &wsp[i_subfr], &wsp[i_subfr], G729EV_G729_L_SUBFR, mem_wsp, 0);
    FOR(j = 0; j < G729EV_G729_M; j++)
    {
#if(WMOPS)
      move16();
#endif
      mem_wsp[j] = wsp[i_subfr + G729EV_G729_L_SUBFR - G729EV_G729_M + j];
    }

    /* scale */
    end_loop = add(i_subfr, G729EV_G729_L_SUBFR);
    FOR(j = i_subfr; j < end_loop; j++)
    {
      /* wsp[j] *= fac; */
      L_temp = L_mult(wsp[j], fac); /* Q14 x Q13 <<1 = Q28 */
      L_temp = L_shl(L_temp, 2);  /* Q30 */
      wsp[j] = round(L_temp);   /* Q14 */
#if(WMOPS)
      move16();
#endif
    }

    ptr_Az += G729EV_G729_MP1;
    i_subfr += G729EV_G729_L_SUBFR;
  }
  G729EV_G729_Copy(wsp, diff, G729EV_MAIN_L_FRAME2);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_inverse_weighting_filter()                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                          *
 *  Inverse weighting filter of lower-band difference signal including      *
 * an adaptive gain compensation                                            *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_inverse_weighting_filter(Word16 * Az,            /* (i)   LPC coefficients from CELP local decoder  */
                                          Word16 * mem_invWz_in,  /* (i)   memory of input  */
                                          Word16 * mem_invwsp,    /* (i)   memory of output  */
                                          Word16 * diff_q         /* (i/o) difference signal before and after weighting */
    )
{
  Word32    L_temp, L_num, L_den;

  Word16    invWz_in_buffer[G729EV_MAIN_L_FRAME2 + G729EV_G729_M];
  Word16    wsp[G729EV_MAIN_L_FRAME2];
  Word16    Ap1[G729EV_G729_MP1];
  Word16    Ap2[G729EV_G729_MP1];

  Word16   *invWz_in, *ptr_Az;

  Word16    i_subfr, i, j, end_loop;
  Word16    fac;
  Word16    e_den, frac_den, e_num, frac_num, e_fac;

  /* set buffer for W(z) */
  invWz_in = invWz_in_buffer + G729EV_G729_M;
#if(WMOPS)
  move16();
#endif
  G729EV_G729_Copy(mem_invWz_in, &invWz_in[-G729EV_G729_M], G729EV_G729_M);
  G729EV_G729_Copy(diff_q, invWz_in, G729EV_MAIN_L_FRAME2);
  G729EV_G729_Copy(&diff_q[(G729EV_MAIN_L_FRAME2) - G729EV_G729_M], mem_invWz_in, G729EV_G729_M);

  /* apply W(z)= fac*A(z/gamma2)/A(z/gamma1) */
  ptr_Az = Az;
  i_subfr = (Word16) 0;
#if(WMOPS)
  move16();
  move16();
#endif
  FOR(i = 0; i < 4; i++)
  {
    /* weight A(z) */
    G729EV_G729_Weight_Az(ptr_Az, G729EV_MAIN_GAMMA1, G729EV_G729_M, Ap1);
    G729EV_G729_Weight_Az(ptr_Az, G729EV_MAIN_GAMMA2, G729EV_G729_M, Ap2);

    /* compute gain */
    L_den = L_deposit_h(shr(Ap2[0], 1));  /* (Word32)Q12>>1 -> Q27 */
    L_num = L_deposit_h(shr(Ap1[0], 1));  /* (Word32)Q12>>1 -> Q27 */
    fac = (Word16) - 16384;     /* Q13 */
#if(WMOPS)
    move16();
#endif
    FOR(j = 1; j <= G729EV_G729_M; j++)
    {
      /*                     Q12 x Q13<<1 -> Q26 */
      L_den = L_mac(L_den, Ap2[j], fac);  /* den += Ap1[j] << 14 */
      L_num = L_mac(L_num, Ap1[j], fac);  /* num += Ap2[j] << 14 */
      fac = negate(fac);
    }
    /* decompose L_den into exponent (e_den) and fraction (frac_den) */
    if (L_den < 0)
    {
      L_den = L_negate(L_den);  /* force den > 0 (needed by div_s) */
    }
    if (L_den == 0)
    {
      L_den = (Word32) 1;
#if(WMOPS)
      move32();
#endif
    }
    e_den = norm_l(L_den);
    frac_den = extract_h(L_shl(L_den, e_den));

    /* decompose L_num into exponent (e_den) and fraction (frac_den) */
    if (L_num < 0)
    {
      L_num = L_negate(L_num);
    }
    if (L_num == 0)
    {
      L_num = (Word32) 1;
#if(WMOPS)
      move32();
#endif
    }
    e_num = norm_l(L_num);
    frac_num = extract_h(L_shl(L_num, e_num));

    /* compute fac = div_s(frac_num, frac_den) * exponent */
    IF(sub(frac_num, frac_den) > 0)
    {
      frac_num = shr(frac_num, 1);
      e_num = sub(e_num, 1);
    }
    fac = div_s(frac_num, frac_den);

    e_fac = sub(e_num, e_den);
    e_fac = add(e_fac, 2);      /* shift by 2 ---> Q13 */
    fac = shr(fac, e_fac);      /* Q13 */

    /* filter by A(z/gamma2) * 1/A(z/gamma1) */
    G729EV_G729_Residu(Ap2, &invWz_in[i_subfr], &wsp[i_subfr], G729EV_G729_L_SUBFR);
    G729EV_G729_Syn_filt(Ap1, &wsp[i_subfr], &wsp[i_subfr], G729EV_G729_L_SUBFR, mem_invwsp, 0);
    FOR(j = 0; j < G729EV_G729_M; j++)
    {
      mem_invwsp[j] = wsp[i_subfr + G729EV_G729_L_SUBFR - G729EV_G729_M + j];
#if(WMOPS)
      move16();
#endif
    }

    /* scale */
    end_loop = add(i_subfr, G729EV_G729_L_SUBFR);
    FOR(j = i_subfr; j < end_loop; j++)
    {
      /* wsp[j] *= fac; */
      L_temp = L_mult(wsp[j], fac); /* Q14 x Q13 <<1 = Q28 */
      L_temp = L_shl(L_temp, 2);  /* Q30 */
      wsp[j] = round(L_temp);   /* Q14 */
#if(WMOPS)
      move16();
#endif
    }
    ptr_Az += G729EV_G729_MP1;
    i_subfr += G729EV_G729_L_SUBFR;
  }
  G729EV_G729_Copy(wsp, diff_q, G729EV_MAIN_L_FRAME2);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_initQMF_ana()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Reset the signal memory                                                 *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_initQMF_ana(G729EV_MAIN_QMFCODSTAT * qmf /* (i/o)   filter states */
    )
{
  int       i;

  FOR(i = 0; i < (2 * G729EV_MAIN_S_QMF - 1); i++)
  {
#if(WMOPS)
    move16();
#endif
    qmf->mem[i] = (Word16) 0;
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_initQMF_ana()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Reset the sum and difference memory                                     *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_initQMF_syn(G729EV_MAIN_QMFDECSTAT * qmf /* (i/o)   filter states */
    )
{
  int       i;

  FOR(i = 0; i < (2 * G729EV_MAIN_S_QMF_FS - 1); i++)
  {
#if(WMOPS)
    move16();
    move16();
#endif
    qmf->mem_add[i] = (Word16) 0;
    qmf->mem_sub[i] = (Word16) 0;
  }
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_QMF_ana()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  Two-channel filter bank analysis                                        *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_QMF_ana(G729EV_MAIN_QMFCODSTAT * qmf,  /* (i/o)       filter states */
                         Word16 * input,  /* (i)   Q15   input */
                         Word16 * bf,     /* (o)   Q14   lower-band */
                         Word16 * hf,     /* (o)   Q14   higher-band */
                         Word16 size      /* (i)         number of samples */
    )
{
  Word32    a1, b1, a2, b2;
  Word32    Tempa, Tempb;

  Word16    signal_buffer[(2 * G729EV_MAIN_S_QMF - 1) + G729EV_MAIN_L_FRAME];

  Word16   *signal_ptr;
  Word16   *x1, *x2;
  const Word16 *c;

  Word16    i;

  signal_ptr = signal_buffer;
#if(WMOPS)
  move16();
#endif

  /* copy memory of signal */
  FOR(i = 0; i < (2 * G729EV_MAIN_S_QMF - 1); i++)
  {
#if(WMOPS)
    move16();
#endif
    *signal_ptr++ = qmf->mem[i];
  }

  /* copy input signal */
  FOR(i = 0; i < size; i++)
  {
#if(WMOPS)
    move16();
#endif
    *signal_ptr++ = *input++;
  }

  /* update memory of signal */
  FOR(i = 0; i < (2 * G729EV_MAIN_S_QMF - 1); i++)
  {
#if(WMOPS)
    move16();
#endif
    qmf->mem[i] = signal_buffer[i + size];
  }

  /* efficient QMF implementation with joint computation of (decimated)
     low-band and high-band signal

     There are two sums (a & b) that are accumulated using two sets of
     coeffs (set1 = 0..12 & set2 = 13..End-1). Each set was prescaled
     with a ratio (32768/31838 or 32768/1378) to make the coeffs more
     precise (minimized quantification errors) during accumulation.

     When accumulation is complete, each sum is rescaled to normal. */

  signal_ptr = &signal_buffer[G729EV_MAIN_S_QMF - 1];
#if(WMOPS)
  move16();
#endif
  FOR(i = 0; i < size; i += 2)
  {
    x1 = signal_ptr++;
    x2 = signal_ptr++;
#if(WMOPS)
    move16();
    move16();
#endif
    /* Use Coeff #1 to Set Sums a1 & b1 */
    b1 = L_mult0(G729EV_MAIN_qmf_J64D[0], *x1--);
    a1 = L_mult0(G729EV_MAIN_qmf_J64D[0], *x2++);

    /* Use Coeffs #2..13 to Accumulate in Sums a1 & b1 */
    FOR(c = &G729EV_MAIN_qmf_J64D[1]; c < &G729EV_MAIN_qmf_J64D[13]; c += 2)
    {
      a1 = L_mac0(a1, c[0], *x1--);
      b1 = L_mac0(b1, c[0], *x2++);
      b1 = L_mac0(b1, c[1], *x1--);
      a1 = L_mac0(a1, c[1], *x2++);
    }

    /* Use Coeff #14 to Set Sums a2 & b2 */
    a2 = L_mult0(G729EV_MAIN_qmf_J64D[13], *x1--);
    b2 = L_mult0(G729EV_MAIN_qmf_J64D[13], *x2++);

    /* Use Coeffs 15..End to Accumulate in Sums a2 & b2 */
    FOR(c = &G729EV_MAIN_qmf_J64D[14]; c < &G729EV_MAIN_qmf_J64D[G729EV_MAIN_S_QMF]; c += 2)
    {
      b2 = L_mac0(b2, c[0], *x1--);
      a2 = L_mac0(a2, c[0], *x2++);
      a2 = L_mac0(a2, c[1], *x1--);
      b2 = L_mac0(b2, c[1], *x2++);
    }

    /* Rescale Sums */
    a1 = L_mls(a1, 31838 / 2);
    b1 = L_mls(b1, 31838 / 2);
    a2 = L_mls(a2, 1378 / 2);
    b2 = L_mls(b2, 1378 / 2);

    /* Calculate An + Bn Sum */
    Tempa = L_add(L_add(a1, a2), L_add(b1, b2));

    /* Calculate An - Bn Difference */
    Tempb = L_sub(L_add(a1, a2), L_add(b1, b2));

    *bf++ = round(Tempa);
    *hf++ = round(L_shl(Tempb, 1));
  }
  return;
}



/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_QMF_syn()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  Two-channel filter bank synthesis                                        *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_QMF_syn(G729EV_MAIN_QMFDECSTAT * qmf,  /* (i/o)       filter states */
                         Word16 * inputBF,              /* (i)   Q14   lower-band */
                         Word16 * inputHF,              /* (i)   Q14   higher-band */
                         Word16 * output,               /* (o)   Q15   output */
                         Word16 size,                   /* (i)         number of samples */
                         Word16 gain_switching          /* (i)         higher-band attenuation factor for bit-rate switching */
    )
{
  Word32    a1, b1, a2, b2;

  Word16    add_buffer[(2 * G729EV_MAIN_S_QMF_FS - 1) + G729EV_MAIN_L_FRAME];
  Word16    sub_buffer[(2 * G729EV_MAIN_S_QMF_FS - 1) + G729EV_MAIN_L_FRAME];

  Word16   *add_ptr;
  Word16   *sub_ptr;
  Word16   *x1a, *x2a, *x1b, *x2b;
  const Word16 *c;

  Word16    sTemp;
  Word16    i;

  /* Joint computation of base-band and high-band now avoids recalculation of the sums and
     differences for previous input signals. They are stored in the memories.
     Stack usage was also reduced by eliminating the two buffers. */

  add_ptr = add_buffer;
  sub_ptr = sub_buffer;
#if(WMOPS)
  move16();
  move16();
#endif

  /* copy the memories of the sums and differences */
  FOR(i = 0; i < (2 * G729EV_MAIN_S_QMF_FS - 1); i++)
  {
#ifdef WMOPS
    move16();
    move16();
#endif
    *add_ptr++ = qmf->mem_add[i];
    *sub_ptr++ = qmf->mem_sub[i];
  }

  /* copy the input signals and calculate the sums and differences */
  FOR(i = 0; i < size; i++)
  {
    /* Scale and Fix for Proper Rounding */
    IF(*inputHF < 0)
    {
      sTemp = mac_r(-1, *inputHF, gain_switching);
    }
    ELSE
    {
      sTemp = mult_r(*inputHF, gain_switching);
    }

#if(WMOPS)
    move16();
    move16();
#endif
    *add_ptr++ = add(*inputBF, sTemp);
    *sub_ptr++ = sub(*inputBF, sTemp);
    inputBF++;
    inputHF++;
  }

  /* add zeroes (no sum and difference to calculate) */
  FOR(i = size; i < G729EV_MAIN_L_FRAME; i++)
  {
#if(WMOPS)
    move16();
    move16();
#endif
    *add_ptr++ = (Word16) 0;
    *sub_ptr++ = (Word16) 0;
  }

  /* update memories of the sums and differences */
  FOR(i = 0; i < (2 * G729EV_MAIN_S_QMF_FS - 1); i++)
  {
#if(WMOPS)
    move16();
    move16();
#endif
    qmf->mem_add[i] = add_buffer[i + size];
    qmf->mem_sub[i] = sub_buffer[i + size];
  }

  /* Guy Richard 2005/10/26: Pointer logic in the loop was removed.
     Two iterations to calculate base-band and high-band have been
     combined into one. */

  add_ptr = &add_buffer[G729EV_MAIN_S_QMF_FS - 1];
  sub_ptr = &sub_buffer[G729EV_MAIN_S_QMF_FS - 1];
#if(WMOPS)
  move16();
  move16();
#endif
  FOR(i = 0; i < size; i++)
  {
    x1a = add_ptr++;
    x2a = x1a;
    x1b = sub_ptr++;
    x2b = x1b;
#if(WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif

    /* Use Coeff #1 to Set Sums a1 & b1 */
    a1 = L_mult0(G729EV_MAIN_qmf_J64D[0], *x1a--);
    b1 = L_mult0(G729EV_MAIN_qmf_J64D[0], *++x2b);

    /* Use Coeffs #2..13 to Accumulate in Sums a1 & b1 */
    FOR(c = &G729EV_MAIN_qmf_J64D[1]; c < &G729EV_MAIN_qmf_J64D[13]; c += 2)
    {
      a1 = L_mac0(a1, c[0], *++x2a);
      b1 = L_mac0(b1, c[0], *x1b--);
      a1 = L_mac0(a1, c[1], *x1a--);
      b1 = L_mac0(b1, c[1], *++x2b);
    }

    /* Use Coeff #14 to Set Sums a2 & b2 */
    a2 = L_mult0(G729EV_MAIN_qmf_J64D[13], *++x2a);
    b2 = L_mult0(G729EV_MAIN_qmf_J64D[13], *x1b--);

    /* Use Coeffs 15..End to Accumulate in Sums a2 & b2 */
    FOR(c = &G729EV_MAIN_qmf_J64D[14]; c < &G729EV_MAIN_qmf_J64D[G729EV_MAIN_S_QMF]; c += 2)
    {
      a2 = L_mac0(a2, c[0], *x1a--);
      a2 = L_mac0(a2, c[1], *++x2a);
      b2 = L_mac0(b2, c[1], *x1b--);
      b2 = L_mac0(b2, c[0], *++x2b);
    }

    /* Rescale */
    a1 = L_mls(a1, 31838);
    a2 = L_mls(a2, 1378);
    b1 = L_mls(b1, 31838);
    b2 = L_mls(b2, 1378);

    /* Add to Get Filter Sum */
    a1 = L_shl(L_add(a1, a2), 1);
    b1 = L_shl(L_add(b1, b2), 1);

    *output++ = round(a1);
    *output++ = round(b1);
  }
  return;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_QMF_mirror()                                      *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  Spectral folding, i.e. multiply by (-1)^n                               *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_QMF_mirror(Word16 * s, /* (i/o)   signal */
                            Word16 l    /* (i)     number of samples */
    )
{
  Word16    i;

  FOR(i = 0; i < l; i += 2)
  {
    s[i] = negate(s[i]);
  }
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_init_iir2()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  memory initialization                                                   *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_init_iir2(G729EV_MAIN_IIR2STAT * stat  /* (i/o)   filter states */
    )
{

#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
#endif

  stat->x0 = (Word16) 0;
  stat->x1 = (Word16) 0;
  stat->y1_hi = (Word16) 0;
  stat->y1_lo = (Word16) 0;
  stat->y2_hi = (Word16) 0;
  stat->y2_lo = (Word16) 0;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_iir2()                                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~                                              *
 *  50 Hz HP preprocessing                                                  *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_iir2(G729EV_MAIN_IIR2STAT * exStat,  /* (i/o)   filter states           */
                      Word16 signal[],                /* (i/o)   signal                  */
                      Word16 lg,                      /* (i)     lenght of signal        */
                      const Word16 * b,               /* (i)     Filter coefficients Q13 */
                      const Word16 * a,               /* (i)     Filter coefficients Q13 */
                      Word16 ScalingMode)             /* (i)     ScalingMode =  1 : Upscale by 2   */
                                                      /* (i)     ScalingMode = -1 : Downscale by 2 */
{
  Word32    ACC0, tmp1;

  Word16    i, x0, x1, x2, y1_hi, y1_lo, y2_hi, y2_lo;


  x0 = exStat->x0;
  x1 = exStat->x1;
  y1_hi = exStat->y1_hi;
  y1_lo = exStat->y1_lo;
  y2_hi = exStat->y2_hi;
  y2_lo = exStat->y2_lo;

#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
#endif

  FOR(i = 0; i < lg; i++)
  {
    x2 = x1;
    x1 = x0;
    x0 = signal[i];

#if(WMOPS)
    move16();
    move16();
    move16();
#endif

    /*  y[i] = b[0]*x[i]   + b[1]*x[i-1]   + b[2]*x[i-2]    */
    /*                     + a[1]*y[i-1] + a[2] * y[i-2];      */


    ACC0 = L_mult0(x0, b[0]);
    ACC0 = L_mac0(ACC0, x1, b[1]);
    ACC0 = L_mac0(ACC0, x2, b[2]);

    ACC0 = L_mac0(ACC0, y1_hi, a[1]);
    tmp1 = L_mult0(y1_lo, a[1]);

    ACC0 = L_mac0(ACC0, y2_hi, a[2]);
    tmp1 = L_mac0(tmp1, y2_lo, a[2]);

    ACC0 = L_shl(ACC0, 2);      /* Q29 --> Q31  */

    ACC0 = L_add(ACC0, L_shr(tmp1, 13));


    /* If ScalingMode == 1, Multiplication by two of output speech with saturation. */
    /* If ScalingMode == -1, Division by two of output speech  */
    signal[i] = round(L_shl(ACC0, ScalingMode));

    y2_hi = y1_hi;
    y2_lo = y1_lo;
#if(WMOPS)
    move16();
    move16();
#endif
    L_Extract(ACC0, &y1_hi, &y1_lo);
  }

  exStat->x0 = x0;
  exStat->x1 = x1;
  exStat->y1_hi = y1_hi;
  exStat->y1_lo = y1_lo;
  exStat->y2_hi = y2_hi;
  exStat->y2_lo = y2_lo;

#if(WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
#endif

  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_init_lp3k()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  50 Hz HP preprocessing                                                  *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_init_lp3k(G729EV_MAIN_IIRN_STAT * stat /* (i/o)   filter states */
    )
{
  Word16    i;

  /* memory initialization */
  FOR(i = 0; i < G729EV_MAIN_LP_ORD; i++)
  {
#if(WMOPS)
    move16();
    move16();
    move16();
#endif
    stat->x[i] = (Word16) 0;
    stat->y_hi[i] = (Word16) 0;
    stat->y_lo[i] = (Word16) 0;
  }
  return;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_lp3k()                                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  3kHz LP filtering                                                       *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_lp3k(G729EV_MAIN_IIRN_STAT * stat, /* (i/o)   filter states */
                      Word16 signal[],              /* (i/o)   signal */
                      Word16 lg                     /* (i)     number of samples */
    )
{
  Word32    ACC0;
  Word32    tmp32;

  Word16    x[G729EV_MAIN_LP_ORD + 1];
  Word16    y_hi[G729EV_MAIN_LP_ORD + 1];
  Word16    y_lo[G729EV_MAIN_LP_ORD + 1];

  Word16    i, j;

  FOR(j = 0; j < G729EV_MAIN_LP_ORD; j++)
  {
#if(WMOPS)
    move16();
#endif
    x[j] = stat->x[j];
  }

  FOR(j = 0; j < G729EV_MAIN_LP_ORD; j++)
  {
#if(WMOPS)
    move16();
    move16();
#endif
    y_hi[j + 1] = stat->y_hi[j];
    y_lo[j + 1] = stat->y_lo[j];
  }

  FOR(i = 0; i < lg; i++)
  {
    FOR(j = G729EV_MAIN_LP_ORD; j >= 1; j--)
    {
#if(WMOPS)
      move16();
#endif
      x[j] = x[j - 1];
    }
    x[0] = signal[i];
    ACC0 = (Word32) 0;
#if(WMOPS)
    move16();
    move32();
#endif
    FOR(j = 1; j <= G729EV_MAIN_LP_ORD; j++)
    {
      tmp32 = Mpy_32(y_hi[j], y_lo[j], G729EV_MAIN_lp3k_a_hi[j], G729EV_MAIN_lp3k_a_lo[j]);
      ACC0 = L_add(ACC0, tmp32);
    }
    ACC0 = L_shl(ACC0, 1);

    FOR(j = 0; j <= G729EV_MAIN_LP_ORD; j++)
    {
      tmp32 = Mpy_32_16(G729EV_MAIN_lp3k_b_hi[j], G729EV_MAIN_lp3k_b_lo[j], x[j]);
      ACC0 = L_add(ACC0, tmp32);
    }

    /* Q27 --> Q30 */
    ACC0 = L_shl(ACC0, 3);
    L_Extract(ACC0, &y_hi[0], &y_lo[0]);

    /* Q30 --> Q31 */
    ACC0 = L_shl(ACC0, 1);
    signal[i] = round(ACC0);

    FOR(j = G729EV_MAIN_LP_ORD; j >= 1; j--)
    {
#if(WMOPS)
      move16();
      move16();
#endif
      y_hi[j] = y_hi[j - 1];
      y_lo[j] = y_lo[j - 1];
    }
  }

  FOR(j = 0; j < G729EV_MAIN_LP_ORD; j++)
  {
#if(WMOPS)
    move16();
#endif
    stat->x[j] = x[j];
  }

  FOR(j = 0; j < G729EV_MAIN_LP_ORD; j++)
  {
#if(WMOPS)
    move16();
    move16();
#endif
    stat->y_hi[j] = y_hi[j + 1];
    stat->y_lo[j] = y_lo[j + 1];
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_CONVOLVE_2Tap()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  convolution with 2-tap pattern                                          *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_CONVOLVE_2Tap(Word16 Input[], Word16 Output[], Word16 Coef, Word16 Length)
{
  Word32    Acc0;

  Word16    x0, x1;
  Word16    i;


  x0 = (Word16) 0;
#if(WMOPS)
  move16();
#endif

  FOR(i = 0; i < Length - 1; i++)
  {
    x1 = Input[i];
    Acc0 = L_deposit_h(x1);
    Acc0 = L_mac(Acc0, Coef, x0);
    Output[i] = round(Acc0);
    x0 = x1;
#if(WMOPS)
    move16();
    move16();
#endif
  }
  Acc0 = L_deposit_h(Input[Length - 1]);
  Acc0 = L_mac(Acc0, Coef, x0);
  Output[Length - 1] = round(Acc0);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_CONVOLVE_2Tap()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  convolution with 3-tap pattern                                          *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_CONVOLVE_3Tap(Word16 Input[], Word16 Output[], Word16 Coef, Word16 Length)
{
  Word32    Acc0;

  Word16    x0, x1;
  Word16    i;

  x0 = (Word16) 0;
#if(WMOPS)
  move16();
#endif

  FOR(i = 0; i < Length - 1; i++)
  {
    x1 = Input[i];
    Acc0 = L_deposit_h(x1);
    Acc0 = L_mac(Acc0, Coef, x0);
    Acc0 = L_mac(Acc0, Coef, Input[i + 1]);
    Output[i] = round(Acc0);
    x0 = x1;
#if(WMOPS)
    move16();
    move16();
#endif
  }

  Acc0 = L_deposit_h(Input[Length - 1]);
  Acc0 = L_mac(Acc0, Coef, x0);
  Output[Length - 1] = round(Acc0);
}
