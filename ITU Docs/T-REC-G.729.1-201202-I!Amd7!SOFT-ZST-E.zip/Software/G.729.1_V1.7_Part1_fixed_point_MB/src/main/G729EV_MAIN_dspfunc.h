/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_DSPFUNC_H__
#define __G729EV_MAIN_DSPFUNC_H__

#include "stl.h"

/*--------------------------------------------------------------------------*
 * Mathematic functions.                                                    *
 *--------------------------------------------------------------------------*/

Word32    Inv_sqrt(             /* (o) Q30 : output value   (range: 0<=val<1)           */
                    Word32 L_x  /* (i) Q0  : input value    (range: 0<=val<=7fffffff)   */
    );

void      Log2(Word32 L_x,        /* (i) Q0  : input value                                */
               Word16 * exponent, /* (o) Q0  : integer part of Log2.   (range: 0<=val<=30) */
               Word16 * fraction  /* (o) Q15 : fractional part of Log2. (range: 0<=val<1) */
    );

Word32    Pow2(                   /* (o) Q0  : result       (range: 0<=val<=0x7fffffff)   */
                Word16 exponent,  /* (i) Q0  : integer part.      (range: 0<=val<=30)     */
                Word16 fraction   /* (i) Q15 : fractional part.  (range: 0.0<=val<1.0)    */
    );

Word16    sqrt_qnls(Word16 in, Word16 nls); /* (i) Q.0 (o) Q.nls */

Word16    sqrt_q15(Word16 in);    /* (i) Q.15 (o) Q.15 */

#endif  /*__G729EV_MAIN_DSPFUNC_H__ */
