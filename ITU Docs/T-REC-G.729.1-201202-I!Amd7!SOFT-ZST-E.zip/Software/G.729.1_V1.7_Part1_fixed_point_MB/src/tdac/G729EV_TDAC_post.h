/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_POST_H__
#define __G729EV_TDAC_POST_H__

#include <stdio.h>
#include "stl.h"

/* Functions */
void      G729EV_TDAC_PostProcess(Word16 * ykr, Word16 nbits);
void      G729EV_TDAC_PostModify(Word16 * yq, Word16 n_yq, Word16 alfa);

#endif /* __G729EV_TDAC_POST_H__ */
