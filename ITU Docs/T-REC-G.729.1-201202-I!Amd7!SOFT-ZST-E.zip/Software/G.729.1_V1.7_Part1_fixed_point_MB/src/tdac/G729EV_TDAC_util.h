/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_UTIL_H__
#define __G729EV_TDAC_UTIL_H__

#include <stdio.h>
#include "stl.h"

/* Functions : */

void      G729EV_TDAC_pushBit(UWord16 code, Word16 ** pBit, Word16 nbit);
void      G729EV_TDAC_pushBitL(UWord32 code, Word16 ** pBit, Word16 nbit);
UWord16   G729EV_TDAC_getBit(Word16 ** pBit, Word16 nbit);
UWord32   G729EV_TDAC_getBitL(Word16 ** pBit, Word16 nbit);


/* Tables : */

#endif /* __G729EV_TDAC_UTIL_H__ */
