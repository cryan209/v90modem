/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_compression.h"

#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_dspfunc.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_compression()                                    *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                    *
 *  Postprocessing of the TDBWE output by adaptive amplitude compression    *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_compression(Word16 * mem_time_env,  /* (i/o) Q10   memory for 2 past time envelope parameters */
                              Word16 * signal,        /* (i/o) Q0     */
                              Word16 * energy_log2)   /* (i)   Q10   quantized time envelope parameters */
{
  Word16    log_ener[G729EV_TDBWE_NB_SUBFRAMES_2 + 1];

  Word16   *ptr;

  Word16    tmp;
  Word16    i, j;
  Word16    limit, limit2;
  Word16    exp_int, exp_frac;
  Word16    sig;

  /* get time envelope for current frame */
  log_ener[0] = mem_time_env[0];
  log_ener[1] = mem_time_env[1];
#ifdef WMOPS
  move16();
  move16();
#endif

  FOR(i = 0; i < G729EV_TDBWE_NB_SUBFRAMES_2_M_1; i++)
  {
    log_ener[i + 2] = energy_log2[i];
#ifdef WMOPS
    move16();
#endif
  }

  /*--------------------------*
   * apply adaptive compander *
   ---------------------------*/
  ptr = signal;

  /* first segment (6 samples) */
  exp_int = shr(log_ener[0], 10);
  exp_frac = shl(sub(log_ener[0], shl(exp_int, 10)), 5);
  sig = extract_l(Pow2(exp_int, exp_frac)); /* sig is in Q0     */
  limit = sig;                  /* sig * 1    in Q0 */
#ifdef WMOPS
  move16();
#endif
  limit2 = add(shl(sig, 1), shr(sig, 1)); /* sig * 2.5  in Q0 */

  FOR(j = 0; j < 6; j++)
  {
    tmp = sub(*ptr, limit);
    IF(tmp > 0)
    {
      *ptr = add(shr(sub(*ptr, limit), 1), limit);
#ifdef WMOPS
      move16();
#endif
      tmp = sub(*ptr, limit2);
      IF(tmp > 0)
      {
        *ptr = add(shr(sub(*ptr, limit2), 3), limit2);
#ifdef WMOPS
        move16();
#endif
      }
    }
    ELSE
    {
      tmp = add(*ptr, limit);
      IF(tmp < 0)
      {
        *ptr = sub(shr(add(*ptr, limit), 1), limit);
#ifdef WMOPS
        move16();
#endif
        tmp = add(*ptr, limit2);
        IF(tmp < 0)
        {
          *ptr = sub(shr(add(*ptr, limit2), 3), limit2);
#ifdef WMOPS
          move16();
#endif
        }
      }
    }
    ptr++;
  }

  /* next segments (16 samples) */
  FOR(i = 1; i < G729EV_TDBWE_NB_SUBFRAMES_2; i++)
  {
    exp_int = shr(log_ener[i], 10);
    exp_frac = shl(sub(log_ener[i], shl(exp_int, 10)), 5);
    sig = extract_l(Pow2(exp_int, exp_frac)); /* sig is in Q0     */
    limit = sig;                /* sig * 1    in Q0 */
#ifdef WMOPS
    move16();
#endif
    limit2 = add(shl(sig, 1), shr(sig, 1)); /* sig * 2.5  in Q0 */

    FOR(j = 0; j < G729EV_TDBWE_SUBFRAME_SIZE; j++)
    {
      tmp = sub(*ptr, limit);
      IF(tmp > 0)
      {
        *ptr = add(shr(sub(*ptr, limit), 1), limit);
#ifdef WMOPS
        move16();
#endif
        tmp = sub(*ptr, limit2);
        IF(tmp > 0)
        {
          *ptr = add(shr(sub(*ptr, limit2), 3), limit2);
#ifdef WMOPS
          move16();
#endif
        }
      }
      ELSE
      {
        tmp = add(*ptr, limit);
        IF(tmp < 0)
        {
          *ptr = sub(shr(add(*ptr, limit), 1), limit);
#ifdef WMOPS
          move16();
#endif
          tmp = add(*ptr, limit2);
          IF(tmp < 0)
          {
            *ptr = sub(shr(add(*ptr, limit2), 3), limit2);
#ifdef WMOPS
            move16();
#endif
          }
        }
      }
      ptr++;
    }

  }

  /* last segment (4 samples) */
  exp_int = shr(log_ener[G729EV_TDBWE_NB_SUBFRAMES_2], 10);
  exp_frac = shl(sub(log_ener[G729EV_TDBWE_NB_SUBFRAMES_2], shl(exp_int, 10)), 5);
  sig = extract_l(Pow2(exp_int, exp_frac)); /* sig is in Q0 */
  limit = sig;                  /* sig * 1    in Q0 */
#ifdef WMOPS
  move16();
#endif
  limit2 = add(shl(sig, 1), shr(sig, 1)); /* sig * 2.5  in Q0 */

  FOR(j = 0; j < 4; j++)
  {
    tmp = sub(*ptr, limit);
    IF(tmp > 0)
    {
      *ptr = add(shr(sub(*ptr, limit), 1), limit);
#ifdef WMOPS
      move16();
#endif
      tmp = sub(*ptr, limit2);
      IF(tmp > 0)
      {
        *ptr = add(shr(sub(*ptr, limit2), 3), limit2);
#ifdef WMOPS
        move16();
#endif
      }
    }
    ELSE
    {
      tmp = add(*ptr, limit);
      IF(tmp < 0)
      {
        *ptr = sub(shr(add(*ptr, limit), 1), limit);
#ifdef WMOPS
        move16();
#endif
        tmp = add(*ptr, limit2);
        IF(tmp < 0)
        {
          *ptr = sub(shr(add(*ptr, limit2), 3), limit2);
#ifdef WMOPS
          move16();
#endif
        }
      }
    }
    ptr++;
  }

  /* Update Memory */
  mem_time_env[0] = energy_log2[G729EV_TDBWE_NB_SUBFRAMES_2_M_2];
  mem_time_env[1] = energy_log2[G729EV_TDBWE_NB_SUBFRAMES_2_M_1];
#ifdef WMOPS
  move16();
  move16();
#endif
}
