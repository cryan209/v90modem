/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_DECODER_H__
#define __G729EV_TDBWE_DECODER_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_TDBWE_generate_excitation.h"
#include "G729EV_TDBWE_frequency_envelope_shaping.h"
#include "G729EV_CELP2S.h"


/* type definition TDBWE decoder state variable */
typedef struct
{

  G729EV_TDBWE_generate_excitation_state generate_excitation;
  G729EV_TDBWE_frequency_envelope_shaping_state frequency_envelope_shaping;
  Word16    old_excitation_1[G729EV_TDBWE_MEM_EXC];
  Word16    mem_freq_env[G729EV_TDBWE_NB_SUBBANDS];
  Word16    mem_time_env[2];
  Word16    prev_gain_time_envelope_shaping;
  Word16    prev_norm_time_envelope_shaping;
} G729EV_TDBWE_DECSTAT;


/* prototypes for exported functions */

void      G729EV_TDBWE_decoder_init(G729EV_TDBWE_DECSTAT * state);

void      G729EV_TDBWE_decoder(G729EV_TDBWE_DECSTAT * state,
                               G729EV_CELP2S_PARAM * nb_celp_param, Word16 * signal_highband, Word16 * parameters);

void      G729EV_TDBWE_dequantization(Word16 * coder_parameters, Word16 * parameters_tdbwe);

/* tables */

/* TDBWE table for mean time envelope quantization       */
extern const Word16 G729EV_TDBWE_MEAN_TIME_ENV_cb[32];

/* TDBWE tables for time envelope quantization           */
extern const Word16 G729EV_TDBWE_TIME_ENV_cb[1024];

/* TDBWE tables for frequecy envelope quantization       */
extern const Word16 G729EV_TDBWE_FREQ_ENV_NUMBER_ENTRIES[3];
extern const Word16 G729EV_TDBWE_FREQ_ENV_BITS[3];
extern const Word16 *G729EV_TDBWE_FREQ_ENV_cb[3];
extern const Word16 G729EV_TDBWE_FREQ_ENV_cb1[128];
extern const Word16 G729EV_TDBWE_FREQ_ENV_cb2[128];
extern const Word16 G729EV_TDBWE_FREQ_ENV_cb3[64];

#endif
