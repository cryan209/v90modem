/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*------------------------------------------------------------------------*/
/* From Original Version :                                                */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B Floating point ANSI C source code      */
/*   Copyright (C) 1999, AT&T, France Telecom, NTT, University of         */
/*   Sherbrooke, Conexant, Ericsson.                                      */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B - Reference C code for Floating point  */
/*                         implementation of G.729 Annex AB               */
/*                                                                        */
/*========================================================================*/


#ifndef __G729EV_G729_CODSTAT_H__
#define __G729EV_G729_CODSTAT_H__

#include <stdio.h>
#include "stl.h"
#include "typedef.h"
#include "basop32.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"



/* Structure of the encoder status variables */


typedef struct
{
  Word32    L_exc_err[4];                       /* To tame the coder */

  Word16    old_speech[G729EV_G729_MEM_SPEECH]; /* Speech vector */
  Word16    old_wsp[G729EV_G729_PIT_MAX];       /* Weighted speech vector */
  Word16    old_exc[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];  /* Excitation vector */
  Word16    lsp_old[G729EV_G729_M];             /* Line Spectral Pairs */
  Word16    lsp_old_q[G729EV_G729_M];           /* Quantified LSP */
  Word16    mem_syn[G729EV_G729_M_LPC];         /* Filter's memory */
  Word16    mem_w0[G729EV_G729_M_LPC];
  Word16    mem_w[G729EV_G729_M_LPC];
  Word16    mem_err[G729EV_G729_M_LPC];
  Word16    old_A[G729EV_G729_MP1];             /* Last LPC coefs  */
  Word16    old_rc[2];
  Word16    freq_prev[G729EV_G729_MA_NP][G729EV_G729_M];  /* previous LSP vector  */
  Word16    past_qua_en[4];                     /* Past quantized energies */
  Word16    lar_old[2];

  Word16    rate;               /* Rate */
  Word16    pit_sharp;
  Word16    smooth;

  /* Excitation vector */
  Word16    mem_w0_2[G729EV_G729_M_LPC];
  Word16    mem_err2[G729EV_G729_M_LPC];
  Word16    mem_synth[G729EV_G729_M_LPC];      /* Filter's memory */

  Word16    pit_old;

} G729EV_G729_CODSTAT;




#endif  /*__G729EV_G729_CODSTAT_H__ */
