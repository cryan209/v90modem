/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.7                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729B_DEFINES_H__
#define __G729EV_G729B_DEFINES_H__

/*--------------------------------------------------------------------------*
 * Constants for DTX/CNG                                                    *
 *--------------------------------------------------------------------------*/

#define G729EV_G729B_RATE_8000       80 /* Full rate  (8000 bit/s)       */
#define G729EV_G729B_RATE_SID        15 /* SID                           */
#define G729EV_G729B_RATE_0           0 /* 0 bit/s rate                  */

/* DTX constants */
#define A_GAIN0         28672
#define A_GAIN1         4096    /* 32768L - A_GAIN0 */
#define FLAG_DEC        (Flag)0
#define NB_GAIN         2
#define INIT_SEED       11111

/* CNG excitation generation constant */
                                /* alpha = 0.5 */
#define FRAC1           19043   /* (sqrt(40)xalpha/2 - 1) * 32768 */
#define K0              24576   /* (1 - alpha ** 2) in Q15        */
#define G_MAX           5000


#endif  /*__G729EV_G729_DEFINES_H__ */
