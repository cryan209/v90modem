README file for the root directory - ITU-T G.729.1 (2006) Amd.7 (2012/02)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

IUT-T G.729.1 (2006) Amd.7 (2010) introduced new Annex F with a voice 
activity detector using G.720.1 Annex A.

For completeness, this software distribution includes not only the
ANSI-C code for Annex F, but also that for the whole of ITU-T G.729.1. 
This distribution is labelled as "Release 1.7".

The ANSI-C code of G.729.1 main body (MB) and its Annexes B, C, D, 
and E is the same as published previously, *except* that the Release 
number has been changed to 1.7 within the .c and .h files.

The folders contain the various elements of the ITU-T G.729.1
(self-evident):

- G.729.1_V1.6_Part1_fixed_point_MB
- G.729.1_V1.6_Part2_floating_point_AnnexB
- G.729.1_V1.6_Part3_dtxcng_fixed-point_AnnexC
- G.729.1_V1.6_Part4_dtxcng_floating-point_AnnexD
- G.729.1_V1.6_Part5_swb_mono_AnnexE
- G.729.1_V1.6_Part6_G.720.1_VAD_AnnexF

Test vectors can be downloaded from the ITU-T Test Signal Database, see:
http://itu.int/net/ITU-T/sigdb/speaudio/Gseries.htm#G.729.1?

-- TSB/SCN - 2012-06-01
