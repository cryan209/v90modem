/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_decod.h"
#include "G729EV_MAIN_prm.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_int2bin()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Push bits of codeword (Word16) into bitstream array                     *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_int2bin(int value,         /* input : value to be converted to binary      */
                         int nb_bits,       /* input : number of bits associated with value */
                         INT16 * bitstream) /* output: address where bits are written       */
{
  int       i, mask;

  /* MSB -> LSB */
  for (i = nb_bits - 1; i >= 0; i--)
  {
    *bitstream = ITU_G192_BIT_1;
    mask = ((value >> i) & 0x0001);
    if (mask == 0)
    {
      *bitstream = ITU_G192_BIT_0;
    }
    bitstream++;
  }
  return;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_bin2int()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Get bits of codeword (Word16) from bitstream array                      *
 *--------------------------------------------------------------------------*/
int G729EV_MAIN_bin2int(INT16 * bitstream,  /* (i)  adress where bits are read              */
                        int nb_bits)        /* (i)  number of bits associated with value    */
{
  int       code;
  int       temp16;
  int       i;

  code = 0;
  for (i = 0; i < nb_bits; i++)
  {
    code = code << 1;
    temp16 = 1;

    if (*bitstream == ITU_G192_BIT_0)
    {
      temp16 = 0;
    }
    code = code | temp16;
    bitstream++;
  }
  return (code);
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_param2bit()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Write coder parameters into G.192 format bitstream                      *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_param2bit(int *coder_parameters,     /* (i)      coder parameters            */
                           int nb_bits,               /* (i)      number of bits for encoder  */
                           INT16 * itu_192_bitstream, /* (o)      G.192 encoder bitstream     */
                           CODSTATMAIN * codstat)     /* (i)      coder states variables      */
{
  INT16    *bit_ptr;
  int      *prm_ptr;
  INT16     bit_FEC[2];

  /* Pointers initialization */
  bit_ptr = itu_192_bitstream;
  prm_ptr = coder_parameters;

  /* Generate 8k bistream */
  /* --> first subframe (80 bits) */
  G729EV_MAIN_int2bin(*prm_ptr++, 8, bit_ptr);
  bit_ptr += 8;
  G729EV_MAIN_int2bin(*prm_ptr++, 10, bit_ptr);
  bit_ptr += 10;
  G729EV_MAIN_int2bin(*prm_ptr++, 8, bit_ptr);
  bit_ptr += 8;
  G729EV_MAIN_int2bin(*prm_ptr++, 1, bit_ptr);
  bit_ptr += 1;
  G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
  bit_ptr += 13;
  G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
  bit_ptr += 4;
  G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
  bit_ptr += 7;
  G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
  bit_ptr += 5;
  G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
  bit_ptr += 13;
  G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
  bit_ptr += 4;
  G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
  bit_ptr += 7;

  if (codstat->g729_bst == 1)
  {
    *bit_ptr++ = ITU_G192_SYNCWORD;
    *bit_ptr++ = 80;
  }

  /* --> second subframe (80 bits) */
  prm_ptr += 6;                 /* jump to beginning of 2nd 8k subframe coder parameters */
  G729EV_MAIN_int2bin(*prm_ptr++, 8, bit_ptr);
  bit_ptr += 8;
  G729EV_MAIN_int2bin(*prm_ptr++, 10, bit_ptr);
  bit_ptr += 10;
  G729EV_MAIN_int2bin(*prm_ptr++, 8, bit_ptr);
  bit_ptr += 8;
  G729EV_MAIN_int2bin(*prm_ptr++, 1, bit_ptr);
  bit_ptr += 1;
  G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
  bit_ptr += 13;
  G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
  bit_ptr += 4;
  G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
  bit_ptr += 7;
  G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
  bit_ptr += 5;
  G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
  bit_ptr += 13;
  G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
  bit_ptr += 4;
  G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
  bit_ptr += 7;

  if (codstat->g729_bst != 1)
  {
    /* Generate 12k bitstream */
    /* --> first subframe (40 bits) */
    prm_ptr -= 17;              /* jump to the beginning of the 1st 12k subframe coder parameters */
    G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
    bit_ptr += 13;
    G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
    bit_ptr += 4;
    G729EV_MAIN_int2bin(*prm_ptr++, 3, bit_ptr);
    bit_ptr += 3;
    G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
    bit_ptr += 13;
    G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
    bit_ptr += 4;
    G729EV_MAIN_int2bin(*prm_ptr++, 3, bit_ptr);
    bit_ptr += 3;
    /* --> second subframe (40 bits) */
    prm_ptr += 11;
    G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
    bit_ptr += 13;
    G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
    bit_ptr += 4;
    G729EV_MAIN_int2bin(*prm_ptr++, 3, bit_ptr);
    bit_ptr += 3;
    G729EV_MAIN_int2bin(*prm_ptr++, 13, bit_ptr);
    bit_ptr += 13;
    G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
    bit_ptr += 4;
    G729EV_MAIN_int2bin(*prm_ptr++, 3, bit_ptr);
    bit_ptr += 3;
    /* Insert FEC information (bits 199 and 239) */
    prm_ptr += 7;               /* jump to FEC 12k parameters */
    G729EV_MAIN_int2bin(*prm_ptr++, 2, bit_FEC);
    itu_192_bitstream[197] = bit_FEC[0];
    itu_192_bitstream[237] = bit_FEC[1];

    /* Generate 14k bitstream (33 bits + 7 bits - FEC -) */
    prm_ptr -= 8;               /* jump to TDBWE coder parameters */
    G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
    bit_ptr += 5;
    G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
    bit_ptr += 7;
    G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
    bit_ptr += 7;
    G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
    bit_ptr += 5;
    G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
    bit_ptr += 5;
    G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
    bit_ptr += 4;
    /* Insert FEC information (7 bits) */
    G729EV_MAIN_int2bin(*prm_ptr++, 7, bit_ptr);
    bit_ptr += 7;

    /* Generate 16k+ bitstream (FEC : 5 bits ; norm_shift : 4 bits) */
    prm_ptr += 1;               /* jump to 3rd coder parameter of FEC */
    G729EV_MAIN_int2bin(*prm_ptr++, 5, bit_ptr);
    bit_ptr += 5;
    G729EV_MAIN_int2bin(*prm_ptr++, 4, bit_ptr);
  }
  /* TDAC part is already in itu_192_bitstream */
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_MAIN_bit2param()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Read coder parameters from G.192 format bitstream                      *
 *--------------------------------------------------------------------------*/
void G729EV_MAIN_bit2param(INT16 * itu_192_bitstream, /* (i)  G.192 decoder bitstream     */
                           int nb_bits,               /* (i)  number of bits available    */
                           int *coder_parameters,     /* (o)  coder paramaters            */
                           int *ind_FER,              /* (o)  FER parameters              */
                           DECSTATMAIN * decstat)     /* (i)  decoder states variables    */
{
  INT16    *bit_ptr;
  int      *prm_ptr;
  int       rate;
  INT16     bit_FEC[2];

  /* variable initialization */
  rate = nb_bits * 50;

  /* Pointers initialization */
  bit_ptr = itu_192_bitstream;
  prm_ptr = coder_parameters;

  /* Get 8k bistream */
  /* --> first subframe (80 bits) */
  if (decstat->g729b_bst != 1)
  {
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
    bit_ptr += 8;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 10);
    bit_ptr += 10;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
    bit_ptr += 8;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
    bit_ptr += 1;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
  }
  else
  {                             /* G.729 mode */
    if (decstat->decStG729.ftyp[0] == 1)
    {                           /* speech frame (80 bits) */
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
      bit_ptr += 8;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 10);
      bit_ptr += 10;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
      bit_ptr += 8;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
      bit_ptr += 1;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
      bit_ptr += 13;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
      bit_ptr += 7;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
      bit_ptr += 13;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
      bit_ptr += 7;
    }
    else if (decstat->decStG729.ftyp[0] == 2)
    {                           /* SID frame (15 bits) */
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
      bit_ptr += 1;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      prm_ptr += 7;
    }
    else if (decstat->decStG729.ftyp[0] == 0)
    {                           /* not transmited frame (0 bit) */
      prm_ptr += 11;
    }
  }

  if (decstat->g729b_bst == 1)
    bit_ptr += 2;               /* Bypass syncword and number of bits in g729 second frame */

  /* --> second subframe (80 bits) */
  prm_ptr += 6;                 /* jump to beginning of 2nd 8k subframe coder parameters */
  if (decstat->decStG729.g729b_bst != 1)
  {
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
    bit_ptr += 8;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 10);
    bit_ptr += 10;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
    bit_ptr += 8;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
    bit_ptr += 1;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
  }
  else
  {                             /* G.729B mode */
    if (decstat->decStG729.ftyp[1] == 1)
    {                           /* speech frame (80 bits) */
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
      bit_ptr += 8;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 10);
      bit_ptr += 10;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 8);
      bit_ptr += 8;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
      bit_ptr += 1;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
      bit_ptr += 13;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
      bit_ptr += 7;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
      bit_ptr += 13;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
      bit_ptr += 7;
    }
    else if (decstat->decStG729.ftyp[1] == 2)
    {                           /* SID frame (15 bits) */
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 1);
      bit_ptr += 1;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
      bit_ptr += 4;
      *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
      bit_ptr += 5;
      prm_ptr += 7;
    }
    else if (decstat->decStG729.ftyp[1] == 1)
    {                           /* not transmitted frame (0 bit) */
      prm_ptr += 11;
    }
  }


  if (rate >= 12000)
  {
    /* Get 12k bitstream */
    /* --> first subframe (40 bits) */
    prm_ptr -= 17;              /* jump to the beginning of the 1st 12k subframe coder parameters */
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 3);
    bit_ptr += 3;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 3);
    bit_ptr += 3;
    /* --> second subframe (40 bits) */
    prm_ptr += 11;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 3);
    bit_ptr += 3;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 13);
    bit_ptr += 13;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 3);
    bit_ptr += 3;
    /* --> get FEC information */
    bit_FEC[0] = itu_192_bitstream[197];
    bit_FEC[1] = itu_192_bitstream[237];
    ind_FER[0] = G729EV_MAIN_bin2int(bit_FEC, 2);
  }

  if (rate >= 14000)
  {
    /* Get 14k bitstream (33 bits + 7 bits for FEC) */
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;
    ind_FER[2] = G729EV_MAIN_bin2int(bit_ptr, 7);
    bit_ptr += 7;
  }

  if (rate >= 16000)
  {
    ind_FER[1] = G729EV_MAIN_bin2int(bit_ptr, 5);
    bit_ptr += 5;
    *prm_ptr++ = G729EV_MAIN_bin2int(bit_ptr, 4);
    bit_ptr += 4;

    /* TDAC bitstream is read in TDAC decoder */
  }
}
