/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_bitalloc.h"
#include "G729EV_TDAC_spectenv.h"
#include "G729EV_TDAC_vq.h"
#include "G729EV_TDAC_util.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_decoder()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  TDAC decoder                                                            *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_decoder(INT16 * bitstream, /* (i)     TDAC bitstream */
                         int nbit,          /* (i)     effective number of bits for TDAC */
                         int nbit_max,      /* (i)     maximal bit allocation for TDAC */
                         REAL * yt_hi,      /* (i)     MDCT spectrum of TDBWE synthesis */
                         REAL * yq_lo,      /* (o)     reconstructed MDCT spectrum of lower band */
                         REAL * yq_hi,      /* (o)     reconstructed MDCT spectrum of higher band */
                         int norm_MDCT      /* (i)     MDCT normalization factor */
    )
{
  REAL      y[G729EV_MAIN_L_FRAME];
  int       i, j, ndec_env_nb, ndec_env_wb, end_index;
  INT16    *pBit, *pBit2;
  int       bit_cnt;
  INT16     vqbits[G729EV_TDAC_MAX_VQBITS];
  int       ord_b[G729EV_TDAC_NB_SB];
  int       coef_ind;
  int       startbit[G729EV_TDAC_NB_SB];
  int       soi;

  REAL      rmsq[G729EV_TDAC_NB_SB];  /* quantized spectrum envelope */
  int       bit_alloc[G729EV_TDAC_NB_SB]; /* number of bits allocated to each subband */
  int       k, delta;
  REAL      fact;
  int       rms_index[G729EV_TDAC_NB_SB];
  REAL      ip[G729EV_TDAC_NB_SB];

  if (nbit > 0)
  {
    pBit = bitstream;

    bit_cnt = 0;

    /* ------------------------------------------ */
    /* - decode spectral envelope (subband rms)   */
    /* ------------------------------------------ */
    G729EV_TDAC_dec_specEnv(&pBit, rms_index, rmsq, &bit_cnt, nbit, &ndec_env_nb, &ndec_env_wb, norm_MDCT);

    if ((ndec_env_nb == G729EV_TDAC_NB_SB_NB) && (ndec_env_wb == G729EV_TDAC_NB_SB_WB))
    {
      /* ---------------------------------------------------------------------------------------------- */
      /* - compute number of bits available for VQ */
      /* - allocate bits to subbands */
      /* - order subbands by decreasing perceptual importance */
      /* ---------------------------------------------------------------------------------------------- */

      /* compute the number of available bits */
      nbit_max -= bit_cnt;
      nbit -= bit_cnt;          /* number of bits left (at this stage) */

      /* compute perceptual importance:
         for 3dB step in spectral envelope coding
         1/2log2(enerq) = 1/2 ( rms_index + log2 nb_coef) */
      for (j = 0; j < G729EV_TDAC_NB_SB; j++)
        ip[j] = (REAL) rms_index[j];  /* integer */
      ip[G729EV_TDAC_NB_SB - 1] += 1.0; /* ++ */
      for (j = 0; j < G729EV_TDAC_NB_SB; j++)
        ip[j] /= 2.0;           /* >>1 */

      /* order subbands by decreasing perceptual importance  */
      G729EV_TDAC_sort_ip(ip, G729EV_TDAC_NB_SB, ord_b);

      /* allocate bits to subbands */
      G729EV_TDAC_allocbit(bit_alloc, nbit_max, ip, G729EV_TDAC_NB_SB, G729EV_TDAC_nb_coef, ord_b);

      /* force zero bit to match bit budget (loop by decreasing perceptual importance) */
      bit_cnt = 0;
      for (j = 0; j < G729EV_TDAC_NB_SB; j++)
      {
        coef_ind = ord_b[j];
        if (((bit_cnt + bit_alloc[coef_ind]) <= nbit))
        {
          bit_cnt += bit_alloc[coef_ind];
        }
        else
        {
          /* bit budget is zero, set allocation to 0 bits for the other bands  */
          for (i = j; i < G729EV_TDAC_NB_SB; i++)
          {
            coef_ind = ord_b[i];
            bit_alloc[coef_ind] = 0;
          }
        }
      }

      /* ---------------------------------------------------------------------------------------------- */
      /* - decode MDCT coefficients */
      /* ---------------------------------------------------------------------------------------------- */

      /* read bits for VQ decoding */
      soi = 0;
      for (j = 0; j < G729EV_TDAC_NB_SB; j++)
      {
        startbit[j] = soi;
        soi += bit_alloc[j];
      }

      for (j = 0; j < G729EV_TDAC_NB_SB; j++)
      {
        coef_ind = ord_b[j];
        soi = startbit[coef_ind];
        for (i = 0; i < bit_alloc[coef_ind]; i++)
        {
          vqbits[soi++] = *pBit++;
        }
      }

      /* decode */
      pBit2 = vqbits;
      G729EV_TDAC_decod_VQ(&pBit2, y, bit_alloc, G729EV_TDAC_NB_SB, rmsq);

      /* ---------------------------------------------------------------------------------------------- */
      /* - reconstruct lower- and higher-band spectra */
      /* ---------------------------------------------------------------------------------------------- */

      /* split full-band spectrum */
      for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
      {
        yq_lo[i] = y[i];
        yq_hi[i] = y[i + G729EV_MAIN_L_FRAME2];
      }

      /* extrapolation (in wideband part) of unquantized subbands */
      delta = G729EV_MAIN_L_FRAME2;
      for (j = G729EV_TDAC_NB_SB_NB; j < G729EV_TDAC_NB_SB; j++)
      {
        if ((bit_alloc[j] == 0))
        {
          for (k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
            yq_hi[k - delta] = yt_hi[k - delta];

          fact = 0;
          for (k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
            fact += yq_hi[k - delta] * yq_hi[k - delta];
          if (fact)
            fact = rmsq[j] * (REAL) sqrt(G729EV_TDAC_nb_coef[j] / fact);
          if (fact > 0)         /* fact == 0 if rmsq of the current band is not sent --> no correction */
            for (k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
              yq_hi[k - delta] *= (REAL) fact;
        }
      }

      /* zero coefficients in 7-8 kHz band */
      for (i = 120; i < 160; i++)
        yq_hi[i] = (REAL) 0.0;
      return;

    }                           /* if (!bad_env) */
    else
    {
      if (ndec_env_wb > 0)
      {
        /* level adjustment of unquantized subbands (in wideband part) */
        delta = G729EV_MAIN_L_FRAME2;
        end_index = G729EV_TDAC_NB_SB_NB + ndec_env_wb;
        for (j = G729EV_TDAC_NB_SB_NB; j < end_index; j++)
        {
          fact = 0;
          for (k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
            fact += yt_hi[k - delta] * yt_hi[k - delta];
          if (fact)
            fact = rmsq[j] * (REAL) sqrt(G729EV_TDAC_nb_coef[j] / fact);
          if (fact > 0)         /* fact == 0 if rmsq of the current band is not sent --> no correction */
            for (k = G729EV_TDAC_sb_bound[j]; k < G729EV_TDAC_sb_bound[j + 1]; k++)
              yt_hi[k - delta] *= (REAL) fact;
        }
      }
    }

  }

 /************************
  * handle case: nbit = 0 
  ************************/

  /* zero coefficients in 7-8 kHz band */
  for (i = 120; i < 160; i++)
    yt_hi[i] = (REAL) 0.0;

  /* split full-band spectrum */
  for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
  {
    yq_lo[i] = 0;
    yq_hi[i] = yt_hi[i];
  }


  return;
}
