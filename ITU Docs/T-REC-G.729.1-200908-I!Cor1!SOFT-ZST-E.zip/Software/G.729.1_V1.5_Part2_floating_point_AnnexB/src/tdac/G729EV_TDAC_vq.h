/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __G729EV_TDAC_QUANTIF_H__
#define __G729EV_TDAC_QUANTIF_H__

#include <stdio.h>
#include "CodecTypedef.h"

/* Functions : */
void      G729EV_TDAC_quantif(REAL * ykr, INT16 ** bit, int *nb_niv, int nb_ssb);
void      G729EV_TDAC_dec_VQcoef(UINT32 code, int dim, INT16 * yq, REAL * inv_norm_l2);
void      G729EV_TDAC_decod_VQ(INT16 ** bit, REAL * ykr, int *nb_niv, int nb_ssb, REAL * rmsq);

/* Tables : */
extern const INT16 G729EV_TDAC_sb_bound[G729EV_TDAC_NB_SB + 1];
extern const INT16 G729EV_TDAC_nb_coef[G729EV_TDAC_NB_SB];

#endif  /*__G729EV_TDAC_QUANTIF_H__ */
