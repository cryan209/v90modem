/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_ENCOD_H__
#define __G729EV_TDAC_ENCOD_H__

#include <stdio.h>
#include "CodecTypedef.h"

/* Functions : */
void      G729EV_TDAC_encoder(REAL * y_lo, REAL * y_hi, INT16 * bitstream, int nbit, int nbit_max, int norm_MDCT);

/* Tables : */

#endif /* __G729EV_TDAC_ENCOD_H__ */
