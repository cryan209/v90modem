/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_vector_quantization.h"

#include "G729EV_G729_ld8k.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_vector_quantization()                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                            *
 *  TDBWE vector quantization,                                              *
 *  find entry in codebook[] closest to vector input[] and output           *
 *  its respective index                                                    *
 *                                                                          *
 *  input, codebook and output must have the same format Q.max              *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_vector_quantization(REAL * input,           /* (i) input buffer                    */
                                      const REAL * codebook,  /* (i) pointer to quantization table   */
                                      int *index,             /* (o) codebook index                  */
                                      int vector_size,        /* (i) length of input[]               */
                                      int codebook_size)      /* (i) number of entries in codebook[] */
{
  const REAL *codebook_ptr;
  int       i, j;
  REAL      error;
  REAL      distortion;
  REAL      min_distortion;

  *index = 0;
  codebook_ptr = codebook;

  /* compute minimum distortion (Euclidean distance) */
  min_distortion = 0.0;
  for (j = 0; j < vector_size; j++)
  {
    error = input[j] - codebook_ptr[j];
    min_distortion += error * error;
  }
  codebook_ptr = &codebook_ptr[vector_size];

  /* loop through codebook */
  for (i = 1; i < codebook_size; i++)
  {
    /* compute Euclidean distance */
    distortion = 0.0;
    for (j = 0; j < vector_size; j++)
    {
      error = input[j] - codebook_ptr[j];
      distortion += error * error;
    }

    /* select best codevector */
    if (distortion < min_distortion)
    {
      *index = i;
      min_distortion = distortion;
    }

    /* advance in codebook */
    codebook_ptr = &codebook_ptr[vector_size];
  }
}
