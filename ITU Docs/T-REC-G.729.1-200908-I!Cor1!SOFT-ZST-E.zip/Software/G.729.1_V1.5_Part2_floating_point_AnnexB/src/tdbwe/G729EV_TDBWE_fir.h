/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_FIR_H__
#define __G729EV_TDBWE_FIR_H__


#include "G729EV_MAIN_defines.h"


/* type definition TDBWE FIR filter state variable */
typedef struct
{

  REAL     *filter_coeffs;
  REAL      state[G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1];

} G729EV_TDBWE_fir_state;


/* prototypes for exported functions */

void      G729EV_TDBWE_fir_initialize(G729EV_TDBWE_fir_state * state, REAL * filter_coeffs);

void      G729EV_TDBWE_fir(G729EV_TDBWE_fir_state * state, REAL * input, REAL * output, int vector_size);

#endif
