/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_encoder.h"

#include "G729EV_TDBWE_extract_time_envelope.h"
#include "G729EV_TDBWE_extract_frequency_envelope.h"
#include "G729EV_TDBWE_vector_quantization.h"
#include "G729EV_G729_ld8k.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_quantization()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Quantization of the TDBWE parameter set by "mean removed VQ"            *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_quantization(REAL * parameters_tdbwe, /* (i) the unquantized parameter set */
                               int *coder_parameters)   /* (o) codebook indices              */
{
  int       i;
  int       vq_index;
  REAL      mu, mu_q;
  REAL     *parameters;
  int      *coder_param_ptr;

  /* initialize pointer to TDBWE parameters */
  coder_param_ptr = coder_parameters;

  /* compute mean time envelope */
  mu = (REAL) 0.0;
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  for (i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++)
  {
    mu += parameters[i];
  }
  mu /= G729EV_TDBWE_NB_SUBFRAMES;

  /* quantize mean */
  G729EV_TDBWE_vector_quantization(&mu,
                                   G729EV_TDBWE_MEAN_TIME_ENV_cb,
                                   &vq_index, 1, G729EV_TDBWE_MEAN_TIME_ENV_NUMBER_ENTRIES);

  /* write vq_index to coder_parameters */
  *coder_param_ptr++ = vq_index;

  /* reconstruct quantized mean (table look-up) */
  mu_q = G729EV_TDBWE_MEAN_TIME_ENV_cb[vq_index];

  /* remove quantized mean from time envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;  /* parameters_tdbwe + 0 */
  for (i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++)
  {
    parameters[i] -= mu_q;
  }

  /* quantize mean-removed time envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  for (i = 0; i < G729EV_TDBWE_TIME_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {

    G729EV_TDBWE_vector_quantization(&parameters[i * 8],
                                     G729EV_TDBWE_TIME_ENV_cb, &vq_index, 8, G729EV_TDBWE_TIME_ENV_NUMBER_ENTRIES);

    /* write vq_index to coder_parameters */
    *coder_param_ptr++ = vq_index;
  }

  /* remove quantized mean from frequency envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  for (i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
  {
    parameters[i] -= mu_q;
  }

  /* quantize mean-removed frequency envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  for (i = 0; i < G729EV_TDBWE_FREQ_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {

    G729EV_TDBWE_vector_quantization(&parameters[i * 4],
                                     G729EV_TDBWE_FREQ_ENV_cb[i],
                                     &vq_index, 4, G729EV_TDBWE_FREQ_ENV_NUMBER_ENTRIES[i]);

    /* write vq_index to coder_parameters */
    *coder_param_ptr++ = vq_index;
  }
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_encoder_init()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Initialization of the TDBWE encoder                                     *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_encoder_init(G729EV_TDBWE_CODSTAT * state)
{
  G729EV_G729_Set_zero(state->old_speech, G729EV_TDBWE_MEM_SPEECH);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_encoder()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 *  TDBWE encoder (parameter extraction),                                   *
 *  computes and quantize time/frequency envelopes                          *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_encoder(G729EV_TDBWE_CODSTAT * state, REAL * input_hi, int *coder_parameters, REAL * input_hi_delay)
{
  REAL      parameters[G729EV_TDBWE_NB_PARAMETERS];
  REAL     *new_speech;
  REAL     *speech;
  REAL      old_speech[G729EV_TDBWE_L_TOTAL];

  /*-------------*
   * set pointers *
   *--------------*/

  new_speech = old_speech + G729EV_TDBWE_MEM_SPEECH;  /* New speech     */
  speech = new_speech - G729EV_TDBWE_L_NEXT;  /* Present frame  */

  /*---------------*
   * update buffer *
   *---------------*/

  G729EV_G729_Copy(state->old_speech, old_speech, G729EV_TDBWE_MEM_SPEECH);
  G729EV_G729_Copy(input_hi, new_speech, G729EV_TDBWE_L_FRAME);

  /*---------------------------------*
   * extract and quantize envelopes  *
   *---------------------------------*/

  /* time envelope extraction */
  G729EV_TDBWE_extract_time_envelope(speech + G729EV_TDBWE_DELTA_TIME_ENV, 0, /* nls */
                                     &parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE], G729EV_TDBWE_NB_SUBFRAMES);

  /* extraction of the frequency envelope for the 2nd 10ms frame */
  G729EV_TDBWE_extract_frequency_envelope(speech + (G729EV_TDBWE_L_FRAME2 + G729EV_TDBWE_DELTA_FREQ_ENV), 0,  /* nls */
                                          &parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE]);

  /* quantize the parameter set and write bitstream */
  G729EV_TDBWE_quantization(parameters, coder_parameters);

  /*---------------*
   * update memory *
   *---------------*/
  G729EV_G729_Copy(&old_speech[G729EV_TDBWE_L_FRAME], state->old_speech, G729EV_TDBWE_MEM_SPEECH);
  G729EV_G729_Copy(speech, input_hi_delay, G729EV_TDBWE_L_FRAME);

}
