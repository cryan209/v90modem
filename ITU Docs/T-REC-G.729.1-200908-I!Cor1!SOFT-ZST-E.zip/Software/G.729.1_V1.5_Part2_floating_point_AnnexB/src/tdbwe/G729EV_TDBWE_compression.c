/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_compression.h"

#include <math.h>

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_compression()                                    *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                    *
 *  Postprocessing of the TDBWE output by adaptive amplitude compression    *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_compression(REAL * mem_time_env,  /* (i/o) memory for 2 past time envelope parameters */
                              REAL * signal,        /* (i/o) input signal                               */
                              REAL * energy_log2)   /* (i)   quantized time envelope parameters         */
{
  REAL      log_ener[G729EV_TDBWE_NB_SUBFRAMES + 1];

  REAL     *ptr;
  int       i, j;
  REAL      limit, limit2;
  REAL      sig;

  /* get time envelope for current frame */
  log_ener[0] = mem_time_env[0];
  log_ener[1] = mem_time_env[1];
  for (i = 0; i < G729EV_TDBWE_NB_SUBFRAMES_2_M_1; i++)
    log_ener[i + 2] = energy_log2[i];

  /*--------------------------*
   * apply adaptive compander *
   *--------------------------*/
  ptr = signal;

  /* first segment (6 samples) */
  sig = (REAL) pow(2, log_ener[0]);
  limit = G729EV_TDBWE_COMP_LINEAR_LIM1 * sig;
  limit2 = G729EV_TDBWE_COMP_LINEAR_LIM2 * sig;

  for (j = 0; j < 6; j++)
  {
    if (*ptr > limit)
    {
      *ptr = (*ptr - limit) / G729EV_TDBWE_COMP_SATURE_SLOPE1 + limit;
      if (*ptr > limit2)
        *ptr = (*ptr - limit2) / G729EV_TDBWE_COMP_SATURE_SLOPE2 + limit2;
    }
    else if (*ptr < -limit)
    {
      *ptr = (*ptr + limit) / G729EV_TDBWE_COMP_SATURE_SLOPE1 - limit;
      if (*ptr < -limit2)
        *ptr = (*ptr + limit2) / G729EV_TDBWE_COMP_SATURE_SLOPE2 - limit2;
    }
    ptr++;
  }

  /* next segments (16 samples) */
  for (i = 1; i < G729EV_TDBWE_NB_SUBFRAMES_2; i++)
  {
    sig = (REAL) pow(2, log_ener[i]);
    limit = G729EV_TDBWE_COMP_LINEAR_LIM1 * sig;
    limit2 = G729EV_TDBWE_COMP_LINEAR_LIM2 * sig;
    for (j = 0; j < G729EV_TDBWE_SUBFRAME_SIZE; j++)
    {
      if (*ptr > limit)
      {
        *ptr = (*ptr - limit) / G729EV_TDBWE_COMP_SATURE_SLOPE1 + limit;
        if (*ptr > limit2)
          *ptr = (*ptr - limit2) / G729EV_TDBWE_COMP_SATURE_SLOPE2 + limit2;
      }
      else if (*ptr < -limit)
      {
        *ptr = (*ptr + limit) / G729EV_TDBWE_COMP_SATURE_SLOPE1 - limit;
        if (*ptr < -limit2)
          *ptr = (*ptr + limit2) / G729EV_TDBWE_COMP_SATURE_SLOPE2 - limit2;
      }
      ptr++;
    }
  }

  /* last segment (4 samples) */
  sig = (REAL) pow(2, log_ener[G729EV_TDBWE_NB_SUBFRAMES_2]);
  limit = G729EV_TDBWE_COMP_LINEAR_LIM1 * sig;
  limit2 = G729EV_TDBWE_COMP_LINEAR_LIM2 * sig;
  for (j = 0; j < 4; j++)
  {
    if (*ptr > limit)
    {
      *ptr = (*ptr - limit) / G729EV_TDBWE_COMP_SATURE_SLOPE1 + limit;
      if (*ptr > limit2)
        *ptr = (*ptr - limit2) / G729EV_TDBWE_COMP_SATURE_SLOPE2 + limit2;
    }
    else if (*ptr < -limit)
    {
      *ptr = (*ptr + limit) / G729EV_TDBWE_COMP_SATURE_SLOPE1 - limit;
      if (*ptr < -limit2)
        *ptr = (*ptr + limit2) / G729EV_TDBWE_COMP_SATURE_SLOPE2 - limit2;
    }
    ptr++;
  }

  /* Update Memory */
  mem_time_env[0] = energy_log2[G729EV_TDBWE_NB_SUBFRAMES_2_M_2];
  mem_time_env[1] = energy_log2[G729EV_TDBWE_NB_SUBFRAMES_2_M_1];

}
