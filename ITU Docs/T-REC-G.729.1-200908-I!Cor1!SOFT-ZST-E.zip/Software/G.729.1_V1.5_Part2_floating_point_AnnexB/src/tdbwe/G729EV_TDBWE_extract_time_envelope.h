/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_EXTRACT_TIME_ENVELOPE_H__
#define __G729EV_TDBWE_EXTRACT_TIME_ENVELOPE_H__

#include "G729EV_MAIN_defines.h"

/* prototype for exported function */

void      G729EV_TDBWE_extract_time_envelope(REAL * signal, int nls, REAL * envelope, int number_subframes);

#endif
