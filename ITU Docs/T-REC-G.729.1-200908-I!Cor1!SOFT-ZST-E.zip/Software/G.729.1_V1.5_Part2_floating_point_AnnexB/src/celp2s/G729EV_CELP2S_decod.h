/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __G729EV_CELP2S_DECODE_H__
#define __G729EV_CELP2S_DECODE_H__

#include <stdio.h>
#include "CodecTypedef.h"

#include "G729EV_CELP2S.h"
#include "G729EV_CELP2S_qua_gain.h"
#include "G729EV_CELP2S_post.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_G729_ld8k.h"

/* Functions */
void      G729EV_CELP2S_InitDecoder(G729EV_G729_DECSTAT * pDecStat, int g729b_bst);
void      G729EV_CELP2S_decoder(G729EV_G729_DECSTAT * pDecStat,
                                int *coder_parameters,
                                int rate,
                                int SubFrNum,
                                G729EV_CELP2S_PARAM * nb_celp_param,
                                REAL * BfAq, REAL * coreExc, REAL * extExc, REAL * pitch_buf, INT16 clas, int bfi);

void      G729EV_G729_syn(                  /* (i)  : 8kbits core excitation              */
                           REAL * exc_core, /* (i)  : 8kbits core excitation              */
                           REAL * exc_ext,  /* (i)  : 12kbits  core excitation  extention */
                           REAL * BfAq,     /* (i)  : LPC coefficient filter              */
                           REAL * synth,    /* (o)  : Synthesis buffer                    */
                           REAL * mem_syn,  /* (i/o): synthesis memory buffer             */
                           INT16 extrate    /* (i)  : Extension bit rate                  */
    );

void      G729EV_CELP2S_Decod_ACELP(int sign, int index, REAL sp, REAL cod[]);
void      G729EV_CELP2S_Decod_pos_sig(int index, int sign, int pos[], int si[]);
void      G729EV_CELP2S_Put4Patterns(int pos[], int si[], REAL sp, REAL cod[]);

#endif  /*__G729EV_CELP2S_DECODE_H__ */
