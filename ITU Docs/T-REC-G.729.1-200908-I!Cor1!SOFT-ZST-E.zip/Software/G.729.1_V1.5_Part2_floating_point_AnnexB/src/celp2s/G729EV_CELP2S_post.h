/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_CELP2S_POST_H__
#define __G729EV_CELP2S_POST_H__

#include "G729EV_MAIN_filt.h"

/* functions */
void      G729EV_CELP2S_init_post_filter(G729EV_MAIN_PFSTAT * pfstat);  /* (i)   : core decoder parameters                */

void      G729EV_CELP2S_post(G729EV_MAIN_PFSTAT * pfstat, /* (i/o): states strucure                           */
                             int t0,                      /* (i)  : pitch delay given by coder                */
                             REAL * signal_ptr,           /* (i)  : input signal (pointer to current subframe */
                             REAL * coeff,                /* (i)  : LPC coefficients for current subframe     */
                             REAL * sig_out,              /* (o)  : postfiltered output                       */
                             REAL gamma1,                 /* (i)  : short term postfilt. den. weighting factor */
                             REAL gamma2,                 /* (i)  : short term postfilt. num. weighting factor */
                             REAL PostNB, INT16 Vad);

#endif
