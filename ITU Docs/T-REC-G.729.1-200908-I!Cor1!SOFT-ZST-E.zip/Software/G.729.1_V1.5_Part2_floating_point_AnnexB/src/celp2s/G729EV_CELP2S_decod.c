/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <math.h>
#include <stdlib.h>

#include "G729EV_CELP2S_decod.h"

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

#include "G729EV_FEC_fer.h"

#include "G729EV_G729B_defines.h"
#include "G729EV_G729B_util.h"
#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729B_sid.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_CELP2S_InitDecoder()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Variables initialisation for the CELP2S                                 *
 *--------------------------------------------------------------------------*/

void G729EV_CELP2S_InitDecoder(G729EV_G729_DECSTAT * pDecStat,  /* (i)   : core decoder parameters             */
                               int g729b_bst                    /* (i)   : G.729 bitstream mode flag           */
    )
{
  int       i;

  /* initialize lsp_old */
  pDecStat->lsp_old[0] = (REAL) 0.9595;
  pDecStat->lsp_old[1] = (REAL) 0.8413;
  pDecStat->lsp_old[2] = (REAL) 0.6549;
  pDecStat->lsp_old[3] = (REAL) 0.4154;
  pDecStat->lsp_old[4] = (REAL) 0.1423;
  pDecStat->lsp_old[5] = (REAL) - 0.1423;
  pDecStat->lsp_old[6] = (REAL) - 0.4154;
  pDecStat->lsp_old[7] = (REAL) - 0.6549;
  pDecStat->lsp_old[8] = (REAL) - 0.8413;
  pDecStat->lsp_old[9] = (REAL) - 0.9595;

  /* vectors to zero */
  G729EV_G729_Set_zero(pDecStat->old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  G729EV_G729_Set_zero(pDecStat->mem_syn, G729EV_G729_M_LPC);

  /* FER */
  pDecStat->seed_fer = (INT16) 21845;

  /* G729EV_G729_post_filter */

  pDecStat->sharp = G729EV_G729_SHARPMIN;
  pDecStat->gain_code = (REAL) 0.;
  pDecStat->gain_pitch = (REAL) 0.;

  pDecStat->past_qua_en[0] = -14.0f;
  pDecStat->past_qua_en[1] = -14.0f;
  pDecStat->past_qua_en[2] = -14.0f;
  pDecStat->past_qua_en[3] = -14.0f;

  G729EV_G729_Lsp_decw_reset(pDecStat->freq_prev, pDecStat->prev_lsp, &pDecStat->prev_ma);

  G729EV_G729_Set_zero(pDecStat->MemTam, G729EV_G729_MEM_LEN_TAM);

  pDecStat->lp_gainp = 0.0f;
  pDecStat->lp_gainc = 0.0f;
  pDecStat->i_subfr_cnt = 0;
  pDecStat->stab_fac = 0.0f;
  pDecStat->tilt_code = 0.0f;
  pDecStat->upd_cnt = G729EV_FEC_MAX_UPD_CNT;
  pDecStat->enr_old = 0.0f;
  pDecStat->fpitch[0] = G729EV_G729_PIT_MIN;
  pDecStat->fpitch[1] = G729EV_G729_PIT_MIN;
  pDecStat->old_fpitch = 40.0f;
  pDecStat->pit_mem[0] = 20.f;
  pDecStat->pit_mem[1] = 20.f;
  pDecStat->pit_mem[2] = 20.f;
  pDecStat->pit_mem[3] = 20.f;
  pDecStat->pit_mem[4] = 20.f;
  pDecStat->bfi_mem = 0;

  /* G.729B mode */
  pDecStat->g729b_bst = g729b_bst;
  pDecStat->ftyp[0] = 1;
  pDecStat->ftyp[1] = 1;
  pDecStat->sid_sav = (REAL) 0.0;
  pDecStat->sid_gain = tab_Sidgain[0];
  pDecStat->past_ftyp = 1;
  pDecStat->seed = INIT_SEED;
  for (i = 0; i < G729EV_G729_M; i++)
    pDecStat->lspSid[i] = (REAL) cos(freq_prev_reset[i]);
  init_lsfq_noise(pDecStat);

  return;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_CELP2S_decoder()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Core Codec decoder                                                      *
 *--------------------------------------------------------------------------*/

void G729EV_CELP2S_decoder(G729EV_G729_DECSTAT * pDecStat,      /* (i/o) : core decoder parameters      */
                           int *coder_parameters,               /* (i)   : decoder parameters           */
                           int rate,                            /* (i)   : decoder rate                 */
                           int SubFrNum,                        /* (i)   : subframe number              */
                           G729EV_CELP2S_PARAM * nb_celp_param, /* (i/o)    celp parameters             */
                           REAL * BfAq,                         /* (i)   :  A_t_fwd parameters          */
                           REAL * coreExc,                      /* (o)   :  8k excitation               */
                           REAL * extExc,                       /* (o)   :  12k excitation              */
                           REAL * pitch_buf,                    /* (o)   :  pit:ch buffer               */
                           INT16 clas,                          /* (i)   :  FEC information             */
                           int bfi                              /* (i)   :  Bad frame information       */
    )
{
  /* Array of the coded parameters */
  REAL      old_exc[G729EV_G729_L_FRAME + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];
  REAL      A_t_fwd[2 * G729EV_G729_MP1]; /* LPC Forward filter */
  REAL      synth_buf[G729EV_G729_L_FRAME + G729EV_G729_M_LPC]; /* synthesis signal buffer  */
  REAL      lsp_new[G729EV_G729_M];       /* LSPs             */
  REAL      code[G729EV_G729_L_SUBFR];    /* ACELP codevector */
  int       t2[2];

  int      *prm;                /* Pointer on analysis parameters */
  REAL     *exc;                /* Pointer on exitation vector    */
  REAL     *synth;
  REAL     *pA_t;               /* Pointer on A_t                 */
  int      *ptr_t2;             /* Pointer on t2                  */

  int       i, i_subfr, i0_2sub;
  int       t0, t0_frac, index;
  REAL      g_p, g_c;           /* fixed and adaptive codebook gain */
  int       t0_first = 0;       /* Pitch lag in 1st subframe        */

  REAL      g_c_enha;
  REAL      code_enha[G729EV_G729_L_SUBFR];
  REAL      exc2[G729EV_G729_L_FRAME];
  int      *prm2;
  REAL      voice_fac, ftmp;
  REAL      norm_voiced_fac;
  REAL     *p_tmp1;
  REAL     *p_tmp2;

  /* G.729B */
  INT16     ftyp;
  REAL      lsfq_mem[G729EV_G729_MA_NP][G729EV_G729_M];


  /*Test if Decoder Initialized */
  if (pDecStat == NULL)
  {
    return;
  }

  pDecStat->rate = rate;

  if (rate >= 12000)
  {
    coder_parameters[3] = G729EV_G729_Check_Parity_Pitch(coder_parameters[2], coder_parameters[3]);
  }

  /* Initialize pointers and restore memories */
  G729EV_G729_Copy(pDecStat->old_exc, old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  exc = old_exc + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL;
  prm = coder_parameters;
  prm2 = &coder_parameters[G729EV_G729_PRM_SIZE];
  synth = synth_buf + G729EV_G729_M_LPC;

  G729EV_G729_Copy(pDecStat->mem_syn, synth_buf, G729EV_G729_M_LPC);

  ftyp = pDecStat->ftyp[SubFrNum];

  if (ftyp != 1)
  {                             /* Processing non active frames (SID & not transmitted) */
    G729EV_G729B_Get_decfreq_prev(pDecStat->freq_prev, lsfq_mem);

    G729EV_G729B_Dec_cng(pDecStat, pDecStat->past_ftyp, pDecStat->sid_sav, prm, exc, pDecStat->lsp_old,
                         A_t_fwd, &pDecStat->seed, lsfq_mem, &pDecStat->sid_gain, &pDecStat->cur_gain, ftyp);

    G729EV_G729B_Update_decfreq_prev(pDecStat->freq_prev, lsfq_mem);

    G729EV_G729_Copy(A_t_fwd, &nb_celp_param->Az[2 * SubFrNum * G729EV_G729_MP1], 2 * G729EV_G729_MP1);

    pDecStat->sharp = G729EV_G729_SHARPMIN;

  }
  else
  {
    pDecStat->seed = INIT_SEED;
    /* ------------- */
    /* LPC decoding  */
    /* ------------- */

    /* Decode the LSPs */
    pDecStat->stab_fac =
        G729EV_G729_D_lsp(prm, lsp_new, 0, pDecStat->freq_prev, pDecStat->prev_lsp, &pDecStat->prev_ma);
    prm += 2;

    /* Interpolation of LPC for the 2 subframes */
    G729EV_G729_Int_qlpc(pDecStat->lsp_old, lsp_new, A_t_fwd);

    G729EV_G729_Copy(A_t_fwd, &nb_celp_param->Az[2 * SubFrNum * G729EV_G729_MP1], 2 * G729EV_G729_MP1);

    /* update the LSFs for the next frame */
    G729EV_G729_Copy(lsp_new, pDecStat->lsp_old, G729EV_G729_M);

    pA_t = A_t_fwd;
     /*------------------------------------------------------------------------*
      *          Loop for every subframe in the analysis frame                 *
      *------------------------------------------------------------------------*
      * The subframe size is L_SUBFR and the loop is repeated L_FRAME/L_SUBFR  *
      *  times                                                                 *
      *     - decode the pitch delay                                           *
      *     - decode algebraic code                                            *
      *     - decode pitch and codebook gains                                  *
      *     - find the excitation and compute synthesis speech                 *
      *------------------------------------------------------------------------*/

    ptr_t2 = t2;                /* pointer to interpolated LPC parameters */
    i0_2sub = 2 * SubFrNum;     /* i0_2sub = 2*SubFrNum + i0 */
    for (i_subfr = 0; i_subfr < G729EV_G729_L_FRAME; i_subfr += G729EV_G729_L_SUBFR)
    {

      index = *prm++;           /* pitch index */

      if (i_subfr == 0)
      {
        /* get parity check result */
        i = *prm++;

        G729EV_G729_Dec_lag3(index, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX, i_subfr, &t0, &t0_frac);
        t0_first = t0;          /* If first frame */
      }
      else                      /* second subframe */
      {

        G729EV_G729_Dec_lag3(index, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX, i_subfr, &t0, &t0_frac);
      }
      G729EV_FEC_pitch_pred(0, &t0, &t0_frac, pDecStat->pit_mem, &(pDecStat->bfi_mem));
      if (i_subfr == 0)
      {
        t0_first = t0;
      }
      *ptr_t2++ = t0;

      pitch_buf[pDecStat->i_subfr_cnt] = (REAL) t0;
      if (clas >= G729EV_FEC_UV_TRANSITION)
      {
        pDecStat->fpitch[0] = pDecStat->fpitch[1];
        pDecStat->fpitch[1] = t0 + t0_frac / 4.0f;
      }

          /*-------------------------------------------------*
           * - Find the adaptive codebook vector.            *
           *-------------------------------------------------*/
      G729EV_G729_Pred_lt_3(&exc[i_subfr], t0, t0_frac, G729EV_G729_L_SUBFR);

          /*-------------------------------------------------------*
           * - Decode innovative codebook.                         *
           *-------------------------------------------------------*/
      G729EV_G729_Decod_ACELP(prm[1], prm[0], code);
      prm += 2;

      if (t0 < G729EV_G729_L_SUBFR)
      {
        for (i = t0; i < G729EV_G729_L_SUBFR; i++)
          code[i] += pDecStat->sharp * code[i - t0];
      }

          /*-------------------------------------------------*
           * - Decode pitch and codebook gains.              *
           *-------------------------------------------------*/
      index = *prm++;           /* index of energy VQ */

      G729EV_G729_Dec_gain(index, code, G729EV_G729_L_SUBFR, 0, &pDecStat->gain_pitch, &pDecStat->gain_code,
                           pDecStat->past_qua_en);

      voice_fac = G729EV_FEC_voice_factor(exc + i_subfr, pDecStat->gain_pitch, code, pDecStat->gain_code);

      norm_voiced_fac = (REAL) ((voice_fac + 1.0f) * 0.5f);
      ftmp = G729EV_CELP2S_SP * norm_voiced_fac;
      if (pDecStat->rate >= 12000)
      {
        G729EV_CELP2S_Decod_ACELP(prm2[1], prm2[0], ftmp, code_enha);
        prm2 += 2;
      }

          /*-------------------------------------------------------------*
           * - Update pitch sharpening "sharp" with quantized gain_pitch *
           *-------------------------------------------------------------*/
      pDecStat->sharp = pDecStat->gain_pitch;
      if (pDecStat->sharp > G729EV_G729_SHARPMAX)
        pDecStat->sharp = G729EV_G729_SHARPMAX;
      if (pDecStat->sharp < G729EV_G729_SHARPMIN)
        pDecStat->sharp = G729EV_G729_SHARPMIN;

         /*-------------------------------------------------------*
          * - Find the total excitation.                          *
          * - Find synthesis speech corresponding to exc[].       *
          *-------------------------------------------------------*/
      g_p = G729EV_G729_TamFer(pDecStat, pDecStat->gain_pitch,  /*gain */
                               t0); /*integer part of the pitch */

      g_c = pDecStat->gain_code;

      nb_celp_param->t0[i0_2sub] = t0;
      nb_celp_param->t0_frac[i0_2sub] = t0_frac;

      p_tmp1 = &nb_celp_param->power_ltp[i0_2sub];
      *p_tmp1 = (REAL) 0.;

      for (i = 0; i < G729EV_G729_L_SUBFR; i++)
      {
        /* accumulate power_ltp */
        *p_tmp1 += (g_p * exc[i + i_subfr]) * (g_p * exc[i + i_subfr]);

        exc[i + i_subfr] = g_p * exc[i + i_subfr] + g_c * code[i];
      }

      if (pDecStat->rate >= 12000)
      {
        index = *prm2++;

        p_tmp2 = &nb_celp_param->power_fix[i0_2sub];
        *p_tmp2 = (REAL) 0.;

        /* decode gain (optimized version: table lookup) */
        g_c_enha = G729EV_CELP2S_dec_gain_Stage2(g_c, index, (INT16) i0_2sub);

        /* Compute excitation for with two inovative codebook */
        for (i = 0; i < G729EV_G729_L_SUBFR; i++)
        {
          /* accumulate power_fix */
          *p_tmp2 += (g_c * code[i] + g_c_enha * code_enha[i]) * (g_c * code[i] + g_c_enha * code_enha[i]);

          exc2[i + i_subfr] = g_c_enha * code_enha[i] + exc[i + i_subfr];
        }

      }

      pDecStat->lp_gainp += ((REAL) ((pDecStat->i_subfr_cnt + 1) / 10.0)) * g_p;
      pDecStat->lp_gainc += ((REAL) ((pDecStat->i_subfr_cnt + 1) / 10.0)) * g_c;

      pDecStat->tilt_code = (REAL) (0.25f * (1.0f + voice_fac));

      pDecStat->i_subfr_cnt++;

      pA_t += G729EV_G729_MP1;  /* interpolated LPC parameters for next subframe */

      i0_2sub++;
    }
  }

  /* G.729B */
  if (bfi == 0)
  {
    pDecStat->sid_sav = (REAL) 0.0;
    for (i = 0; i < G729EV_G729_L_FRAME; i++)
    {
      pDecStat->sid_sav += exc[i] * exc[i];
    }
  }
    /*--------------------------------------------------*
    * Update signal for next frame.                     *
    * -> shift to the left by G729EV_G729_L_FRAME  exc[]*
    *---------------------------------------------------*/
  G729EV_G729_Copy(&old_exc[G729EV_G729_L_FRAME], &pDecStat->old_exc[0], G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);

  G729EV_G729_Copy(exc, coreExc, G729EV_G729_L_FRAME);
  G729EV_G729_Copy(exc2, extExc, G729EV_G729_L_FRAME);
  G729EV_G729_Copy(A_t_fwd, BfAq, 2 * G729EV_G729_MP1);

  /* G.729B */
  pDecStat->past_ftyp = ftyp;

  return;
}


/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_Decod_pos_sig()                  *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *   Decode positions and signs of the 4 tri-pulse patterns  *
 *-----------------------------------------------------------*/

void G729EV_CELP2S_Decod_pos_sig(int index, /* (i) : positions of the 4 patterns  */
                                 int sign,  /* (i) : signs of the 4 patterns      */
                                 int pos[], /* (o) : decoded positions            */
                                 int si[]   /* (o) : decoded signs                */
    )
{
  int       i, j;

  /* decode the positions */
  i = index & 7;
  pos[0] = i * 5;

  index >>= 3;
  i = index & 7;
  pos[1] = i * 5 + 1;

  index >>= 3;
  i = index & 7;
  pos[2] = i * 5 + 2;

  index >>= 3;
  j = index & 1;
  index >>= 1;
  i = index & 7;
  pos[3] = i * 5 + 3 + j;

  /* decode the signs */
  for (j = 0; j < 4; j++)
  {
    i = sign & 1;
    si[j] = i;
    sign >>= 1;
  }

  return;
}

/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_Decod_ACELP()                    *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *   Algebraic codebook decoder.                             *
 *-----------------------------------------------------------*/

void G729EV_CELP2S_Decod_ACELP(int sign,  /* (i) :  signs of 4 patterns                   */
                               int index, /* (i) :  positions of the 4 pattern centres    */
                               REAL sp,   /* (i) :  amplidude of the side pulses          */
                               REAL cod[] /* (o) :  algebraic (fixed) codebook excitation */
    )
{
  int       pos[4], si[4];

  /* Decode the positions and signs */
  G729EV_CELP2S_Decod_pos_sig(index, sign, pos, si);

  /* Put the tri-pulse patterns */
  G729EV_CELP2S_Put4Patterns(pos, si, sp, cod);

  return;
}
