/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __G729EV_G729_SID_H__
#define __G729EV_G729_SID_H__

#include "CodecTypedef.h"

void      G729EV_G729B_Dec_cng(G729EV_G729_DECSTAT * pDecStat, int past_ftyp,     /* (i)   : past frame type                      */
                               REAL sid_sav,                                      /* (i)   : energy to recover SID gain           */
                               int *parm,                                         /* (i)   : coded SID parameters                 */
                               REAL * exc,                                        /* (i/o) : excitation array                     */
                               REAL * lsp_old,                                    /* (i/o) : previous lsp                         */
                               REAL * A_t,                                        /* (o)   : set of interpolated LPC coefficients */
                               INT16 * seed,                                      /* (i/o) : random generator seed                */
                               REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i/o) : previous LPS for quantization        */
                               REAL * sid_gain, REAL * cur_gain, INT16 ftyp);

void      init_lsfq_noise(G729EV_G729_DECSTAT * pDecStat);

void      sid_lsfq_decode(int *index,                                       /* (i) : quantized indices    */
                          REAL * lspq,                                      /* (o) : quantized lsp vector */
                          REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i) : memory of predictor  */
                          REAL noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M]);

#endif
