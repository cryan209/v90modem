/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729B_DEFINES_H__
#define __G729EV_G729B_DEFINES_H__

/*--------------------------------------------------------------------------*
 * Constants for DTX/CNG                                                    *
 *--------------------------------------------------------------------------*/

#define G729EV_G729B_RATE_8000       80 /* Full rate  (8000 bit/s)       */
#define G729EV_G729B_RATE_SID        15 /* SID                           */
#define G729EV_G729B_RATE_0           0 /* 0 bit/s rate                  */

/* DTX constants */
#define INIT_SEED       11111
#define NB_GAIN         2
#define MIN_ENER        (REAL)0.1588489319   /* <=> - 8 dB      */
#define A_GAIN0         (REAL)0.875
#define A_GAIN1         ((REAL)1. - A_GAIN0)
#define FLAG_DEC        0

/* CNG excitation generation constant */
                                            /* alpha = 0.5 */
#define NORM_GAUSS      (REAL)3.16227766    /* sqrt(40)xalpha */
#define K0              (REAL)3.            /* 4 x (1 - alpha ** 2) */
#define G_MAX           (REAL)5000.

#endif  /*__G729EV_G729_DEFINES_H__ */
