/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/



#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"




/*  Constants defined in G729EV_G729_defines.h */
/*  G729EV_G729_L_SUBFR   -> Lenght of subframe.                                        */
/*  G729EV_G729_NB_POS    -> Number of positions for each pulse.                         */
/*  G729EV_G729_STEP      -> Step betweem position of the same pulse.                   */
/*  G729EV_G729_MSIZE     -> Size of vectors for cross-correlation between two pulses.  */


/*-------------------------------------------------------------------------*
*  Function  G729EV_G729_Cor_h_X()                                         *
*  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
* Compute  correlations of input response h[] with the target vector X[].  *
*--------------------------------------------------------------------------*/

void G729EV_G729_Cor_h_X(REAL h[],  /* (i) :Impulse response of filters      */
                         REAL x[],  /* (i) :Target vector                    */
                         REAL d[],  /* (o) :Correlations between h[] and x[] */
                         short stp  /* (i) : starting point                  */
    )
{
  int       i, j;
  REAL      s;

  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    s = (REAL) 0.0;

    for (j = i - stp; j < G729EV_G729_L_SUBFR; j++)
    {
      s += x[j] * h[j - i];
    }
    d[i] = s;
  }

  return;
}


/**-------------------------------------------------------------------------*
 *  Function  G729EV_G729_Cor_h()                                           *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 * Compute  correlations of h[]  needed for the codebook search.            *
 *--------------------------------------------------------------------------*/

void G729EV_G729_Cor_h(REAL * h,  /* (i) :Impulse response of filters */
                       REAL * rr  /* (o) :Correlations of H[]         */
    )
{
  REAL     *rri0i0, *rri1i1, *rri2i2, *rri3i3, *rri4i4;
  REAL     *rri0i1, *rri0i2, *rri0i3, *rri0i4;
  REAL     *rri1i2, *rri1i3, *rri1i4;
  REAL     *rri2i3, *rri2i4;

  REAL     *p0, *p1, *p2, *p3, *p4;

  REAL     *ptr_hd, *ptr_hf, *ptr_h1, *ptr_h2;
  REAL      cor;
  REAL      tmp1;

  int       i, k, ldec, l_fin_sup, l_fin_inf;




 /*------------------------------------------------------------*
  * Compute rri0i0[], rri1i1[], rri2i2[], rri3i3 and rri4i4[]  *
  *------------------------------------------------------------*/
  /* Init pointers */
  rri0i0 = rr;
  rri1i1 = rri0i0 + G729EV_G729_NB_POS;
  rri2i2 = rri1i1 + G729EV_G729_NB_POS;
  rri3i3 = rri2i2 + G729EV_G729_NB_POS;
  rri4i4 = rri3i3 + G729EV_G729_NB_POS;
  rri0i1 = rri4i4 + G729EV_G729_NB_POS;
  rri0i2 = rri0i1 + G729EV_G729_MSIZE;
  rri0i3 = rri0i2 + G729EV_G729_MSIZE;
  rri0i4 = rri0i3 + G729EV_G729_MSIZE;
  rri1i2 = rri0i4 + G729EV_G729_MSIZE;
  rri1i3 = rri1i2 + G729EV_G729_MSIZE;
  rri1i4 = rri1i3 + G729EV_G729_MSIZE;
  rri2i3 = rri1i4 + G729EV_G729_MSIZE;
  rri2i4 = rri2i3 + G729EV_G729_MSIZE;

  p0 = rri0i0 + G729EV_G729_NB_POS - 1; /* Init pointers to last position of rrixix[] */
  p1 = rri1i1 + G729EV_G729_NB_POS - 1;
  p2 = rri2i2 + G729EV_G729_NB_POS - 1;
  p3 = rri3i3 + G729EV_G729_NB_POS - 1;
  p4 = rri4i4 + G729EV_G729_NB_POS - 1;


  ptr_h1 = h - 1;
  cor = *ptr_h1 * *ptr_h1;
  ptr_h1++;
  tmp1 = cor;

  for (i = 0; i < G729EV_G729_NB_POS; i++)
  {
    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p4-- = cor;

    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p3-- = cor;

    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p2-- = cor;

    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p1-- = cor;

    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p0-- = cor;
  }

  *(p0 + 1) -= tmp1;


  /*-----------------------------------------------------------------*
  * Compute elements of: rri2i3[], rri1i2[], rri0i1[] and rri0i4[]  *
  *-----------------------------------------------------------------*/

  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;
  ldec = G729EV_G729_NB_POS + 1;

  ptr_hd = h;
  ptr_hf = ptr_hd + 1;

  for (k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p3 = rri2i3 + l_fin_sup;
    p2 = rri1i2 + l_fin_sup;
    p1 = rri0i1 + l_fin_sup;
    p0 = rri0i4 + l_fin_inf;

    ptr_h1 = ptr_hd - 1;
    ptr_h2 = ptr_hf - 1;
    cor = *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;


    for (i = k + 1; i < G729EV_G729_NB_POS; i++)
    {
      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p3 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p2 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p1 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p0 = cor;

      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p3 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p2 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p1 = cor;

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

 /*---------------------------------------------------------------------*
  * Compute elements of: rri2i4[], rri1i3[], rri0i2[], rri1i4[], rri0i3 *
  *---------------------------------------------------------------------*/

  ptr_hd = h;
  ptr_hf = ptr_hd + 2;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;

  for (k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p4 = rri2i4 + l_fin_sup;
    p3 = rri1i3 + l_fin_sup;
    p2 = rri0i2 + l_fin_sup;
    p1 = rri1i4 + l_fin_inf;
    p0 = rri0i3 + l_fin_inf;

    ptr_h1 = ptr_hd - 1;
    ptr_h2 = ptr_hf - 1;
    cor = *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;

    for (i = k + 1; i < G729EV_G729_NB_POS; i++)
    {
      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p4 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p3 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p2 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p1 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p0 = cor;

      p4 -= ldec;
      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p4 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p3 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p2 = cor;

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

  /*----------------------------------------------------------------------*
  * Compute elements of: rri1i4[], rri0i3[], rri2i4[], rri1i3[], rri0i2  *
  *----------------------------------------------------------------------*/

  ptr_hd = h;
  ptr_hf = ptr_hd + 3;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;

  for (k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p4 = rri1i4 + l_fin_sup;
    p3 = rri0i3 + l_fin_sup;
    p2 = rri2i4 + l_fin_inf;
    p1 = rri1i3 + l_fin_inf;
    p0 = rri0i2 + l_fin_inf;

    ptr_h1 = ptr_hd - 1;
    ptr_h2 = ptr_hf - 1;
    cor = *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;

    for (i = k + 1; i < G729EV_G729_NB_POS; i++)
    {

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p4 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p3 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p2 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p1 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p0 = cor;

      p4 -= ldec;
      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p4 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p3 = cor;

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

  /*----------------------------------------------------------------------*
  * Compute elements of: rri0i4[], rri2i3[], rri1i2[], rri0i1[]          *
  *----------------------------------------------------------------------*/

  ptr_hd = h;
  ptr_hf = ptr_hd + 4;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;
  for (k = 0; k < G729EV_G729_NB_POS; k++)
  {

    p3 = rri0i4 + l_fin_sup;
    p2 = rri2i3 + l_fin_inf;
    p1 = rri1i2 + l_fin_inf;
    p0 = rri0i1 + l_fin_inf;

    ptr_h1 = ptr_hd - 1;
    ptr_h2 = ptr_hf - 1;
    cor = *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;

    for (i = k + 1; i < G729EV_G729_NB_POS; i++)
    {

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p3 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p2 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p1 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p0 = cor;

      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p3 = cor;

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }
  return;
}
