/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729_DTX_H__
#define __G729EV_G729_DTX_H__

#include "G729EV_G729_decstat.h"

/* SID gain Quantization */
void      qua_Sidgain(REAL * ener,  /* (i)   array of energies                   */
                      int nb_ener,  /* (i)   number of energies or               */
                      REAL * enerq, /* (o)   decoded energies in dB              */
                      int *idx      /* (o)   SID gain quantization index         */
    );

/* CNG excitation generation */
void      calc_exc_rand(G729EV_G729_DECSTAT * pDecStat, REAL cur_gain,  /* (i)   :   target sample gain                 */
                        REAL * exc,                                     /* (i/o) :   excitation array                   */
                        INT16 * seed,                                   /* (i)   :   current Vad decision               */
                        int flag_cod                                    /* (i)   :   encoder/decoder flag               */
    );

#endif
