# Microsoft Developer Studio Project File - Name="encoder" - Package Owner=<4>
# Microsoft Developer Studio Generated Build File, Format Version 6.00
# ** DO NOT EDIT **

# TARGTYPE "Win32 (x86) Console Application" 0x0103

CFG=encoder - Win32 Debug
!MESSAGE This is not a valid makefile. To build this project using NMAKE,
!MESSAGE use the Export Makefile command and run
!MESSAGE 
!MESSAGE NMAKE /f "encoder.mak".
!MESSAGE 
!MESSAGE You can specify a configuration when running NMAKE
!MESSAGE by defining the macro CFG on the command line. For example:
!MESSAGE 
!MESSAGE NMAKE /f "encoder.mak" CFG="encoder - Win32 Debug"
!MESSAGE 
!MESSAGE Possible choices for configuration are:
!MESSAGE 
!MESSAGE "encoder - Win32 Release" (based on "Win32 (x86) Console Application")
!MESSAGE "encoder - Win32 Debug" (based on "Win32 (x86) Console Application")
!MESSAGE 

# Begin Project
# PROP AllowPerConfigDependencies 0
# PROP Scc_ProjName ""
# PROP Scc_LocalPath ""
CPP=cl.exe
RSC=rc.exe

!IF  "$(CFG)" == "encoder - Win32 Release"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 0
# PROP BASE Output_Dir "Release"
# PROP BASE Intermediate_Dir "Release"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 0
# PROP Output_Dir "../../Release"
# PROP Intermediate_Dir "../../Release"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /GX /O2 /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /c
# ADD CPP /nologo /W3 /GX /O2 /I "..\..\src\main" /I "..\..\src\g729" /I "..\..\src\tdac" /I "..\..\src\tdbwe" /I "..\..\src\celp2s" /I "..\..\src\fec" /D "WIN32" /D "NDEBUG" /D "_CONSOLE" /D "_MBCS" /FR /YX /FD /c
# ADD BASE RSC /l 0x40c /d "NDEBUG"
# ADD RSC /l 0x40c /d "NDEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /machine:I386

!ELSEIF  "$(CFG)" == "encoder - Win32 Debug"

# PROP BASE Use_MFC 0
# PROP BASE Use_Debug_Libraries 1
# PROP BASE Output_Dir "Debug"
# PROP BASE Intermediate_Dir "Debug"
# PROP BASE Target_Dir ""
# PROP Use_MFC 0
# PROP Use_Debug_Libraries 1
# PROP Output_Dir "../../Debug"
# PROP Intermediate_Dir "../../Debug"
# PROP Target_Dir ""
# ADD BASE CPP /nologo /W3 /Gm /GX /ZI /Od /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /YX /FD /GZ /c
# ADD CPP /nologo /W3 /Gm /GX /ZI /Od /I "..\..\src\stl2005_basop" /I "..\..\src\main" /I "..\..\src\g729" /I "..\..\src\tdac" /I "..\..\src\tdbwe" /I "..\..\src\celp2s" /I "..\..\src\fec" /D "WIN32" /D "_DEBUG" /D "_CONSOLE" /D "_MBCS" /FR /YX /FD /GZ /c
# ADD BASE RSC /l 0x40c /d "_DEBUG"
# ADD RSC /l 0x40c /d "_DEBUG"
BSC32=bscmake.exe
# ADD BASE BSC32 /nologo
# ADD BSC32 /nologo
LINK32=link.exe
# ADD BASE LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept
# ADD LINK32 kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib kernel32.lib user32.lib gdi32.lib winspool.lib comdlg32.lib advapi32.lib shell32.lib ole32.lib oleaut32.lib uuid.lib odbc32.lib odbccp32.lib /nologo /subsystem:console /debug /machine:I386 /pdbtype:sept

!ENDIF 

# Begin Target

# Name "encoder - Win32 Release"
# Name "encoder - Win32 Debug"
# Begin Group "Source Files"

# PROP Default_Filter "cpp;c;cxx;rc;def;r;odl;idl;hpj;bat"
# Begin Group "CELP2S"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_acelp_ca.c
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_encod.c
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_put4pat.c
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_qua_gain.c
# End Source File
# End Group
# Begin Group "FEC"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_ferenc.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_ferutil.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_tools.c
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_voicefac.c
# End Source File
# End Group
# Begin Group "G729"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_acelp_ca.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_error.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_filter.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_gainpred.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_lpc.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_lpcfunc.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_lspgetq.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_p_parity.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_pitch.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_pred_lt3.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_pwf.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_qua_gain.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_qua_lsp.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_tab_ld8k.c
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_util.c
# End Source File
# End Group
# Begin Group "MAIN"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_encod.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_encoder.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_envadaption.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_filt.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_prm.c
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_table.c
# End Source File
# End Group
# Begin Group "TDAC"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_bitalloc.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_encod.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_lib_vq.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_mdct.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_spectenv.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_tfr.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_util.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_vq.c
# End Source File
# End Group
# Begin Group "TDBWE"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_encoder.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_extract_frequency_envelope.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_extract_time_envelope.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_fft.c
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_vector_quantization.c
# End Source File
# End Group
# End Group
# Begin Group "Header Files"

# PROP Default_Filter "h;hpp;hxx;hm;inl"
# Begin Group "CELP2S_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_acelp_ca.h
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_encod.h
# End Source File
# Begin Source File

SOURCE=..\..\src\celp2s\G729EV_CELP2S_qua_gain.h
# End Source File
# End Group
# Begin Group "FEC_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_fer.h
# End Source File
# Begin Source File

SOURCE=..\..\src\fec\G729EV_FEC_tools.h
# End Source File
# End Group
# Begin Group "G729_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_codstat.h
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_defines.h
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_ld8k.h
# End Source File
# Begin Source File

SOURCE=..\..\src\g729\G729EV_G729_tab_ld8k.h
# End Source File
# End Group
# Begin Group "MAIN_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\main\CodecTypedef.h
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_defines.h
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_encod.h
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_filt.h
# End Source File
# Begin Source File

SOURCE=..\..\src\main\G729EV_MAIN_prm.h
# End Source File
# End Group
# Begin Group "TDAC_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_bitalloc.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_encod.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_lib_vq.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_mdct.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_spectenv.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_tfr.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_util.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdac\G729EV_TDAC_vq.h
# End Source File
# End Group
# Begin Group "TDBWE_H"

# PROP Default_Filter ""
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_encoder.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_extract_frequency_envelope.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_extract_time_envelope.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_fft.h
# End Source File
# Begin Source File

SOURCE=..\..\src\tdbwe\G729EV_TDBWE_vector_quantization.h
# End Source File
# End Group
# End Group
# Begin Group "Resource Files"

# PROP Default_Filter "ico;cur;bmp;dlg;rc2;rct;bin;rgs;gif;jpg;jpeg;jpe"
# End Group
# End Target
# End Project
