/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"


/************************************************************************/
/*                                                                      */
/*   ADAPTIVE BANDWIDTH EXPANSION for THE PERCEPTUAL WEIGHTING FILTER   */
/*                                                                      */
/*                 W(z) = A (z/gamma1) / A(z/gamma2)                    */
/*                                                                      */
/************************************************************************/

void G729EV_G729_perc_var(Word16 * gamma1,  /* Bandwidth expansion parameter */
                          Word16 * gamma2,  /* Bandwidth expansion parameter */
                          Word16 * LsfInt,  /* Interpolated LSP vector : 1st subframe */
                          Word16 * LsfNew,  /* New LSP vector : 2nd subframe */
                          Word16 * r_c,     /* Reflection coefficients */
                          Word16 * smooth, Word16 LarOld[2])
{

  Word32    L_temp;

  Word16    Lar[4];             /* Q11 */

  Word16   *LarNew;             /* Q11 */
  Word16   *Lsf;                /* Q15 */

  Word16    cur_rc;             /* Q11 */
  Word16    CritLar0, CritLar1; /* Q11 */
  Word16    temp;
  Word16    d_min;              /* Q10 */
  Word16    i, k;



  FOR(k = 0; k < G729EV_G729_M; k++)
  {
    LsfInt[k] = shl(LsfInt[k], 1);
    LsfNew[k] = shl(LsfNew[k], 1);
#ifdef WMOPS
    move16();
    move16();
#endif
  }


  LarNew = &Lar[2];
  /* ---------------------------------------------------------------------------- */
  /* Reflection coefficients ---> Lar                                             */
  /* Lar(i) = log10( (1+rc) / (1-rc) )                                            */
  /* Approximated by                                                              */
  /* x <= G729EV_G729_SEG1            y = x                                       */
  /* G729EV_G729_SEG1 < x <= G729EV_G729_SEG2     y = G729EV_G729_A1 x - B1_L     */
  /* G729EV_G729_SEG2 < x <= G729EV_G729_SEG3     y = G729EV_G729_A2 x - B2_L     */
  /* x > G729EV_G729_SEG3             y = G729EV_G729_A3 x - B3_L                 */
  /* ---------------------------------------------------------------------------- */
  FOR(i = 0; i < 2; i++)
  {

    cur_rc = abs_s(r_c[i]);
    cur_rc = shr(cur_rc, 4);

    IF(sub(cur_rc, G729EV_G729_SEG1) <= 0)
    {
      LarNew[i] = cur_rc;
#ifdef WMOPS
      move16();
#endif
    }
    ELSE
    {
      IF(sub(cur_rc, G729EV_G729_SEG2) <= 0)
      {
        cur_rc = shr(cur_rc, 1);
        L_temp = L_mult(cur_rc, G729EV_G729_A1);
        L_temp = L_sub(L_temp, G729EV_G729_L_B1);
        L_temp = L_shr(L_temp, 11);
        LarNew[i] = extract_l(L_temp);
#ifdef WMOPS
        move16();
#endif
      }
      ELSE
      {
        IF(sub(cur_rc, G729EV_G729_SEG3) <= 0)
        {
          cur_rc = shr(cur_rc, 1);
          L_temp = L_mult(cur_rc, G729EV_G729_A2);
          L_temp = L_sub(L_temp, G729EV_G729_L_B2);
          L_temp = L_shr(L_temp, 11);
          LarNew[i] = extract_l(L_temp);
#ifdef WMOPS
          move16();
#endif
        }
        ELSE
        {
          cur_rc = shr(cur_rc, 1);
          L_temp = L_mult(cur_rc, G729EV_G729_A3);
          L_temp = L_sub(L_temp, G729EV_G729_L_B3);
          L_temp = L_shr(L_temp, 11);
          LarNew[i] = extract_l(L_temp);
#ifdef WMOPS
          move16();
#endif
        }
      }
    }
    if (r_c[i] < 0)
    {
      LarNew[i] = sub(0, LarNew[i]);
#ifdef WMOPS
      move16();
#endif
    }
  }

  /* Interpolation of Lar for the 1st subframe */

  temp = add(LarNew[0], LarOld[0]);
  Lar[0] = shr(temp, 1);
  LarOld[0] = LarNew[0];
  temp = add(LarNew[1], LarOld[1]);
  Lar[1] = shr(temp, 1);
  LarOld[1] = LarNew[1];
#ifdef WMOPS
  move16();
  move16();
  move16();
  move16();
#endif

  FOR(k = 0; k < 2; k++)
  {                             /* LOOP : gamma2 for 1st to 2nd subframes */

    /* ---------------------------------------------------------- */
    /* First criterion based on the first two Lars                */
    /* smooth == 1  ==>  gamma2 can vary from 0.4 to 0.7          */
    /* smooth == 0  ==>  gamma2 is set to 0.6                     */
    /*                                                            */
    /* Double threshold + hysteresis :                            */
    /* if smooth = 1                                              */
    /*  if (CritLar0 < THRESH_L1) and (CritLar1 > THRESH_H1)      */
    /*                                                 smooth = 0 */
    /* if smooth = 0                                              */
    /*  if (CritLar0 > THRESH_L2) or (CritLar1 < THRESH_H2)       */
    /*                                                 smooth = 1 */
    /* ---------------------------------------------------------- */

    CritLar0 = Lar[2 * k];
    CritLar1 = Lar[2 * k + 1];

#ifdef WMOPS
    move16();
    move16();
#endif


    IF(*smooth != 0)
    {
#ifdef WMOPS
      test();
#endif
      if ((sub(CritLar0, G729EV_G729_THRESH_L1) < 0) && (sub(CritLar1, G729EV_G729_THRESH_H1) > 0))
      {
        *smooth = 0;
#ifdef WMOPS
        move16();
#endif
      }
    }
    ELSE
    {
#ifdef WMOPS
      test();
#endif
      if ((sub(CritLar0, G729EV_G729_THRESH_L2) > 0) || (sub(CritLar1, G729EV_G729_THRESH_H2) < 0))
      {
        *smooth = 1;
#ifdef WMOPS
        move16();
#endif

      }

    }

    IF(*smooth == 0)
    {
      /* ------------------------------------------------------ */
      /* Second criterion based on the minimum distance between */
      /*                two successives LSPs                    */
      /*                                                        */
      /*           gamma2[k] = -6.0 * pi * d_min + 1.0          */
      /*                                                        */
      /*       with Lsfs normalized range 0.0 <= val <= 1.0     */
      /* ------------------------------------------------------ */
      gamma1[k] = G729EV_G729_GAMMA1_0;
#ifdef WMOPS
      move16();
      move16();
#endif

      IF(k == 0)
      {
        Lsf = LsfInt;
      }
      ELSE
      {
        Lsf = LsfNew;
      }
      d_min = sub(Lsf[1], Lsf[0]);
      FOR(i = 1; i < G729EV_G729_M - 1; i++)
      {
        temp = sub(Lsf[i + 1], Lsf[i]);
        if (sub(temp, d_min) < 0)
        {
#ifdef WMOPS
          move16();
#endif
          d_min = temp;
        }
      }
      temp = mult(G729EV_G729_ALPHA, d_min);
      temp = sub(G729EV_G729_BETA, temp);
      temp = shl(temp, 5);
      gamma2[k] = temp;
#ifdef WMOPS
      move16();
#endif

      if (sub(gamma2[k], G729EV_G729_GAMMA2_0_H) > 0)
      {
#ifdef WMOPS
        move16();
#endif
        gamma2[k] = G729EV_G729_GAMMA2_0_H;
      }
      if (sub(gamma2[k], G729EV_G729_GAMMA2_0_L) < 0)
      {
#ifdef WMOPS
        move16();
#endif
        gamma2[k] = G729EV_G729_GAMMA2_0_L;
      }

    }
    ELSE
    {
      gamma1[k] = G729EV_G729_GAMMA1_1;
      gamma2[k] = G729EV_G729_GAMMA2_1;
#ifdef WMOPS
      move16();
      move16();
#endif
    }
  }
  return;
}
