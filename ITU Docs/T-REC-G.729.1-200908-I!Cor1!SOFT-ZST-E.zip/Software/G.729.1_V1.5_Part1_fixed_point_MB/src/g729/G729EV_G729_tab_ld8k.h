/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729_TAB_LD8K_H__
#define __G729EV_G729_TAB_LD8K_H__

#include "stl.h"
#include "G729EV_G729_defines.h"

extern Word16 hamwindow[G729EV_G729_L_WINDOW];
extern Word16 lag_h[G729EV_G729_M];
extern Word16 lag_l[G729EV_G729_M];
extern Word16 table[65];
extern Word16 slope[64];
extern Word16 slope_cos[64];
extern Word16 lspcb1[G729EV_G729_NC0][G729EV_G729_M];
extern Word16 lspcb2[G729EV_G729_NC1][G729EV_G729_M];
extern Word16 fg[2][G729EV_G729_MA_NP][G729EV_G729_M];
extern Word16 fg_sum[2][G729EV_G729_M];
extern Word16 fg_sum_inv[2][G729EV_G729_M];
extern Word16 grid[G729EV_G729_GRID_POINTS + 1];
extern Word16 inter_3[G729EV_G729_FIR_SIZE_ANA];
extern Word16 inter_3l[G729EV_G729_FIR_SIZE_SYN];
extern Word16 pred[4];
extern Word16 gbk1[G729EV_G729_NCODE1][2];
extern Word16 gbk2[G729EV_G729_NCODE2][2];
extern Word16 map1[G729EV_G729_NCODE1];
extern Word16 map2[G729EV_G729_NCODE2];
extern Word16 coef[2][2];
extern Word32 L_coef[2][2];
extern Word16 thr1[G729EV_G729_NCODE1 - G729EV_G729_NCAN1];
extern Word16 thr2[G729EV_G729_NCODE2 - G729EV_G729_NCAN2];
extern Word16 imap1[G729EV_G729_NCODE1];
extern Word16 imap2[G729EV_G729_NCODE2];
extern Word16 tab_hup_s[G729EV_G729_SIZ_TAB_HUP_S];
extern Word16 tab_hup_l[G729EV_G729_SIZ_TAB_HUP_L];
extern Word16 tabpow[33];
extern Word16 tablog[33];
extern Word16 tabsqr[49];
extern Word16 tab_zone[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL - 1];
extern Word16 freq_prev_reset[G729EV_G729_M];

#endif /* __G729EV_G729_TAB_LD8K_H__ */
