/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_ENCODER_H__
#define __G729EV_TDBWE_ENCODER_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"


/* type definition TDBWE encoder state variable */
typedef struct
{

  Word16    old_speech[G729EV_TDBWE_MEM_SPEECH];

} G729EV_TDBWE_CODSTAT;


/* prototypes for exported functions */

void      G729EV_TDBWE_encoder_init(G729EV_TDBWE_CODSTAT * state);

void      G729EV_TDBWE_encoder(G729EV_TDBWE_CODSTAT * state,
                               Word16 * input_hi, Word16 * coder_parameters, Word16 * input_hi_delay);

/*****************************************************************************/

#endif
