/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_GENERATE_EXCITATION_H__
#define __G729EV_TDBWE_GENERATE_EXCITATION_H__

#include "stl.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"



/* type definition for excitation information (for 10 ms frames)
   from the G.729A+ baseband codec */
typedef struct
{
  Word32    power_ltp[2];
  Word32    power_fix[2];
  Word16    lag[2];             /* Q.0 */
  Word16    frac_lag[2];        /* Q.0 */

} G729EV_TDBWE_g729_info;


/* type definition for the excitation generator's state */
typedef struct
{
  G729EV_MAIN_IIRN_STAT lowpass_3_kHz;

  Word16    signal_tonal_buffer[G729EV_TDBWE_LENGTH_PULSE_SHAPE];

  Word16    old_lag;
  Word16    old_gain_tonal;
  Word32    seed;

  Word16    prev_pulse;
  Word16    prev_pulse_frac;

} G729EV_TDBWE_generate_excitation_state;



/* prototypes for exported functions */

void      G729EV_TDBWE_generate_excitation_initialize(G729EV_TDBWE_generate_excitation_state * state);

void      G729EV_TDBWE_generate_excitation(G729EV_TDBWE_generate_excitation_state * state,
                                           G729EV_TDBWE_g729_info * parameters, Word16 * output);


/* tables */

extern const Word16 G729EV_TDBWE_pulse_shapes_frac6[G729EV_TDBWE_LENGTH_PULSE_SHAPE * G729EV_TDBWE_NUMBER_PULSE_SHAPES];



#endif
