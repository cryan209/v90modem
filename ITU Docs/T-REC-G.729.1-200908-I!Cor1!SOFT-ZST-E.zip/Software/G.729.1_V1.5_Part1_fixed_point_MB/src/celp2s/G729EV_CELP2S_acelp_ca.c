/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_CELP2S_acelp_ca.h"


/*--------------------------------------------------------------------------*
 * Function  G729EV_G729_cor_h_OTH()                            *
 * Compute  correlations of h[] needed for the codebook search.             *
 *--------------------------------------------------------------------------*/

void G729EV_CELP2S_cor_h_OTH(Word16 * h,  /* (i) Q12 : Impulse response of filters  */
                             Word16 * rr, /* (o)     : Correlation of H[]           */
                             Word16 * y1)
{
  Word32    cor;
  Word32    ACC0;
  Word32    tmp32[G729EV_G729_L_SUBFR];
  Word32    Max_ACC0;

  Word16    h_scaled[G729EV_G729_L_SUBFR];
  Word16    tmp[G729EV_G729_L_SUBFR];

  Word16   *rri0i0, *rri1i1, *rri2i2, *rri3i3, *rri4i4;
  Word16   *rri0i1, *rri0i2, *rri0i3, *rri0i4;
  Word16   *rri1i2, *rri1i3, *rri1i4;
  Word16   *rri2i3, *rri2i4;
  Word16   *p0, *p1, *p2, *p3, *p4;
  Word16   *p01, *p02, *p03, *p04, *p12, *p13, *p14, *p23, *p24;
  Word16   *ptr_hd, *ptr_hf, *ptr_h1, *ptr_h2;

  Word16    rt0, rt1, rt2, rt3, rt4;
  Word16    i, ii, j, jj;
  Word16    k, kk, shift;
  Word16    ldec, l_fin_sup, l_fin_inf;
  Word16    r1;
  Word16    tmp16;
  Word16    shift_div;
  Word16    shift_y1;

  Word32   *ptr32;
  Word16   *ptr16, *ptr16tmp;

  /* Scaling h[] for maximum precision */
  cor = (Word32) 0;
#if (WMOPS)
  move32();
#endif

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    cor = L_mac(cor, h[i], h[i]);

  IF(sub(extract_h(cor), 32000) > 0)
  {
    /* shift right h --> h_scaled */
    shift = (Word16) - 1;
#if (WMOPS)
    move16();
#endif
    ptr_hd = h_scaled;
    FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
#if (WMOPS)
      move16();
#endif
      *ptr_hd++ = shr(h[i], 1);
    }
  }
  ELSE
  {
    /* shift left h --> h_scaled */
    shift = norm_l(cor);
    shift = shr(shift, 1);

    ptr_hd = h_scaled;
    FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
#if (WMOPS)
      move16();
#endif
      *ptr_hd++ = shl(h[i], shift);
    }
  }

  /*------------------------------------------------------------*
   * Compute rri0i0[], rri1i1[], rri2i2[], rri3i3 and rri4i4[]  *
   *------------------------------------------------------------*/
  /* Init pointers */
  rri0i0 = rr;
  rri1i1 = rri0i0 + G729EV_G729_NB_POS; /* 8 */
  rri2i2 = rri1i1 + G729EV_G729_NB_POS;
  rri3i3 = rri2i2 + G729EV_G729_NB_POS;
  rri4i4 = rri3i3 + G729EV_G729_NB_POS;
  rri0i1 = rri4i4 + G729EV_G729_NB_POS;
  rri0i2 = rri0i1 + G729EV_G729_MSIZE;  /* 16 */
  rri0i3 = rri0i2 + G729EV_G729_MSIZE;
  rri0i4 = rri0i3 + G729EV_G729_MSIZE;
  rri1i2 = rri0i4 + G729EV_G729_MSIZE;
  rri1i3 = rri1i2 + G729EV_G729_MSIZE;
  rri1i4 = rri1i3 + G729EV_G729_MSIZE;
  rri2i3 = rri1i4 + G729EV_G729_MSIZE;
  rri2i4 = rri2i3 + G729EV_G729_MSIZE;

  p0 = rri0i0 + G729EV_G729_NB_POS - 1; /* Init pointers to last position of rrixix[] */
  p1 = rri1i1 + G729EV_G729_NB_POS - 1;
  p2 = rri2i2 + G729EV_G729_NB_POS - 1;
  p3 = rri3i3 + G729EV_G729_NB_POS - 1;
  p4 = rri4i4 + G729EV_G729_NB_POS - 1;

#if (WMOPS)
  move32();
#endif

  ptr_h1 = h_scaled;
  cor = (Word32) 0;

  FOR(i = 0; i < G729EV_G729_NB_POS; i++)
  {

    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p4-- = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p3-- = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p2-- = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p1-- = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    cor = L_mac(cor, *ptr_h1, *ptr_h1);
    ptr_h1++;
    *p0-- = extract_h(cor);
#if(WMOPS)
    move16();
#endif
  }

  /*-----------------------------------------------------------------*
   * Compute elements of: rri2i3[], rri1i2[], rri0i1[] and rri0i4[]  *
   *-----------------------------------------------------------------*/

#if (WMOPS)
  move16();
  move16();
  move16();
#endif

  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;
  ldec = G729EV_G729_NB_POS + 1;

  ptr_hd = h_scaled;
  ptr_hf = ptr_hd + 1;

  FOR(k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p3 = rri2i3 + l_fin_sup;
    p2 = rri1i2 + l_fin_sup;
    p1 = rri0i1 + l_fin_sup;
    p0 = rri0i4 + l_fin_inf;

#if (WMOPS)
    move32();
#endif

    cor = (Word32) 0;
    ptr_h1 = ptr_hd;
    ptr_h2 = ptr_hf;

    FOR(i = k + 1; i < G729EV_G729_NB_POS; i++)
    {

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p3 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p2 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p1 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p0 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p3 = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p2 = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p1 = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

  /*---------------------------------------------------------------------*
   * Compute elements of: rri2i4[], rri1i3[], rri0i2[], rri1i4[], rri0i3 *
   *---------------------------------------------------------------------*/

#if (WMOPS)
  move16();
  move16();
#endif

  ptr_hd = h_scaled;
  ptr_hf = ptr_hd + 2;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;

  FOR(k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p4 = rri2i4 + l_fin_sup;
    p3 = rri1i3 + l_fin_sup;
    p2 = rri0i2 + l_fin_sup;
    p1 = rri1i4 + l_fin_inf;
    p0 = rri0i3 + l_fin_inf;

#if (WMOPS)
    move32();
#endif

    cor = (Word32) 0;
    ptr_h1 = ptr_hd;
    ptr_h2 = ptr_hf;

    FOR(i = k + (Word16) 1; i < G729EV_G729_NB_POS; i++)
    {

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p4 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p3 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p2 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p1 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p0 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      p4 -= ldec;
      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p4 = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p3 = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p2 = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

  /*----------------------------------------------------------------------*
   * Compute elements of: rri1i4[], rri0i3[], rri2i4[], rri1i3[], rri0i2  *
   *----------------------------------------------------------------------*/

#if (WMOPS)
  move16();
  move16();
#endif

  ptr_hd = h_scaled;
  ptr_hf = ptr_hd + 3;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;

  FOR(k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p4 = rri1i4 + l_fin_sup;
    p3 = rri0i3 + l_fin_sup;
    p2 = rri2i4 + l_fin_inf;
    p1 = rri1i3 + l_fin_inf;
    p0 = rri0i2 + l_fin_inf;

#if (WMOPS)
    move32();
#endif

    ptr_h1 = ptr_hd;
    ptr_h2 = ptr_hf;
    cor = (Word32) 0;

    FOR(i = k + (Word16) 1; i < G729EV_G729_NB_POS; i++)
    {

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p4 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p3 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p2 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p1 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p0 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      p4 -= ldec;
      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p4 = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p3 = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

  /*----------------------------------------------------------------------*
   * Compute elements of: rri0i4[], rri2i3[], rri1i2[], rri0i1[]          *
   *----------------------------------------------------------------------*/

#if (WMOPS)
  move16();
  move16();
#endif

  ptr_hd = h_scaled;
  ptr_hf = ptr_hd + 4;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;

  FOR(k = 0; k < G729EV_G729_NB_POS; k++)
  {
    p3 = rri0i4 + l_fin_sup;
    p2 = rri2i3 + l_fin_inf;
    p1 = rri1i2 + l_fin_inf;
    p0 = rri0i1 + l_fin_inf;

#if (WMOPS)
    move32();
#endif

    ptr_h1 = ptr_hd;
    ptr_h2 = ptr_hf;
    cor = (Word32) 0;

    FOR(i = k + 1; i < G729EV_G729_NB_POS; i++)
    {

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p3 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p2 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p1 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      cor = L_mac(cor, *ptr_h1, *ptr_h2);
      ptr_h1++;
      ptr_h2++;
      *p0 = extract_h(cor);
#if(WMOPS)
      move16();
#endif

      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor = L_mac(cor, *ptr_h1, *ptr_h2);
    ptr_h1++;
    ptr_h2++;
    *p3 = extract_h(cor);
#if(WMOPS)
    move16();
#endif

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }


  /*----------------------------------------------------------------------*
   * Compute rr for AC orthogonalizing search                             *
   *----------------------------------------------------------------------*/



#if (WMOPS)
  move32();
#endif

  Max_ACC0 = (Word32) 0;
  ptr32 = tmp32 + G729EV_G729_L_SUBFR;
  ptr16 = y1 + G729EV_G729_L_SUBFR;

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {

#if (WMOPS)
    move32();
#endif
    ACC0 = (Word32) 0;
    ptr32--;
    ptr16--;
    ptr16tmp = ptr16;
    FOR(j = 0; j <= i; j++)
      ACC0 = L_mac(ACC0, h_scaled[j], *ptr16tmp++);

#if (WMOPS)
    move32();
#endif
    *ptr32 = ACC0;

    if (L_sub(L_abs(ACC0), Max_ACC0) > 0)
      Max_ACC0 = L_abs(ACC0);
  }
  shift_y1 = norm_l(Max_ACC0);

  ptr16 = tmp;
  FOR(i = 0; i < 40; i++)
  {
    *ptr16++ = extract_h(L_shl(tmp32[i], shift_y1));

  }


#if (WMOPS)
  move32();
#endif
  ACC0 = (Word32) 0;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    ACC0 = L_mac(ACC0, y1[i], y1[i]);


  IF(ACC0 > 0)
  {
    shift_div = norm_l(ACC0);
    tmp16 = extract_h(L_shl(ACC0, shift_div));
    r1 = div_s(16384, tmp16);
  }
  ELSE
  {

#if (WMOPS)
    move16();
    move16();
#endif

    shift_div = (Word16) 0;
    r1 = (Word16) 0;
  }

  shift_div = sub(sub(shl(shift_y1, 1), shift_div), 1);

  p0 = rri0i0;
  p1 = rri1i1;
  p2 = rri2i2;
  p3 = rri3i3;
  p4 = rri4i4;

#if (WMOPS)
  move16();
  move16();
#endif

  ii = (Word16) 0;
  kk = (Word16) 0;
  FOR(i = 0; i < G729EV_G729_NB_POS; i++)
  {
    rt0 = mult(tmp[ii], r1);
    rt1 = mult(tmp[ii + 1], r1);
    rt2 = mult(tmp[ii + 2], r1);
    rt3 = mult(tmp[ii + 3], r1);
    rt4 = mult(tmp[ii + 4], r1);

    tmp16 = mult(rt0, tmp[ii]);
    *p0++ = sub(rri0i0[i], shr(tmp16, shift_div));
#if (WMOPS)
    move16();
#endif

    tmp16 = mult(rt1, tmp[ii + 1]);
    *p1++ = sub(rri1i1[i], shr(tmp16, shift_div));
#if (WMOPS)
    move16();
#endif

    tmp16 = mult(rt2, tmp[ii + 2]);
    *p2++ = sub(rri2i2[i], shr(tmp16, shift_div));
#if (WMOPS)
    move16();
#endif

    tmp16 = mult(rt3, tmp[ii + 3]);
    *p3++ = sub(rri3i3[i], shr(tmp16, shift_div));
#if (WMOPS)
    move16();
#endif

    tmp16 = mult(rt4, tmp[ii + 4]);
    *p4++ = sub(rri4i4[i], shr(tmp16, shift_div));
#if (WMOPS)
    move16();
#endif


    p01 = rri0i1 + kk;
    p02 = rri0i2 + kk;
    p03 = rri0i3 + kk;
    p04 = rri0i4 + kk;
    p12 = rri1i2 + kk;
    p13 = rri1i3 + kk;
    p14 = rri1i4 + kk;
    p23 = rri2i3 + kk;
    p24 = rri2i4 + kk;

#if (WMOPS)
    move16();
#endif
    jj = (Word16) 0;
    FOR(j = 0; j < G729EV_G729_NB_POS; j++)
    {
      tmp16 = mult(rt0, tmp[jj + 1]);
      *p01++ = sub(rri0i1[kk + j], shr(tmp16, shift_div));
#if (WMOPS)
      move16();
#endif

      tmp16 = mult(rt0, tmp[jj + 2]);
      *p02++ = sub(rri0i2[kk + j], shr(tmp16, shift_div));
#if (WMOPS)
      move16();
#endif

      tmp16 = mult(rt0, tmp[jj + 3]);
      *p03++ = sub(rri0i3[kk + j], shr(tmp16, shift_div));
#if (WMOPS)
      move16();
#endif

      tmp16 = mult(rt0, tmp[jj + 4]);
      *p04++ = sub(rri0i4[kk + j], shr(tmp16, shift_div));
#if (WMOPS)
      move16();
#endif

      tmp16 = mult(rt1, tmp[jj + 2]);
      *p12++ = sub(rri1i2[kk + j], shr(tmp16, shift_div));
#if (WMOPS)
      move16();
#endif

      tmp16 = mult(rt1, tmp[jj + 3]);
      *p13++ = sub(rri1i3[kk + j], shr(tmp16, shift_div));
#if (WMOPS)
      move16();
#endif

      tmp16 = mult(rt1, tmp[jj + 4]);
      *p14++ = sub(rri1i4[kk + j], shr(tmp16, shift_div));
#if (WMOPS)
      move16();
#endif

      tmp16 = mult(rt2, tmp[jj + 3]);
      *p23++ = sub(rri2i3[kk + j], shr(tmp16, shift_div));
#if (WMOPS)
      move16();
#endif

      tmp16 = mult(rt2, tmp[jj + 4]);
      *p24++ = sub(rri2i4[kk + j], shr(tmp16, shift_div));
#if (WMOPS)
      move16();
#endif

      jj = add(jj, 5);
    }

    ii = add(ii, 5);
    kk = add(kk, 8);
  }
}


/*--------------------------------------------------------------------------*
 * Function  G729EV_CELP2S_cor_h_x_OTH()                                    *
 * Compute  correlations of input response h[] with the target vector X[].  *
 *--------------------------------------------------------------------------*/
void G729EV_CELP2S_cor_h_x_OTH(Word16 h[],  /* (i) : Impulse response of filters (Q12) */
                               Word16 x[],  /* (i) : Target vector */
                               Word16 d[],  /* (o) : Correlation between h[] and x[] */
                               Word16 y1[]  /* (i) : ac synthesised signal */
    )
{
  Word32    y32[G729EV_G729_L_SUBFR];
  Word32   *p_y32;

  Word32    ACC0, ACC1, tmp32;
  Word32    r0, max, s;

  Word16    tmp[G729EV_G729_L_SUBFR];
  Word16   *p_tmp;

  Word16   *p_d;

  Word16    i, j;
  Word16    shift_div, shift_mult;
  Word16    w16_hi, w16_lo;
  Word16    tmp16;


#if (WMOPS)
  move32();
  move32();
#endif
  ACC0 = (Word32) 0;
  ACC1 = (Word32) 0;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    ACC0 = L_mac(ACC0, x[i], y1[i]);
    ACC1 = L_mac(ACC1, y1[i], y1[i]);
  }

  IF(ACC1 > 0)
  {
    /* 1/r1 */
    shift_div = norm_l(ACC1);
    tmp16 = extract_h(L_shl(ACC1, shift_div));
    tmp16 = div_s(16384, tmp16);

    /* r0 * (1/r1) */
    shift_mult = norm_l(ACC0);
    L_Extract(L_shl(ACC0, shift_mult), &w16_hi, &w16_lo);
    r0 = Mpy_32_16(w16_hi, w16_lo, tmp16);

    shift_div = sub(15, shift_div);
    shift_div = add(shift_div, shift_mult);
  }
  ELSE
  {
#if (WMOPS)
    move32();
    move16();
#endif
    r0 = (Word32) 0;
    shift_div = (Word16) 0;
  }


  p_tmp = tmp;
  L_Extract(r0, &w16_hi, &w16_lo);
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    tmp32 = Mpy_32_16(w16_hi, w16_lo, y1[i]);
    *p_tmp++ = sub(x[i], extract_l(L_shr(tmp32, shift_div)));
#if (WMOPS)
    move16();
#endif
  }

  /* first keep the result on 32 bits and find absolute maximum */
#if (WMOPS)
  move32();
#endif
  p_y32 = y32;
  max = (Word32) 0;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    s = L_mult(tmp[i], h[0]);
    FOR(j = i + 1; j < G729EV_G729_L_SUBFR; j++)
      s = L_mac(s, tmp[j], h[j - i]);
#if (WMOPS)
    move32();
#endif
    *p_y32++ = s;

    s = L_abs(s);
    tmp32 = L_sub(s, max);

    if (tmp32 > 0L)
    {
      max = s;
#if (WMOPS)
      move32();
#endif
    }
  }

  /* Find the number of right shifts to do on y32[]  */
  /* so that maximum is on 13 bits                   */

  j = norm_l(max);

  if (sub(j, 16) > 0)
  {
#if (WMOPS)
    move16();
#endif
    j = (Word16) 16;
  }

  p_d = d;

  j = sub(18, j);

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    *p_d++ = extract_l(L_shr(y32[i], j));
#if (WMOPS)
    move16();
#endif
  }
}


/*------------------------------------------------------------------------*
 * Function  G729EV_d4i40_17_fast                      *
 *  -> 17 bits; 4 pulses in a frame of 40 samples                         *
 *------------------------------------------------------------------------*
 * The code length is 40, containing 4 nonzero pulses i0, i1, i2, i3.     *
 * Each pulses can have 8 possible positions (positive or negative)       *
 * except i3 that have 16 possible positions.                             *
 *                                                                        *
 * i0 (+-1) : 0, 5, 10, 15, 20, 25, 30, 35                                *
 * i1 (+-1) : 1, 6, 11, 16, 21, 26, 31, 36                                *
 * i2 (+-1) : 2, 7, 12, 17, 22, 27, 32, 37                                *
 * i3 (+-1) : 3, 8, 13, 18, 23, 28, 33, 38                                *
 *            4, 9, 14, 19, 24, 29, 34, 39                                *
 *------------------------------------------------------------------------*/

Word16 G729EV_CELP2S_d4i40_17_fast( /* (o)    : Index of pulses positions.            */
                                    Word16 layer,   /* (i): 0=8k layer, other=12k layer */
                                    Word16 sp,      /* (i): amplitude of the side-pulses */
                                    Word16 b[],     /* (i)    : LTP residual & Dn                */
                                    Word16 dn[],    /* (i)    : Correlations between h[] and Xn[].        */
                                    Word16 rr[],    /* (i)    : Correlations of impulse response h[].      */
                                    Word16 h0[],    /* (i) Q12: Impulse response of filters for the 1st sample.  */
                                    Word16 h[],     /* (i) Q12: Impulse response of filters.          */
                                    Word16 cod[],   /* (o) Q13: Selected algebraic codeword.          */
                                    Word16 y[],     /* (o) Q12: Filtered algebraic codeword.          */
                                    Word16 * sign   /* (o)    : Signs of 4 pulses.                */
    )
{
  Word32    Ek, Ek_share;
  Word32    xtmp32, ytmp32;

  Word16    i, j, k;
  Word16    track, p_max;
  Word16    max;
  Word16    i0, i1, i2, i3, ip[5];
  Word16    i0_offset, i1_offset, i2_offset, i3_offset;
  Word16    sign_dn[G729EV_G729_L_SUBFR], sign_dn_inv[G729EV_G729_L_SUBFR], *psign;
  Word16   *p0, *p1, *p2, *p3, *p4, *p5;
  Word16   *rri0i0, *rri1i1, *rri2i2, *rri3i3, *rri4i4;
  Word16   *rri0i1, *rri0i2, *rri0i3, *rri0i4;
  Word16   *rri1i2, *rri1i3, *rri1i4;
  Word16   *rri2i3, *rri2i4;
  Word16   *ptr_rri0i3_i4;
  Word16   *ptr_rri1i3_i4;
  Word16   *ptr_rri2i3_i4;
  Word16   *ptr_rri3i3_i4;
  Word16    Ck, Ck_share;
  Word16    num_max, den_max, num, den, prev_num_max, prev_den_max;
  Word16    xtmp16, ytmp16;

  Word16    sign_pat[4];

  /* Initialize pointers */
  rri0i0 = rr;
  rri1i1 = rri0i0 + G729EV_G729_NB_POS;
  rri2i2 = rri1i1 + G729EV_G729_NB_POS;
  rri3i3 = rri2i2 + G729EV_G729_NB_POS;
  rri4i4 = rri3i3 + G729EV_G729_NB_POS;
  rri0i1 = rri4i4 + G729EV_G729_NB_POS;
  rri0i2 = rri0i1 + G729EV_G729_MSIZE;
  rri0i3 = rri0i2 + G729EV_G729_MSIZE;
  rri0i4 = rri0i3 + G729EV_G729_MSIZE;
  rri1i2 = rri0i4 + G729EV_G729_MSIZE;
  rri1i3 = rri1i2 + G729EV_G729_MSIZE;
  rri1i4 = rri1i3 + G729EV_G729_MSIZE;
  rri2i3 = rri1i4 + G729EV_G729_MSIZE;
  rri2i4 = rri2i3 + G729EV_G729_MSIZE;

  p0 = sign_dn;
  p1 = sign_dn_inv;
  p2 = dn;
  p3 = b;

  /* Obtain the signs and absolute values of dn[], b[] */
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
#if(WMOPS)
    move16();
    move16();
#endif
    IF(dn[i] >= 0)
    {
      *p0++ = MAX_16;
      *p1++ = MIN_16;
      p2++;
      p3++;
    }
    ELSE
    {
      *p0++ = MIN_16;
      *p1++ = MAX_16;
      *p2++ = negate(dn[i]);
      *p3++ = negate(b[i]);
#if(WMOPS)
      move16();
      move16();
#endif
    }
  }

  p0 = rri0i1;
  p1 = rri0i2;
  p2 = rri0i3;
  p3 = rri0i4;

  /* Modify the rr[](rri0i1[], rri0i2[], rri0i3[], rri0i4[]) */
  /* to take signs into account */
  FOR(i0 = 0; i0 < G729EV_G729_L_SUBFR; i0 += G729EV_G729_STEP)
  {
    psign = sign_dn;
    if (psign[i0] < 0)
    {
      psign = sign_dn_inv;
    }

    FOR(i1 = 1; i1 < G729EV_G729_L_SUBFR; i1 += G729EV_G729_STEP)
    {
      *p0 = mult(*p0, psign[i1]);
      p0++;
      *p1 = mult(*p1, psign[i1 + 1]);
      p1++;
      *p2 = mult(*p2, psign[i1 + 2]);
      p2++;
      *p3 = mult(*p3, psign[i1 + 3]);
      p3++;
#if (WMOPS)
      move16();
      move16();
      move16();
      move16();
#endif
    }
  }

  p0 = rri1i2;
  p1 = rri1i3;
  p2 = rri1i4;

  /* Modify the rr[](rri1i2[], rri1i3[], rri1i4[]) */
  /* to take signs into account */
  FOR(i1 = 1; i1 < G729EV_G729_L_SUBFR; i1 += G729EV_G729_STEP)
  {
    psign = sign_dn;
    if (psign[i1] < 0)
    {
      psign = sign_dn_inv;
    }

    FOR(i2 = 2; i2 < G729EV_G729_L_SUBFR; i2 += G729EV_G729_STEP)
    {
      *p0 = mult(*p0, psign[i2]);
      p0++;
      *p1 = mult(*p1, psign[i2 + 1]);
      p1++;
      *p2 = mult(*p2, psign[i2 + 2]);
      p2++;
#if (WMOPS)
      move16();
      move16();
      move16();
#endif
    }
  }

  p0 = rri2i3;
  p1 = rri2i4;

  /* Modify the rr[](rri2i3[], rri2i4[]) to take signs into account */
  FOR(i2 = 2; i2 < G729EV_G729_L_SUBFR; i2 += G729EV_G729_STEP)
  {
    psign = sign_dn;
    if (psign[i2] < 0)
    {
      psign = sign_dn_inv;
    }

    FOR(i3 = 3; i3 < G729EV_G729_L_SUBFR; i3 += G729EV_G729_STEP)
    {
      *p0 = mult(*p0, psign[i3]);
      p0++;
      *p1 = mult(*p1, psign[i3 + 1]);
      p1++;
#if (WMOPS)
      move16();
      move16();
#endif
    }
  }

  /* Find initial positions of the 4 pulses which maximize b[] */
  FOR(track = 0; track < 5; track++)
  {
#if (WMOPS)
    move16();
    move16();
#endif
    max = b[track];
    ip[track] = track;

    FOR(i = track + G729EV_G729_STEP; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
    {
      IF(sub(b[i], max) > 0)
      {
#if (WMOPS)
        move16();
        move16();
#endif
        max = b[i];
        ip[track] = i;
      }
    }
  }

  ptr_rri0i3_i4 = rri0i3;
  ptr_rri1i3_i4 = rri1i3;
  ptr_rri2i3_i4 = rri2i3;
  ptr_rri3i3_i4 = rri3i3;

  IF(sub(b[ip[3]], b[ip[4]]) < 0)
  {
#if (WMOPS)
    move16();
#endif
    ip[3] = ip[4];
    ptr_rri0i3_i4 = rri0i4;
    ptr_rri1i3_i4 = rri1i4;
    ptr_rri2i3_i4 = rri2i4;
    ptr_rri3i3_i4 = rri4i4;
  }

  /* Compute Qk terms(square(correlation), energy) according to the initial pulses */
  i0 = mult(ip[0], 6554);       /* ip[0]/5 */
  i1 = mult(ip[1], 6554);       /* ip[1]/5 */
  i2 = mult(ip[2], 6554);       /* ip[2]/5 */
  i3 = mult(ip[3], 6554);       /* ip[3]/5 */
  i0_offset = shl(i0, 3);
  i1_offset = shl(i1, 3);
  i2_offset = shl(i2, 3);
  i3_offset = shl(i3, 3);

  p0 = rri0i1 + i0_offset + i1;
  p1 = rri0i2 + i0_offset + i2;
  p2 = ptr_rri0i3_i4 + i0_offset + i3;
  p3 = rri1i2 + i1_offset + i2;
  p4 = ptr_rri1i3_i4 + i1_offset + i3;
  p5 = ptr_rri2i3_i4 + i2_offset + i3;


  xtmp16 = add(dn[ip[0]], dn[ip[1]]);
  ytmp16 = add(dn[ip[2]], dn[ip[3]]);
  Ck = add(xtmp16, ytmp16);

  Ek = L_mult0(rri0i0[i0], G729EV_CELP2S_FCB_1_8);
  Ek = L_mac0(Ek, rri1i1[i1], G729EV_CELP2S_FCB_1_8);
  Ek = L_mac0(Ek, rri2i2[i2], G729EV_CELP2S_FCB_1_8);
  Ek = L_mac0(Ek, ptr_rri3i3_i4[i3], G729EV_CELP2S_FCB_1_8);
  Ek = L_mac0(Ek, *p0, G729EV_CELP2S_FCB_1_4);
  Ek = L_mac0(Ek, *p1, G729EV_CELP2S_FCB_1_4);
  Ek = L_mac0(Ek, *p2, G729EV_CELP2S_FCB_1_4);
  Ek = L_mac0(Ek, *p3, G729EV_CELP2S_FCB_1_4);
  Ek = L_mac0(Ek, *p4, G729EV_CELP2S_FCB_1_4);
  Ek = L_mac0(Ek, *p5, G729EV_CELP2S_FCB_1_4);

#if (WMOPS)
  move16();
  move16();
  move16();
  move16();
#endif
  num_max = mult(Ck, Ck);
  den_max = round(Ek);
  prev_num_max = num_max;
  prev_den_max = den_max;
  track = 5;
  p_max = 0;

  /****************************************************************/
  /* Perform one pulse replacement for each track and select     */
  /* pulse positions which maximize square(correlation)/energy */
  /* The number of repetition is G729EV_CELP2S_FCB_REPEAT         */
  /****************************************************************/
  FOR(j = 0; j < G729EV_CELP2S_FCB_REPEAT; j++)
  {
    /* If previously searched track is not 0 */
    IF(track != 0)
    {
      p0 = rri1i1 + i1;
      p1 = rri2i2 + i2;
      p2 = ptr_rri3i3_i4 + i3;
      p3 = rri1i2 + i1_offset + i2;
      p4 = ptr_rri1i3_i4 + i1_offset + i3;
      p5 = ptr_rri2i3_i4 + i2_offset + i3;

      xtmp16 = add(dn[ip[1]], dn[ip[2]]);
      Ck_share = add(xtmp16, dn[ip[3]]);

      Ek_share = L_mult0(*p0, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p1, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p2, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p3, G729EV_CELP2S_FCB_1_4);
      Ek_share = L_mac0(Ek_share, *p4, G729EV_CELP2S_FCB_1_4);
      Ek_share = L_mac0(Ek_share, *p5, G729EV_CELP2S_FCB_1_4);

      p0 = rri0i0;
      p1 = rri0i1 + i1;
      p2 = rri0i2 + i2;
      p3 = ptr_rri0i3_i4 + i3;

      FOR(i = 0; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
      {
        Ck = add(Ck_share, dn[i]);
        Ek = L_mac0(Ek_share, *p0, G729EV_CELP2S_FCB_1_8);
        Ek = L_mac0(Ek, *p1, G729EV_CELP2S_FCB_1_4);
        Ek = L_mac0(Ek, *p2, G729EV_CELP2S_FCB_1_4);
        Ek = L_mac0(Ek, *p3, G729EV_CELP2S_FCB_1_4);

        p0++;
        p1 += G729EV_G729_NB_POS;
        p2 += G729EV_G729_NB_POS;
        p3 += G729EV_G729_NB_POS;

        num = mult(Ck, Ck);
        den = round(Ek);
        xtmp32 = L_msu0(L_mult0(num, den_max), num_max, den);


        IF(xtmp32 > 0)
        {
#if (WMOPS)
          move16();
          move16();
          move16();
#endif
          num_max = num;
          den_max = den;
          p_max = i;
        }
      }
    }

    /* If previously searched track is not 1 */
    IF(sub(track, 1) != 0)
    {

      p0 = rri0i0 + i0;
      p1 = rri2i2 + i2;
      p2 = ptr_rri3i3_i4 + i3;
      p3 = rri0i2 + i0_offset + i2;
      p4 = ptr_rri0i3_i4 + i0_offset + i3;
      p5 = ptr_rri2i3_i4 + i2_offset + i3;

      xtmp16 = add(dn[ip[0]], dn[ip[2]]);
      Ck_share = add(xtmp16, dn[ip[3]]);

      Ek_share = L_mult0(*p0, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p1, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p2, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p3, G729EV_CELP2S_FCB_1_4);
      Ek_share = L_mac0(Ek_share, *p4, G729EV_CELP2S_FCB_1_4);
      Ek_share = L_mac0(Ek_share, *p5, G729EV_CELP2S_FCB_1_4);

      p0 = rri1i1;
      p1 = rri0i1 + i0_offset;
      p2 = rri1i2 + i2;
      p3 = ptr_rri1i3_i4 + i3;

      FOR(i = 1; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
      {
        Ck = add(Ck_share, dn[i]);
        Ek = L_mac0(Ek_share, *p0, G729EV_CELP2S_FCB_1_8);
        Ek = L_mac0(Ek, *p1, G729EV_CELP2S_FCB_1_4);
        Ek = L_mac0(Ek, *p2, G729EV_CELP2S_FCB_1_4);
        Ek = L_mac0(Ek, *p3, G729EV_CELP2S_FCB_1_4);

        p0++;
        p1++;
        p2 += G729EV_G729_NB_POS;
        p3 += G729EV_G729_NB_POS;


        num = mult(Ck, Ck);
        den = round(Ek);
        xtmp32 = L_msu0(L_mult0(num, den_max), num_max, den);



        IF(xtmp32 > 0)
        {
#if (WMOPS)
          move16();
          move16();
          move16();
#endif
          num_max = num;
          den_max = den;
          p_max = i;
        }
      }
    }

    /* If previously searched track is not 2 */
    IF(sub(track, 2) != 0)
    {
      p0 = rri0i0 + i0;
      p1 = rri1i1 + i1;
      p2 = ptr_rri3i3_i4 + i3;
      p3 = rri0i1 + i0_offset + i1;
      p4 = ptr_rri0i3_i4 + i0_offset + i3;
      p5 = ptr_rri1i3_i4 + i1_offset + i3;

      xtmp16 = add(dn[ip[0]], dn[ip[1]]);
      Ck_share = add(xtmp16, dn[ip[3]]);
      Ek_share = L_mult0(*p0, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p1, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p2, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p3, G729EV_CELP2S_FCB_1_4);
      Ek_share = L_mac0(Ek_share, *p4, G729EV_CELP2S_FCB_1_4);
      Ek_share = L_mac0(Ek_share, *p5, G729EV_CELP2S_FCB_1_4);

      p0 = rri2i2;
      p1 = rri0i2 + i0_offset;
      p2 = rri1i2 + i1_offset;
      p3 = ptr_rri2i3_i4 + i3;

      FOR(i = 2; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
      {
        Ck = add(Ck_share, dn[i]);
        Ek = L_mac0(Ek_share, *p0, G729EV_CELP2S_FCB_1_8);
        Ek = L_mac0(Ek, *p1, G729EV_CELP2S_FCB_1_4);
        Ek = L_mac0(Ek, *p2, G729EV_CELP2S_FCB_1_4);
        Ek = L_mac0(Ek, *p3, G729EV_CELP2S_FCB_1_4);

        p0++;
        p1++;
        p2++;
        p3 += G729EV_G729_NB_POS;

        num = mult(Ck, Ck);
        den = round(Ek);
        xtmp32 = L_msu0(L_mult0(num, den_max), num_max, den);

        IF(xtmp32 > 0)
        {
#if (WMOPS)
          move16();
          move16();
          move16();
#endif
          num_max = num;
          den_max = den;
          p_max = i;
        }
      }
    }

    /* If previously searched track is not 3 */
    IF(sub(track, 3) != 0)
    {
      p0 = rri0i0 + i0;
      p1 = rri1i1 + i1;
      p2 = rri2i2 + i2;
      p3 = rri0i1 + i0_offset + i1;
      p4 = rri0i2 + i0_offset + i2;
      p5 = rri1i2 + i1_offset + i2;

      xtmp16 = add(dn[ip[0]], dn[ip[1]]);
      Ck_share = add(xtmp16, dn[ip[2]]);
      Ek_share = L_mult0(*p0, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p1, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p2, G729EV_CELP2S_FCB_1_8);
      Ek_share = L_mac0(Ek_share, *p3, G729EV_CELP2S_FCB_1_4);
      Ek_share = L_mac0(Ek_share, *p4, G729EV_CELP2S_FCB_1_4);
      Ek_share = L_mac0(Ek_share, *p5, G729EV_CELP2S_FCB_1_4);

      p0 = rri3i3;
      p1 = rri0i3 + i0_offset;
      p2 = rri1i3 + i1_offset;
      p3 = rri2i3 + i2_offset;

      FOR(i = 3; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
      {
        Ck = add(Ck_share, dn[i]);
        Ek = L_mac0(Ek_share, *p0, G729EV_CELP2S_FCB_1_8);
        Ek = L_mac0(Ek, *p1, G729EV_CELP2S_FCB_1_4);
        Ek = L_mac0(Ek, *p2, G729EV_CELP2S_FCB_1_4);
        Ek = L_mac0(Ek, *p3, G729EV_CELP2S_FCB_1_4);

        p0++;
        p1++;
        p2++;
        p3++;

        num = mult(Ck, Ck);
        den = round(Ek);
        xtmp32 = L_msu0(L_mult0(num, den_max), num_max, den);


        IF(xtmp32 > 0)
        {
#if (WMOPS)
          move16();
          move16();
          move16();
#endif
          num_max = num;
          den_max = den;
          p_max = i;
        }

        IF(sub(i, 38) == 0)
        {
#if (WMOPS)
          move16();
#endif
          i = -1;
          p0 = rri4i4;
          p1 = rri0i4 + i0_offset;
          p2 = rri1i4 + i1_offset;
          p3 = rri2i4 + i2_offset;
        }
      }
    }

    xtmp32 = L_msu(L_mult(num_max, prev_den_max), prev_num_max, den_max);
    ytmp32 = L_sub(xtmp32, G729EV_CELP2S_FCB_THRES);

    IF(ytmp32 > 0)
    {
#if (WMOPS)
      move16();
      move16();
#endif
      prev_num_max = num_max;
      prev_den_max = den_max;

      xtmp16 = mult(p_max, 6554); /* track = p_max % 5 */
      ytmp16 = add(xtmp16, shl(xtmp16, 2));
      track = sub(p_max, ytmp16);
#if (WMOPS)
      move16();
#endif
      ip[track] = p_max;

      IF(sub(track, 3) == 0)
      {
        ptr_rri0i3_i4 = rri0i3;
        ptr_rri1i3_i4 = rri1i3;
        ptr_rri2i3_i4 = rri2i3;
        ptr_rri3i3_i4 = rri3i3;
      }

      IF(sub(track, 4) == 0)
      {
#if (WMOPS)
        move16();
        move16();
#endif
        ip[3] = ip[4];
        track = 3;
        ptr_rri0i3_i4 = rri0i4;
        ptr_rri1i3_i4 = rri1i4;
        ptr_rri2i3_i4 = rri2i4;
        ptr_rri3i3_i4 = rri4i4;
      }

      i0 = mult(ip[0], 6554);
      i1 = mult(ip[1], 6554);
      i2 = mult(ip[2], 6554);
      i3 = mult(ip[3], 6554);
      i0_offset = shl(i0, 3);
      i1_offset = shl(i1, 3);
      i2_offset = shl(i2, 3);
      i3_offset = shl(i3, 3);
    }
    ELSE
    {
      BREAK;
    }
  }

  /* Set the sign of impulses */
#if (WMOPS)
  move16();
  move16();
  move16();
  move16();
#endif
  i0 = sign_dn[ip[0]];
  i1 = sign_dn[ip[1]];
  i2 = sign_dn[ip[2]];
  i3 = sign_dn[ip[3]];

  /* Find the codeword corresponding to the selected positions */

  p0 = cod;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
#if (WMOPS)
    move16();
#endif
    *p0++ = 0;
  }

  IF(layer != 0)
  {
#if (WMOPS)
    logic16();
    logic16();
    logic16();
    logic16();
    move16();
    move16();
    move16();
    move16();
#endif
    sign_pat[0] = i0 & 1;
    sign_pat[1] = i1 & 1;
    sign_pat[2] = i2 & 1;
    sign_pat[3] = i3 & 1;
    G729EV_CELP2S_Put4Patterns(ip, sign_pat, sp, cod);
  }
  ELSE
  {
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif
    cod[ip[0]] = shr(i0, 2);    /* From Q15 to Q13 */
    cod[ip[1]] = shr(i1, 2);
    cod[ip[2]] = shr(i2, 2);
    cod[ip[3]] = shr(i3, 2);
  }

  /* find the filtered codeword */
  p0 = y;
  FOR(i = 0; i < ip[0]; i++)
  {
#if (WMOPS)
    move16();
#endif
    *p0++ = 0;
  }


  IF(i0 > 0)
  {
    IF(ip[0] > 0)
    {
#if (WMOPS)
      move16();
      move16();
#endif
      k = sub(ip[0], 1);
      p0 = y + k;
      p1 = h - 1;

      FOR(i = k; i < G729EV_G729_L_SUBFR; i++)
      {
#if (WMOPS)
        move16();
#endif
        *p0++ = *p1++;
      }
    }
    ELSE
    {
#if (WMOPS)
      move16();
      move16();
#endif
      p0 = y + ip[0];
      p1 = h0;
      FOR(i = ip[0]; i < G729EV_G729_L_SUBFR; i++)
      {
#if (WMOPS)
        move16();
#endif
        *p0++ = *p1++;
      }
    }
  }
  ELSE
  {

    IF(ip[0] > 0)
    {
#if (WMOPS)
      move16();
      move16();
#endif
      k = sub(ip[0], 1);
      p0 = y + k;
      p1 = h - 1;

      FOR(i = k; i < G729EV_G729_L_SUBFR; i++)
      {
        *p0++ = negate(*p1++);
#if (WMOPS)
        move16();
#endif
      }
    }
    ELSE
    {
#if (WMOPS)
      move16();
      move16();
#endif
      p0 = y + ip[0];
      p1 = h0;
      FOR(i = ip[0]; i < G729EV_G729_L_SUBFR; i++)
      {
        *p0++ = negate(*p1++);
#if (WMOPS)
        move16();
#endif
      }
    }
  }


#if (WMOPS)
  move16();
  move16();
#endif
  k = sub(ip[1], 1);
  p0 = y + k;
  p1 = h - 1;

  IF(i1 > 0)
  {
    FOR(i = k; i < G729EV_G729_L_SUBFR; i++)
    {
      *p0++ = add(y[i], *p1++);
#if (WMOPS)
      move16();
#endif
    }
  }
  ELSE
  {
    FOR(i = k; i < G729EV_G729_L_SUBFR; i++)
    {
      *p0++ = sub(y[i], *p1++);
#if (WMOPS)
      move16();
#endif
    }
  }

#if (WMOPS)
  move16();
  move16();
#endif
  k = sub(ip[2], 1);
  p0 = y + k;
  p1 = h - 1;

  IF(i2 > 0)
  {
    FOR(i = k; i < G729EV_G729_L_SUBFR; i++)
    {
      *p0++ = add(y[i], *p1++);
#if (WMOPS)
      move16();
#endif
    }
  }
  ELSE
  {
    FOR(i = k; i < G729EV_G729_L_SUBFR; i++)
    {
      *p0++ = sub(y[i], *p1++);
#if (WMOPS)
      move16();
#endif
    }
  }

#if (WMOPS)
  move16();
  move16();
#endif
  k = sub(ip[3], 1);
  p0 = y + k;
  p1 = h - 1;

  IF(i3 > 0)
  {
    FOR(i = k; i < G729EV_G729_L_SUBFR; i++)
    {
      *p0++ = add(y[i], *p1++);
#if (WMOPS)
      move16();
#endif
    }
  }
  ELSE
  {
    FOR(i = k; i < G729EV_G729_L_SUBFR; i++)
    {
      *p0++ = sub(y[i], *p1++);
#if (WMOPS)
      move16();
#endif
    }
  }


  /* find codebook index;  17-bit address */

#if (WMOPS)
  move16();
#endif
  i = 0;

  if (i0 > 0)
  {
    i = add(i, 1);
  }
  if (i1 > 0)
  {
    i = add(i, 2);
  }
  if (i2 > 0)
  {
    i = add(i, 4);
  }
  if (i3 > 0)
  {
    i = add(i, 8);
  }
#if (WMOPS)
  move16();
#endif
  *sign = i;


#if (WMOPS)
  move16();
#endif
  p0 = ip;
  *p0++ = mult(ip[0], 6554);    /* ip[0]/5  */
  *p0++ = mult(ip[1], 6554);    /* ip[1]/5  */
  *p0++ = mult(ip[2], 6554);    /* ip[2]/5  */
#if (WMOPS)
  move16();
  move16();
  move16();
#endif
  i = mult(ip[3], 6554);        /* ip[3]/5  */
  j = add(i, shl(i, 2));        /* j = i*5  */
  j = sub(ip[3], add(j, 3));    /* j= ip3%5 -3 */
  *p0 = add(shl(i, 1), j);
#if (WMOPS)
  move16();
#endif

  i = add(ip[0], shl(ip[1], 3));
  i = add(i, shl(ip[2], 6));
  i = add(i, shl(ip[3], 9));


  return i;
}


/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_ACELP_code_A_OTH()               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~               *
 *   Index of pulses positions                               *
 *-----------------------------------------------------------*/

Word16 G729EV_CELP2S_ACELP_code_A_OTH(Word16 x[],           /* (i)  Target vector                */
                                      Word16 res2[],        /* (i)  LTP residual                 */
                                      Word16 h[],           /* (i)  Inpulse response of filters  */
                                      Word16 T0,            /* (i)  Pitch lag                    */
                                      Word16 pitch_sharp,   /* (i)  Last quantized pitch gain    */
                                      Word16 code[],        /* (o)  Innovative codebook          */
                                      Word16 y[],           /* (o)  Filtered innovative codebook */
                                      Word16 * sign,        /* (o)  Signs of 4 pulses            */
                                      Word16 y1[]           /* (i)  AC synthesized signal        */
    )
{

  Word32    xtmp32, ytmp32;

  Word16    i, index, sharp;
  Word16    Dn[G729EV_G729_L_SUBFR], bn[G729EV_G729_L_SUBFR];
  Word16    rr[G729EV_G729_DIM_RR];
  Word16    norm_res2, norm_Dn;
  Word16    h_buf[G729EV_G729_L_SUBFR + 1];
  Word16   *ptr;


  G729EV_G729_Copy(h, h_buf + 1, G729EV_G729_L_SUBFR);
  h_buf[0] = 0;
#if (WMOPS)
  move16();
#endif



   /*-----------------------------------------------------------------*
    * Include fixed-gain pitch contribution into impulse resp. h[]    *
    * Find correlations of h[] needed for the codebook search.        *
    *-----------------------------------------------------------------*/

  sharp = shl(pitch_sharp, 1);  /* From Q14 to Q15 */
  IF(sub(T0, G729EV_G729_L_SUBFR) < 0)
  {
    ptr = h + T0;
    FOR(i = T0; i < G729EV_G729_L_SUBFR; i++)
    {                           /* h[i] += pitch_sharp*h[i-T0] */
      *ptr++ = add(h[i], mult(h[i - T0], sharp));
#if (WMOPS)
      move16();
#endif
    }
  }

  G729EV_CELP2S_cor_h_OTH(h, rr, y1);

   /*-----------------------------------------------------------------*
    * Compute correlation of target vector with impulse response.     *
    *-----------------------------------------------------------------*/

  G729EV_CELP2S_cor_h_x_OTH(h, x, Dn, y1);


  /* Initialization of xtmp32 and ytmp32 */
#if (WMOPS)
  move32();
  move32();
#endif
  xtmp32 = 256;
  ytmp32 = 256;

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    xtmp32 = L_mac(xtmp32, res2[i], res2[i]);
    ytmp32 = L_mac(ytmp32, Dn[i], Dn[i]);
  }

  xtmp32 = Inv_sqrt(xtmp32);
  norm_res2 = extract_h(L_shl(xtmp32, 5));
  ytmp32 = Inv_sqrt(ytmp32);
  norm_Dn = extract_h(L_shl(ytmp32, 5));

  /* bn[i] = res2[i] * norm_res2 + Dn[i] * norm_Dn */
  ptr = bn;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    xtmp32 = L_mult(norm_res2, res2[i]);
    ytmp32 = L_mac(xtmp32, norm_Dn, Dn[i]);
    *ptr++ = round(L_shl(ytmp32, 10));
#if (WMOPS)
    move16();
#endif
  }

  /*-----------------------------------------------------------------*
   * Find innovative codebook.                                       *
   *-----------------------------------------------------------------*/

  /* 1st layer search */
  index = G729EV_CELP2S_d4i40_17_fast(0, 0, bn, Dn, rr, h_buf + 1, h_buf + 1, code, y, sign);

  /*-----------------------------------------------------------------*
   * Compute innovation vector gain.                                 *
   * Include fixed-gain pitch contribution into code[].              *
   *-----------------------------------------------------------------*/

  IF(sub(T0, G729EV_G729_L_SUBFR) < 0)
  {
    ptr = code + T0;
    FOR(i = T0; i < G729EV_G729_L_SUBFR; i++)  /* code[i] += pitch_sharp*code[i-T0] */
      *ptr++ = add(code[i], mult(code[i - T0], sharp));
#if (WMOPS)
    move16();
#endif
  }

  return index;
}


/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_ACELP_code_2NDLAYER()            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~            *
 *   Index of patterns centre positions                      *
 *-----------------------------------------------------------*/

Word16 G729EV_CELP2S_ACELP_code_2NDLAYER(Word16 x[],                /* (i)  Target vector                */
                                         Word16 res2[],             /* (i)  LTP residual                 */
                                         Word16 h[],                /* (i)  Impulse response of filters  */
                                         Word16 norm_voiced_fac,    /* (i)  Voicing factor               */
                                         Word16 code[],             /* (o)  Innovative codebook          */
                                         Word16 y[],                /* (o)  Filtered innovative codebook */
                                         Word16 * sign              /* (o)  Signs of 4 patterns          */
    )
{
  Word32    xtmp32, ytmp32;

  Word16    index;
  Word16    rr[G729EV_G729_DIM_RR];
  Word16    Dn[G729EV_G729_L_SUBFR], bn[G729EV_G729_L_SUBFR];
  Word16    h_buf[G729EV_G729_L_SUBFR + 1], x_hp[G729EV_G729_L_SUBFR + 1];
  Word16    h0_buf[G729EV_G729_L_SUBFR + 1], h1_buf[G729EV_G729_L_SUBFR + 1];
  Word16    h0_buf0[G729EV_G729_L_SUBFR + 1];
  Word16    norm_res2, norm_Dn;
  Word16    i;
  Word16    sp;
  Word16   *ptr;


  G729EV_G729_Copy(h, h0_buf + 1, G729EV_G729_L_SUBFR);
  G729EV_G729_Copy(x, x_hp + 1, G729EV_G729_L_SUBFR);
  h0_buf[0] = 0;
  x_hp[0] = 0;
#if (WMOPS)
  move16();
  move16();
#endif

  /* High Pass filter the target vector and the impulse response to better focus on HFs */
  G729EV_MAIN_CONVOLVE_3Tap(h0_buf, h1_buf, G729EV_CELP2S_HP_FACT, G729EV_G729_L_SUBFR + 1);
  G729EV_MAIN_CONVOLVE_3Tap(x_hp, x_hp, G729EV_CELP2S_HP_FACT, G729EV_G729_L_SUBFR + 1);
  h1_buf[0] = 0;
  x_hp[0] = 0;
#if (WMOPS)
  move16();
  move16();
#endif

  sp = mult_r(G729EV_CELP2S_SP, norm_voiced_fac); /* compute side pulse amplitude */

  /* Modify h to introduce tripulse pattern effect */
  G729EV_MAIN_CONVOLVE_3Tap(h1_buf, h_buf, sp, G729EV_G729_L_SUBFR + 1);


 /*-----------------------------------------------------------------*
  * Include fixed-gain pitch contribution into impulse resp. h[]    *
  * Find correlations of h[] needed for the codebook search.        *
  *-----------------------------------------------------------------*/

  G729EV_G729_Cor_h(h_buf + 1, rr);

 /*-----------------------------------------------------------------*
  * Compute correlation of target vector with impulse response.     *
  *-----------------------------------------------------------------*/

  G729EV_G729_Cor_h_X(h_buf + 1, x_hp + 1, Dn, 1);

  /* Initialization of xtmp32 and ytmp32 */
  xtmp32 = 256;
  ytmp32 = 256;
#if (WMOPS)
  move32();
  move32();
#endif

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    xtmp32 = L_mac(xtmp32, res2[i], res2[i]);
    ytmp32 = L_mac(ytmp32, Dn[i], Dn[i]);
  }

  xtmp32 = Inv_sqrt(xtmp32);
  norm_res2 = extract_h(L_shl(xtmp32, 5));
  ytmp32 = Inv_sqrt(ytmp32);
  norm_Dn = extract_h(L_shl(ytmp32, 5));

  /* bn[i] = res2[i] * norm_res2 + Dn[i] * norm_Dn */
  ptr = bn;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    xtmp32 = L_mult(norm_res2, res2[i]);
    ytmp32 = L_mac(xtmp32, norm_Dn, Dn[i]);
    *ptr++ = round(L_shl(ytmp32, 10));
#if (WMOPS)
    move16();
#endif
  }

 /*-----------------------------------------------------------------*
  * Find innovative codebook.                                       *
  *-----------------------------------------------------------------*/
  G729EV_MAIN_CONVOLVE_2Tap(h0_buf, h0_buf0, sp, G729EV_G729_L_SUBFR + 1);
  G729EV_MAIN_CONVOLVE_3Tap(h0_buf, h0_buf, sp, G729EV_G729_L_SUBFR + 1);
  /* 2nd layer search */
  index = G729EV_CELP2S_d4i40_17_fast(1, sp, bn, Dn, rr, h0_buf0 + 1, h0_buf + 1, code, y, sign);

  return index;
}
