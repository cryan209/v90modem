/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_DECOD_H__
#define __G729EV_TDAC_DECOD_H__

#include <stdio.h>
#include <string.h>
#include "stl.h"


/* Functions : */
void      G729EV_TDAC_decoder(Word16 * bitstream,
                              Word16 nbit,
                              Word16 nbit_max, Word16 * yt_hi, Word16 * yq_lo, Word16 * yq_hi, Word16 norm_MDCT);
/* Tables : */


#endif  /*__G729EV_TDAC_DECOD_H__ */
