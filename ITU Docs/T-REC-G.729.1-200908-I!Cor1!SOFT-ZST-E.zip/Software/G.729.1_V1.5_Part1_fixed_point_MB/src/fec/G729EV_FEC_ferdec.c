/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/******************************************************************************/
/* G729EV_FEC_dec :  Decode FER information                                   */
/* - Decode class information (if avalaible)                                  */
/* - Decode pulse postion and sign information (if avalaible)                 */
/* - Decode enegy information (if avalaible)                                  */
/******************************************************************************/
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_FEC_tools.h"
#include "G729EV_MAIN_oper_32b.h"
#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_TDAC_util.h"
#include "stl.h"


Word16 G729EV_FEC_dec(                         /* o:   frame class information               */
                       Word16 * last_good,     /* i:   last good received frame class        */
                       Word16 plast_good,      /* i:  previous last good received frame class */
                       const Word16 prev_bfi,  /* i:   BFI of the previous frame             */
                       Word16 * indice,        /* i/o: Q indices (parameter vector)          */
                       Word32 * enr_q,         /* o:   E information for FER protection      */
                       Word16 Rate             /* i:   Bitrate decoded                       */
    )
{
  Word16    clas, ind, tmp, frac;
  Word32    L_tmp;

  clas = G729EV_FEC_UNVOICED;   /* Initialization         */
  ind = (Word16) indice[0];

#if(WMOPS)
  move16();
  move16();
  move16();
#endif
  IF(ind == 0)
  {
    clas = G729EV_FEC_UNVOICED;
  }
  ELSE if   (sub(ind, 1) == 0)
  {

    IF(sub(*last_good, G729EV_FEC_V_TRANSITION) >= 0)
    {
      clas = G729EV_FEC_V_TRANSITION;
    }
    ELSE
    {
      clas = G729EV_FEC_UV_TRANSITION;
    }
  }
  ELSE if   (sub(ind, 2) == 0)
  {
    clas = G729EV_FEC_VOICED;
  }
  ELSE
  {
    clas = G729EV_FEC_ONSET;
  }

   /*-----------------------------------------------------------------*
    * Decide whether to model ONSET by sinusoidal model (FER) 
    * or regular ACELP  
    *-----------------------------------------------------------------*/

  IF(sub(prev_bfi, G729EV_FEC_GOOD_FRAME) != 0) /* first good after bfi                  */
  {
    IF((sub(clas, G729EV_FEC_VOICED) >= 0) && /* G729EV_FEC_VOICED                                */
       ((sub(*last_good, G729EV_FEC_UV_TRANSITION) < 0))) /* last good received frame was G729EV_FEC_UNVOICED */
    {
#if(WMOPS)
      move16();
      move16();
#endif
      clas = G729EV_FEC_SIN_ONSET;
      move16();
      *last_good = G729EV_FEC_SIN_ONSET;
      move16();
    }
    IF((sub(clas, G729EV_FEC_VOICED) == 0) && /* G729EV_FEC_VOICED                                */
       ((sub(*last_good, G729EV_FEC_VOICED) > 0)) /* last good received frame was G729EV_FEC_UNVOICED */
        )
    {
#if(WMOPS)
      move16();
#endif
      *last_good = G729EV_FEC_VOICED;
      move16();
    }
    ELSE if   ((sub(clas, G729EV_FEC_VOICED) == 0) && /* G729EV_FEC_VOICED                                */
               (sub(plast_good, G729EV_FEC_VOICED) >= 0)) /* last good received frame was G729EV_FEC_UNVOICED */
    {
#if(WMOPS)
      move16();
#endif
      *last_good = G729EV_FEC_VOICED;
      move16();
    }
    ELSE if   ((sub(clas, G729EV_FEC_UNVOICED) == 0) && /* G729EV_FEC_VOICED                                */
               (sub(*last_good, G729EV_FEC_VOICED) == 0)) /* last good received frame was G729EV_FEC_UNVOICED */
    {
#if(WMOPS)
      move16();
#endif
      *last_good = G729EV_FEC_UV_TRANSITION;
      move16();
    }

  }

    /*-----------------------------------------------------------------*
    * Decode the energy for FER concealment
    *-----------------------------------------------------------------*/
  IF(sub(indice[1], -1000) != 0)  /* if information is present */
  {

    /*ftmp = (REAL)pow( 10.0f, ( (REAL)indice[1] * 1.55f ) / 5.0f ); */
    tmp = mult_r(shl(indice[1], 9), 25395); /* Q9*Q14->Q8      */
    L_tmp = L_mult(tmp, 10885); /* 0.332192 in Q15 */
    L_tmp = L_shr(L_tmp, 7);    /* From Q24 to Q16 */
    L_Extract(L_tmp, &tmp, &frac);
    *enr_q = Pow2(tmp, frac);
#if(WMOPS)
    move32();
#endif
  }

  return clas;
}
