/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*-----------------------------------------------------------*
 * Tool library
 * ~~~~~~~~~~~~~~~~~~~                                             
 *-----------------------------------------------------------*/


/* Fixed-point definitions and prototypes */
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_tools.h"
#include "G729EV_FEC_fer.h"

#include "stl.h"

/*----------------------------------------------------------------------------------*
 * procedure   Emaximum:                                     
 *             ~~~~~~~~                                      
 *   Find index of a maximum energy in a vector              
 *----------------------------------------------------------------------------------*/
Word16 G729EV_Emaximum2(                    /* o:   return index with energy value in vector  Q0 */
                         const Word16 Qvec, /* i:   Q of input vector                         Q0 */
                         const Word16 * vec,/* i:   input vector                              Qx */
                         const Word16 lvec, /* i:   length of input vector                    Q0 */
                         Word32 * ener_max  /* o:   maximum energy value                      Q0 */
    )
{
  Word16    j, ind;
  Word32    L_tmp;

#if(WMOPS)
  move16();
  move32();
#endif

  *ener_max = (Word32) 0;
  ind = (Word16) 0;

  FOR(j = 0; j < lvec; j++)
  {
    L_tmp = L_mult(vec[j], vec[j]);
    if (L_sub(L_tmp, *ener_max) > 0)
    {
      ind = j;
      move16();
      *ener_max = L_tmp;
      move32();
#if(WMOPS)
      move16();
      move32();
#endif
    }
  }

#if(WMOPS)
  move32();
#endif
  *ener_max = L_shr(*ener_max, add(add(Qvec, Qvec), 1));

  return ind;
}

/*----------------------------------------------------------------------------------*
 * Function Name : Dot_product()                           
 * Compute scalar product of <x[],y[]> using accumulator.   
 * Performs no normalization, as opposed to Dot_product12()  
 *----------------------------------------------------------------------------------*/
Word32 G729EV_Dot_product(                    /* o:   Sum               */
                           const Word16 x[],  /* i:   12bits: x vector  */
                           const Word16 y[],  /* i:   12bits: y vector  */
                           const Word16 lg    /* i:   vector length     */
    )
{
  Word16    i;
  Word32    L_sum;

  L_sum = L_mac(1L, x[0], y[0]);
  FOR(i = 1; i < lg; i++)
  {
    L_sum = L_mac(L_sum, x[i], y[i]);
  }
  return (L_sum);
}

/*----------------------------------------------------------------------------------*
 * Scale_sig                                                 
 *----------------------------------------------------------------------------------*/
void G729EV_Scale_sig(Word16 x[],       /* i/o: signal to scale                 Qx        */
                      const Word16 lg,  /* i:   size of x[]                     Q0        */
                      const Word16 exp0 /* i:   exponent: x = round(x << exp)   Qx � exp  */
    )
{
  Word16    i;
  Word32    L_tmp;

  FOR(i = 0; i < lg; i++)
  {
    L_tmp = L_deposit_h(x[i]);
    L_tmp = L_shl(L_tmp, exp0); /* saturation can occur here */
    x[i] = round(L_tmp);
#if(WMOPS)
    move16();
#endif
  }

  return;
}


/*___________________________________________________________________________
 |                                                                           |
 |   Function Name : Isqrt_n                                                 |
 |                                                                           |
 |       Compute 1/sqrt(value).                                              |
 |       if value is negative or zero, result is 1 (frac=7fffffff, exp=0).   |
 |---------------------------------------------------------------------------|
 |  Algorithm:                                                               |
 |                                                                           |
 |   The function 1/sqrt(value) is approximated by a table and linear        |
 |   interpolation.                                                          |
 |                                                                           |
 |   1- If exponant is odd then shift fraction right once.                   |
 |   2- exponant = -((exponant-1)>>1)                                        |
 |   3- i = bit25-b30 of fraction, 16 <= i <= 63 ->because of normalization. |
 |   4- a = bit10-b24                                                        |
 |   5- i -=16                                                               |
 |   6- fraction = table[i]<<16 - (table[i] - table[i+1]) * a * 2            |
 |___________________________________________________________________________|
*/


void Isqrt_n(Word32 * frac,     /* (i/o) Q31: normalized value (1.0 < frac <= 0.5) */
             Word16 * exp       /* (i/o)    : exponent (value = frac x 2^exponent) */
    )
{
  Word16    i, a, tmp;


  IF(*frac <= (Word32) 0)
  {
#if(WMOPS)
    move16();
    move32();
#endif
    *exp = 0;
    *frac = 0x7fffffffL;
    return;
  }
#if(WMOPS)
  logic16();
#endif
  if (sub((Word16) (*exp & 1), 1) == 0) /* If exponant odd -> shift right */
  {
    *frac = L_shr(*frac, 1);
#if(WMOPS)
    move16();
#endif
  }

#if(WMOPS)
  move16();
  move32();
  move32();
  move32();
  move32();
  logic16();
#endif

  *exp = negate(shr(sub(*exp, 1), 1));

  *frac = L_shr(*frac, 9);
  i = extract_h(*frac);         /* Extract b25-b31 */
  *frac = L_shr(*frac, 1);
  a = extract_l(*frac);         /* Extract b10-b24 */
  a = (Word16) (a & (Word16) 0x7fff);

  i = sub(i, 16);
  *frac = L_deposit_h(G729EV_table_isqrt[i]); /* table[i] << 16         */
  tmp = sub(G729EV_table_isqrt[i], G729EV_table_isqrt[i + 1]);  /* table[i] - table[i+1]) */

  *frac = L_msu(*frac, tmp, a); /* frac -=  tmp*a*2       */

  return;
}

/*___________________________________________________________________________
 |                                                                           |
 |   Function Name : Dot_product12()                                         |
 |                                                                           |
 |       Compute scalar product of <x[],y[]> using accumulator.              |
 |                                                                           |
 |       The result is normalized (in Q31) with exponent (0..30).            |
 |---------------------------------------------------------------------------|
 |  Algorithm:                                                               |
 |                                                                           |
 |       dot_product = sum(x[i]*y[i])     i=0..N-1                           |
 |___________________________________________________________________________|
*/

Word32 G729EV_Dot_product12(                    /* (o) Q31: normalized result (1 < val <= -1) */
                             const Word16 x[],  /* (i) 12bits: x vector                       */
                             const Word16 y[],  /* (i) 12bits: y vector                       */
                             const Word16 lg,   /* (i)    : vector length                     */
                             Word16 * exp       /* (o)    : exponent of result (0..+30)       */
    )
{
  Word16    i, sft;
  Word32    L_sum;

#if(WMOPS)
  move32();
  move16();
#endif

  L_sum = (Word32) 1;
  FOR(i = 0; i < lg; i++)
  {
    L_sum = L_mac(L_sum, x[i], y[i]);
  }

  /* Normalize acc in Q31 */

  sft = norm_l(L_sum);
  L_sum = L_shl(L_sum, sft);

  *exp = sub(30, sft);          /* exponent = 0..30 */

  return (L_sum);
}
