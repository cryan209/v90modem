/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.5                                                            */
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_ENVADAPTATION_H__
#define __G729EV_MAIN_ENVADAPTATION_H__

#include "stl.h"

void      G729EV_MAIN_envAdapt(Word16 * sOut_low,
                               Word16 * sBasic_low,
                               Word16 * sTdacAdd_low,
                               Word16 * vmlold,
                               Word16 * sOut_hi,
                               Word16 * sBasic_hi,
                               Word16 * sTdacInc_hi,
                               Word16 * vmhold,
                               Word16 work,
                               Word16 begin_index_low,
                               Word16 end_index_low, Word16 begin_index_high, Word16 end_index_high);

void      G729EV_MAIN_PreechoFalseAlarm(Word16 * rec_sig,
                                        Word16 * imdct_mem, Word32 * max_prev, Word16 * begin_ind, Word16 * end_ind);

#endif /* __G729EV_MAIN_ENVADAPTATION_H__ */
