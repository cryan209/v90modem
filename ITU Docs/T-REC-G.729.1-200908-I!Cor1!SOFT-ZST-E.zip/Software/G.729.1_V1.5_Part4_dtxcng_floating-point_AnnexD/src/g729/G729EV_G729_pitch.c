/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.2                                                            */
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_defines.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

/* local functions */

static int G729EV_G729_Lag_max(                 /* output: lag found */
                                REAL signal[],  /* input : Signal to compute the open loop pitch  */
                                int l_frame,    /* input : Length of frame to compute pitch       */
                                int lagmax,     /* input : maximum lag                            */
                                int lagmin,     /* input : minimum lag                            */
                                REAL * cor_max, /* input : normalized correlation of selected lag */
                                REAL * voicing);

static void G729EV_G729_Norm_Corr(REAL exc[], REAL xn[], REAL h[], int l_subfr, int t_min, int t_max, REAL corr_norm[]);

/*****************************************************************************/
/*           Long Term Prediction Routines                                   */
/*****************************************************************************/

/*---------------------------------------------------------------------------*
 * procedure G729EV_G729_Pitch_ol                                            *
 * ~~~~~~~~~~~~~~~~~~                                                        *
 * Compute the open loop pitch lag.                                          *
 *                                                                           *
 *---------------------------------------------------------------------------*/

int G729EV_G729_Pitch_ol(                                                                    /* output: open-loop pitch lag */
                          REAL signal[],                                                     /* input : signal to compute the open loop pitch  
                                             signal[-pit_max] to signal[-1] should be known */
                          int pit_min,                                                       /**< input : minimum pitch lag        */
                          int pit_max,                                                       /**< input : maximum pitch lag        */
                          int l_frame,                                                       /* input : length of frame to compute pitch           */
                          REAL * voicing, INT16 * pit_old)
{
  REAL      max1, max2, max3;
  int       p_max1, p_max2, p_max3;
  int       i, j;
  REAL      thresh;

  /*--------------------------------------------------------------------*
  *  The pitch lag search is divided in three sections.                *
  *  Each section cannot have a pitch multiple.                        *
  *  We find a maximum for each section.                               *
  *  We compare the maxima of each section by favoring small lag.      *
  *                                                                    *
  *  First section:  lag delay = pit_max     downto 4*pit_min          *
  *  Second section: lag delay = 4*pit_min-1 downto 2*pit_min          *
  *  Third section:  lag delay = 2*pit_min-1 downto pit_min            *
  *--------------------------------------------------------------------*/

  j = pit_min * 4;
  p_max1 = G729EV_G729_Lag_max(signal, l_frame, pit_max, j, &max1, &voicing[0]);

  i = j - 1;
  j = pit_min * 2;
  p_max2 = G729EV_G729_Lag_max(signal, l_frame, i, j, &max2, &voicing[1]);

  i = j - 1;
  p_max3 = G729EV_G729_Lag_max(signal, l_frame, i, pit_min, &max3, &voicing[2]);

  /*--------------------------------------------------------------------*
  * Compare the 3 sections maximal, and favor small lag.               *
  *--------------------------------------------------------------------*/

  if (abs(*pit_old - p_max2) < 10)
    thresh = 0.7f;
  else
    thresh = 0.9f;

  if (max1 * thresh < max2)
  {
    max1 = max2;
    p_max1 = p_max2;
  }

  if (abs(*pit_old - p_max3) < 5)
    thresh = 0.7f;
  else
    thresh = 0.9f;

  if (max1 * thresh < max3)
    p_max1 = p_max3;

  *pit_old = p_max1;

  /* Keep maximum voicing in voicing[0] */
  if ((voicing[1] - voicing[0]) > 0)
    voicing[0] = voicing[1];

  if ((voicing[2] - voicing[0]) > 0)
    voicing[0] = voicing[2];


  return (p_max1);
}

/*---------------------------------------------------------------------------*
 * procedure G729EV_G729_Lag_max                                             *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 * Find the lag that has maximum correlation with scal_sig[]                 *
 *                                                                           *
 *---------------------------------------------------------------------------*/
static int G729EV_G729_Lag_max(                 /* output: lag found */
                                REAL signal[],  /* input : Signal to compute the open loop pitch  */
                                int l_frame,    /* input : Length of frame to compute pitch       */
                                int lagmax,     /* input : maximum lag                            */
                                int lagmin,     /* input : minimum lag                            */
                                REAL * cor_max, /* input : normalized correlation of selected lag */
                                REAL * voicing)
{
  int       i, j;
  REAL     *p, *p1;
  REAL      max, t0;
  int       p_max;

  max = G729EV_G729_FLT_MIN_G729;
  p_max = lagmax;               /* to avoid visual warning */

  for (i = lagmax; i >= lagmin; i--)
  {
    p = signal;
    p1 = &signal[-i];
    t0 = (REAL) 0.0;

    for (j = 0; j < l_frame; j++)
    {
      t0 += *p++ * *p1++;
    }

    if (t0 >= max)
    {
      max = t0;
      p_max = i;
    }
  }

  /* compute energy */

  t0 = (REAL) 0.01;             /* to avoid division by zero */
  p = &signal[-p_max];
  for (i = 0; i < l_frame; i++, p++)
  {
    t0 += *p * *p;
  }

  t0 = G729EV_G729_inv_sqrt(t0);  /* 1/sqrt(energy)    */

  *cor_max = max * t0;          /* max/sqrt(energy)  */

  t0 = (REAL) 0.01;             /* to avoid division by zero */
  p = signal;
  for (i = 0; i < l_frame; i++, p++)
  {
    t0 += *p * *p;
  }
  t0 = G729EV_G729_inv_sqrt(t0);  /* 1/sqrt(energy)    */
  *voicing = *cor_max * t0;

  return (p_max);
}

/*--------------------------------------------------------------------------*
 * Function  G729EV_G729_Pitch_fr3()                                        *
 * ~~~~~~~~~~~~~~~~~~~~~                                                    *
 * Find the pitch period with 1/3 subsample resolution.                     *
 *--------------------------------------------------------------------------*/
int G729EV_G729_Pitch_fr3(                /* (o): pitch period        */
                           REAL exc[],    /* (i) : excitation buffer                   */
                           REAL xn[],     /* (i) : target vector                       */
                           REAL h[],      /* (i) : impulse response of filters.        */
                           int l_subfr,   /* (i) : Length of subframe                  */
                           int t0_min,    /* (i) : minimum value in the searched range */
                           int t0_max,    /* (i) : maximum value in the searched range */
                           int i_subfr,   /* (i) : indicator for first subframe        */
                           int *pit_frac) /* (o): chosen fraction                      */
{
  int       i, frac;
  int       lag, t_min, t_max;
  REAL      max;
  REAL      corr_int;
  REAL      corr_v[40];         /* Total length = t0_max-t0_min+1+2*L_INTER */
  REAL     *corr;

  /* Find interval to compute normalized correlation */
  t_min = t0_min - G729EV_G729_L_INTER4;
  t_max = t0_max + G729EV_G729_L_INTER4;

  corr = &corr_v[-t_min];

  /* Compute normalized correlation between target and filtered excitation */
  G729EV_G729_Norm_Corr(exc, xn, h, l_subfr, t_min, t_max, corr);

  /* find integer pitch */
  max = corr[t0_min];
  lag = t0_min;

  for (i = t0_min + 1; i <= t0_max; i++)
  {
    if (corr[i] >= max)
    {
      max = corr[i];
      lag = i;
    }
  }

  /* If first subframe and lag > 84 do not search fractionnal pitch */

  if ((i_subfr == 0) && (lag > 84))
  {
    *pit_frac = 0;
    return (lag);
  }

  /* test the fractions around T0 and choose the one which maximizes  */
  /* the interpolated normalized correlation                          */

  max = G729EV_G729_Interpol_3(&corr[lag], -2);
  frac = -2;

  for (i = -1; i <= 2; i++)
  {
    corr_int = G729EV_G729_Interpol_3(&corr[lag], i);
    if (corr_int > max)
    {
      max = corr_int;
      frac = i;
    }
  }
  /* limit the fraction value between -1 and 1 */
  if (frac == -2)
  {
    frac = 1;
    lag -= 1;
  }
  if (frac == 2)
  {
    frac = -1;
    lag += 1;
  }

  *pit_frac = frac;

  return lag;
}

/*---------------------------------------------------------------------------*
 * Function G729EV_G729_Norm_Corr()                                          *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 * Find the normalized correlation between the target vector and the         *
 * filtered past excitation.                                                 *
 *---------------------------------------------------------------------------*
 * Input arguments:                                                          *
 *     exc[]    : excitation buffer                                          *
 *     xn[]     : target vector                                              *
 *     h[]      : impulse response of synthesis and weighting filters        *
 *     L_subfr  : Length of subframe                                         *
 *     t_min    : minimum value of pitch lag.                                *
 *     t_max    : maximum value of pitch lag.                                *
 *                                                                           *
 * Output arguments:                                                         *
 *     corr_norm[]:  normalized correlation (correlation between target and  *
 *                   filtered excitation divided by the square root of       *
 *                   energy of filtered excitation)                          *
 *--------------------------------------------------------------------------*/

static void G729EV_G729_Norm_Corr(REAL exc[], REAL xn[], REAL h[], int l_subfr, int t_min, int t_max, REAL corr_norm[])
{
  int       i, j, k;
  REAL      excf[G729EV_G729_L_SUBFR];  /* filtered past excitation */
  REAL      alp, s, norm;

  k = -t_min;

  /* compute the filtered excitation for the first delay t_min */
  G729EV_G729_Convolve(&exc[k], h, excf, l_subfr);

  /* loop for every possible period */
  for (i = t_min; i <= t_max; i++)
  {
    /* Compute 1/sqrt(energie of excf[]) */
    alp = (REAL) 0.01;
    for (j = 0; j < l_subfr; j++)
      alp += excf[j] * excf[j];

    norm = G729EV_G729_inv_sqrt(alp);

    /* Compute correlation between xn[] and excf[] */
    s = (REAL) 0.0;
    for (j = 0; j < l_subfr; j++)
      s += xn[j] * excf[j];

    /* Normalize correlation = correlation * (1/sqrt(energie)) */
    corr_norm[i] = s * norm;

    /* modify the filtered excitation excf[] for the next iteration */
    if (i != t_max)
    {
      k--;
      for (j = l_subfr - 1; j > 0; j--)
        excf[j] = excf[j - 1] + exc[k] * h[j];
      excf[0] = exc[k];
    }
  }

  return;

}

/*---------------------------------------------------------------------*
 * Function  G729EV_G729_G_pitch:                                      *
 *           ~~~~~~~~~~~~~~~~~~~~                                      *
 *---------------------------------------------------------------------*
 * Compute correlations <xn,y1> and <y1,y1> to use in gains quantizer. *
 * Also compute the gain of pitch.                                     *
 *  if (gain < 0)  gain =0                                             *
 *  if (gain >1.2) gain =1.2                                           *
 *---------------------------------------------------------------------*/

REAL G729EV_G729_G_pitch(                 /* (o) : Gain of pitch lag saturated to 1.2 */
                          REAL xn[],      /* (i) : Pitch target                            */
                          REAL y1[],      /* (i) : Filtered adaptive codebook              */
                          REAL g_coeff[], /* (i) : Correlations need for gain quantization */
                          int l_subfr     /* (i) : Length of subframe                      */
    )
{
  REAL      xy, yy, gain;
  int       i;

  xy = (REAL) 0.0;
  for (i = 0; i < l_subfr; i++)
  {
    xy += xn[i] * y1[i];
  }
  yy = (REAL) 0.01;
  for (i = 0; i < l_subfr; i++)
  {
    yy += y1[i] * y1[i];        /* energy of filtered excitation */
  }
  g_coeff[0] = yy;
  g_coeff[1] = (REAL) - 2.0 * xy + (REAL) 0.01;

  /* find pitch gain and bound it by [0,1.2] */
  gain = xy / yy;

  if (gain < (REAL) 0.0)
    gain = (REAL) 0.0;
  if (gain > G729EV_G729_PIT_MAX_GAIN)
    gain = G729EV_G729_PIT_MAX_GAIN;

  return gain;
}

/*---------------------------------------------------------------------*
*    Function G729EV_G729_Enc_lag3()                                   *
*             ~~~~~~~~~~~~~~~~~~~~~~                                   *
*   Encoding of fractional pitch lag with 1/3 resolution.              *
*----------------------------------------------------------------------*
* The pitch range for the first subframe is divided as follows:        *
*   19 1/3  to   84 2/3   resolution 1/3                               *
*   85      to   143      resolution 1                                 *
*                                                                      *
* The period in the first subframe is encoded with 8 bits.             *
* For the range with fractions:                                        *
*   index = (T-19)*3 + frac - 1;   where T=[19..85] and frac=[-1,0,1]  *
* and for the integer only range                                       *
*   index = (T - 85) + 197;        where T=[86..143]                   *
*----------------------------------------------------------------------*
* For the second subframe a resolution of 1/3 is always used, and the  *
* search range is relative to the lag in the first subframe.           *
* If t0 is the lag in the first subframe then                          *
*  t_min=t0-5   and  t_max=t0+4   and  the range is given by           *
*       t_min - 2/3   to  t_max + 2/3                                  *
*                                                                      *
* The period in the 2nd subframe is encoded with 5 bits:               *
*   index = (T-(t_min-1))*3 + frac - 1;    where T[t_min-1 .. t_max+1] *
*----------------------------------------------------------------------*/
int G729EV_G729_Enc_lag3(               /*  (o) : Return index of encoding */
                          int T0,       /*  (i)   : Pitch delay              */
                          int T0_frac,  /*  (i)   : Fractional pitch delay   */
                          int *T0_min,  /*  (i/o) : Minimum search delay     */
                          int *T0_max,  /*  (i/o) : Maximum search delay     */
                          int pit_min,  /*  (i)   : Minimum pitch delay      */
                          int pit_max,  /*  (i)   : Maximum pitch delay      */
                          int pit_flag) /*  (i)   : Flag for 1st subframe    */
{
  int       index;

  if (pit_flag == 0)            /* if 1st subframe */
  {
    /* encode pitch delay (with fraction) */

    if (T0 <= 85)
      index = T0 * 3 - 58 + T0_frac;
    else
      index = T0 + 112;

    /* find T0_min and T0_max for second subframe */

    *T0_min = T0 - 5;
    if (*T0_min < pit_min)
      *T0_min = pit_min;
    *T0_max = *T0_min + 9;
    if (*T0_max > pit_max)
    {
      *T0_max = pit_max;
      *T0_min = *T0_max - 9;
    }
  }

  else                          /* if second subframe */
  {
    index = T0 - *T0_min;
    index = index * 3 + 2 + T0_frac;
  }
  return index;
}

/*---------------------------------------------------------------------------*
 * Procedure G729EV_G729_Interpol_3()                                        *
 * ~~~~~~~~~~~~~~~~~~~~~~                                                    *
 * For interpolating the normalized correlation with 1/3 resolution.         *
 *---------------------------------------------------------------------------*/
REAL G729EV_G729_Interpol_3(            /* (o) : interpolated value */
                             REAL * x,  /* (i) : input vector */
                             int frac   /* (i) : fraction     */
    )
{
  int       i;
  REAL      s, *x1, *x2;
  const REAL *c1, *c2;

  if (frac < 0)
  {
    frac += G729EV_G729_UP_SAMP;
    x--;
  }
  x1 = &x[0];
  x2 = &x[1];
  c1 = &inter_3[frac];
  c2 = &inter_3[G729EV_G729_UP_SAMP - frac];

  s = (REAL) 0.0;
  for (i = 0; i < G729EV_G729_L_INTER4; i++, c1 += G729EV_G729_UP_SAMP, c2 += G729EV_G729_UP_SAMP)
    s += (*x1--) * (*c1) + (*x2++) * (*c2);

  return s;
}
