/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.2                                                            */
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"


/************************************************************************/
/*                                                                      */
/*   ADAPTIVE BANDWIDTH EXPANSION for THE PERCEPTUAL WEIGHTING FILTER   */
/*                                                                      */
/*                 W(z) = A (z/gamma1) / A(z/gamma2)                    */
/*                                                                      */
/************************************************************************/

void G729EV_G729_perc_var(REAL * gamma1,  /*(o) : Bandwidth expansion parameter           */
                          REAL * gamma2,  /*(o) : Bandwidth expansion parameter           */
                          REAL * lsfint,  /*(i) : Interpolated LSF vector : 1st subframe  */
                          REAL * lsfnew,  /*(i) : LSF vector : 2nd subframe               */
                          REAL * r_c,     /*(i) : Reflection coefficients                 */
                          REAL lar_old[2], INT16 * smooth)
{
  REAL      lar[4];
  REAL     *lar_new;
  REAL     *lsf;
  REAL      critlar0, critlar1;
  REAL      d_min, temp;
  int       i, k;

  lar_new = &lar[2];

  /* reflection coefficients --> lar */
  for (i = 0; i < 2; i++)
    lar_new[i] = (REAL) log10((double) (((REAL) 1.0 + r_c[i]) / ((REAL) 1.0 - r_c[i])));

  /* Interpolation of lar for the 1st subframe */
  for (i = 0; i < 2; i++)
  {
    lar[i] = (REAL) 0.5 *(lar_new[i] + lar_old[i]);

    lar_old[i] = lar_new[i];
  }

  for (k = 0; k < 2; k++)
  {                             /* LOOP : gamma2 for 1st to 2nd subframes */

    /* ---------------------------------------------------------- */
    /* First criterion based on the first two Lars                */
    /* smooth == 1  ==>  gamma2 can vary from 0.4 to 0.7          */
    /* smooth == 0  ==>  gamma2 is set to 0.6                     */
    /*                                                            */
    /* Double threshold + hysteresis :                            */
    /* if smooth = 1                                              */
    /*  if (CritLar0 < THRESH_L1) and (CritLar1 > THRESH_H1)      */
    /*                                                 smooth = 0 */
    /* if smooth = 0                                              */
    /*  if (CritLar0 > THRESH_L2) or (CritLar1 < THRESH_H2)       */
    /*                                                 smooth = 1 */
    /* ---------------------------------------------------------- */

    critlar0 = lar[2 * k];
    critlar1 = lar[2 * k + 1];

    if (*smooth != 0)
    {
      if ((critlar0 < G729EV_G729_THRESH_L1) && (critlar1 > G729EV_G729_THRESH_H1))
        *smooth = 0;
    }
    else
    {
      if ((critlar0 > G729EV_G729_THRESH_L2) || (critlar1 < G729EV_G729_THRESH_H2))
        *smooth = 1;
    }

    if (*smooth == 0)
    {
      /* ------------------------------------------------------ */
      /* Second criterion based on the minimum distance between */
      /* two successives lsfs                                   */
      /* ------------------------------------------------------ */
      gamma1[k] = G729EV_G729_GAMMA1_0;
      if (k == 0)
        lsf = lsfint;
      else
        lsf = lsfnew;
      d_min = lsf[1] - lsf[0];
      for (i = 1; i < G729EV_G729_M - 1; i++)
      {
        temp = lsf[i + 1] - lsf[i];
        if (temp < d_min)
          d_min = temp;
      }

      gamma2[k] = G729EV_G729_ALPHA * d_min + G729EV_G729_BETA;

      if (gamma2[k] > G729EV_G729_GAMMA2_0_H)
        gamma2[k] = G729EV_G729_GAMMA2_0_H;
      if (gamma2[k] < G729EV_G729_GAMMA2_0_L)
        gamma2[k] = G729EV_G729_GAMMA2_0_L;
    }
    else
    {
      gamma1[k] = G729EV_G729_GAMMA1_1;
      gamma2[k] = G729EV_G729_GAMMA2_1;;
    }
  }

  return;
}
