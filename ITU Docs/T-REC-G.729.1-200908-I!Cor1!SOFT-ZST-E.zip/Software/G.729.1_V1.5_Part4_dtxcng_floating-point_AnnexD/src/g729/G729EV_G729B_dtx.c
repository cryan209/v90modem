/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   Version:       1.2                                                            
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      

   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/


/* DTX and Comfort Noise Generator - Encoder part */
#include <stdio.h>
#include <stdlib.h>
#include <math.h>

#include "CodecTypedef.h"
#include "G729EV_G729_LD8k.h"
#include "G729EV_G729B_defines.h"
#include "G729EV_G729B_dtx.h"
#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729B_enc_sid.h"

/* Local functions */
static void calc_pastfilt(REAL *sumAcf, REAL *Coeff, REAL old_A[],  REAL old_rc[], REAL* energy);
static void calc_RCoeff(REAL *Coeff, REAL *RCoeff);
static int cmp_filt(REAL *RCoeff, REAL *acf, REAL alpha, REAL Thresh);
static void calc_sum_acf(REAL *acf, REAL *sum, int nb);
static void update_sumAcf(G729EV_G729_CODSTAT * pCodStat);
static REAL cmp_filt_test(REAL *RCoeff, REAL *acf, REAL alpha, REAL Thresh);
static void calc_mean_acf(REAL *acf, REAL *mean, int nb);

/*-----------------------------------------------------------*
* procedure init_Cod_cng:                                   *
*           ~~~~~~~~~~~~                                    *
*   Initialize variables used for dtx at the encoder        *
*-----------------------------------------------------------*/
void init_cod_cng(G729EV_G729_CODSTAT * pCodStat)
{
    int i;
    
    for(i=0; i<SIZ_SUMACF; i++) pCodStat->sumAcf[i] = (REAL)0.;
    
    for(i=0; i<SIZ_ACF; i++) pCodStat->Acf[i] = (REAL)0.;
    
    for(i=0; i<NB_GAIN; i++) pCodStat->ener[i] = (REAL)0.;
    
    pCodStat->fr_cur = 0;
	 pCodStat->seed2 = INIT_SEED;
    
    return;
}


/*-----------------------------------------------------------*
* procedure G729EV_cod_cng:                                  *
*           ~~~~~~~~                                        *
*   computes DTX decision                                   *
*   encodes SID frames                                      *
*   computes CNG excitation for encoder update              *
*-----------------------------------------------------------*/
void G729EV_cod_cng(
    G729EV_G729_CODSTAT * pCodStat,
	int   ftyp_j,         /* (i) : number of 10 ms frame */
    REAL *exc,          /* (i/o) : excitation array                     */
    REAL *Aq,           /* (o)   : set of interpolated LPC coefficients */
    int *ana,            /* (o)   : coded SID parameters                 */
    REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i/o) : previous LPS for quantization        */
    REAL *SID_tdbwe_parameters,
	REAL *tdbwe_parameters
)
{
    int i;
    
    REAL curAcf[G729EV_G729_MP1];
    REAL bid[G729EV_G729_MP1];
    REAL curCoeff[G729EV_G729_MP1];
    REAL lsp_new[G729EV_G729_M];
    REAL *lpcCoeff;
    int cur_igain, cur_igain2;
    REAL energyq, energyq2;
	REAL dist, dist_lsp[G729EV_G729_M];
	REAL cur_lsf[G729EV_G729_M];

	INT16 tmp_i_subfr_cnt;                              /* nonsense parameters */
	REAL  tmp_lp_gainp, tmp_lp_gainc, tmp_tilt_code;    /* nonsense parameters */
	REAL delt1, delt2, delt;
	int change_flag = 0;
	REAL tmp_gain;
    REAL   SuperFrameCurAcfMove[G729EV_G729_MP1];      // smoothed ACF parameters
    REAL   SuperFrameEnerMove;                         // smoothed energy parameters
    int j;
    REAL   Frame_Rate;        // weight factor
    
	G729EV_G729_Set_zero(exc, G729EV_MAIN_L_FRAME4);
    /* Update Ener */
    for(i = NB_GAIN-1; i>=1; i--) {
        pCodStat->ener[i] = pCodStat->ener[i-1];
    }
    
	calc_mean_acf(pCodStat->Acf, curAcf, NB_CURACF);
    
    /* Compute LPC coefficients and residual energy */
    if(curAcf[0] == (REAL)0.) {
        pCodStat->ener[0] = (REAL)0.;                /* should not happen */
    }
    else {
        pCodStat->ener[0] = G729EV_G729_Levinson(curAcf, curCoeff, bid, pCodStat->old_A, pCodStat->old_rc);
		pCodStat->ener[0] = pCodStat->ener[0] * 0.1 + pCodStat->energy_lt * 0.9;
		pCodStat->energy_lt = pCodStat->ener[0];
    }

	if(ftyp_j == 0) // 1st 10ms frame
	{
		G729EV_G729_Copy(curAcf, &pCodStat->SuperFrame_CurAcf[0][0], G729EV_G729_MP1);   
	}
	else            //2nd 10ms frame
	{
		G729EV_G729_Copy(curAcf, &pCodStat->SuperFrame_CurAcf[1][0], G729EV_G729_MP1);   
	}
    /* if first frame of silence => SID frame */
    if((pCodStat->pastVad != 0)||(pCodStat->ppastVad != 0)) {
		if(ftyp_j == 0)
		{
			ana[0] = 0;
			pCodStat->nb_ener = 1;  
		}
		else
		{
			ana[0] = 1;              
			pCodStat->count_fr0 = 0;       
			pCodStat->nb_ener++;
		}
    }
    else {
			pCodStat->nb_ener++;
			if(pCodStat->nb_ener > NB_GAIN) pCodStat->nb_ener = NB_GAIN;

		if(ftyp_j == 0)
		{
			ana[0] = 0;
			/* quantize the energy and buffer 1st ms frame energy */
			G729EV_Qua_Sidgain(pCodStat->ener, pCodStat->nb_ener, &energyq, &cur_igain, &energyq2, &cur_igain2,&pCodStat->SuperFrame_Ener[0]);

			/* 1st 10ms frame DTX */
			pCodStat->Nb_First_change_flag = 0;
			if(cmp_filt(pCodStat->RCoeff, curAcf, pCodStat->ener[0], THRESH1) != 0) 
			{
			    pCodStat->Nb_First_change_flag = 1;
			}
        
			/* compare energy difference between current frame and last frame */
			if( (REAL)fabs(pCodStat->prev_energy - energyq2) > (REAL)3.0)
			{
				pCodStat->Nb_First_change_flag = 1;
			}

		}
		else
		{
			/* quantize the energy parameter and buffer the 2nd frame energy */
			G729EV_Qua_Sidgain(pCodStat->ener, pCodStat->nb_ener, &energyq, &cur_igain, &energyq2, &cur_igain2,&pCodStat->SuperFrame_Ener[1]);

			/* 2nd 10ms frame DTX */
			pCodStat->Nb_Second_change_flag = 0;
			if(cmp_filt(pCodStat->RCoeff, curAcf, pCodStat->ener[0], THRESH1) != 0) 
			{
			    pCodStat->Nb_Second_change_flag = 1;
			}
        
            /* compute the stationary of energy */
			/* compare energy difference between current frame and last frame */
			if( (REAL)fabs(pCodStat->prev_energy - energyq2) > (REAL)3.0)
			{
				pCodStat->Nb_Second_change_flag = 1;
			}

            /* weight the two frame paramgerss */
			if((pCodStat->Nb_Second_change_flag == 1)&&(pCodStat->Nb_First_change_flag==0))
			{
				Frame_Rate = 0.1;
			}
			else
			{
				Frame_Rate = 0.5;
			}

			SuperFrameEnerMove = pCodStat->SuperFrame_Ener[0]*Frame_Rate + pCodStat->SuperFrame_Ener[1]*(1-Frame_Rate);
			G729EV_Qua_Sidgain_quant_Energy(&energyq, &cur_igain, &energyq2, &cur_igain2, SuperFrameEnerMove);

			for(i=0;i<G729EV_G729_MP1;i++)
			{
				SuperFrameCurAcfMove[i] = pCodStat->SuperFrame_CurAcf[0][i]*Frame_Rate + pCodStat->SuperFrame_CurAcf[1][i]*(1-Frame_Rate);
			}
            G729EV_G729_Levinson(SuperFrameCurAcfMove, curCoeff, bid, pCodStat->old_A, pCodStat->old_rc); 

			/* combined NB-DTX with WB-DTX */
			change_flag = (pCodStat->Nb_Second_change_flag||pCodStat->Nb_First_change_flag);

			pCodStat->flag_chang_wb += change_flag;


			/* too weak WB components should be neglected */
			if((pCodStat->flag_chang_wb == 1) && (tdbwe_parameters[0] > 0.00390625))
			{
				delt1 = fabs(SID_tdbwe_parameters[0] - tdbwe_parameters[0]) / G729EV_TDBWE_THR_TD;
				delt2 = 0;
				for(i = 0; i < 12; i ++)
					delt2 += fabs(SID_tdbwe_parameters[i+1] - tdbwe_parameters[i+16])/G729EV_TDBWE_THR_SD;
				delt = delt1 * 0.4 + delt2 * 0.6;
				delt1 = cmp_filt_test(pCodStat->RCoeff, SuperFrameCurAcfMove, pCodStat->ener[0], THRESH1);
				delt2 = fabs(pCodStat->prev_energy - energyq2)/3.0;
				delt = delt * 0.25 + (delt1 * 0.6 + delt2 * 0.4) * 0.75;
				if(delt < 1)
					pCodStat->flag_chang_wb = 0;
			}

			/* update SID_tdbwe_parameters */
			if(pCodStat->flag_chang_wb)
			{
				for(i = 0; i < 13; i ++)
					SID_tdbwe_parameters[i] = tdbwe_parameters[i+15];
			}
			
			pCodStat->count_fr0++;
			if(pCodStat->count_fr0 < FR_SID_MIN) {
				ana[0] = 0;  /* no transmission */
			}
			else {
				if((pCodStat->flag_chang_wb) != 0) {
					ana[0] = 1;  /* transmit SID frame */
				}
				else{
					ana[0] = 0;
				}
			if((pCodStat->count_fr0 > pCodStat->dtx_max_fr) && (pCodStat->dtx_max_fr != 0)) {
				ana[0] = 1;             /* transmit SID frame */
			}
			}
		}
    }

    if(ana[0] == 1) {
		ana = ana - G729EV_G729_PRM_SIZE_MAX;
		ana[0] = 1;

		ana[G729EV_G729_PRM_SIZE_MAX] = 0;
		pCodStat->counter_n = pCodStat->counter_k;
		pCodStat->counter_k = 0;
		pCodStat->flag_chang_wb = 0;
		pCodStat->counter_n_lt = pCodStat->counter_n_lt * 0.95 + pCodStat->counter_n * 0.05;

        /* Reset frame count and change flag */
        pCodStat->count_fr0 = 0;
        
		  if(pCodStat->ppastVad != 0) {
            update_sumAcf(pCodStat);
            calc_pastfilt(pCodStat->sumAcf, pCodStat->pastCoeff, pCodStat->old_A, pCodStat->old_rc, &SuperFrameEnerMove);
			calc_RCoeff(pCodStat->pastCoeff, pCodStat->RCoeff);
            lpcCoeff = pCodStat->pastCoeff;
			SuperFrameEnerMove = pCodStat->energy_lt * 0.9 + SuperFrameEnerMove * 0.1;
			pCodStat->energy_lt = SuperFrameEnerMove;
			SuperFrameEnerMove *= fact[1];
			G729EV_Qua_Sidgain_quant_Energy(&energyq, &cur_igain, &energyq2, &cur_igain2, SuperFrameEnerMove);
		  }                                                                     
		  else {
        /* Compute past average filter */
            calc_pastfilt(pCodStat->sumAcf, pCodStat->pastCoeff, pCodStat->old_A, pCodStat->old_rc, &SuperFrameEnerMove);
        calc_RCoeff(pCodStat->pastCoeff, pCodStat->RCoeff);
        
        /* Compute stationarity of current filter   */
        /* versus past average filter               */
        
        /* if stationary */
        /* transmit average filter => new ref. filter */
        if(cmp_filt(pCodStat->RCoeff, curAcf, pCodStat->ener[0], THRESH2) == 0) {
            lpcCoeff = pCodStat->pastCoeff;
        }
        
        /* transmit current filter => new ref. filter */
        else {
            lpcCoeff = curCoeff;
            calc_RCoeff(curCoeff, pCodStat->RCoeff);
        }
        }                                                                     
        
        /* Compute SID frame codes */
        G729EV_G729_Az_lsp(lpcCoeff, lsp_new, pCodStat->lsp_old_q); /* From A(z) to lsp */
        
        /* LSP quantization */
        lsfq_noise(noise_fg, lsp_new, pCodStat->sid_lsp, freq_prev, &ana[1],cur_igain);
        
        pCodStat->prev_energy = energyq2;
        ana[4] = cur_igain;    /* first stage SID gain quantization index */
        pCodStat->sid_gain = tab_Sidgain[cur_igain];

		{
			ana[6] = cur_igain2;      /* second stage SID gain quantization index */
			if(cur_igain < 6) pCodStat->sid_gain *= tab_Sidgain2[cur_igain2];
			else              pCodStat->sid_gain *= tab_Sidgain3[cur_igain2];
		}
    } /* end of SID frame case */

	/* generate energe and Az of nodata frame   */
	/* D  = (Psid - Pk-1)/(|k-N|+1)             */
    /* Pk = Pk-1+D+rand(-D/2,D/2)               */
	/* P0 = Psid_old                            */
		dist = (pCodStat->sid_gain - pCodStat->pre_gain) / (abs(pCodStat->counter_k-pCodStat->counter_n) + 1);
		pCodStat->pre_gain = pCodStat->pre_gain + dist;
		for(i = 0; i < G729EV_G729_M; i++)
		{
			dist_lsp[i] = (pCodStat->sid_lsp[i] - pCodStat->pre_lsp[i]) / (abs(pCodStat->counter_k-pCodStat->counter_n) + 1);
			pCodStat->pre_lsp[i]  = pCodStat->pre_lsp[i] + dist_lsp[i] + (REAL)G729EV_G729_Random(&pCodStat->seed2)/32768*(dist_lsp[i] / 2.0);
		}
    if((pCodStat->pastVad != 0)&&(pCodStat->ppastVad != 0)) 
	{
		/*calculate the spectrum and energy*/
		G729EV_G729_Copy(pCodStat->lsp_mean, pCodStat->pre_lsp, G729EV_G729_M);  
		pCodStat->counter_k = 2*DTX_HANG_CONST-1;
		pCodStat->pre_gain = pCodStat->Gf_gain_mean * 0.4;
	}
	/* check the stabilty */
	G729EV_G729_Lsp_lsf(pCodStat->pre_lsp ,cur_lsf, G729EV_G729_M);
	G729EV_G729_Lsp_expand_1_2(cur_lsf, G729EV_G729_GAP1);
    G729EV_G729_Lsp_expand_1_2(cur_lsf, G729EV_G729_GAP2);
    G729EV_G729_Lsp_stability(cur_lsf);
	G729EV_G729_Lsf_lsp(cur_lsf ,pCodStat->pre_lsp, G729EV_G729_M);


    /* Compute new excitation */
    if(pCodStat->counter_n_lt > 40)
	{
		tmp_gain = 0.9 + 0.1 * (30.0*pCodStat->VAD_flag_change_counter_move+(pCodStat->gain_change_hangover)) / ((REAL) ATTENUATION_CONST + 30.0*pCodStat->VAD_flag_change_counter_move + pCodStat->counter_n);
		tmp_gain = (pCodStat->pre_gain)*tmp_gain;
	}
	else
		tmp_gain = pCodStat->pre_gain;
	G729EV_calc_exc_rand(tmp_gain, exc,	&pCodStat->seed, FLAG_COD, pCodStat->exc_err, 
				  pCodStat->pastVad, &(pCodStat->old_pitch), &(pCodStat->old_gp), &(pCodStat->pre_gain), 
				  &tmp_i_subfr_cnt, &tmp_lp_gainp, &tmp_lp_gainc, &tmp_tilt_code);
    if((pCodStat->pastVad != 0)&&(pCodStat->ppastVad != 0)) 
	{
		pCodStat->sid_gain = pCodStat->pre_gain;
		G729EV_G729_Copy(pCodStat->pre_lsp, pCodStat->sid_lsp, G729EV_G729_M);  
	}
    
    G729EV_G729_Int_qlpc(pCodStat->lsp_old_q, pCodStat->pre_lsp, Aq);
    G729EV_G729_Copy(pCodStat->pre_lsp, pCodStat->lsp_old_q, G729EV_G729_M);
    
    /* Update sumAcf if fr_cur = 0 */
    if((pCodStat->fr_cur == 0) && (pCodStat->pastVad != 2)) {
        update_sumAcf(pCodStat);
    }

    (pCodStat->counter_k) ++;
	if(ftyp_j == 1) 
	{
		pCodStat->Nb_First_change_flag = 0;
		pCodStat->Nb_Second_change_flag = 0;

		for(i=0;i<2;i++)
		{
			for(j=0;j<G729EV_G729_MP1;j++)
			{
				pCodStat->SuperFrame_CurAcf[i][j] = 0.0;
			}
		}
	}

    return;
}


/*-----------------------------------------------------------*
* procedure update_cng:                                     *
*           ~~~~~~~~~~                                      *
*   updates autocorrelation arrays                          *
*   used for DTX/CNG                                        *
*   If Vad=1 : updating of array pCodStat->sumAcf           *
*-----------------------------------------------------------*/
void update_cng(
    G729EV_G729_CODSTAT * pCodStat,
    REAL *r,         /* (i) :   frame autocorrelation               */
    int Vad           /* (i) :   current Vad decision                */
)
{
    int i;
    REAL *ptr1, *ptr2;
    
    /* Update Acf */
    ptr1 = pCodStat->Acf + SIZ_ACF - 1;
    ptr2 = ptr1 - G729EV_G729_MP1;
    for(i=0; i<(SIZ_ACF-G729EV_G729_MP1); i++) {
        *ptr1-- = *ptr2--;
    }
    
    /* Save current Acf */
    for(i=0; i<G729EV_G729_MP1; i++) {
        pCodStat->Acf[i] = r[i];
    }
    
    pCodStat->fr_cur++;
    if(pCodStat->fr_cur == NB_ACCACF) {
        pCodStat->fr_cur = 0;
        if(Vad != 0) {
            update_sumAcf(pCodStat);
        }
    }
    
    return;
}


/*-----------------------------------------------------------*
*         Local procedures                                  *
*         ~~~~~~~~~~~~~~~~                                  *
*-----------------------------------------------------------*/

/* Compute autocorr of LPC coefficients used for Itakura distance */
/******************************************************************/
static void calc_RCoeff(REAL *Coeff, REAL *RCoeff)
{
    int i, j;
    REAL temp;
    
    /* RCoeff[0] = SUM(j=0->M) Coeff[j] ** 2 */
    for(j=0, temp = (REAL)0.; j <= G729EV_G729_M; j++) {
        temp += Coeff[j] * Coeff[j];
    }
    RCoeff[0] = temp;
    
    /* RCoeff[i] = SUM(j=0->M-i) Coeff[j] * Coeff[j+i] */
    for(i=1; i<=G729EV_G729_M; i++) {
        for(j=0, temp=(REAL)0.; j<=G729EV_G729_M-i; j++) {
            temp += Coeff[j] * Coeff[j+i];
        }
        RCoeff[i] = (REAL)2. * temp;
    }
    return;
}

/* Compute Itakura distance and compare to threshold */
/*****************************************************/
static int cmp_filt(REAL *RCoeff, REAL *acf, REAL alpha, REAL Thresh)
{
    REAL temp1, temp2;
    int i;
    int diff;
    
    temp1 = (REAL)0.;
    for(i=0; i <= G729EV_G729_M; i++) {
        temp1 += RCoeff[i] * acf[i];
    }
    
    temp2 = alpha * Thresh;
    if(temp1 > temp2) diff = 1;
    else diff = 0;
    
    return(diff);
}

static REAL cmp_filt_test(REAL *RCoeff, REAL *acf, REAL alpha, REAL Thresh)
{
    REAL temp1;
    int i;
    
    temp1 = (REAL)0.;
    for(i=0; i <= G729EV_G729_M; i++) {
        temp1 += RCoeff[i] * acf[i];
    }
    
    
    return(temp1/(alpha*THRESH1));
}
/* Compute past average filter */
/*******************************/
static void calc_pastfilt(REAL *sumAcf, REAL *Coeff, REAL old_A[],  REAL old_rc[], REAL* energy)
{
    int i;
    REAL s_sumAcf[G729EV_G729_MP1];
    REAL bid[G729EV_G729_M];

    calc_sum_acf(sumAcf, s_sumAcf, NB_SUMACF);
    
    if(s_sumAcf[0] == (REAL)0.) {
        Coeff[0] = (REAL)1.;
        for(i=1; i<=G729EV_G729_M; i++) Coeff[i] = (REAL)0.;
        return;
    }

	for(i = 0; i < G729EV_G729_MP1; i ++)
		s_sumAcf[i] *= 0.1;
    *energy = G729EV_G729_Levinson(s_sumAcf, Coeff, bid, old_A, old_rc);
    return;
}

/* Update sumAcf */
/*****************/
static void update_sumAcf(G729EV_G729_CODSTAT * pCodStat)
{
    REAL *ptr1, *ptr2;
    int i;
    
    /*** Move sumAcf ***/
    ptr1 = pCodStat->sumAcf + SIZ_SUMACF - 1;
    ptr2 = ptr1 - G729EV_G729_MP1;
    for(i=0; i<(SIZ_SUMACF-G729EV_G729_MP1); i++) {
        *ptr1-- = *ptr2--;
    }
    
    /* Compute new sumAcf */
    calc_sum_acf(pCodStat->Acf, pCodStat->sumAcf, NB_ACCACF);
    return;
}

/* Compute sum of acfs (curAcf, sumAcf or s_sumAcf) */
/****************************************************/
static void calc_sum_acf(REAL *acf, REAL *sum, int nb)
{
    
    REAL *ptr1;
    int i, j;
    
    for(j=0; j<G729EV_G729_MP1; j++) {
        sum[j] = (REAL)0.;
    }
    ptr1 = acf;
    for(i=0; i<nb; i++) {
        for(j=0; j<G729EV_G729_MP1; j++) {
            sum[j] += (*ptr1++);
        }
    }
    return;
}
static void calc_mean_acf(REAL *acf, REAL *mean, int nb)
{
    
    REAL *ptr1, *ptr2;
    int i, j;
	REAL tmp;
	REAL norm[NB_CURACF];
	int idx[NB_CURACF];
    
    ptr1 = acf;
	for(i=0; i < NB_CURACF; i++) 
	{
		norm[i] = 0.0;
		idx[i] = i;
        for(j=0; j<G729EV_G729_MP1; j++) 
		{
            norm[i] += (*ptr1) * (*ptr1);
			ptr1++;
        }
    }
	if(norm[0] > norm[1])
	{
		idx[0] = 0;
		idx[1] = 1;
	}
	else
    {
		idx[0] = 1;
		idx[1] = 0;
		tmp = norm[0];
		norm[0] = norm[1];
		norm[1] = tmp;
	} /* norm[0] > norm[1]*/
	if(norm[2] > norm[3])
	{
		idx[2] = 2;
		idx[3] = 3;
	}
	else
    {
		idx[2] = 3;
		idx[3] = 2;
		tmp = norm[2];
		norm[2] = norm[3];
		norm[3] = tmp;
	} /* norm[2] > norm[3]*/

	if(norm[0] > norm[2])
	{
		if(norm[1] > norm[3])
		{
			idx[0] = idx[1];
			idx[1] = idx[2];
		}
		else
		{
			idx[0] = idx[2];
			idx[1] = idx[3];
		}
	}
	else
    {
		if(norm[1] < norm[3])
			idx[1] = idx[3];
	}
    ptr1 = acf + idx[0] * G729EV_G729_MP1;
    ptr2 = acf + idx[1] * G729EV_G729_MP1;
	for(j=0; j<G729EV_G729_MP1; j++) 
	{
		mean[j] = ((*ptr1) + (*ptr2));
		mean[j] *= 0.5;
		ptr1++;
		ptr2++;
	}
	return;
}
