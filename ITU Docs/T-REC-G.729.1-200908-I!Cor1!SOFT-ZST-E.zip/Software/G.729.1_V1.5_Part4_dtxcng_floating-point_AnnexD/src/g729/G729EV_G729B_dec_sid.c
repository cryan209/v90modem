/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   Version:       1.2                                                            
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      

   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/

/*
**
**
** Description:     Comfort noise generation
**                  performed at the decoder part
**
*/
/**** Floatting point version ***/

#include <math.h>


#include "G729EV_G729_defines.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"
#include "G729EV_G729B_defines.h"
#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729B_sid.h"
#include "G729EV_G729B_dtx.h"

/*-----------------------------------------------------------*
* procedure dec_cng:                                        *
*           ~~~~~~~~                                        *
*                     Receives frame type                   *
*                     0  :  for untransmitted frames        *
*                     2  :  for SID frames                  *
*                     Decodes SID frames                    *
*                     Computes current frame excitation     *
*                     Computes current frame LSPs
*-----------------------------------------------------------*/
void G729EV_G729B_Dec_cng(G729EV_G729_DECSTAT * pDecStat, int past_ftyp,    /* (i)   : past frame type                      */
                          REAL sid_sav,                                     /* (i)   : energy to recover SID gain           */
                          int *parm,                                        /* (i)   : coded SID parameters                 */
                          REAL * exc,                                       /* (i/o) : excitation array                     */
                          REAL * lsp_old,                                   /* (i/o) : previous lsp                         */
                          REAL * A_t,                                       /* (o)   : set of interpolated LPC coefficients */
                          INT16 * seed,                                     /* (i/o) : random generator seed                */
                          REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i/o) : previous LPS for quantization        */
                          INT16 ftyp, int bfi)
{
	int i;
	REAL dist, dist_lsp[G729EV_G729_M];
	REAL cur_lsf[G729EV_G729_M];
	REAL tmp_exc_err[4];   /* nonsense parameters */
	REAL tmp_gain;
	int Ratio_3rd_idx = 0;

	G729EV_G729_Set_zero(exc, G729EV_MAIN_L_FRAME4);
  /* SID Frame */
    /*************/
	if(((pDecStat->g729b_bst == 0)&&(past_ftyp > 1)&&(ftyp == 0))
		||((pDecStat->g729b_bst == 1)&&(ftyp != 0)))
	{
		if(pDecStat->g729b_bst == 0)
			parm -= G729EV_G729_PRM_SIZE_MAX;
		pDecStat->counter_n = pDecStat->counter_k;
		pDecStat->counter_k = 0;
		pDecStat->counter_n_lt = pDecStat->counter_n_lt * 0.95 + pDecStat->counter_n * 0.05;
        
		pDecStat->sid_gain = tab_Sidgain[parm[3]];
		if(pDecStat->sid_nb == 1)
		{
			if(parm[3] < 6) pDecStat->sid_gain *= tab_Sidgain2[parm[5]];
			else            pDecStat->sid_gain *= tab_Sidgain3[parm[5]];
		}
		Ratio_3rd_idx = parm[3] >> 2;
        /* Inverse quantization of the LSP */
        sid_lsfq_decode(&parm[0], pDecStat->sid_lsp, freq_prev, noise_fg, pDecStat->sid_nb,Ratio_3rd_idx);
  }

	/* generate energe and Az of nodata frame   */
	/* D  = (Psid - Pk-1)/(|k-N|+1)             */
    /* Pk = Pk-1+D+rand(-D/2,D/2)               */
	/* P0 = Psid_old                            */
		dist = (pDecStat->sid_gain - pDecStat->pre_gain) / (abs(pDecStat->counter_k-pDecStat->counter_n) + 1);
		pDecStat->pre_gain = pDecStat->pre_gain + dist;
		for(i = 0; i < G729EV_G729_M; i++)
		{
			dist_lsp[i] = (pDecStat->sid_lsp[i] - pDecStat->pre_lsp[i]) / (abs(pDecStat->counter_k-pDecStat->counter_n) + 1);
			pDecStat->pre_lsp[i]  = pDecStat->pre_lsp[i] + dist_lsp[i] + (REAL)G729EV_G729_Random(&pDecStat->seed2)/32768*(dist_lsp[i] / 2.0);
		}
    if(past_ftyp == 1) 
	{
		// initial spectrum and energy paramters
		G729EV_G729_Copy(pDecStat->lsp_mean, pDecStat->pre_lsp, G729EV_G729_M);  
		pDecStat->counter_k = 2*DTX_HANG_CONST-1;
		pDecStat->pre_gain = pDecStat->Gf_gain_mean * 0.4;
	}
	/* check the stabilty */
	G729EV_G729_Lsp_lsf(pDecStat->pre_lsp ,cur_lsf, G729EV_G729_M);
	G729EV_G729_Lsp_expand_1_2(cur_lsf, G729EV_G729_GAP1);
    G729EV_G729_Lsp_expand_1_2(cur_lsf, G729EV_G729_GAP2);
    G729EV_G729_Lsp_stability(cur_lsf);
	G729EV_G729_Lsf_lsp(cur_lsf ,pDecStat->pre_lsp, G729EV_G729_M);

	if(bfi)
	{
		pDecStat->sid_gain = pDecStat->sid_gain*G729EV_G729B_ATTEN_COEFF;
	}

	/* Compute new excitation */
	if(pDecStat->counter_n_lt > 40)
	{
		tmp_gain = 0.9 + 0.1 * (30.0*pDecStat->VAD_flag_change_counter_move+(pDecStat->gain_change_hangover)) / ((REAL) ATTENUATION_CONST + 30.0*pDecStat->VAD_flag_change_counter_move + pDecStat->counter_n);
		tmp_gain = pDecStat->pre_gain*tmp_gain;
	}
	else
		tmp_gain = pDecStat->pre_gain;
    G729EV_calc_exc_rand(tmp_gain, exc, seed, FLAG_DEC, tmp_exc_err, 
		             pDecStat->past_ftyp, &(pDecStat->old_pitch), &(pDecStat->old_gp), 
		             &(pDecStat->pre_gain), &pDecStat->i_subfr_cnt, &pDecStat->lp_gainp, 
					 &pDecStat->lp_gainc, &pDecStat->tilt_code);
if(pDecStat->g729b_bst == 0)
{
    if(past_ftyp == 1) 
	{
		pDecStat->sid_gain = pDecStat->pre_gain;
		G729EV_G729_Copy(pDecStat->pre_lsp, pDecStat->sid_lsp, G729EV_G729_M);  
#ifdef FLAG1
		G729EV_G729_Copy(pDecStat->sid_lsp, pDecStat->old_lsp, G729EV_G729_M);
#endif
	} 
}

  /* Interpolate the Lsp vectors */
  G729EV_G729_Int_qlpc(lsp_old, pDecStat->pre_lsp, A_t);
  G729EV_G729_Copy(pDecStat->pre_lsp, lsp_old, G729EV_G729_M);
    (pDecStat->counter_k) ++;
  return;
}

void sid_lsfq_decode(int *index,                                        /* (i) : quantized indices    */
                     REAL * lspq,                                       /* (o) : quantized lsp vector */
                     REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i) : memory of predictor  */
                     REAL noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M]
                     ,INT16 sid_nb
					 ,int Ratio_3rd_idx
                     )
{
  int       i;
  REAL      lsfq[G729EV_G729_M], tmpbuf[G729EV_G729_M];
  	REAL tmpbuf1[G729EV_G729_M];

  /* get the lsf error vector */
  G729EV_G729_Copy((REAL *) lspcb1[PtrTab_1[index[1]]], tmpbuf, G729EV_G729_M);
  for (i = 0; i < G729EV_G729_M / 2; i++)
    tmpbuf[i] = tmpbuf[i] + lspcb2[PtrTab_2[0][index[2]]][i];
  for (i = G729EV_G729_M / 2; i < G729EV_G729_M; i++)
    tmpbuf[i] = tmpbuf[i] + lspcb2[PtrTab_2[1][index[2]]][i];

	G729EV_G729_Copy(tmpbuf, tmpbuf1, G729EV_G729_M);

	if(sid_nb == 1)
	{
		for (i=0; i<G729EV_G729_M/2; i++)
			tmpbuf[i] = tmpbuf[i]+ (REAL)ratio_cb2[Ratio_3rd_idx] * lspcb2[PtrTab_3[0][index[4]]][i];
		for (i=G729EV_G729_M/2; i<G729EV_G729_M; i++)
			tmpbuf[i] = tmpbuf[i]+ (REAL)ratio_cb2[Ratio_3rd_idx] * lspcb2[PtrTab_3[1][index[4]]][i];
	}
  /* guarantee minimum distance of 0.0012 between tmpbuf[j]
     and tmpbuf[j+1] */
  G729EV_G729_Lsp_expand_1_2(tmpbuf, (REAL) 0.0012);

  /* compute the quantized lsf vector */
  G729EV_G729_Lsp_prev_compose(tmpbuf, lsfq, noise_fg[index[0]], freq_prev, noise_fg_sum[index[0]]);

    /* update the prediction memory */
    G729EV_G729_Lsp_prev_update(tmpbuf1, freq_prev);

  /* lsf stability check */
  G729EV_G729_Lsp_stability(lsfq);

  /* convert lsf to lsp */
  for (i = 0; i < G729EV_G729_M; i++)
    lspq[i] = (REAL) cos(lsfq[i]);

}
