/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

*/

#ifndef __G729EV_SP2NO_TRANS_H__
#define __G729EV_SP2NO_TRANS_H__

#include "CodecTypedef.h"
#include "G729EV_G729_ld8k.h"

void G729EV_Pitch_copy(REAL* old_exc,	/*excitation in the previous frame*/
 		  REAL* new_exc,	/*new excitation in the current superframe*/ 
 		  int Tc);	/*pitch of the last subframe in previous frame*/
 		  
void G729EV_Exc_tans_sub(REAL* prev_exc,	/*excitation in the previous superframe*/
		 REAL* curr_exc,		/*excitation in the current superframe*/
		 REAL* new_exc,			/*excitation in the new superframe*/
		 int subfr_num);			/*subframe number in the superframe*/
/* complete excitation transition */
void G729EV_post_cng(INT16 transition_flag,/*excitation transition flag*/
			  REAL *prev_exc,      /*excitation of the previous superframe*/
			  REAL *exc,           /*excitation of the current superframe*/
			  INT16 *subfr_num);     /*subframe number in the superframe*/
void G729EV_adjust_gain(REAL *Ga, REAL *Gf, REAL g_p, REAL g_c, REAL g_a);
void G729EV_fir_filt(REAL x[], INT16 i_frame, REAL filt[], INT16 count);		 
#endif  /*__G729EV_G729_ACELP_CA_H__ */
