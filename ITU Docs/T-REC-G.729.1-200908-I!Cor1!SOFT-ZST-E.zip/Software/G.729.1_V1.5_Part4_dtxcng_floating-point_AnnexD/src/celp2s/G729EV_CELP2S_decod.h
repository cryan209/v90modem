/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   Version:       1.2                                                            
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_CELP2S_DECODE_H__
#define __G729EV_CELP2S_DECODE_H__

#include <stdio.h>
#include "CodecTypedef.h"

#include "G729EV_CELP2S.h"
#include "G729EV_CELP2S_qua_gain.h"
#include "G729EV_CELP2S_post.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_G729_ld8k.h"

/* Functions */
void      G729EV_CELP2S_InitDecoder(G729EV_G729_DECSTAT * pDecStat, int g729b_bst);
void      G729EV_CELP2S_decoder(G729EV_G729_DECSTAT * pDecStat,
                                int *coder_parameters,
                                int rate,
                                int SubFrNum,
                                G729EV_CELP2S_PARAM * nb_celp_param,
                                REAL * BfAq, REAL * coreExc, REAL * extExc, REAL * pitch_buf, INT16 clas, int bfi);

void      G729EV_G729_syn(                  /* (i)  : 8kbits core excitation              */
                           REAL * exc_core, /* (i)  : 8kbits core excitation              */
                           REAL * exc_ext,  /* (i)  : 12kbits  core excitation  extention */
                           REAL * BfAq,     /* (i)  : LPC coefficient filter              */
                           REAL * synth,    /* (o)  : Synthesis buffer                    */
                           REAL * mem_syn,  /* (i/o): synthesis memory buffer             */
                           INT16 extrate    /* (i)  : Extension bit rate                  */
    );

void      G729EV_CELP2S_Decod_ACELP(int sign, int index, REAL sp, REAL cod[]);
void      G729EV_CELP2S_Decod_pos_sig(int index, int sign, int pos[], int si[]);
void      G729EV_CELP2S_Put4Patterns(int pos[], int si[], REAL sp, REAL cod[]);

#endif  /*__G729EV_CELP2S_DECODE_H__ */
