/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

*/
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729B_tab_dtx.h"
#include <math.h>
 

/* last pitch cycle of the previous frame is repeatedly copied up to an extra superframe */    
void G729EV_Pitch_copy(REAL* old_exc,	/*excitation in the previous frame*/
 		  REAL* new_exc,	/*new excitation in the current superframe*/ 
 		  int Tc)	/*pitch of the last subframe in previous frame*/
{
	REAL *pt_exc, *pt1_exc;
	int pos,i;
		
	pt_exc = old_exc + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL;
	pt_exc -= Tc;
	pt1_exc = new_exc;
	pos = 0;
	for (i = 0; i < Tc; i++)
    {
    	*pt1_exc++ = *pt_exc++;
    }
    pos = Tc;
    
    pt_exc = new_exc;
    
    for (i = pos; i < G729EV_MAIN_L_FRAME2; i++)
    {
        *pt1_exc++ = *pt_exc++;
    }
}    

/* excitation smoothing in the subframe*/ 
void G729EV_Exc_tans_sub(REAL* prev_exc,	/*excitation in the previous superframe*/
		 REAL* curr_exc,		/*excitation in the current superframe*/
		 REAL* new_exc,			/*excitation in the new superframe*/
		 int subfr_num)			/*subframe number in the superframe*/
		
{
	REAL step,gain1,gain2;
	REAL *pt_exc,*pt1_exc,*pt2_exc;
	int i;
	REAL energy_tmp1, energy_tmp2;
		
	step = 1.0 / (REAL) G729EV_MAIN_L_FRAME2;  // Linearly attenuate the gain through the frame 
	gain1 = 0.0 + subfr_num * G729EV_MAIN_L_FRAME4 * step; //curr
	gain2 = 1.0 - subfr_num * G729EV_MAIN_L_FRAME4 * step; //prev
	pt_exc = new_exc; //new              
	pt1_exc  = curr_exc; //curr
	pt2_exc = prev_exc + subfr_num * G729EV_MAIN_L_FRAME4; //prev

	
	energy_tmp1 = 0.25;
	for(i = 0; i < G729EV_MAIN_L_FRAME4; i ++)
	{
		energy_tmp1 += pt1_exc[i] * pt1_exc[i];
	}
	energy_tmp1 = sqrt(energy_tmp1/G729EV_MAIN_L_FRAME4);
	
	for (i = 0; i < G729EV_MAIN_L_FRAME4; i++)
	{
		*pt_exc++ = gain1 * (*pt1_exc++) + gain2 * (*pt2_exc++);
		gain1 += step;
		gain2 -= step;
	}
	
	energy_tmp2 = 0.25;
	for(i = 0; i < G729EV_MAIN_L_FRAME4; i ++)
	{
		energy_tmp2 += new_exc[i] * new_exc[i];
	}
	energy_tmp2 = sqrt(energy_tmp2/G729EV_MAIN_L_FRAME4);

	// Gain control for excitation transition
	for(i = 0; i < G729EV_MAIN_L_FRAME4; i ++)
	{
		new_exc[i] *= (energy_tmp1/energy_tmp2);
	}
	
}
/* complete excitation transition */
void G729EV_post_cng(INT16 transition_flag,/*excitation transition flag*/
			  REAL *prev_exc,      /*excitation of the previous superframe*/
			  REAL *exc,           /*excitation of the current superframe*/
			  INT16 *subfr_num)     /*subframe number in the superframe*/
{		
	REAL new_exc[G729EV_G729_L_FRAME];	
	if(transition_flag == 1)
	{
		G729EV_Exc_tans_sub(prev_exc, exc, new_exc, *subfr_num);
		G729EV_G729_Copy(new_exc, exc, G729EV_G729_L_FRAME);
		*subfr_num = *subfr_num + 1;
	}
}
/* estimate initial energy of inactive */
void G729EV_adjust_gain(REAL *Ga, REAL *Gf, REAL g_p, REAL g_c, REAL g_a)
{
	REAL temp;
	*Ga = 0.5*(*Ga) + 0.5*g_p;
	temp = g_c*g_c + g_a*g_a;
	temp = sqrt(temp);
	*Gf = 0.5*(*Gf) + 0.5*temp;
}
/* excitation re-shaping filter */
void G729EV_fir_filt(REAL x[], INT16 i_frame, REAL filt[], INT16 count)
{
	INT16 i, j;
	REAL s;
	for (i = 0; i < count; i++)
	{
		s = x[i_frame+i] * Shaping_filter[0] * GAIN_SHAPING_FILTER;
		for (j = 0; j < FILTERORDER; j++)
		  s += Shaping_filter[j+1] * filt[FILTERORDER-1-j] * GAIN_SHAPING_FILTER;
 
		for(j = 0; j < FILTERORDER-1; j++)
		{
			 filt[j] = filt[j+1];
		}
		filt[j] = x[i_frame+i];

		x[i_frame+i] = s;
	}
}
