/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.2                                                            */
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __G729EV_TDAC_DECOD_H__
#define __G729EV_TDAC_DECOD_H__

#include <stdio.h>
#include <string.h>
#include "CodecTypedef.h"


/* Functions : */
void      G729EV_TDAC_decoder(INT16 * bit, int nbit, int nbit_max, REAL * yt_hi,
                              REAL * yq_lo, REAL * yq_hi, int norm_MDCT);

/* Tables : */


#endif  /*__G729EV_TDAC_DECOD_H__ */
