/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* Version:       1.2                                                            */
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_tfr.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_tfr()                                             *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  The good thomas fast fourier transform                                  *
 *--------------------------------------------------------------------------*/

void G729EV_TDAC_tfr(REAL * x1, /* (i/o) pointer on the real part of data       */
                     REAL * x2, /* (i/o) pointer on the imaginary part of data  */
                     int sign)  /* (i) flag to select FFT (1) or IFFT (-1)      */
{

  REAL      tab_x1[G729EV_TDAC_NP * G729EV_TDAC_NPP];
  REAL      tab_x2[G729EV_TDAC_NP * G729EV_TDAC_NPP];
  REAL      rx1[G729EV_TDAC_NP];
  REAL      rx2[G729EV_TDAC_NP];

  REAL     *ptr_x1;             /* Pointer on tab_x1 */
  REAL     *ptr_x2;             /* Pointer on tab_x2 */
  REAL     *ptr0_x1;            /* Pointer on tab_x1 for DFT step */
  REAL     *ptr0_x2;            /* Pointer on tab_x2 for DFT step */
  const REAL *ptr_cos;          /* Pointer on cos table */
  const REAL *ptr_sin;          /* Pointer on sin table */
  const INT16 *ptr_map;         /* Pointer on mapping indice (input and output) */

  int       ip, ipp, i, j;
  REAL      x1_tmp;
  REAL      x2_tmp;
  int       exp_n2;
  int       n1;
  int       n2;                 /* size of sub array */
  int       n3;
  int       p;                  /* size of the butterfly */
  int       inkw;
  REAL      rix;
  REAL      cix;
  REAL      rjx;
  REAL      cjx;

 /********************************************************************************
 * Mapping for the input indices (Good Thomas FTT)                              *
 ********************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  ptr_map = G729EV_TDAC_tab_map;
  for (ip = 0; ip < G729EV_TDAC_NP; ip++)
  {
    for (ipp = 0; ipp < G729EV_TDAC_NPP; ipp++)
    {
      i = (int) *ptr_map++;
      *ptr_x1++ = x1[i];
      *ptr_x2++ = x2[i];
    }
  }

    /***************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  for (ip = 0; ip < G729EV_TDAC_NP; ip++)
  {
    for (j = 0; j < G729EV_TDAC_NB_REV; j++)
    {
      i = G729EV_TDAC_tab_rev_i[j];
      ipp = G729EV_TDAC_tab_rev_ipp[j];
      x1_tmp = ptr_x1[ipp];     /* swap value ptr_x1[i] and ptr_x1[ipp] */
      x2_tmp = ptr_x2[ipp];     /* swap value ptr_x2[i] and ptr_x2[ipp] */
      ptr_x1[ipp] = ptr_x1[i];
      ptr_x2[ipp] = ptr_x2[i];
      ptr_x1[i] = x1_tmp;
      ptr_x2[i] = x2_tmp;
    }
    ptr_x1 += G729EV_TDAC_NPP;
    ptr_x2 += G729EV_TDAC_NPP;
  }

 /*******************************************************************************
 * n1 size of butterfly                                                        *
 *******************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  for (ip = 0; ip < G729EV_TDAC_NP; ip++)
  {
    for (exp_n2 = 0; exp_n2 <= G729EV_TDAC_EXP_NPP; exp_n2++)
    {
      /*  n2 : size of sub arrays */
      n2 = 1 << exp_n2;
      n1 = n2 >> 1;
      n3 = G729EV_TDAC_EXP_NPP - exp_n2;
      /* p equal the size of the butterfly */
      for (p = 0; p < n1; p++)
      {
        /*  get twiddle factor in arrays rw1 and rw2 */
        inkw = (p * G729EV_TDAC_NP) << n3;
        x1_tmp = G729EV_TDAC_rw1[inkw];
        x2_tmp = -(REAL) sign *G729EV_TDAC_rw2[inkw];

        for (i = p; i < G729EV_TDAC_NPP; i += n2)
        {
          /*  selecet item p in array p */
          j = i + n1;
          /*   butterfly on x[i] and x[j] */
          rix = ptr_x1[i];
          cix = ptr_x2[i];
          /*  twiddle factor */
          rjx = (x1_tmp * ptr_x1[j]) - (x2_tmp * ptr_x2[j]);
          cjx = (x2_tmp * ptr_x1[j]) + (x1_tmp * ptr_x2[j]);
          ptr_x1[i] = rix + rjx;
          ptr_x2[i] = cix + cjx;
          ptr_x1[j] = rix - rjx;
          ptr_x2[j] = cix - cjx;
        }
      }
    }                           /* end while */
    ptr_x1 += G729EV_TDAC_NPP;
    ptr_x2 += G729EV_TDAC_NPP;
  }                             /* end for ip */

  /**************************************************************************
   * G729EV_TDAC_NPP DFT (size 5)                                           *
   **************************************************************************/

  ptr0_x1 = tab_x1;
  ptr0_x2 = tab_x2;
  for (ipp = 0; ipp < G729EV_TDAC_NPP; ipp++)
  {
    ptr_x1 = ptr0_x1;
    ptr_x2 = ptr0_x2;
    for (ip = 0; ip < G729EV_TDAC_NP; ip++)
    {
      rx1[ip] = *ptr_x1;
      rx2[ip] = *ptr_x2;
      ptr_x1 += G729EV_TDAC_NPP;
      ptr_x2 += G729EV_TDAC_NPP;
    }

    ptr_x1 = ptr0_x1++;
    ptr_x2 = ptr0_x2++;
    ptr_cos = G729EV_TDAC_xcos;
    ptr_sin = G729EV_TDAC_xsin;
    if (sign > 0)               /* FFT */
    {
      for (ip = 0; ip < G729EV_TDAC_NP; ip++)
      {
        x1_tmp = (REAL) 0.0;
        x2_tmp = (REAL) 0.0;
        for (i = 0; i < G729EV_TDAC_NP; i++)
        {
          x1_tmp += rx1[i] * (*ptr_cos) - rx2[i] * (*ptr_sin);
          x2_tmp += rx2[i] * (*ptr_cos++) + rx1[i] * (*ptr_sin++);
        }
        *ptr_x1 = x1_tmp;
        *ptr_x2 = x2_tmp;
        ptr_x1 += G729EV_TDAC_NPP;
        ptr_x2 += G729EV_TDAC_NPP;
      }                         /*end for ip */
    }
    else                        /* IFFT */
    {
      for (ip = 0; ip < G729EV_TDAC_NP; ip++)
      {
        x1_tmp = (REAL) 0.0;
        x2_tmp = (REAL) 0.0;
        for (i = 0; i < G729EV_TDAC_NP; i++)
        {
          x1_tmp += rx1[i] * (*ptr_cos) + rx2[i] * (*ptr_sin);
          x2_tmp += rx2[i] * (*ptr_cos++) - rx1[i] * (*ptr_sin++);
        }
        *ptr_x1 = x1_tmp;
        *ptr_x2 = x2_tmp;
        ptr_x1 += G729EV_TDAC_NPP;
        ptr_x2 += G729EV_TDAC_NPP;
      }                         /*end for ip */
    }
  }                             /*end for ipp */

    /***************************************************************************
     * mapping for the output indices                                          *
     ***************************************************************************/
  ptr_x1 = tab_x1;
  ptr_x2 = tab_x2;
  ptr_map = G729EV_TDAC_tab_map2;
  for (ip = 0; ip < G729EV_TDAC_NP; ip++)
  {
    for (ipp = 0; ipp < G729EV_TDAC_NPP; ipp++)
    {
      i = (int) *ptr_map++;
      x1[i] = *ptr_x1++;
      x2[i] = *ptr_x2++;
    }
  }

  return;
}
