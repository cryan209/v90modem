/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   Version:       1.2                                                            
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
#ifndef __G729EV_MAIN_FILT_H__
#define __G729EV_MAIN_FILT_H__

#include <stdio.h>
#include "CodecTypedef.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"

/* Types : */

typedef struct
{
  /* QMF filter states */
  REAL      mem[2 * G729EV_MAIN_S_QMF - 1];
} G729EV_MAIN_QMFCODSTAT;

typedef struct
{
  /* QMF filter states */
  REAL      mem_add[2 * G729EV_MAIN_S_QMF_FS - 1];
  REAL      mem_sub[2 * G729EV_MAIN_S_QMF_FS - 1];
} G729EV_MAIN_QMFDECSTAT;


typedef struct
{                               /* memory state structure */
  REAL      x0, x1;             /* input samples */
  REAL      y1, y2;             /* output samples */
} G729EV_MAIN_IIR2STAT;


typedef struct
{                               /* memory state structure */
  REAL      x[G729EV_MAIN_LP_ORD];  /* input samples */
  REAL      y[G729EV_MAIN_LP_ORD];  /* output samples */
} G729EV_MAIN_IIRN_STAT;


typedef struct
{                               /* memory state structure */
  REAL      mem_stp[G729EV_G729_M_LPC];
  REAL      mem_res2[G729EV_G729_MEM_RES2];
  REAL      mem_zero[G729EV_G729_M_LPC];
  REAL      apond2[G729EV_G729_LONG_H_ST];
  REAL      gain_prec;
  REAL      Level_in_sm;
  INT16     voicing;
  REAL  parcor0_old;
  REAL  PostNB_old;
} G729EV_MAIN_PFSTAT;



/* Functions : */

/* set gammas */
void      G729EV_MAIN_set_gamma(REAL * output_lo, REAL * tab_Th, int rate, REAL * ga1_post, REAL * ga2_post);

/* median filter */
REAL      G729EV_MAIN_gmed_n(REAL ind[], int n);

/* weighting filter */
void      G729EV_MAIN_weighting_filter(REAL * ptr_Az, REAL * mem_Wz_in, REAL * mem_wsp, REAL * diff);
void      G729EV_MAIN_inverse_weighting_filter(REAL * ptr_Az, REAL * mem_invWz_in, REAL * mem_invwsp, REAL * diff_q);

/* pre/post-processing routines */
void      G729EV_MAIN_init_iir2(G729EV_MAIN_IIR2STAT * preprocStat);
void      G729EV_MAIN_iir2(G729EV_MAIN_IIR2STAT * preprocStat, REAL signal[], int lg, const REAL * b, const REAL * a);

void      G729EV_MAIN_init_lp3k(G729EV_MAIN_IIRN_STAT * preprocStat);
void      G729EV_MAIN_lp3k(G729EV_MAIN_IIRN_STAT * preprocStat, REAL signal[], int lg);

/* QMF routines */
void      G729EV_MAIN_initQMF_ana(G729EV_MAIN_QMFCODSTAT * codstat);
void      G729EV_MAIN_initQMF_syn(G729EV_MAIN_QMFDECSTAT * codstat);
void      G729EV_MAIN_QMF_ana(G729EV_MAIN_QMFCODSTAT * codstat, REAL * input, REAL * bf, REAL * hf, int size);
void      G729EV_MAIN_QMF_syn(G729EV_MAIN_QMFDECSTAT * decstat, REAL * inputBF, REAL * inputHF,
                              REAL * output, int size, REAL gain_switching);

void      G729EV_MAIN_QMF_mirror(REAL * s, int l);

/* 2nd order FIR filter */
void      G729EV_MAIN_CONVOLVE_2Tap(REAL Input[], REAL Output[], REAL Coef, int Length);
void      G729EV_MAIN_CONVOLVE_3Tap(REAL Input[], REAL Output[], REAL Coef, int Length);

/* Tables : */
extern const REAL G729EV_MAIN_qmf_J64D[32];

extern const REAL G729EV_MAIN_hp50_b[3];
extern const REAL G729EV_MAIN_hp50_a[3];
extern const REAL G729EV_MAIN_b100[3];
extern const REAL G729EV_MAIN_a100[3];

extern const REAL G729EV_MAIN_lp3k_b[G729EV_MAIN_LP_ORD + 1];
extern const REAL G729EV_MAIN_lp3k_a[G729EV_MAIN_LP_ORD + 1];

/* codebook for fixed-codebook gain correction in cascade CELP (2 bits)    */
extern const REAL Sqrt_han_wind8k[G729EV_MAIN_L_FRAME4 + 1];
extern const REAL G729EV_FEC_h_low[];
extern const REAL G729EV_FEC_h_high[5];
extern const REAL interpol_frac1[G729EV_MAIN_NB_SUBFR];

#endif  /*__G729EV_MAIN_FILT_H__ */
