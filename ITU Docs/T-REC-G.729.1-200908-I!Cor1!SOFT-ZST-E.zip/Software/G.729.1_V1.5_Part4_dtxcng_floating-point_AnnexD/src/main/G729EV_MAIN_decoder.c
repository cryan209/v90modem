/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */ 
/*      Copyright (c) 2008-09                                                         */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.5                                                                   */
/*      Revision Date: August 29, 2009                                                */
/*	                                                                                  */

/*      Based on code version:                                                        */

/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   Version:       1.2                                                            
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdio.h>
#include <string.h>
#include <stdlib.h>

#include "G729EV_G729_defines.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_decod.h"
#include "G729EV_G729B_defines.h"

#if 0
#define FRAME_ERASURE_G192
#else
#define FRAME_ERASURE_JETBUFFER
#endif
/*--------------------------------------------------------------------------*
 *  Function  display_usage()                                               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~                                               *
 *  Display decoder usage                                                   *
 *--------------------------------------------------------------------------*/

static void display_usage(char *argv)
{
  printf("Usage: %s [options] <bitstream> <outputfile>\n", argv);
  printf("\n");
  printf("Options:\n");
  printf("  -quiet     do not display frame counter\n");
  printf("  -rXXXXX    run decoder at maximal bit rate XXXXX bit/s (32000 by default)\n");
  printf("  -f8        output sampled at 8 kHz\n");
  printf("  -g729b_bst read and decode G.729 or G.729B bitstream\n");
  printf("  -ld        low-delay mode\n");
  printf("\n");
}

/*--------------------------------------------------------------------------*
 *  Function  check_arguments()                                             *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                                             *
 *  Check decoder arguments                                                 *
 *--------------------------------------------------------------------------*/

static void check_arguments(int argc, char *argv[], int *used_rate, /* (i/o)    rate used by decoder            */
                            int *nb_bits_used,                      /* (i/o)    number of bits used by decoder  */
                            INT16 * frame_size,                     /* (i/o)    frame size used by encoder      */
                            int *i,                                 /* (o)      argv index                      */
                            int *quiet,                             /* (i/o)    quiet mode flag                 */
                            int *f8,                                /* (i/o)    8kHz sampled output flag        */
                            int *g729b_bst,                         /* (i/o)    G.729 bitstream mode flag       */
                            int *low_delay)                         /* (i/o)    Low-delay mode flag             */
{

  if ((argc < 3) || (argc > 8))
  {
    display_usage(argv[0]);
    exit(-1);
  }

  for (*i = 1; (*i < argc) && (strncmp(argv[*i], "-", 1) == 0); (*i)++)
  {
    if (strcmp(argv[*i], "-quiet") == 0)
      *quiet = 1;
    else if (strcmp(argv[*i], "-f8") == 0)
    {
      *f8 = 1;
      *frame_size = G729EV_MAIN_L_FRAME2;
    }
    else if (strcmp(argv[*i], "-g729b_bst") == 0)
    {
      *g729b_bst = 1;
      *low_delay = 1;
    }
    else if (strcmp(argv[*i], "-ld") == 0)
    {
      *low_delay = 1;
    }
    else if (strncmp(argv[*i], "-r", 2) == 0)
    {
      *used_rate = atoi(&argv[*i][2]);
      if (((*used_rate != 8000) && (*used_rate < 12000)) || (*used_rate > 32000) || (*used_rate % 2000 != 0))
      {
        printf("Error: wrong bit rate\n");
        exit(-1);
      }
      *nb_bits_used = (int) ((*used_rate) * 0.02);
    }
    else
    {
      printf("Error: unrecognized option %s\n", argv[*i]);
      display_usage(argv[0]);
      exit(-1);
    }
  }

  if ((*g729b_bst) && (*nb_bits_used != 0))
  {
    *used_rate = 0;
    *nb_bits_used = 0;
    printf("Warning: information rate ignored (G729B_BST mode on)\n");
  }

  if ((*low_delay) && (!*g729b_bst) && ((*used_rate > 14000) || (*used_rate == 0)))
  {
    *used_rate = 14000;
    *nb_bits_used = 280;
    printf("Warning: bit rate limited to 14000 bit/s (LOW_DELAY mode on)\n");
  }

}

int main(int argc, char *argv[])
{
  FILE     *pfilin;             /* input file descriptor */
  FILE     *pfilout;            /* output file descriptor */
  DECSTATMAIN decStat;          /* structure of decoder states variables */
  INT16     tabout[G729EV_MAIN_L_FRAME];  /* table of the 16 bits ouput samples */
  int       nb_bits_sent = 0;   /* number of bits available to decoder */
  int   nb_bits_read = 0;
  int   nb_bits_sid = 0;
  int   nb_bits_used = 640;         /* number of bits used to decode */
  int   used_rate = 32000;            /* bitrate specified with "-rXXXXX" option */
  int		nb_act_frame = 0;
  INT16     frame_size = G729EV_MAIN_L_FRAME; /* number of samples per frame */
  int       nb_frame = 0;       /* frame counter */
  int       nb;                 /* number of samples/bytes read in input file */
  int       bfi;                /* bad frame indicator */
  int       i;
  INT16     itu_192_bitstream[G729EV_MAX_BITS_BST + 2];
  int       quiet = 0;
  int       f8 = 0;             /* flag for 8kHz output */
  int       g729b_bst = 0;      /* flag for g729 bitstream */
  int       low_delay = 0;      /* flag for low delay mode */
  int       skip;
  INT16    *bst;
  int       rate;
  int       nclf = 0;           /* not complete last frame (for G729 bitstream mode */
  INT16     g729ftyp[2];
  INT16     Sid_Layer[2];

  printf("\n");
  printf("              ***** ITU-T G.729.1 Annex D Decoder *****\n");
  printf("\n");
  printf("                Floating-point C simulation\n");
  printf("                Version 1.4 - Sep. 16, 2008 \n");
  printf("\n");

  /*------------------------------- read command line and check arguments -----------------------*/
  check_arguments(argc, argv, &used_rate, &nb_bits_used, &frame_size, &i, &quiet, &f8, &g729b_bst, &low_delay);

 
  /* open input file */
  if (i < argc)
  {
    if ((pfilin = fopen(argv[i], "rb")) == NULL)
    {
      printf("Error: cannot open file %s\n", argv[i]);
      exit(-1);
    }
    i++;
  }
  else
  {
    printf("Error: no input and output files specified\n");
    exit(-1);
  }

  /* open output file */
  if (i < argc)
  {
    if ((pfilout = fopen(argv[i], "wb")) == NULL)
    {
      printf("Error: cannot open file %s\n", argv[i]);
      exit(-1);
    }
  }
  else
  {
    printf("Error: no output file specified\n");
    exit(-1);
  }


  /* print arguments */
  printf("Input file         : %s\n", argv[i - 1]);
  printf("Output file        : %s\n", argv[i]);
  if (used_rate != 0)
    printf("Used bitrate       : %d\n", (int) used_rate);
  if (f8)
    printf("Sampling frequency : 8000 Hz\n");
  else
    printf("Sampling frequency : 16000 Hz\n");
  if (g729b_bst)
    printf("Mode               : G729B_BST\n");
  if (low_delay & (!g729b_bst))
    printf("Mode               : LOW_DELAY\n");
  printf("Decoding file %s...\n", argv[i - 1]);

        /*------------------------------------------ main processing ---------------------------------------*/

  /* init decoder */
  G729EV_MAIN_InitDecoder(&decStat, f8, g729b_bst, low_delay);

  /* set delay for synthesis alignment */
  if (f8)
    skip = G729EV_MAIN_DELAY / 2;
  else
    skip = G729EV_MAIN_DELAY;
  if (low_delay != 1)
    skip += frame_size;

  /* loop over bitstream file */
  while ((nb = fread(&itu_192_bitstream[0], sizeof(itu_192_bitstream[0]), 1, pfilin)) == 1) /*reads sync word */
  {
    bst = itu_192_bitstream;
    bfi = 0;
	  for(i = 0; i <= g729b_bst; i++){   /* if G729 bitstream, reads 2frames */
          if ((*bst != ITU_G192_SYNCWORD) && (*bst != ITU_G192_SYNCWORD_ERASURE)){
              printf ("Error: wrong synchron word in bitstream\n");
              exit (-1);
          }
          if (*bst == ITU_G192_SYNCWORD_ERASURE){
              bfi = 1;
          }
          bst++;
          
          /* get number of bits in current frame */
		  if ((nb = fread (bst, sizeof (bst[0]), 1, pfilin)) != 1){  /*reads number of bits */
              printf("WARNING: not complete last frame, number of bits is missing : \n");
              bfi = 1;
          }
		  nb_bits_sent = *bst;
		  bst++;

#ifdef FRAME_ERASURE_JETBUFFER
		  if((decStat.prev_bfi != 0) && (nb_bits_sent == 0))
		  {
			  bfi = 1;
		  }
#endif
		  /* set number of bit sent and rate of CELP core in DecStat  */
		  if(g729b_bst == 0)
		  {
			if(nb_bits_used <= 160) nb_bits_sid = G729EV_G729B_RATE_SID;
			else if(nb_bits_used <= 250) nb_bits_sid = G729EV_G729B_RATE_SID+G729EV_RATE_SID_NB;
			else nb_bits_sid = G729EV_G729B_RATE_SID+G729EV_RATE_SID_NB+G729EV_RATE_SID_WB;
			nb_bits_read = nb_bits_sent;

			if(nb_bits_sent >= G729EV_G729B_RATE_8000)
			{
				if(nb_bits_sent > nb_bits_used) nb_bits_sent = nb_bits_used;
			}
			else
			{
				if((nb_bits_used != 0) && (nb_bits_sent > nb_bits_sid)) nb_bits_sent = nb_bits_sid;
			}
			if (nb_bits_sent > G729EV_G729B_RATE_8000)
			{
				g729ftyp[0] = 1;
				g729ftyp[1] = 1;
				Sid_Layer[0] = 0;
				Sid_Layer[1] = 0;
			}
			else if (((nb_bits_sent < G729EV_G729B_RATE_8000) && (nb_bits_sent > 0)) && (bfi != 1))
			{
				g729ftyp[1] = 0;
				if(nb_bits_sent < G729EV_G729B_RATE_SID)
				{
					g729ftyp[0] = 2;
					Sid_Layer[0] = 0;
					Sid_Layer[1] = 0;
				}
				else if(nb_bits_sent < (G729EV_G729B_RATE_SID+G729EV_RATE_SID_NB))
				{
					g729ftyp[0] = 2;
					Sid_Layer[0] = 1;
					Sid_Layer[1] = 0;
				}
				else
				{
					g729ftyp[0] = 3;
					Sid_Layer[0] = 1;
					Sid_Layer[1] = 1;
				}
			}
			else if ((nb_bits_sent == 0) || (bfi == 1))
			{
				g729ftyp[0] = 0;
				g729ftyp[1] = 0;
			}
			else
			{
				printf("Error: Bad bitstream format for G729.1 bitstream mode\n");
				exit(-1);
			}
		  }
		  else
		  {
			  /* for G729 bitstream mode, determine the type of the received frame */
			  /* 1: speech / 2: SID / 0: not transmitted */
			  nb_bits_read = nb_bits_sent;
			  Sid_Layer[i] = 0;
			  if (nb_bits_sent == G729EV_G729B_RATE_8000)
				  g729ftyp[i] = 1;
			  else if (nb_bits_sent == G729EV_G729B_RATE_SID)
				  g729ftyp[i] = 2;
			  else if (nb_bits_sent == G729EV_G729B_RATE_0)
				  g729ftyp[i] = 0;
			  else
			  {
				  printf("Error: Bad bitstream format for G729 bitstream mode\n");
				  exit(-1);
			  }
		  }
          
          /* read bitstream and check if whole frame received */
		  // In case WB SIDs are received, only one frame is read
		  if ((nb = fread (bst, sizeof (bst[0]), nb_bits_read, pfilin)) != nb_bits_read){

			  printf("WARNING: not complete last frame, data bits are missing : \n");
			  bfi = 1;
		  }
		  bst += nb;
		  if ((i == 0) && g729b_bst){
			  if ((nb = fread(bst, sizeof(bst[0]), 1, pfilin)) != 1){
				  printf("WARNING: incomplete last 20ms frame in G729 bitstream mode: \n");
				  nclf = 1;
				  i++;
			  }
		  }
	  }

	if (!nclf)
    {
      /* set number of bit sent and rate of CELP core in DecStat  */
      if ((nb_bits_used != 0) && (nb_bits_sent > nb_bits_used))
        nb_bits_sent = nb_bits_used;

      if (g729b_bst == 1)
        nb_bits_sent = G729EV_G729B_RATE_8000 * 2;
      /* set rate of CELP core in DecStat  */
      rate = nb_bits_sent * 50;

      /* decode bitstream */
      G729EV_MAIN_Decode(&decStat, &itu_192_bitstream[2], tabout, rate, bfi, g729ftyp, Sid_Layer);

      /* Make sure output speech is aligned with input speech                      */
      /* Dump first G729EV_MAIN_DELAY + frame_size samples samples (lookahead)     */

      if (skip == 0)
      {
        /* write output */
        fwrite(tabout, sizeof(INT16), frame_size, pfilout);
      }
      else
      {
        if (skip <= frame_size)
        {
          fwrite(tabout, sizeof(INT16), frame_size - skip, pfilout);
          skip = 0;
        }
        else
        {
          skip -= frame_size;
        }
      }
      nb_frame++;
      if (g729b_bst)
        nb_frame++;
	  if ((decStat.decStG729.ftyp[0] == 1) && (decStat.first_sp_seg == 0))
	  {
		  nb_act_frame++;
		  decStat.wbStat *= (REAL)(nb_act_frame-1)/nb_act_frame;
		  if (rate >= 14000)
			  decStat.wbStat += (REAL) 1/nb_act_frame;
	  }
      if (quiet == 0)
      {
        if (nb_frame % 100 == 0)
        {
          printf(" frame  %d  \r", nb_frame);
          fflush(stdout);
        }
      }
    }
  }


  if (!skip)
  {
    INT16     buf[G729EV_MAIN_DELAY + G729EV_MAIN_L_FRAME];

    for (i = 0; i < G729EV_MAIN_DELAY + G729EV_MAIN_L_FRAME; i++)
      buf[i] = 0;

    fwrite(buf, sizeof(INT16), G729EV_MAIN_DELAY + G729EV_MAIN_L_FRAME, pfilout);
  }

  printf("Number of processed frames: %d\n\n", nb_frame);

  fclose(pfilin);
  fclose(pfilout);

  return (0);
}
