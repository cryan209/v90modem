/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   Version:       1.2                                                            
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_DECOD_H__
#define __G729EV_MAIN_DECOD_H__

#include <stdio.h>
#include "CodecTypedef.h"
#include "G729EV_TDBWE_decoder.h"
#include "G729EV_TDAC_decod.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_G729_decstat.h"


/* Types : */
typedef struct
{
  /* filter states */
  G729EV_MAIN_QMFDECSTAT qmf_syn;
  G729EV_MAIN_IIR2STAT mem_postpro;
  G729EV_MAIN_IIRN_STAT mem_lp3k;

  /* state variables of G.729 and TDBWE decoders */
  G729EV_G729_DECSTAT decStG729;
  G729EV_TDBWE_DECSTAT tdbwe;

  /* previous G.729 parameters (for FEC) */
  G729EV_CELP2S_PARAM prev_nb_celp_param;

  /* lower-band postfiltering */
  G729EV_MAIN_PFSTAT mem_pf;
  REAL      mem_pf_in[G729EV_G729_M_LPC];
  REAL      mem_Az[G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1];
  int       mem_t0[G729EV_MAIN_NB_SUBFR];

  /* states for inverse perceptual weighting filtering of lower-band difference signal */
  REAL      mem_invWz_in[G729EV_G729_M];
  REAL      mem_invwsp[G729EV_G729_M];

  /* MDCT memories */
  REAL      mem_mdct_hi[G729EV_MAIN_L_FRAME2];
  REAL      mem_inv_mdct_lo[G729EV_MAIN_L_FRAME2];
  REAL      mem_inv_mdct_hi[G729EV_MAIN_L_FRAME2];

  /* gamma adaptation memory for lower-band postfilter */
  REAL      tab_Th[G729EV_MAIN_NMAX];

  /* state variables for FEC */
  REAL      prev_parameters_tdbwe[G729EV_TDBWE_NB_PARAMETERS];
  REAL      old_celp_output[G729EV_MAIN_L_FRAME2];
  REAL      sTdbweOld[G729EV_MAIN_L_FRAME2];
  REAL      synth_buf[G729EV_G729_PIT_MAX];
  REAL      vmhold;
  REAL      vmlold;
  int       first_frame;
  int       prev_nRcv_hi;
  int       prev_rate;
  REAL      lp_ener_FER;
  INT16     lastgood;
  REAL      old_enrLP;
  INT16     plast_good;
  REAL      max_prev_lo;
  REAL      max_prev_hi;

  /* variables for bit-rate switching */
  int       count_rcv;
  int       mem_postflag;
  REAL		wbStat;
  INT16		count_rcv_dtx;
  INT16		SpToSil;
  INT16		first_sp_seg;
  INT16		old_SID_rate;
  INT16		prev_ftyp_null;

  /* decoder flags (8kHz sampled input, G.729 bistream mode, low-delay mode) */
  int       f8;
  int       g729b_bst;
  int       low_delay;
  REAL		pfmem;

  /* bfi of previous frame */
  int       prev_bfi;
  REAL	SID_parameters_tdbwe[G729EV_TDBWE_NB_PARAMETERS];
  int layer_pre;
  int layer_cur;
  REAL SIDpre_parameters_tdbwe[G729EV_TDBWE_NB_PARAMETERS];
  int fade_out_count;         
  int fade_out_flag;
  REAL parameters_tdbwe_longmove[G729EV_TDBWE_NB_PARAMETERS];
} DECSTATMAIN;


/* Functions : */
void      G729EV_MAIN_InitDecoder(DECSTATMAIN * decstat, int f8, int g729b_bst, int low_delay);
void      G729EV_MAIN_Decode(DECSTATMAIN * pDecStatH, INT16 * itu_192_bitstream, INT16 * tabout, int rate, int bfi, UINT16 g729ftyp[2], UINT16 Sid_Layer[2]);

/* Tables : */
extern const REAL G729EV_MAIN_switching_gain[G729EV_MAIN_COUNT_RCV_MAX + 1];

#endif  /*__G729EV_MAIN_DECOD_H__ */
