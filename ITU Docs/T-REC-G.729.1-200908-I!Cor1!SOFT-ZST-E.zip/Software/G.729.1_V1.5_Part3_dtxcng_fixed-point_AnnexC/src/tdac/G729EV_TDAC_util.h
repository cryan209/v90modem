/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_UTIL_H__
#define __G729EV_TDAC_UTIL_H__

#include <stdio.h>
#include "stl.h"

/* Functions : */

void      G729EV_TDAC_pushBit(UWord16 code, Word16 ** pBit, Word16 nbit);
void      G729EV_TDAC_pushBitL(UWord32 code, Word16 ** pBit, Word16 nbit);
UWord16   G729EV_TDAC_getBit(Word16 ** pBit, Word16 nbit);
UWord32   G729EV_TDAC_getBitL(Word16 ** pBit, Word16 nbit);


/* Tables : */

#endif /* __G729EV_TDAC_UTIL_H__ */
