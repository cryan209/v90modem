/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_TFR_H__
#define __G729EV_TDAC_TFR_H__

#include <stdio.h>
#include "stl.h"

/* Functions : */

void      G729EV_TDAC_tfr(Word16 * x1, Word16 * x2, Word16 sign);

/* Tables : */

extern const Word16 G729EV_TDAC_tab_map[G729EV_TDAC_NP * G729EV_TDAC_NPP];
extern const Word16 G729EV_TDAC_tab_map2[G729EV_TDAC_NP * G729EV_TDAC_NPP];
extern const Word16 G729EV_TDAC_tab_rev_i[G729EV_TDAC_NB_REV];
extern const Word16 G729EV_TDAC_tab_rev_ipp[G729EV_TDAC_NB_REV];
extern const Word16 G729EV_TDAC_rw1[G729EV_TDAC_L_WIN4];
extern const Word16 G729EV_TDAC_rw2[G729EV_TDAC_L_WIN4];
extern const Word16 G729EV_TDAC_xcos[25];
extern const Word16 G729EV_TDAC_xsin[25];


#endif /* __G729EV_TDAC_TFR_H__ */
