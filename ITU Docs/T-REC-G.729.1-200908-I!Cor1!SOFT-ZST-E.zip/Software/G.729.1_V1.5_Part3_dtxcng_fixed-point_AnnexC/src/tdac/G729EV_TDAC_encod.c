/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>

#include "G729EV_G729_defines.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_encod.h"
#include "G729EV_TDAC_util.h"
#include "G729EV_TDAC_mdct.h"
#include "G729EV_TDAC_vq.h"
#include "G729EV_TDAC_tfr.h"
#include "G729EV_TDAC_spectenv.h"
#include "G729EV_TDAC_encod.h"
#include "G729EV_TDAC_bitalloc.h"

/****************************************************************/
/* G729EV_TDAC_encoder                                          */
/*--------------------------------------------------------------*/
/*                                                              */
/****************************************************************/

void G729EV_TDAC_encoder(Word16 * y_lo,
                         Word16 * y_hi,
                         Word16 * bitstream,
                         Word16 nbit, Word16 nbit_max, Word16 norm_lo, Word16 norm_hi, Word16 norm_MDCT)
{
  Word16    startbit[G729EV_TDAC_NB_SB];
  Word16    rms_index[G729EV_TDAC_NB_SB];
  Word16    log_rms[G729EV_TDAC_NB_SB];
  Word16    ip[G729EV_TDAC_NB_SB];
  Word16    ord_b[G729EV_TDAC_NB_SB];
  Word16    bit_alloc[G729EV_TDAC_NB_SB];
  Word16    vqbits[G729EV_TDAC_MAX_VQBITS];
  Word16    y[G729EV_MAIN_L_FRAME];

  Word16   *pBit;
  Word16   *pBit2;

  Word16    i, j;
  Word16    tmp16;
  Word16    bit_cnt;
  Word16    coef_ind;
  Word16    soi;

  IF(nbit > 0)
  {
    pBit = bitstream;
#if(WMOPS)
    move16();
#endif

    /* Form full-band spectrum */
    FOR(i = 0; i < G729EV_MAIN_L_FRAME2; i++)
    {
      y[i] = y_lo[i];
      y[i + G729EV_MAIN_L_FRAME2] = y_hi[i];
#if(WMOPS)
      move16();
      move16();
#endif
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* - compute and encode of spectral envelope (subband rms) */
    /* ---------------------------------------------------------------------------------------------- */

    /* compute spectral envelope */
    /* log_rms : Q11 */
    G729EV_TDAC_calc_specEnv(y, log_rms, G729EV_TDAC_NB_SB, norm_lo, norm_hi, norm_MDCT);

    /* encode spectral envelope */
    bit_cnt = (Word16) 0;
#if(WMOPS)
    move16();
#endif
    G729EV_TDAC_cod_spenv(log_rms, rms_index, &pBit, &bit_cnt, nbit, norm_MDCT);

    /* ---------------------------------------------------------------------------------------------- */
    /* - compute number of bits available for VQ */
    /* - allocate bits to subbands */
    /* - order subbands by decreasing perceptual importance */
    /* ---------------------------------------------------------------------------------------------- */

    /* compute the number of available bits */
    nbit_max = sub(nbit_max, bit_cnt);
    nbit = sub(nbit, bit_cnt);  /* number of bits left (at this stage) */

    /* compute perceptual importance:
       for 3dB step in spectral envelope coding
       1/2log2(enerq) = 1/2 ( rms_index + log2 nb_coef) */

    FOR(j = 0; j < G729EV_TDAC_NB_SB; j++)
    {
      ip[j] = rms_index[j];
#if(WMOPS)
      move16();
#endif
    }
    tmp16 = sub(G729EV_TDAC_NB_SB, 1);
    ip[tmp16] = add(ip[tmp16], 1);  /* ++ */
    /* ip is in Q1 at this stage */
#if(WMOPS)
    move16();
#endif

    /* order subbands by decreasing perceptual importance  */
    G729EV_TDAC_sort_ip(ip, G729EV_TDAC_NB_SB, ord_b);

    /* allocate bits to subbands */
    G729EV_TDAC_allocbit(bit_alloc, nbit_max, ip, G729EV_TDAC_NB_SB, G729EV_TDAC_nb_coef, ord_b);


    /* force zero bit to match bit budget (loop by decreasing perceptual importance) */
    bit_cnt = (Word16) 0;
#if(WMOPS)
    move16();
#endif
    FOR(j = 0; j < G729EV_TDAC_NB_SB; j++)
    {
      coef_ind = ord_b[j];
#if(WMOPS)
      move16();
#endif
      tmp16 = add(bit_cnt, bit_alloc[coef_ind]);
      IF(sub(tmp16, nbit) <= 0)
      {
        bit_cnt = add(bit_cnt, bit_alloc[coef_ind]);
      }
      ELSE
      {
        /* bit budget is zero, set allocation to 0 bits for the other bands  */
        FOR(i = j; i < G729EV_TDAC_NB_SB; i++)
        {
          coef_ind = ord_b[i];
          bit_alloc[coef_ind] = (Word16) 0;
#if(WMOPS)
          move16();
          move16();
#endif
        }
      }
    }

    /* ---------------------------------------------------------------------------------------------- */
    /* - quantize MDCT coefficients */
    /* ---------------------------------------------------------------------------------------------- */

    /* apply split spherical vector quantization to MDCT coefficients */
    pBit2 = vqbits;
#if(WMOPS)
    move16();
#endif
    G729EV_TDAC_quantif(y, &pBit2, bit_alloc, G729EV_TDAC_NB_SB);

    /* write VQ bits to bitsream */
    soi = (Word16) 0;
#if(WMOPS)
    move16();
#endif
    FOR(j = 0; j < G729EV_TDAC_NB_SB; j++)
    {
      startbit[j] = soi;
#if(WMOPS)
      move16();
#endif
      soi = add(soi, bit_alloc[j]);
    }
    FOR(j = 0; j < G729EV_TDAC_NB_SB; j++)
    {
      coef_ind = ord_b[j];
      soi = startbit[coef_ind];
#if(WMOPS)
      move16();
      move16();
#endif
      FOR(i = 0; i < bit_alloc[coef_ind]; i++)
      {
        *pBit++ = vqbits[soi++];
#if(WMOPS)
        move16();
#endif
      }
    }
    FOR(i = bit_cnt; i < nbit; i++)
    {
      *pBit++ = ITU_G192_BIT_0;
#if(WMOPS)
      move16();
#endif
    }
  }
}
