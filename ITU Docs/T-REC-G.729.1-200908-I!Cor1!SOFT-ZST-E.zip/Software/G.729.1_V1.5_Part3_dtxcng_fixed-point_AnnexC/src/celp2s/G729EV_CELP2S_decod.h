/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/



#ifndef __G729EV_G729_DECODE_H__
#define __G729EV_G729_DECODE_H__

#include "G729EV_CELP2S.h"

#include "G729EV_CELP2S_qua_gain.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_FEC_fer.h"

/* Functions */
void      G729EV_CELP2S_InitDecoder(G729EV_G729_DECSTAT * pDecStat, Word16 g729b_bst);
void G729EV_CELP2S_decoder(G729EV_G729_DECSTAT * pDecStat,      
                           Word16 * coder_parameters,           
                           Word16 rate,                         
                           Word16 SubFrNum,                     
                           G729EV_CELP2S_PARAM * nb_celp_param, 
                           Word16 * BfAq,                        
                           Word16 * coreExc, Word16 * extExc, Word16 * pitch_buf, Word16 clas, Word16 bfi);


void      G729EV_G729_syn(Word16 * exc_core,    /* (i)  : 8kbits core excitation              */
                           Word16 * exc_ext,    /* (i)  : 12kbits  core excitation  extention */
                           Word16 * exc_mem,    /* (i)  : 12kbits  core excitation  extention */
                           Word16 * BfAq,       /* (i)  : LPC coefficient filter              */
                           Word16 * synth,      /* (o)  : Synthesis buffer                    */
                           Word16 * mem_syn,    /* (i/o): synthesis memory buffer             */
                           Word16 extrate       /* (i)  : Extension bit rate                  */
    );

void      G729EV_CELP2S_Decod_ACELP(Word16 sign, Word16 index, Word16 sp, Word16 cod[]  /* (o) Q13 */
    );
void      G729EV_CELP2S_Decod_pos_sig(Word16 index, Word16 sign, Word16 pos[], Word16 si[]);
void      G729EV_CELP2S_Put4Patterns(Word16 pos[], Word16 si[], Word16 sp, Word16 cod[]);

/* Tables */

#endif  /*__G729EV_G729_DECODE_H__ */
