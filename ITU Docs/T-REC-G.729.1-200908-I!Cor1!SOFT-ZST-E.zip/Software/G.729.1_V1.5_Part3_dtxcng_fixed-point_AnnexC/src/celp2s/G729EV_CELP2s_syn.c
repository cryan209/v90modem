/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_G729_ld8k.h"

/*-----------------------------------------------------------*
 *  Function  G729EV_G729_syn()                              *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                              *
 *  Synthesys of g729ev core                                 *
 *-----------------------------------------------------------*/

void G729EV_G729_syn(Word16 * exc_core,     /* (i)  : 8kbits core excitation                 (Q1)       */
                      Word16 * exc_ext,     /* (i)  : 12kbits  core excitation  extention    (Q1)       */
                      Word16 * exc_mem,     /* (i)  : 12kbits  core excitation  extention    (Q1)       */
                      Word16 * BfAq,        /* (i)  : LPC coefficient filter                 (Q12)      */
                      Word16 * synth,       /* (o)  : Synthesis buffer                       (Q0)       */
                      Word16 * mem_syn,     /* (i/o): synthesis memory buffer                (Q0)       */
                      Word16 extrate        /* (i)  : Extension bit rate                                */
    )
{
  Word16    i_subfr, i;         /* Backward / Forward mode indication */

  /* Tables */
  Word16   *pA_t;               /* Pointer on A_t   */
  Word16   *ptr0, *ptr1;


  /* G729EV_G729_Syn_filt2 takes into account that the excitation is in Q1 to produce Q0 outputs */
  pA_t = BfAq;
  FOR(i_subfr = 0; i_subfr < 2 * G729EV_G729_L_FRAME; i_subfr += G729EV_G729_L_SUBFR)
  {

#if (WMOPS)
    move16();
#endif
    Overflow = 0;
    IF(sub(extrate, 12000) >= 0)
        G729EV_G729_Syn_filt2(pA_t, &exc_ext[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn, 0);
    ELSE G729EV_G729_Syn_filt2(pA_t, &exc_core[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn, 0);
    IF(Overflow != 0)
    {
      /* In case of overflow in the synthesis          */
      /* -> Scale down vector exc[] and redo synthesis */

      ptr0 = exc_mem;
      FOR(i = 0; i < G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL; i++)
      {
        *ptr0++ = shr(exc_mem[i], 2);
#if (WMOPS)
        move16();
#endif
      }
      ptr0 = exc_core;
      ptr1 = exc_ext;
      FOR(i = 0; i < 2 * G729EV_G729_L_FRAME; i++)
      {
#if (WMOPS)
        move16();
        move16();
#endif
        *ptr0++ = shr(exc_core[i], 2);
        *ptr1++ = shr(exc_ext[i], 2);
      }

      IF(sub(extrate, 12000) >= 0)
          G729EV_G729_Syn_filt2(pA_t, &exc_ext[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn, 1);
      ELSE G729EV_G729_Syn_filt2(pA_t, &exc_core[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn, 1);
    }
    ELSE
    {
      G729EV_G729_Copy(&synth[i_subfr + G729EV_G729_L_SUBFR - G729EV_G729_M], mem_syn, G729EV_G729_M);
    }
    pA_t += G729EV_G729_MP1;    /* interpolated LPC parameters for next subframe */
  }

}
