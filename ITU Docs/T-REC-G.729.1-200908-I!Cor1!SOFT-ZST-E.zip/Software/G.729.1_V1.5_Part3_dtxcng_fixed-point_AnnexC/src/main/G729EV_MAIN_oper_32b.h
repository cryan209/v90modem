/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_OPER_32B_H__
#define __G729EV_MAIN_OPER_32B_H__

#include "stl.h"

/* Double precision operations */

void      L_Extract(Word32 L_32, Word16 * hi, Word16 * lo);
Word32    L_Comp(Word16 hi, Word16 lo);
Word32    Mpy_32(Word16 hi1, Word16 lo1, Word16 hi2, Word16 lo2);
Word32    Mpy_32_16(Word16 hi, Word16 lo, Word16 n);
Word32    Div_32(Word32 L_num, Word16 denom_hi, Word16 denom_lo);

UWord32   UL_add(UWord32 a, UWord32 b);
void      UL_sub(UWord32 a, UWord32 b, UWord32 * c, UWord16 * sgn);
UWord32   UL_shl(UWord32 a, Word16 b);

#endif /* __G729EV_MAIN_OPER_32B_H__ */
