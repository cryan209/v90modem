/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "stl.h"
#include "G729EV_MAIN_oper_32b.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"




/**************************************************************************
 * routine G729EV_G729_Corr_xy2 - Compute correlation between target xn   *
 * and filtered codevectors y1 and y2                                     *
 **************************************************************************/
void G729EV_G729_Corr_xy2(Word16 xn[],           /* (i) Q0  :Target vector.                  */
                          Word16 y1[],           /* (i) Q0  :Adaptive codebook.              */
                          Word16 y2[],           /* (i) Q12 :Filtered innovative vector.     */
                          Word16 g_coeff[],      /* (o) Q[exp]:Correlations between xn,y1,y2 */
                          Word16 exp_g_coeff[]   /* (o)       :Q-format of g_coeff[]         */
    )
{
  Word32    L_acc;

  Word16    scaled_y2[G729EV_G729_L_SUBFR]; /* Q9 */

  Word16    i, exp;
  Word16    exp_y2y2, exp_xny2, exp_y1y2;
  Word16    y2y2, xny2, y1y2;



      /*------------------------------------------------------------------*
       * Scale down y2[] from Q12 to Q9 to avoid overflow                 *
       *------------------------------------------------------------------*/

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
#if (WMOPS)
    move16();
#endif
    scaled_y2[i] = shr(y2[i], 3);
  }

  /* Compute scalar product <y2[],y2[]> */

#if (WMOPS)
  move32();
#endif
  L_acc = 1;                    /* Avoid case of all zeros */
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    L_acc = L_mac(L_acc, scaled_y2[i], scaled_y2[i]); /* L_acc:Q19 */
  }
  exp = norm_l(L_acc);
  y2y2 = round(L_shl(L_acc, exp));
  exp_y2y2 = add(exp, 19 - 16); /* Q[19+exp-16] */

#if (WMOPS)
  move16();
  move16();
#endif
  g_coeff[2] = y2y2;
  exp_g_coeff[2] = exp_y2y2;

  /* Compute scalar product <xn[],y2[]> */

#if (WMOPS)
  move32();
#endif
  L_acc = 1;                    /* Avoid case of all zeros */
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    L_acc = L_mac(L_acc, xn[i], scaled_y2[i]);  /* L_acc:Q10 */
  }
  exp = norm_l(L_acc);
  xny2 = round(L_shl(L_acc, exp));
  exp_xny2 = add(exp, 10 - 16); /* Q[10+exp-16] */

#if (WMOPS)
  move16();
  move16();
#endif
  g_coeff[3] = negate(xny2);
  exp_g_coeff[3] = sub(exp_xny2, 1);  /* -2<xn,y2> */

  /* Compute scalar product <y1[],y2[]> */

#if (WMOPS)
  move32();
#endif
  L_acc = 1;                    /* Avoid case of all zeros */
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    L_acc = L_mac(L_acc, y1[i], scaled_y2[i]);  /* L_acc:Q10 */
  }
  exp = norm_l(L_acc);
  y1y2 = round(L_shl(L_acc, exp));
  exp_y1y2 = add(exp, 10 - 16); /* Q[10+exp-16] */

#if (WMOPS)
  move16();
  move16();
#endif
  g_coeff[4] = y1y2;
  exp_g_coeff[4] = sub(exp_y1y2, 1);; /* 2<y1,y2> */

  return;
}





Word16 G729EV_G729_test_err(    /* (o) flag set to 1 if taming is necessary  */
                             G729EV_G729_CODSTAT * pCodStat, Word16 T0, /* (i) integer part of pitch delay           */
                             Word16 T0_frac  /* (i) fractional part of pitch delay        */
    )
{
  Word32    L_maxloc, L_acc;

  Word16    i, t1, zone1, zone2, flag;


  IF(T0_frac > 0)
  {
    t1 = add(T0, 1);
  }
  ELSE
  {
#if (WMOPS)
    move16();
#endif
    t1 = T0;
  }

  i = sub(t1, (G729EV_G729_L_SUBFR + G729EV_G729_L_INTER10));
  if (i < 0)
  {
#if (WMOPS)
    move16();
#endif
    i = 0;
  }
#if (WMOPS)
  move16();
  move16();
#endif
  zone1 = tab_zone[i];

  i = add(t1, (G729EV_G729_L_INTER10 - 2));
  zone2 = tab_zone[i];

#if (WMOPS)
  move32();
  move16();
#endif

  L_maxloc = -1L;
  flag = 0;
  FOR(i = zone2; i >= zone1; i--)
  {
    L_acc = L_sub(pCodStat->L_exc_err[i], L_maxloc);
    if (L_acc > 0L)
    {
#if (WMOPS)
      move32();
#endif
      L_maxloc = pCodStat->L_exc_err[i];
    }
  }
  L_acc = L_sub(L_maxloc, G729EV_G729_L_THRESH_ERR);
  if (L_acc > 0L)
  {
#if (WMOPS)
    move16();
#endif
    flag = 1;
  }

  return (flag);
}

/**************************************************************************
 *routine update_exc_err - maintains the memory used to compute the error *
 * function due to an adaptive codebook mismatch between encoder and      *
 * decoder                                                                *
 **************************************************************************/

void G729EV_G729_update_exc_err(Word32 * L_exc_err, 
								Word16 gain_pit,	/* (i) Q14 : pitch gain */
                                Word16 T0			/* (i)     : integer part of pitch delay */
    )
{
  Word32    L_worst, L_temp, L_acc;

  Word16    i, zone1, zone2, n;
  Word16    hi, lo;

#if (WMOPS)
  move32();
#endif
  L_worst = -1L;
  n = sub(T0, G729EV_G729_L_SUBFR);

  IF(n < 0)
  {
    L_Extract(L_exc_err[0], &hi, &lo);
    L_temp = Mpy_32_16(hi, lo, gain_pit);
    L_temp = L_shl(L_temp, 1);
    L_temp = L_add(0x00004000L, L_temp);
    L_acc = L_sub(L_temp, L_worst);
    if (L_acc > 0L)
    {
#if (WMOPS)
      move32();
#endif
      L_worst = L_temp;
    }
    L_Extract(L_temp, &hi, &lo);
    L_temp = Mpy_32_16(hi, lo, gain_pit);
    L_temp = L_shl(L_temp, 1);
    L_temp = L_add(0x00004000L, L_temp);
    L_acc = L_sub(L_temp, L_worst);
    if (L_acc > 0L)
    {
#if (WMOPS)
      move32();
#endif
      L_worst = L_temp;
    }
  }

  ELSE
  {

#if (WMOPS)
    move16();
    move16();
#endif
    zone1 = tab_zone[n];

    i = sub(T0, 1);
    zone2 = tab_zone[i];

    FOR(i = zone1; i <= zone2; i++)
    {
      L_Extract(L_exc_err[i], &hi, &lo);
      L_temp = Mpy_32_16(hi, lo, gain_pit);
      L_temp = L_shl(L_temp, 1);
      L_temp = L_add(0x00004000L, L_temp);
      L_acc = L_sub(L_temp, L_worst);
      if (L_acc > 0L)
      {
#if (WMOPS)
        move32();
#endif
        L_worst = L_temp;
      }
    }
  }

  FOR(i = 3; i >= 1; i--)
  {
#if (WMOPS)
    move32();
#endif
    L_exc_err[i] = L_exc_err[i - 1];
  }
#if (WMOPS)
  move32();
#endif
  L_exc_err[0] = L_worst;

  return;
}

/********************************************************************/
/*    UpdateMemTam   called for  an erased frame            */
/* 1 tap LTP filtering of 1 as input value for one g729 frame       */
/* last G729EV_G729_MEM_LEN_TAM samples are saved  (no fractional pitch for taming -> no interpolation)    */
/********************************************************************/
void G729EV_G729_UpdateMemTam(G729EV_G729_DECSTAT * pDecStat, Word16 CoefLtp, Word16 Pitch)
{
  Word16    tambuf[G729EV_G729_L_FRAME];  /*Q7, 1->128, max 256 */
  Word16    i, j;

  /*filtering */
  IF(sub(Pitch, G729EV_G729_L_FRAME) < 0)
  {
#if (WMOPS)
    move16();
#endif
    j = 0;
    FOR(i = sub(G729EV_G729_MEM_LEN_TAM, Pitch); i < G729EV_G729_MEM_LEN_TAM; i++) /*memory from the end of MemTam */
    {
      tambuf[j] = shl(mac_r(4194304, CoefLtp, pDecStat->MemTam[i]), 1); /*CoefLtp * pDecStat->MemTam[i] + 1;, 4194304:1 @ Q22 */
#if (WMOPS)
      move16();
#endif
      j++;
    }
    FOR(j = Pitch; j < G729EV_G729_L_FRAME; j++) /*memory from tambuf */
    {
      tambuf[j] = shl(mac_r(4194304, CoefLtp, tambuf[j - Pitch]), 1); /*CoefLtp * tambuf[j - Pitch] + 1;, 4194304:1 @ Q22 */
#if (WMOPS)
      move16();
#endif
    }
  }
  ELSE
  {
    i = sub(G729EV_G729_MEM_LEN_TAM, Pitch);
    FOR(j = 0; j < G729EV_G729_L_FRAME; j++) /*memory from the end of MemTam */
    {
      tambuf[j] = shl(mac_r(4194304, CoefLtp, pDecStat->MemTam[i]), 1); /*CoefLtp * pDecStat->MemTam[i] + 1;, 4194304:1 @ Q22 */
#if (WMOPS)
      move16();
#endif
      i++;
    }
  }
  /*memory update */
  FOR(i = 0; i < G729EV_G729_LEN_MEMTAM_UPDATE_UPDATE; i++)  /*shift MemTam */
  {
#if (WMOPS)
    move16();
#endif
    pDecStat->MemTam[i] = pDecStat->MemTam[i + G729EV_G729_L_FRAME];
  }
  FOR(j = 0; j < G729EV_G729_L_FRAME; j++) /*copie tambuf */
  {
#if (WMOPS)
    move16();
#endif
    pDecStat->MemTam[i] = tambuf[j];
    i++;
  }
}


/********************************************************************/
/*    TamFer   called for  a not erased frame            */
/* 1 tap LTP filtering of 1 as input value for one g729 subframe       */
/* last G729EV_G729_MEM_LEN_TAM samples are saved  (no fractional pitch for taming -> no interpolation)    */
/********************************************************************/
Word16 G729EV_G729_TamFer(G729EV_G729_DECSTAT * pDecStat, Word16 CoefLtp /*Q14 */ , Word16 Pitch)
{
  Word16    i, j;
  Word16    tambuf[G729EV_G729_L_SUBFR];
  Word16    somme = 0;

#if (WMOPS)
  move16();
#endif
  somme = 0;

  /*filtering */
  IF(sub(Pitch, G729EV_G729_L_SUBFR) < 0)
  {
#if (WMOPS)
    move16();
#endif
    j = 0;
    FOR(i = sub(G729EV_G729_MEM_LEN_TAM, Pitch); i < G729EV_G729_MEM_LEN_TAM; i++) /*memory from the end of MemTam */
    {
#if (WMOPS)
      move16();
#endif
      tambuf[j] = shl(mult_r(CoefLtp, pDecStat->MemTam[i]), 1); /*CoefLtp * pDecStat->MemTam[i]; */
      somme = add(somme, tambuf[j]);  /*somme += tambuf[j]; */
      j++;
    }
    FOR(j = Pitch; j < G729EV_G729_L_SUBFR; j++) /*memory from tambuf */
    {
      tambuf[j] = shl(mult_r(CoefLtp, tambuf[j - Pitch]), 1); /*CoefLtp * tambuf[j - Pitch]; */
#if (WMOPS)
      move16();
#endif
      somme = add(somme, tambuf[j]);  /*somme += tambuf[j]; */
    }
    /*calcul of the weighting factor MultGainBk to use in the LTP synthesis */
    if (sub(somme, G729EV_G729_MAXTAMLIM) > 0)
    {
#if (WMOPS)
      move16();
#endif
      somme = G729EV_G729_MAXTAMLIM;
    }

#if (WMOPS)
    test();
#endif
    IF((sub(CoefLtp, 16384) > 0 /*1 @ Q14 */ ) && (sub(somme, G729EV_G729_MINTAMLIM) > 0))
    {
      CoefLtp =
          mac_r(1073741824 /*1 @ Q30 */ , div_s(sub(G729EV_G729_MAXTAMLIM, somme), G729EV_G729_DIFF_MAXMINTAMLIM),
                sub(CoefLtp, 16384));
    }
    /*filtering using the modified cprrection */
#if (WMOPS)
    move16();
#endif
    j = 0;
    FOR(i = sub(G729EV_G729_MEM_LEN_TAM, Pitch); i < G729EV_G729_MEM_LEN_TAM; i++) /*memory from the end of MemTam */
    {
      tambuf[j] = shl(mult_r(CoefLtp, pDecStat->MemTam[i]), 1); /*CoefLtp * pDecStat->MemTam[i]; */
#if (WMOPS)
      move16();
#endif
      j++;
    }
    FOR(j = Pitch; j < G729EV_G729_L_SUBFR; j++) /*memory from tambuf */
    {
      tambuf[j] = shl(mult_r(CoefLtp, tambuf[j - Pitch]), 1); /*CoefLtp * tambuf[j - Pitch]; */
#if (WMOPS)
      move16();
#endif
    }
  }
  ELSE
  {
    i = sub(G729EV_G729_MEM_LEN_TAM, Pitch);
    FOR(j = 0; j < G729EV_G729_L_SUBFR; j++) /*memory from the end of MemTam */
    {
#if (WMOPS)
      move16();
#endif
      tambuf[j] = shl(mult_r(CoefLtp, pDecStat->MemTam[i]), 1); /*CoefLtp * pDecStat->MemTam[i]; */
      somme = add(somme, tambuf[j]);  /*somme += tambuf[j]; */
      i++;
    }
    /*calcul of the weighting factor MultGainBk to use in the LTP synthesis */
    if (sub(somme, G729EV_G729_MAXTAMLIM) > 0)
    {
#if (WMOPS)
      move16();
#endif
      somme = G729EV_G729_MAXTAMLIM;
    }

#if (WMOPS)
    test();
#endif
    IF((sub(CoefLtp, 16384) > 0 /*1 @ Q14 */ ) && (sub(somme, G729EV_G729_MINTAMLIM) > 0))
    {
      CoefLtp =
          mac_r(1073741824 /*1 @ Q30 */ , div_s(sub(G729EV_G729_MAXTAMLIM, somme), G729EV_G729_DIFF_MAXMINTAMLIM),
                sub(CoefLtp, 16384));
    }
    /*filtering using the modified cprrection */
    i = sub(G729EV_G729_MEM_LEN_TAM, Pitch);
    FOR(j = 0; j < G729EV_G729_L_SUBFR; j++) /*memory from the end of MemTam */
    {
      tambuf[j] = shl(mult_r(CoefLtp, pDecStat->MemTam[i]), 1); /*CoefLtp * pDecStat->MemTam[i]; */
#if (WMOPS)
      move16();
#endif
      i++;
    }
  }

  /*memory update */
  FOR(i = 0; i < G729EV_G729_LEN_MEMTAM_UPDATE_TAM; i++) /*shift MemTam */
  {
    pDecStat->MemTam[i] = pDecStat->MemTam[i + G729EV_G729_L_SUBFR];
#if (WMOPS)
    move16();
#endif
  }
  FOR(j = 0; j < G729EV_G729_L_SUBFR; j++) /*copie tambuf */
  {
#if (WMOPS)
    move16();
#endif
    pDecStat->MemTam[i] = tambuf[j];
    i++;
  }

  return (CoefLtp);
}
