/*  ITU-T G.729.1 Annex - Reference C code for floating-point implementation  */
/*  Version :  1.1                                                            */
/*  Revision Date : Aug 6, 2007                                              */

/* -------------------------------  Copyright ---------------------------------
  
 AUTHORS      :    

 ----------------------------------------------------------------------------*/
 /* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

 /*
   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/

/*
 File : QSIDLSF.C
*/
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729B_enc_sid.h"
#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729_tab_ld8k.h"


/* local functions */
static void Qnt_e(Word16 *errlsf,    /* (i)  : error lsf vector             */
                  Word16 *weight,    /* (i)  : weighting vector             */
                  Word16 DIn,        /* (i)  : number of input candidates   */
                  Word16 *qlsf,      /* (o)  : quantized error lsf vector   */
                  Word16 *Pptr,      /* (o)  : predictor index              */
                  Word16 DOut,       /* (i)  : number of quantized vectors  */
                  Word16 *cluster,   /* (o)  : quantizer indices            */
                  Word16 *MS,         /* (i)  : size of the quantizers       */
				  Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
				  Word16 *lsf, 
				  Word16 *new_errlsf);
static void Qnt_e_stage3(
    Word16 *errlsf,    /* (i)  : error lsf vector             */
    Word16 *weight,    /* (i)  : weighting vector             */
    Word16 *qlsf,      /* (i/o)  : quantized error lsf vector   */
    Word16 *Pptr,      /* (o)  : predictor index              */
    Word16 *cluster   /* (o)  : quantizer indices            */
	,Word16 sid_gain
);
static void New_ML_search_1(Word16 *d_data,    /* (i) : error vector             */
                            Word16 J,          /* (i) : number of input vectors  */
                            Word16 *new_d_data,/* (o) : output vector            */
                            Word16 K,          /* (i) : number of candidates     */
                            Word16 *best_indx, /* (o) : best indices             */
                            Word16 *ptr_back,  /* (o) : pointer for backtracking */
                            Word16 *PtrTab,    /* (i) : quantizer table          */
                            Word16 MQ          /* (i) : size of quantizer        */
                            );

static void New_ML_search_2(Word16 *d_data,    /* (i) : error vector             */
                            Word16 *weight,    /* (i) : weighting vector         */
                            Word16 J,          /* (i) : number of input vectors  */
                            Word16 *new_d_data,/* (o) : output vector            */
                            Word16 K,          /* (i) : number of candidates     */
                            Word16 *best_indx, /* (o) : best indices             */
                            Word16 *ptr_prd,   /* (i) : pointer for backtracking */
                            Word16 *ptr_back,  /* (o) : pointer for backtracking */
                            Word16 PtrTab[2][16],/* (i) : quantizer table        */
                            Word16 MQ          /* (i) : size of quantizer        */
                            );
static void New_ML_search_3(
    Word16 *d_data,    /* (i) : error vector             */
    Word16 *weight,    /* (i) : weighting vector         */
    Word16 *best_indx, /* (o) : best indices             */
    Word16 *ptr_prd,   /* (i) : pointer for backtracking */
    Word16 PtrTab[2][G729EV_G729B_3rdCB_LEN],/* (i) : quantizer table        */
    Word16 MQ,          /* (i) : size of quantizer        */
	Word16 ratio_index
);
static void Qnt_e_stage3_loop(
								Word16 *qlsf, 
								Word16 PtrTab_n, 
								Word16 ratio_index,
								Word16 init_n
);
static void New_ML_search_loop(
								 Word32 *acc0, 
								 Word16 ptr_prd_n,
								 Word16 *weight,
								 Word16 *d_data, 
								 Word16 PtrTab_n, 
								 Word16 ratio_index, 
								 Word16 init_n
);
/*-----------------------------------------------------------------*
 * Functions lsfq_noise                                            *
 *           ~~~~~~~~~~                                            *
 * Input:                                                          *
 *   lsp[]         : unquantized lsp vector                        *
 *   freq_prev[][] : memory of the lsf predictor                   *
 *                                                                 *
 * Output:                                                         *
 *                                                                 *
 *   lspq[]        : quantized lsp vector                          * 
 *   ana[]         : indices                                       *
 *                                                                 *
 *-----------------------------------------------------------------*/
void lsfq_noise(Word16 noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M], 
                Word16 *lsp, 
                Word16 *lspq, 
                Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], 
                Word16 *ana,
				Word16 sid_gain)
{
  Word16 i, lsf[G729EV_G729_M], lsfq[G729EV_G729_M], weight[G729EV_G729_M], tmpbuf[G729EV_G729_M];
  Word16 MS[G729EV_G729_MODE]={32, 16}, Clust[G729EV_G729_MODE], mode, errlsf[G729EV_G729_M*G729EV_G729_MODE];
  Word16 d_data[G729EV_G729_M];
  Word16 tmpbuf1[G729EV_G729_M];
  /* convert lsp to lsf */
  G729EV_G729_Lsp_lsf2(lsp, lsf, G729EV_G729_M);

  /* spacing to ~100Hz */
  if (lsf[0] < G729EV_G729_L_LIMIT)
  {
        lsf[0] = G729EV_G729_L_LIMIT;
#if(WMOPS)
    move16();
#endif       
  }
  
  FOR (i=0 ; i < G729EV_G729_M-1 ; i++)
	  if (sub(lsf[i+1], lsf[i]) < 2*G729EV_G729_GAP3) 
		  lsf[i+1] = add(lsf[i], 2*G729EV_G729_GAP3);
	  
  if (lsf[G729EV_G729_M-1] > G729EV_G729_M_LIMIT)
  {
       lsf[G729EV_G729_M-1] = G729EV_G729_M_LIMIT;
	   
#if(WMOPS)
    move16();
#endif
  }
  if (lsf[G729EV_G729_M-1] < lsf[G729EV_G729_M-2])
	  lsf[G729EV_G729_M-2] = sub(lsf[G729EV_G729_M-1], G729EV_G729_GAP3);

  /* get the lsf weighting */
  G729EV_G729_Get_wegt(lsf, weight);
  
  /**********************/
  /* quantize the lsf's */
  /**********************/
  
  /* get the prediction error vector */
  FOR (mode=0; mode<G729EV_G729_MODE; mode++)
	  G729EV_G729_Lsp_prev_extract(lsf, errlsf+mode*G729EV_G729_M, noise_fg[mode], freq_prev, noise_fg_sum_inv[mode]);

  /* quantize the lsf and get the corresponding indices */
	Qnt_e(errlsf, weight, G729EV_G729_MODE, tmpbuf, &mode, 1, Clust, MS, freq_prev, lsf, &d_data[0]);
	G729EV_G729_Copy(tmpbuf, tmpbuf1, G729EV_G729_M);
	Qnt_e_stage3(&d_data[0], weight, tmpbuf, &mode, Clust,sid_gain);
  ana[0] = mode;
  ana[1] = Clust[0];
  ana[2] = Clust[1];
  ana[4] = Clust[2];
  
#if(WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif

  /* guarantee minimum distance of 0.0012 (~10 in Q13) between tmpbuf[j]
     and tmpbuf[j+1] */
  G729EV_G729_Lsp_expand_1_2(tmpbuf, 10);

  /* compute the quantized lsf vector */
  G729EV_G729_Lsp_prev_compose(tmpbuf, lsfq, noise_fg[mode], freq_prev, noise_fg_sum[mode]);
  
  /* update the prediction memory */
  G729EV_G729_Lsp_prev_update(tmpbuf1, freq_prev);
  
  /* lsf stability check */
  G729EV_G729_Lsp_stability(lsfq);

  /* convert lsf to lsp */
  G729EV_G729_Lsf_lsp2(lsfq, lspq, G729EV_G729_M);

}

static void Qnt_e(Word16 *errlsf,    /* (i) Q13 : error lsf vector             */
                  Word16 *weight,    /* (i) Q11 : weighting vector             */
                  Word16 DIn,        /* (i)  : number of input candidates   */
                  Word16 *qlsf,      /* (o) Q13 : quantized error lsf vector   */
                  Word16 *Pptr,      /* (o)  : predictor index              */
                  Word16 DOut,       /* (i)  : number of quantized vectors  */
                  Word16 *cluster,   /* (o)  : quantizer indices            */
                  Word16 *MS,         /* (i)  : size of the quantizers       */
				  Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
				  Word16 *lsf,
				  Word16 *new_errlsf)
{
  Word16  best_indx[2][R_LSFQ];
  Word16 ptr_back[2][R_LSFQ], ptr, i;
  Word16 d_data0[4*G729EV_G729_M], d_data1[G729EV_G729_M];

  New_ML_search_1(errlsf, DIn, d_data0, 4, best_indx[0], ptr_back[0], PtrTab_1, MS[0]);
  New_ML_search_2(d_data0, weight, 4, d_data1, DOut, best_indx[1], 
                  ptr_back[0], ptr_back[1], PtrTab_2, MS[1]);
  
  G729EV_G729_Copy(d_data1, new_errlsf, G729EV_G729_M);
  /* backward path for the indices */
  cluster[1] = best_indx[1][0];
  ptr = ptr_back[1][0];
  cluster[0] = best_indx[0][ptr];

  /* this is the pointer to the best predictor */
  *Pptr = ptr_back[0][ptr];
  
#if(WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif
  /* generating the quantized vector */
  G729EV_G729_Copy(lspcb1[PtrTab_1[cluster[0]]], qlsf, G729EV_G729_M);
  FOR (i=0; i<G729EV_G729_M/2; i++)
    qlsf[i] = add(qlsf[i], lspcb2[PtrTab_2[0][cluster[1]]][i]); /* Q13 */
  FOR (i=G729EV_G729_M/2; i<G729EV_G729_M; i++)
    qlsf[i] = add(qlsf[i], lspcb2[PtrTab_2[1][cluster[1]]][i]);	/* Q13 */
}

static void Qnt_e_stage3(
    Word16 *errlsf,    /* (i)  : error lsf vector             */
    Word16 *weight,    /* (i)  : weighting vector             */
    Word16 *qlsf,      /* (i/o) Q13 : quantized error lsf vector   */
    Word16 *Pptr,       /* (o)  : predictor index              */
    Word16 *cluster,    /* (o)  : quantizer indices            */
    Word16 sid_gain)
{
    Word16 index3, ratio_index;
    ratio_index = shr(sid_gain, 2);     
    /* the third stage quantization of lsf */
	New_ML_search_3(errlsf, weight,  &index3, Pptr, PtrTab_3, G729EV_G729B_3rdCB_LEN, ratio_index);
	/* generating the quantized vector */
	cluster[2] = index3;
	Qnt_e_stage3_loop(qlsf, PtrTab_3[0][cluster[2]], ratio_index, 0);
	Qnt_e_stage3_loop(qlsf, PtrTab_3[1][cluster[2]], ratio_index, G729EV_G729_M/2);
}

static void New_ML_search_1(Word16 *d_data,    /* (i) : error vector             */
                            Word16 J,          /* (i) : number of input vectors  */
                            Word16 *new_d_data,/* (o) : output vector            */
                            Word16 K,          /* (i) : number of candidates     */
                            Word16 *best_indx, /* (o) : best indices             */
                            Word16 *ptr_back,  /* (o) : pointer for backtracking */
                            Word16 *PtrTab,    /* (i) : quantizer table          */
                            Word16 MQ)          /* (i) : size of quantizer        */
{
	Word16 tmp, m, l, p, q, sum[64];
    Word16 min[4], min_indx_p[4], min_indx_m[4];
    Word32 acc0;
	
	FOR (q=0; q<K; q++)
		min[q] = MAX_16;

  /* compute the errors */
  FOR (p=0; p<J; p++)
    FOR (m=0; m<MQ; m++){
      acc0 = 0;
	  
     #if(WMOPS)
           move16();
     #endif
	 
      FOR (l=0; l<G729EV_G729_M; l++){
        tmp = sub(d_data[p*G729EV_G729_M+l], lspcb1[PtrTab[m]][l]);
        acc0 = L_mac(acc0, tmp, tmp);
      }
      sum[p*MQ+m] = extract_h(acc0);
      sum[p*MQ+m] = mult(sum[p*MQ+m], Mp[p]);
    }
      
  /* select the candidates */
  FOR (q=0; q<K; q++){
	min_indx_p[q] = min_indx_m[q] = 0; 
    FOR (p=0; p<J; p++)
      FOR (m=0; m<MQ; m++)
        if (sub(sum[p*MQ+m], min[q]) < 0){
          min[q] = sum[p*MQ+m];
          min_indx_p[q] = p;
          min_indx_m[q] = m;
      #if(WMOPS)
           move16();
	    move16();
	    move16();
     #endif
        }
    
    sum[min_indx_p[q]*MQ+min_indx_m[q]] = MAX_16;
#if(WMOPS)
    move16();
#endif
  }

  /* compute the candidates */
  FOR (q=0; q<K; q++){
    FOR (l=0; l<G729EV_G729_M; l++)
      new_d_data[q*G729EV_G729_M+l] = sub(d_data[min_indx_p[q]*G729EV_G729_M+l], 
                              lspcb1[PtrTab[min_indx_m[q]]][l]);
    
    ptr_back[q] = min_indx_p[q];
    best_indx[q] = min_indx_m[q];
#if(WMOPS)
    move16();
    move16();
#endif
  }
}

static void New_ML_search_2(Word16 *d_data,    /* (i) : error vector             */
                            Word16 *weight,    /* (i) : weighting vector         */
                            Word16 J,          /* (i) : number of input vectors  */
                            Word16 *new_d_data,/* (o) : output vector            */
                            Word16 K,          /* (i) : number of candidates     */
                            Word16 *best_indx, /* (o) : best indices             */
                            Word16 *ptr_prd,   /* (i) : pointer FOR backtracking */
                            Word16 *ptr_back,  /* (o) : pointer for backtracking */
                            Word16 PtrTab[2][16],/* (i) : quantizer table        */
                            Word16 MQ)          /* (i) : size of quantizer        */
{
  Word16 m, l, p, q;
    Word16   min_indx_p[1];
    Word16   min_indx_m[1];
    Word16   sum[64];
    Word16   min[1];
    Word32 acc0;
	
  FOR (q=0; q<K; q++)
    min[q] = MAX_16;

  /* compute the errors */
  FOR (p=0; p<J; p++)
    FOR (m=0; m<MQ; m++){
      acc0 = 0;
	  New_ML_search_loop(&acc0, ptr_prd[p], weight, &d_data[p*G729EV_G729_M], PtrTab[0][m],G729EV_G729B_3rdRAT_LEN + 1, 0);
	  New_ML_search_loop(&acc0, ptr_prd[p], weight, &d_data[p*G729EV_G729_M], PtrTab[1][m],G729EV_G729B_3rdRAT_LEN + 1, G729EV_G729_M/2);
      sum[p*MQ+m] = extract_h(acc0);
    }
      
  /* select the candidates */
  FOR (q=0; q<K; q++){
	min_indx_p[q] = min_indx_m[q] = 0; 
    FOR (p=0; p<J; p++)
      FOR (m=0; m<MQ; m++)
        if (sub(sum[p*MQ+m], min[q]) < 0){
          min[q] = sum[p*MQ+m];
          min_indx_p[q] = p;
          min_indx_m[q] = m;
	#if(WMOPS)
          move16();
          move16();
	   move16();
      #endif
        }
    
    sum[min_indx_p[q]*MQ+min_indx_m[q]] = MAX_16;
#if(WMOPS)
    move16();
#endif
  }

  /* compute the candidates */
  FOR (q=0; q<K; q++){
    FOR (l=0; l<G729EV_G729_M/2; l++)
      new_d_data[q*G729EV_G729_M+l] = sub(d_data[min_indx_p[q]*G729EV_G729_M+l], 
                              lspcb2[PtrTab[0][min_indx_m[q]]][l]);
    FOR (l=G729EV_G729_M/2; l<G729EV_G729_M; l++)
      new_d_data[q*G729EV_G729_M+l] = sub(d_data[min_indx_p[q]*G729EV_G729_M+l], 
                              lspcb2[PtrTab[1][min_indx_m[q]]][l]);
    
    ptr_back[q] = min_indx_p[q];
    best_indx[q] = min_indx_m[q];
#if(WMOPS)
    move16();
    move16();
#endif
  }
}


static void New_ML_search_3(
    Word16 *d_data,    /* (i) : error vector             */
    Word16 *weight,    /* (i) : weighting vector         */
    Word16 *best_indx, /* (o) : best indices             */
    Word16 *ptr_prd,   /* (i) : pointer for backtracking */
    Word16 PtrTab[2][G729EV_G729B_3rdCB_LEN],/* (i) : quantizer table        */
    Word16 MQ,          /* (i) : size of quantizer        */
    Word16 ratio_index)
{
    Word16   m;
    Word16   min_indx_m;
    Word32   sum[G729EV_G729B_3rdCB_LEN];
    Word32   acc0, min;

    min = G729EV_G729_FLT_MAX_G729;
#if(WMOPS)
    move16();
#endif
    
    /* compute the errors */
    FOR(m=0 ; m < MQ ; m++) 
	{
        acc0= (Word32)0;
        New_ML_search_loop(&acc0, ptr_prd[0], weight, d_data, PtrTab[0][m], ratio_index, 0);
        New_ML_search_loop(&acc0, ptr_prd[0], weight, d_data, PtrTab[1][m], ratio_index, G729EV_G729_M/2);
		sum[m] = acc0;	
    }
    
    /* select the candidates */
    FOR (m=0 ; m < MQ ; m++) {
        if (sum[m] < min) {
            min = sum[m];
            min_indx_m = m;
	 #if(WMOPS)
            move16();
            move16();
       #endif
        }
    }
    
    best_indx[0] = min_indx_m;
#if(WMOPS)
    move16();
#endif

    return; 
}
static void Qnt_e_stage3_loop(Word16 *qlsf, Word16 PtrTab_n, Word16 ratio_index, Word16 init_n)
{
	Word16 i, m;
	Word32 tmp32;
	tmp32 = 0;
	m = init_n + G729EV_G729_M/2;
	FOR (i = init_n; i < m; i++)
	{
		tmp32 = L_mac(L_deposit_h(qlsf[i]), ratio_cb2[ratio_index], shl(lspcb2[PtrTab_n][i], 1));
		qlsf[i] = extract_h(L_add(tmp32, (Word32)32768));
	}

}

static void New_ML_search_loop(Word32 *acc0, Word16 ptr_prd_n, Word16 *weight,Word16 *d_data, Word16 PtrTab_n, Word16 ratio_index, Word16 init_n)
{
	Word16 l, m , tmp1, tmp2;
	m = init_n + G729EV_G729_M/2;
	FOR (l = init_n ; l < m ; l++) 
	{
		tmp1 = extract_h(L_shl(L_mult(noise_fg_sum[ptr_prd_n][l], noise_fg_sum[ptr_prd_n][l]), 2));
		tmp1 = mult(tmp1, weight[l]);
		IF(ratio_index < G729EV_G729B_3rdRAT_LEN)
			tmp2 = sub(d_data[l], mult(ratio_cb2[ratio_index], shl(lspcb2[PtrTab_n][l], 1)));
		ELSE	
		    tmp2 = sub(d_data[l], lspcb2[PtrTab_n][l]);	
		*acc0 = L_mac(*acc0, extract_h(L_shl(L_mult(tmp1, tmp2), 3)), tmp2);	    
	}

}
