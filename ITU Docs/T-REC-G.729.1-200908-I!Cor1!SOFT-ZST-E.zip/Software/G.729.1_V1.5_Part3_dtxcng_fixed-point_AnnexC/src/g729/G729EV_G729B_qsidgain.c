/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

/*
   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/

/*
 File : QSIDGAIN.C
*/

/* Quantize SID gain                                      */
#include "G729EV_G729_defines.h"
#include "G729EV_G729B_defines.h"

#include "G729EV_G729B_dtx.h"
#include "G729EV_G729B_tab_dtx.h"

#include "G729EV_MAIN_oper_32b.h"
#include "G729EV_MAIN_dspfunc.h"

#include "G729EV_G729B_tab_dtx.h"

/* Local function */
static Word16 Quant_Energy(Word32 L_x,        /* (i)  : Energy                 */
                           Word16 sh,         /* (i)  : Exponent of the energy */
                           Word16 * enerq,     /* (o)  : quantized energy in dB */
						   Word16  *index2,   /* (o) Q0 : second stage SID gain quantization index */
						   Word16 *enerq2     /* (o) Q2 : second stage quantized energy in dB */
						   );
/*-------------------------------------------------------------------*
* Function  G729EV_Qua_Sidgain_quant_Energy                                 *
*           Quantize the current 10ms frame energy                   *
*--------------------------------------------------------------------*/
void G729EV_Qua_Sidgain_quant_Energy(
    Word16 *enerq,               /* (o) Q0:  first stage decoded energies in dB              */
    Word16 *idx,                 /* (o) Q0:  first stage SID gain quantization index         */
    Word16 *enerq2,              /* (o) Q2 :  second stage decoded energies in dB             */
    Word16 *idx2,                /* (o) Q0 :  second stage SID gain quantization index        */
    Word32 frame_energy,         /* (i) :  frame energy*/
    Word16 sh_frame_energy       /* (i) :  corresponding scaling factors                   */
)
{
	*idx = Quant_Energy(frame_energy,sh_frame_energy, enerq, idx2, enerq2);
	 
}
/*-------------------------------------------------------------------*
 * Function  G729EV_Qua_Sidgain                                             *
 *           ~~~~~~~~~~~                                             *
 *-------------------------------------------------------------------*/
void G729EV_Qua_Sidgain(Word16 * ener,           /* (i) : array of energies                   */
                 Word16 * sh_ener,        /* (i) : corresponding scaling factors       */
                 Word16 nb_ener,          /* (i) : number of energies or               */
                 Word16 * enerq,          /* (o) Q0 : decoded energies in dB              */
                 Word16 * idx,            /* (o) Q0 : SID gain quantization index         */
				 Word16 *enerq2,          /* (o) Q2 : second stage decoded energies in dB       */
                 Word16 *idx2 ,           /* (o) Q0 :  second stage SID gain quantization index  */
                 Word32 *frame_energy,    /* (i) : energy                                    */
                 Word16 *sh_frame_energy  /* (i) :  corresponding scaling factors             */
    )
{
  Word32    L_acc;

  Word16    i;
  Word32    L_x;
  Word16    sh1, temp;
  Word16    hi, lo;

  IF(nb_ener == 0)
  {
    /* Quantize energy saved for frame erasure case                */
    /* L_x = average_ener                                          */
    L_acc = L_deposit_l(*ener);
    L_acc = L_shl(L_acc, *sh_ener); /* >> if *sh_ener < 0 */
    L_Extract(L_acc, &hi, &lo);
    L_x = Mpy_32_16(hi, lo, fact[0]);
    sh1 = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }
  ELSE
  {

    /*
     * Compute weighted average of energies
     * ener[i] = enerR[i] x 2**sh_ener[i]
     * L_x = k[nb_ener] x SUM(i=0->nb_ener-1) enerR[i]
     * with k[nb_ener] =  fact_ener / nb_ener x L_FRAME x nbAcf
     */
    sh1 = sh_ener[0];
#if(WMOPS)
    move16();
#endif
    FOR(i = 1; i < nb_ener; i++)
    {
      if (sh_ener[i] < sh1)
      {
        sh1 = sh_ener[i];
#if(WMOPS)
        move16();
#endif
      }
    }
    sh1 = add(sh1, (Word16) (16 - marg[nb_ener]));
    L_x = (Word32) 0L;
#if(WMOPS)
    move32();
#endif
    FOR(i = 0; i < nb_ener; i++)
    {
      temp = sub(sh1, sh_ener[i]);
      L_acc = L_deposit_l(ener[i]);
      L_acc = L_shl(L_acc, temp);
      L_x = L_add(L_x, L_acc);
    }
    L_Extract(L_x, &hi, &lo);
    L_x = Mpy_32_16(hi, lo, fact[i]);
	/* adjust difference; */
	L_acc = L_shr(Mpy_32_16(hi, lo, Adjust_fact[i-1]), 15);
	L_x = L_add(L_x, L_acc);
  }

	*sh_frame_energy = sh1;
	Norm_shl_r(L_x, sh_frame_energy, frame_energy, &temp);
    *idx = Quant_Energy(L_x, sh1, enerq, idx2, enerq2);	
#if(WMOPS)
    move16();
#endif

  return;
}

/* Local function */

static Word16 Quant_Energy(Word32 L_x,       /* (i)  : Energy                 */
                           Word16 sh,        /* (i)  : Exponent of the energy */
                           Word16 * enerq,   /* (o) Q0 : quantized energy in dB */
						   Word16  *index2,  /* (o) Q0 : second stage SID gain quantization index */
	                       Word16 *enerq2    /* (o) Q2 : second stage quantized energy in dB */
						   )
{

  Word16    exp, frac;
  Word16    e_tmp, temp, index, e_tmp1;

  Log2(L_x, &exp, &frac);
  e_tmp = add(shl(sub(exp, sh), 10), mult_r(frac, 1024)); /* 2^10 x log2(L_x . 2^-sh) */
  /* log2(ener) = 10log10(ener) / K */
  /* K = 10 Log2 / Log10 */

  temp = sub(e_tmp, -2721);     /* -2721 -> -8dB */
  IF(temp <= 0)
  {
    *enerq = (Word16) - 12;
	*enerq2 = (Word16) -48;         /* *enerq2 -> Q2 */
	*index2 = (Word16) 0;
#if(WMOPS)
    move16();
    move16();
    move16();
#endif
    return (0);
  }

  temp = sub(e_tmp, 22111);     /* 22111 -> 65 dB */
  IF(temp > 0)
  {
    *enerq = (Word16) 66;
    *enerq2 = (Word16)264;        /* *enerq2 -> Q2  */
    *index2 = (Word16) 0;
#if(WMOPS)
    move16();
    move16();
    move16();
#endif
    return (31);
  }
  
    e_tmp1=e_tmp;
#if(WMOPS)
      move16();
#endif

  temp = sub(e_tmp, 4762);      /* 4762 -> 14 dB */
  IF (temp <= 0) {
    e_tmp = add(e_tmp, 3401);   /* 10/K[Q10]-> 3401 */
    index = mult(e_tmp, 24);    /* 0.25K[Q5]-> 24 */
    if (sub(index, 1) < 0)
    {
      index = (Word16) 1;
#if(WMOPS)
      move16();
#endif
    }
    *enerq = sub(shl(index, 2), 8);           /* Q0 */
    
    /* 1/k[Q10]-> 340, 2*k[Q5]->193, e_tmp1 -> Q10; */
    e_tmp = sub(e_tmp1, i_mult(*enerq, 340));
    *index2 = add(mult(e_tmp, 193), 4);
	if (*index2 < 0)
    {
		*index2 = (Word16) 0;
#if(WMOPS)
		move16();
#endif
    }
    if (sub(*index2, 7) > 0)
    {
      *index2 = (Word16) 7;
      
#if(WMOPS)
      move16();
#endif      
    }
        
    /* *enerq2-> Q2 */
    *enerq2 = sub(add( shl(*enerq, 2) , shl(*index2, 1)) , 8);       
    return(index);   
    }
  /* 1/k[Q10]-> 340, 0.5*k[Q7]->193, e_tmp1 -> Q10; */
  index = sub(shr(mult(sub(e_tmp, 340), 193), 2), 1);
  if (sub(index, 6) < 0)
  {
    index = (Word16) 6;
#if(WMOPS)
    move16();
#endif
  }
  
  *enerq = add(shl(index, 1), 4);
  temp = sub(e_tmp1, 5443);         /* 5443 -> 16 dB */
  IF(temp <= 0)
  {
     /* 1/k[Q10]-> 340, 2*k[Q5]->193, e_tmp1 -> Q10, 0.25/k[Q10]-> 85; */
   	 e_tmp = add(sub(e_tmp1, i_mult(*enerq, 340)), 85);
	 *index2 = add(mult(e_tmp, 193), 4);
	 /* *enerq2-> Q2;*/
	 *enerq2 = sub(add( shl(*enerq, 2) , shl(*index2, 1)) , 8); 
  }
  ELSE
  {
    /* 1/k[Q10]-> 340, 4*k[Q5]->385, e_tmp1 -> Q10, 0.125/k[Q10]-> 43; */
    e_tmp = add(sub(e_tmp1, i_mult(*enerq, 340)), 43);
    *index2 = add(mult(e_tmp, 385), 4);
    if (sub(*index2, 7) > 0)
	{
		*index2 = (Word16) 7;
#if(WMOPS)
		move16();
#endif
	}
	/* *enerq2-> Q2;*/
	*enerq2 = sub(add(shl(*enerq, 2), *index2), 4); 
  }
  return (index);  
}
