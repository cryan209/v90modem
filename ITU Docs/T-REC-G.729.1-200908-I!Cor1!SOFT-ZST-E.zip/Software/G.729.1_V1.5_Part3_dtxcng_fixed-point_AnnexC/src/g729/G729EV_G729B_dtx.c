/*  ITU-T G.729.1 Annex - Reference C code for floating-point implementation  */
/*  Version :  1.1                                                            */
/*  Revision Date : Aug 6, 2007                                             */

/* -------------------------------  Copyright ---------------------------------
  
 AUTHORS      :    

 ----------------------------------------------------------------------------*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

/*
   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                          Version 2.1 of October 1999
*/


/* DTX and Comfort Noise Generator - Encoder part */
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729B_dtx.h"
#include "G729EV_G729B_enc_sid.h"
#include "G729EV_G729B_tab_dtx.h"

#include "G729EV_MAIN_oper_32b.h"	
#include "G729EV_MAIN_dspfunc.h"	
#include "G729EV_G729EVDTX_sp2no_trans.h"
/* Local functions */
static void calc_pastfilt(Word16 *sumAcf, Word16 *sh_sumAcf, Word16 *Coeff, Word16 old_A[],  Word16 old_rc[], Word32 *energy, Word16 *sh_energy);
static void calc_RCoeff(Word16 *Coeff, Word16 *RCoeff, Word16 *sh_RCoeff);
static Word16 cmp_filt(Word16 *RCoeff, Word16 sh_RCoeff, Word16 *acf, Word16 sh_acf, Word16 alpha, Word16 sh_alpha, Word16 FracThresh);
static void calc_sum_acf(Word16 *acf, Word16 *sh_acf, Word16 *sum, Word16 *sh_sum, Word16 nb);
static void update_sumAcf(G729EV_G729_CODSTAT * pCodStat);
static Word16 cmp_filt_test(Word16 *RCoeff, Word16 sh_RCoeff, Word16 *acf, Word16 sh_acf, Word16 alpha, Word16 sh_alpha, Word16 FracThresh);
static void calc_mean_acf(Word16 *acf, Word16 *sh_acf, Word16 *mean, Word16 *sh_mean, Word16 nb);
static Word16 cmp_num_sh(Word32 L_num1, Word16 sh_num1, Word32 L_num2, Word16 sh_num2);
static Word16 adjust_level(Word16 *ptr1, Word16 *ptr2, Word16 count, Word32 *L_acc);
static Word16 compute_change_flag(G729EV_G729_CODSTAT * pCodStat, 
						 Word16 *curAcf, Word16 sh_curAcf, Word16 energyq2);
/*----------------------------------------------------------*
* procedure G729EV_cod_cng:                                 *
*           ~~~~~~~~                                        *
*   computes DTX decision                                   *
*   encodes SID frames                                      *
*   computes CNG excitation for encoder update              *
*-----------------------------------------------------------*/
void G729EV_cod_cng(
    G729EV_G729_CODSTAT * pCodStat,
	Word16   ftyp_j,         /* (i) : number of 10 ms frame */
    Word16 *exc,          /* (i/o) : excitation array                     */
    Word16 *Aq,           /* (o)   : set of interpolated LPC coefficients */
    Word16 *ana,            /* (o)   : coded SID parameters                 */
    Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i/o) : previous LPS for quantization        */
	Word16 *SID_tdbwe_parameters,
	Word16 *tdbwe_parameters)
{
    Word16 i, j, tmp_gain, temp16, Hi, Lo;
    Word16 curAcf[G729EV_G729_MP1];
    Word16 zero[G729EV_G729_MP1];
    Word16 bid[G729EV_G729_MP1];
    Word16 curCoeff[G729EV_G729_MP1];
	Word16 lsp_new[G729EV_G729_M], cur_lsf[G729EV_G729_M];
    Word16 *lpcCoeff;
    Word16 cur_igain, cur_igain2, energyq, energyq2;
    Word16 dist, Frame_Rate, delt1, delt2, delt;			
    Word16 SuperFrameCurAcfMove[G729EV_G729_MP1];
    Word16 sh_SuperFrameCurAcfMove, sh_curAcf;
    Word32 SuperFrameEnerMove;                         // smoothed energy parameters
    Word16 sh_SuperFrameEnerMove;
    Word32 L_acc;
	Word16 change_flag = 0;

	G729EV_G729_Set_zero(exc, G729EV_MAIN_L_FRAME4);

    /* Update Ener */
    FOR(i = NB_GAIN-1; i>=1; i--)
	{
        pCodStat->ener[i] = pCodStat->ener[i-1];
    	pCodStat->sh_ener[i] = pCodStat->sh_ener[i-1];
#if(WMOPS)
  move16();
  move16();
#endif
    }
    
    G729EV_G729_Set_zero(zero, G729EV_G729_MP1);
    /* Compute current Acfs */
	calc_mean_acf(pCodStat->Acf, pCodStat->sh_Acf, curAcf, &sh_curAcf, NB_CURACF);
	pCodStat->sh_ener[0] = sh_curAcf;
    /* Compute LPC coefficients and residual energy */
    IF(curAcf[0] == 0)
	{
        pCodStat->ener[0] = (Word16)0;     /* should not happen */
		pCodStat->sh_ener[0] = sh_curAcf = 0;
#if(WMOPS)
  move16();
  move16();
  move16();
#endif
    }
    ELSE {
        pCodStat->ener[0] = G729EV_G729_Levinson(curAcf, zero, curCoeff, bid, pCodStat->old_A, pCodStat->old_rc);
		
		G729EV_linear_compose(&pCodStat->ener[0], &pCodStat->sh_ener[0], &pCodStat->energy_lt, &pCodStat->sh_energy_lt, 29491, 3277);
		pCodStat->ener[0] = pCodStat->energy_lt;

#if(WMOPS)
  move16();
#endif
    }

	IF(ftyp_j == 0) // 1st 10ms frame
	{
		G729EV_G729_Copy(curAcf, &pCodStat->SuperFrame_CurAcf[0][0], G729EV_G729_MP1);   
		pCodStat->sh_SuperFrame_CurAcf[0] = sh_curAcf;
	}
	ELSE            //2nd 10ms frame
	{
		G729EV_G729_Copy(curAcf, &pCodStat->SuperFrame_CurAcf[1][0], G729EV_G729_MP1);   
		pCodStat->sh_SuperFrame_CurAcf[1] = sh_curAcf;
	}
#if(WMOPS)
  move16();
#endif

#if(WMOPS)
  test();
#endif
    /* if first frame of silence => SID frame */
    IF((pCodStat->pastVad != 0)||(pCodStat->ppastVad != 0))
	{
		IF(ftyp_j == 0)
		{
			ana[0] = 0;
			pCodStat->nb_ener = 1;
		}
		ELSE
		{
			ana[0] = 1;              
			pCodStat->count_fr0 = 0;
			pCodStat->nb_ener=add(pCodStat->nb_ener, 1);
		}
#if(WMOPS)
  move16();
  move16();
#endif
    }
    ELSE
	{			
		pCodStat->nb_ener = add(pCodStat->nb_ener, 1);
		if(sub(pCodStat->nb_ener, NB_GAIN)> 0) 	pCodStat->nb_ener = NB_GAIN;

		IF(ftyp_j == 0)
		{    
			ana[0] = 0;
#if(WMOPS)
	move16();
#endif
			G729EV_Qua_Sidgain(pCodStat->ener, pCodStat->sh_ener,pCodStat->nb_ener, &energyq, &cur_igain, &energyq2, &cur_igain2,&pCodStat->SuperFrame_Ener[0], &pCodStat->sh_SuperFrame_Ener[0]);
			/* quantize the energy and buffer 1st ms frame energy */

			/* 1st 10ms frame DTX */
			pCodStat->Nb_First_change_flag = compute_change_flag(pCodStat, 
						curAcf, sh_curAcf, energyq2);
		}
		ELSE
		{
			G729EV_Qua_Sidgain(pCodStat->ener, pCodStat->sh_ener, pCodStat->nb_ener, &energyq, &cur_igain, &energyq2, &cur_igain2,&pCodStat->SuperFrame_Ener[1],&pCodStat->sh_SuperFrame_Ener[1]);
			/* quantize the energy parameter and buffer the 2nd frame energy */

			/* 2nd 10ms frame DTX */
			pCodStat->Nb_Second_change_flag = compute_change_flag(pCodStat, 
						curAcf, sh_curAcf, energyq2);

#if(WMOPS)
  test();
#endif
            /* weight the two frame paramgerss*/
            IF((sub(pCodStat->Nb_Second_change_flag ,1)==0)&&(pCodStat->Nb_First_change_flag==0))
				Frame_Rate = 3277;  /* Frame_Rate = 0.1; Q15 */
			ELSE
				Frame_Rate = 16384; /* Frame_Rate = 0.5; Q15 */

			/* SuperFrameEnerMove = pCodStat->SuperFrame_Ener[0]*Frame_Rate + pCodStat->SuperFrame_Ener[1]*(1-Frame_Rate); */
			{Word16 Frame_Rate2;
			 Word32 tmp32, acc32;

		     Frame_Rate2=(Word16)L_sub(32768L, Frame_Rate);
			 temp16 = pCodStat->sh_SuperFrame_Ener[0];
			 if(sub(pCodStat->sh_SuperFrame_Ener[1], temp16)<0) 
				 temp16 = pCodStat->sh_SuperFrame_Ener[1];
			 tmp32=L_shr(pCodStat->SuperFrame_Ener[0], sub(pCodStat->sh_SuperFrame_Ener[0], temp16));
			 acc32=L_shr(pCodStat->SuperFrame_Ener[1], sub(pCodStat->sh_SuperFrame_Ener[1], temp16));

			 L_Extract(tmp32, &Hi, &Lo);
			 SuperFrameEnerMove = Mpy_32_16(Hi, Lo, Frame_Rate);			 
			 L_Extract(acc32, &Hi, &Lo);
			 SuperFrameEnerMove = L_add(SuperFrameEnerMove, Mpy_32_16(Hi, Lo, Frame_Rate2));
			 sh_SuperFrameEnerMove = temp16;
			 Norm_shl_r(SuperFrameEnerMove, &sh_SuperFrameEnerMove, &SuperFrameEnerMove, &Frame_Rate2);
			}
			/*Must be in same scaling,so does just scaling.*/
			
			G729EV_Qua_Sidgain_quant_Energy(&energyq, &cur_igain, &energyq2, &cur_igain2, SuperFrameEnerMove, sh_SuperFrameEnerMove);

			{Word16 Frame_Rate2;

			 Frame_Rate2=(Word16)L_sub(32768L, Frame_Rate);
		     temp16 = pCodStat->sh_SuperFrame_CurAcf[0];
			 if(sub(pCodStat->sh_SuperFrame_CurAcf[1], temp16)<0) 
				 temp16=pCodStat->sh_SuperFrame_CurAcf[1];			 
             sh_SuperFrameCurAcfMove = temp16;
 			 FOR(i=0;i<G729EV_G729_MP1;i++)
			 {
                /* Frame_Rate -> Q15 */
				L_acc = L_mult(shr(pCodStat->SuperFrame_CurAcf[0][i], sub(pCodStat->sh_SuperFrame_CurAcf[0], temp16)), Frame_Rate);
				L_acc = L_mac(L_acc, shr(pCodStat->SuperFrame_CurAcf[1][i], sub(pCodStat->sh_SuperFrame_CurAcf[1], temp16)), Frame_Rate2);
				SuperFrameCurAcfMove[i] = round(L_acc);
			 }
			 temp16 = norm_s(SuperFrameCurAcfMove[0]);
			 FOR(i=0;i<G729EV_G729_MP1;i++)
				SuperFrameCurAcfMove[i] = shl(SuperFrameCurAcfMove[i], temp16);
			 sh_SuperFrameCurAcfMove=add(sh_SuperFrameCurAcfMove, temp16);
			}
            G729EV_G729_Levinson(SuperFrameCurAcfMove, zero, curCoeff, bid, pCodStat->old_A, pCodStat->old_rc); 

			/* combined NB-DTX with WB-DTX */
			change_flag = (pCodStat->Nb_Second_change_flag||pCodStat->Nb_First_change_flag);
			pCodStat->flag_chang_wb = add(pCodStat->flag_chang_wb, change_flag);

			/* too weak WB components should be neglected */
			/*//0.00390625 -->Q10,SID_tdbwe_parameters[],tdbwe_parameters[] ->Q10 */
#if(WMOPS)
  test();
#endif
			IF((sub(pCodStat->flag_chang_wb, 1) == 0) && (sub(tdbwe_parameters[0], 4) > 0))
			{
				delt1 = mult(abs_s(sub(SID_tdbwe_parameters[0], tdbwe_parameters[0])), G729EV_TDBWE_THR_TD_INV);    /* delt1 -> Q10 */ 
				delt2=0;
				FOR(i = 0; i < 12; i ++)	
                {   /*delt2 += fabs(SID_tdbwe_parameters[i+1] - tdbwe_parameters[i+16])/G729EV_TDBWE_THR_SD; */
					temp16 = abs_s(sub(SID_tdbwe_parameters[i+1], tdbwe_parameters[i+16]));
					delt2 = add(delt2, mult(temp16, G729EV_TDBWE_THR_TD_INV)); /* delt2 -> Q10 */
				}				
				
				delt = round(L_add(L_mult(delt1, 13107), L_mult(delt2, 19661))); /* Q10 */
				
				delt1 = cmp_filt_test(pCodStat->RCoeff, pCodStat->sh_RCoeff, SuperFrameCurAcfMove, sh_SuperFrameCurAcfMove, pCodStat->ener[0], pCodStat->sh_ener[0], FRAC_THRESH1); //delt1 Q10
				
				delt2 = (Word16)L_shr(L_shl(L_mult(abs_s(sub(pCodStat->prev_energy, energyq2)), 21845), 7), 16);       /* Q10 */
                delt = round(L_mac(L_mac(L_mult(delt, 8192), delt1, 14746), delt2, 9830)); 			/* Q10 */
				/* if(delt < 1) */
				if(sub(delt, 1024) < 0)	pCodStat->flag_chang_wb = 0;
			}

			/* update SID_tdbwe_parameters */
			IF(pCodStat->flag_chang_wb)
			{
				FOR(i = 0; i < 13; i ++)
					SID_tdbwe_parameters[i] = tdbwe_parameters[add(i,15)];
			}
			
			pCodStat->count_fr0 = add(pCodStat->count_fr0, 1);
			IF(sub(pCodStat->count_fr0,  FR_SID_MIN) < 0) {
				ana[0] = 0;       /* no transmission   */
			}
			ELSE {
				IF((pCodStat->flag_chang_wb) != 0) ana[0] = 1;  /* transmit SID frame */
				ELSE  ana[0] = 0;
#if(WMOPS)
  test();
#endif
				if((sub(pCodStat->count_fr0, pCodStat->dtx_max_fr) > 0) && (pCodStat->dtx_max_fr != 0))
					ana[0] = 1;             /* transmit SID frame */
			}
		}
    }
    IF(ana[0] == 1) {
		ana = ana - G729EV_G729_PRM_SIZE_MAX;
		ana[0] = 1;

		ana[G729EV_G729_PRM_SIZE_MAX] = 0;
		pCodStat->counter_n = pCodStat->counter_k;
		pCodStat->counter_k = 0;
		pCodStat->flag_chang_wb = 0;
		L_acc = L_mult(pCodStat->counter_n_lt, 31130);
		pCodStat->counter_n_lt = round(L_mac(L_acc, pCodStat->counter_n, 1638));

        /* Reset frame count and change flag */
        pCodStat->count_fr0 = 0;
        
		  IF(pCodStat->ppastVad != 0) {
            update_sumAcf(pCodStat);
            calc_pastfilt(pCodStat->sumAcf, pCodStat->sh_sumAcf, pCodStat->pastCoeff, pCodStat->old_A, pCodStat->old_rc, &SuperFrameEnerMove, &sh_SuperFrameEnerMove);
			calc_RCoeff(pCodStat->pastCoeff, pCodStat->RCoeff, &pCodStat->sh_RCoeff);
            lpcCoeff = pCodStat->pastCoeff;
			{Word16 tmp, tmp16;
			 Word32 tmp32;
			
			tmp=add(pCodStat->sh_energy_lt, 16);
			L_Extract(SuperFrameEnerMove, &Hi, &Lo);
			SuperFrameEnerMove = Mpy_32_16(Hi, Lo, 3277);

			tmp16=tmp;
#if(WMOPS)
  move16();
#endif
			if(sub(sh_SuperFrameEnerMove, tmp16)<0) 
			{
				tmp16=sh_SuperFrameEnerMove;
#if(WMOPS)
  move16();
#endif
			}
			tmp32=L_shr(L_mult(pCodStat->energy_lt, 29491), sub(tmp, tmp16));
			tmp32=L_add(tmp32, L_shr(SuperFrameEnerMove, sub(sh_SuperFrameEnerMove, tmp16)));
			sh_SuperFrameEnerMove=tmp16;

			Norm_shl_r(tmp32, &sh_SuperFrameEnerMove, &SuperFrameEnerMove, &tmp16);
			pCodStat->energy_lt=(Word16)L_shr(SuperFrameEnerMove, 16);
			pCodStat->sh_energy_lt=sub(sh_SuperFrameEnerMove, 16);
			}
			L_Extract(SuperFrameEnerMove, &Hi, &Lo);
			SuperFrameEnerMove = Mpy_32_16(Hi, Lo, shl(fact[1], 9));
			sh_SuperFrameEnerMove=add(sh_SuperFrameEnerMove, 9);
			G729EV_Qua_Sidgain_quant_Energy(&energyq, &cur_igain, &energyq2, &cur_igain2, SuperFrameEnerMove, sh_SuperFrameEnerMove);
		  }                                                                     
		  ELSE {
			  /* Compute past average filter */
			  calc_pastfilt(pCodStat->sumAcf, pCodStat->sh_sumAcf, pCodStat->pastCoeff, pCodStat->old_A, pCodStat->old_rc, &SuperFrameEnerMove, &sh_SuperFrameEnerMove);
			  calc_RCoeff(pCodStat->pastCoeff, pCodStat->RCoeff, &pCodStat->sh_RCoeff);
			  
			  /* Compute stationarity of current filter   */
			  /* versus past average filter               */
			  
			  /* if stationary */
			  /* transmit average filter => new ref. filter */
			  IF(cmp_filt(pCodStat->RCoeff, pCodStat->sh_RCoeff, curAcf, sh_curAcf, pCodStat->ener[0], pCodStat->sh_ener[0], FRAC_THRESH2) == 0)
				  lpcCoeff = pCodStat->pastCoeff;
			  /* transmit current filter => new ref. filter */
			  ELSE {
				  lpcCoeff = curCoeff;
				  calc_RCoeff(curCoeff, pCodStat->RCoeff, &pCodStat->sh_RCoeff);
			  }
#if(WMOPS)
  move16();
#endif
		  }                                                                     
        
        /* Compute SID frame codes */
        G729EV_G729_Az_lsp(lpcCoeff, lsp_new, pCodStat->lsp_old_q); /* From A(z) to lsp */
        
        /* LSP quantization */
        lsfq_noise(noise_fg, lsp_new, pCodStat->sid_lsp, freq_prev, &ana[1],cur_igain);
        
        pCodStat->prev_energy = energyq2;

        ana[4] = cur_igain;    /* first stage SID gain quantization index */
        pCodStat->sid_gain = tab_Sidgain[cur_igain];

		{
			ana[6] = cur_igain2;      /* second stage SID gain quantization index */
			IF(sub(cur_igain, 6) < 0)
				pCodStat->sid_gain = round(L_shl(L_mult(pCodStat->sid_gain, tab_Sidgain2[cur_igain2]), 1)); /* tab_Sidgain2[cur_igain2] in Q14 */
			ELSE
				pCodStat->sid_gain = round(L_shl(L_mult(pCodStat->sid_gain, tab_Sidgain3[cur_igain2]), 1)); /* tab_Sidgain2[cur_igain2] in Q14 */	
		}
    } /* end of SID frame case */

	/* generate energe and Az of nodata frame   */
	/* D  = (Psid - Pk-1)/(|k-N|+1)             */
    /* Pk = Pk-1+D+rand(-D/2,D/2)               */
	/* P0 = Psid_old                            */
	{
		Word16 temp16, ind, dist_lsp;
		ind = extract_h(Inv_x((Word32)add(abs_s(sub(pCodStat->counter_k, pCodStat->counter_n)), 1)));
		dist = mult_r(sub(pCodStat->sid_gain, pCodStat->pre_gain), ind);            /* dist -> Q2 */
		pCodStat->pre_gain = add(pCodStat->pre_gain, dist);
		
		FOR(i = 0; i < G729EV_G729_M; i++)
		{
			dist_lsp = mult_r(sub(pCodStat->sid_lsp[i], pCodStat->pre_lsp[i]), ind);   /* Q15 */
			temp16 = shr(mult_r(G729EV_G729_Random(&pCodStat->seed2), dist_lsp), 1);
			pCodStat->pre_lsp[i] =add(add(pCodStat->pre_lsp[i], dist_lsp), temp16);
		}
	}
#if(WMOPS)
  test();
#endif
    IF((pCodStat->pastVad != 0)&&(pCodStat->ppastVad != 0)) 
	{
		/*calculate the spectrum and energy*/
		G729EV_G729_Copy(pCodStat->lsp_mean, pCodStat->pre_lsp, G729EV_G729_M);  
		pCodStat->counter_k = 2*DTX_HANG_CONST-1;
		pCodStat->pre_gain = round(L_mult(pCodStat->Gf_gain_mean, (Word16)26214));
		/* 26214(Q15) <=> 0.4 */
		/* pCodStat->Gf_gain_mean in Q1 */
		/* pCodStat->cur_gain in Q2 */
	}
	/* check the stabilty */
	G729EV_G729_Lsp_lsf2(pCodStat->pre_lsp ,cur_lsf, G729EV_G729_M); /* pCodStat->cur_lsp in Q15, cur_lsf in Q13*/
	G729EV_G729_Lsp_expand_1_2(cur_lsf, G729EV_G729_GAP1);
    G729EV_G729_Lsp_expand_1_2(cur_lsf, G729EV_G729_GAP2);
    G729EV_G729_Lsp_stability(cur_lsf);
	G729EV_G729_Lsf_lsp2(cur_lsf ,pCodStat->pre_lsp, G729EV_G729_M); /* cur_lsf in Q13, pCodStat->cur_lsp in Q15*/

    
    /* Compute new excitation */
	IF(sub(pCodStat->counter_n_lt, 40) > 0)
	{
		Word16 ind;
		temp16 = mult(30720, shl(pCodStat->VAD_flag_change_counter_move, 4));		/*temp16 in Q0, pCodStat->VAD_flag_change_counter_move in Q1*/
		ind = add(add(temp16,  ATTENUATION_CONST), pCodStat->counter_n);			/* ind -> Q0  */
		L_Extract(L_shr(Inv_x(L_deposit_l(ind)), 1), &Hi, &Lo);
		temp16 = mult(extract_l(Mpy_32_16(Hi, Lo, add(temp16, pCodStat->gain_change_hangover))), 3277);					/* temp16[Q15] < 1 */						
		tmp_gain = mult_r(pCodStat->pre_gain, add(29491,temp16)); /* tmp_gain -> Q2 */
	}
	ELSE
		tmp_gain = pCodStat->pre_gain;

	{
		Word16 i_subfr_cnt, lp_gainp, lp_gainc, tilt_code;
		G729EV_calc_exc_rand(tmp_gain, exc, &(pCodStat->seed), FLAG_COD, pCodStat->L_exc_err,
		pCodStat->pastVad, &(pCodStat->old_pitch), &(pCodStat->old_gp), &(pCodStat->pre_gain), 
		&i_subfr_cnt, &lp_gainp, &lp_gainc, &tilt_code);
	}
#if(WMOPS)
  test();
#endif
    IF((pCodStat->pastVad != 0)&&(pCodStat->ppastVad != 0)) 
	{
		pCodStat->sid_gain = pCodStat->pre_gain;
		G729EV_G729_Copy(pCodStat->pre_lsp, pCodStat->sid_lsp, G729EV_G729_M);  
	}
    
    G729EV_G729_Int_qlpc(pCodStat->lsp_old_q, pCodStat->pre_lsp, Aq);
    G729EV_G729_Copy(pCodStat->pre_lsp, pCodStat->lsp_old_q, G729EV_G729_M);
    
    /* Update sumAcf if fr_cur = 0 */
    IF((pCodStat->fr_cur == 0) && (sub(pCodStat->pastVad, 2) != 0)) {
        update_sumAcf(pCodStat);
    }

    (pCodStat->counter_k) ++;
	IF(sub(ftyp_j, 1) == 0) 
	{
		pCodStat->Nb_First_change_flag = (Word16)0;
		pCodStat->Nb_Second_change_flag = (Word16)0;

		FOR(i = 0; i < 2; i++)
			FOR(j = 0; j < G729EV_G729_MP1; j++)
				pCodStat->SuperFrame_CurAcf[i][j] = (Word16)0;
	}

    return;
}

/*----------------------------------------------------------*
* procedure G729EV_update_cng:                              *
*           ~~~~~~~~~~                                      *
*   updates autocorrelation arrays                          *
*   used for DTX/CNG                                        *
*   If Vad=1 : updating of array pCodStat->sumAcf           *
*-----------------------------------------------------------*/
void G729EV_update_cng(
    G729EV_G729_CODSTAT * pCodStat,
    Word16 *r_h,      /* (i) :   MSB of frame autocorrelation        */
    Word16 exp_r,     /* (i) :   scaling factor associated           */
    Word16 Vad        /* (i) :   current Vad decision                */
)
{
    Word16 i;
    Word16 *ptr1, *ptr2;
    
    /* Update Acf */
    ptr1 = pCodStat->Acf + SIZ_ACF - 1;
    ptr2 = ptr1 - G729EV_G729_MP1;
    FOR(i=0; i<(SIZ_ACF-G729EV_G729_MP1); i++) 
		*ptr1-- = *ptr2--;
    FOR(i=NB_CURACF-1; i>=1; i--) 
		pCodStat->sh_Acf[i] = pCodStat->sh_Acf[i-1];
    /* Save current Acf */
    pCodStat->sh_Acf[0] = negate(add(16, exp_r));
    FOR(i=0; i<G729EV_G729_MP1; i++) 
		pCodStat->Acf[i] = r_h[i];

    pCodStat->fr_cur = add(pCodStat->fr_cur, 1);
    IF(sub(pCodStat->fr_cur, NB_ACCACF) == 0) {
        pCodStat->fr_cur = 0;
        IF(Vad != 0)  update_sumAcf(pCodStat);
    }
    
    return;
}


/*-----------------------------------------------------------*
*         Local procedures                                  *
*         ~~~~~~~~~~~~~~~~                                  *
*-----------------------------------------------------------*/

/* Compute autocorr of LPC coefficients used for Itakura distance */
/******************************************************************/
static void calc_RCoeff(Word16 *Coeff, Word16 *RCoeff, Word16 *sh_RCoeff)
{
  Word16 i, j;
  Word16 sh1, sh;
  Word32 L_acc;

  sh = adjust_level(Coeff, Coeff, G729EV_G729_M, &L_acc);
  
  /* Compute exponent RCoeff */
  sh1 = norm_l(L_acc);
  RCoeff[0] = round(L_shl(L_acc, sub(sh1, 1)));
   
  FOR(i=1; i<=G729EV_G729_M; i++) {
    L_acc = 0L;
    FOR(j=0; j<=G729EV_G729_M-i; j++) 
		L_acc = L_mac(L_acc, Coeff[j], Coeff[j+i]);
    RCoeff[i] = round(L_shl(L_acc, sh1));
  }
  *sh_RCoeff = sub(sh1, shl(sh, 1));
  *sh_RCoeff = add(*sh_RCoeff, 8);
  return;
}

/* Compute Itakura distance and compare to threshold */
/*****************************************************/
static Word16 cmp_filt(Word16 *RCoeff, Word16 sh_RCoeff, Word16 *acf, Word16 sh_acf, 
                              Word16 alpha, Word16 sh_alpha, Word16 FracThresh)
{
  Word32 L_temp0, L_temp1;
  Word16 temp1, sh, sh2, diff;

  sh = adjust_level(RCoeff, acf, G729EV_G729_M, &L_temp0);

  sh = add(sh_acf, add(sub(sh_RCoeff, add(sh, sh)), 1));  
  
  L_temp1 = L_mult(alpha, FracThresh);  //FracThresh  Q14
  sh2 = add(sh_alpha, 15);

  temp1=sh;
  if(sub(sh2, temp1)<0)  temp1=sh2;

  L_temp0=L_shr(L_temp0, sub(sh, temp1));
  L_temp1=L_shr(L_temp1, sub(sh2, temp1));

  IF(L_sub(L_temp0, L_temp1) > 0L) diff = 1;
  ELSE                             diff = 0;

  return(diff);
}

static Word16 cmp_filt_test(Word16 *RCoeff, Word16 sh_RCoeff, Word16 *acf, Word16 sh_acf, 
                                        Word16 alpha, Word16 sh_alpha, Word16 FracThresh)
{
    Word32 L_temp0, L_temp2;
    Word16 temp1, temp2, sh, sh1;
    Word16 hi, lo, hi2, lo2;//i, 
	
	sh = adjust_level(RCoeff, acf, G729EV_G729_M, &L_temp0);

	sh = add(sh_acf, add(sub(sh_RCoeff, add(sh, sh)), 1));
  
    /*(alpha*THRESH1);*/
	L_temp2 = Inv_x(mult(alpha, FracThresh));
	sh1=sub(31, sub(sh_alpha, 1));

	Norm_shl_r(L_temp2, &sh1, &L_temp2, &temp2);

    L_Extract(L_temp2, &hi2, &lo2);
	L_Extract(L_temp0, &hi, &lo);

	L_temp2 = Mpy_32(hi, lo, hi2, lo2);
	sh1=add(sh, sh1);
	sh1=sub(sh1, 31);

	Norm_shl_r(L_temp2, &sh1, &L_temp2, &temp2);
	temp1=(Word16)L_shr(L_temp2, sub(sh1, 10));

    return(temp1);
}
/* Compute past average filter */
/*******************************/
static void calc_pastfilt(Word16 *sumAcf, Word16 *sh_sumAcf, Word16 *Coeff, Word16 old_A[],  Word16 old_rc[], Word32 *energy, Word16 *sh_energy)
{
	Word16 i, temp, sh;
	Word32 s_sumAcf[G729EV_G729_MP1];
	Word16 s_sumAcf_hi[G729EV_G729_MP1], s_sumAcf_lo[G729EV_G729_MP1];
	Word16 bid[G729EV_G729_M];

    calc_sum_acf(sumAcf, sh_sumAcf, s_sumAcf_lo, &temp, NB_SUMACF);
    
	IF(s_sumAcf_lo[0] == 0L) {
    Coeff[0] = 4096; /*Q12*/
    FOR(i=1; i<=G729EV_G729_M; i++) Coeff[i] = 0;
    return;
	}

	FOR(i = 0; i < G729EV_G729_MP1; i ++)
		s_sumAcf[i] = L_mult(s_sumAcf_lo[i], (Word16)3277);
	
	sh = norm_l(s_sumAcf[0]);
	FOR(i = 0; i < G729EV_G729_MP1; i ++)
	{
		s_sumAcf[i] = L_shl(s_sumAcf[i], sh);
		L_Extract(s_sumAcf[i], &s_sumAcf_hi[i], &s_sumAcf_lo[i]);
	}

    *energy = L_deposit_h(G729EV_G729_Levinson(s_sumAcf_hi, s_sumAcf_lo, Coeff, bid, old_A, old_rc));
	*sh_energy = add(add(temp, 16), sh);
	Norm_shl_r(*energy, sh_energy, energy, &sh);
    return;
}

/* Update sumAcf */
/*****************/
static void update_sumAcf(G729EV_G729_CODSTAT * pCodStat)
{
    Word16 *ptr1, *ptr2;
    Word16 i;
    
    /*** Move sumAcf ***/
    ptr1 = pCodStat->sumAcf + SIZ_SUMACF - 1;
    ptr2 = ptr1 - G729EV_G729_MP1;
#if(WMOPS)
  move16();
  move16();
#endif
    FOR(i=0; i<(SIZ_SUMACF-G729EV_G729_MP1); i++) 
        *ptr1-- = *ptr2--;
	FOR(i=NB_SUMACF-1; i>=1; i--) 
		pCodStat->sh_sumAcf[i] = pCodStat->sh_sumAcf[i-1];
    /* Compute new sumAcf */
    calc_sum_acf(pCodStat->Acf, pCodStat->sh_Acf, pCodStat->sumAcf, pCodStat->sh_sumAcf, NB_ACCACF);
    return;
}

/* Compute sum of acfs (curAcf, sumAcf or s_sumAcf) */
/****************************************************/
static void calc_sum_acf(Word16 *acf, Word16 *sh_acf,
                         Word16 *sum, Word16 *sh_sum, Word16 nb)
{

  Word16 *ptr1;
  Word32 L_temp, L_tab[G729EV_G729_MP1];
  Word16 sh0, temp;
  Word16 i, j;
  
  /* Compute sum = sum of nb acfs */
  /* Find sh_acf minimum */
  sh0 = sh_acf[0];
  FOR(i=1; i<nb; i++) {
    if(sub(sh_acf[i], sh0) < 0) 
		sh0 = sh_acf[i];
  }

  sh0 = add(sh0, add(norm_s(sub(nb, 1)), 1));           /* 2 bits of margin */

  FOR(j=0; j<G729EV_G729_MP1; j++) 
	  L_tab[j] = 0L;
  ptr1 = acf;
  FOR(i=0; i<nb; i++) {
    temp = sub(sh0, sh_acf[i]);
    FOR(j=0; j<G729EV_G729_MP1; j++) {
      L_temp = L_shl(L_deposit_l(*ptr1++), temp); /* shift right if temp<0 */
      L_tab[j] = L_add(L_tab[j], L_temp);
    }
  } 
  temp = norm_l(L_tab[0]);
  FOR(i = 0; i < G729EV_G729_MP1; i++)
	  sum[i] = extract_h(L_shl(L_tab[i], temp));
  *sh_sum = add(sh0, sub(temp, 16));
  return;
}

/* static void calc_mean_acf(REAL *acf, REAL *mean, int nb) */
static void calc_mean_acf(Word16 *acf, Word16 *sh_acf,
                         Word16 *mean, Word16 *sh_mean, Word16 nb)
{                                                       
    Word16 *ptr1;
    Word16 i, j, sh0, temp;
    Word32 L_temp, L_tab[G729EV_G729_MP1];
    Word32 norm[NB_CURACF];
	Word16 sh_norm[NB_CURACF];
    Word16 idx[NB_CURACF];
                                                       
    ptr1 = acf;                                         
	FOR(i = 0; i < NB_CURACF; i++)                        
	{                                                   
		sh0 = adjust_level(&acf[i*G729EV_G729_MP1], &acf[i*G729EV_G729_MP1], G729EV_G729_M, &norm[i]);
		sh_norm[i] = sub(sh_acf[i], sh0) *2;
	}                                                   
	FOR (i = 0; i < NB_CURACF; i++)
		idx[i] = i;
	
	FOR ( i = 0; i < NB_CURACF; i ++)
	{
		if (cmp_num_sh(norm[idx[0]], sh_norm[idx[0]], norm[idx[i]], sh_norm[idx[i]]) < 0)
		{
			temp = idx[0];
			idx[0] = idx[i];
			idx[i] = temp;
		}
		if (cmp_num_sh(norm[idx[3]], sh_norm[idx[3]], norm[idx[i]], sh_norm[idx[i]]) > 0)
		{
			temp = idx[3];
			idx[3] = idx[i];
			idx[i] = temp;
		}
	}
  
	sh0 = sh_acf[idx[1]];
	if(sub(sh_acf[idx[2]], sh0) < 0) 
		sh0 = sh_acf[idx[2]];
	sh0 = add(sh0, 14);           /* 2 bits of margin */

	FOR(j=0; j<G729EV_G729_MP1; j++) 
		L_tab[j] = 0L;
	
	FOR(i=0; i<2; i++) {
		temp = sub(sh0, sh_acf[idx[i+1]]);
		ptr1 = acf + i_mult(idx[i+1], G729EV_G729_MP1); 
		FOR(j=0; j<G729EV_G729_MP1; j++) {
			L_temp = L_deposit_l(*ptr1++);
			L_temp = L_shl(L_temp, temp); /* shift right if temp<0 */
			L_tab[j] = L_add(L_tab[j], L_temp);
		}
	} 
	temp = norm_l(L_tab[0]);
	FOR(i = 0; i < G729EV_G729_MP1; i++) {
		mean[i] = extract_h(L_shl(L_tab[i], temp));
	}
	*sh_mean = add(add(sh0, sub(temp, 16)), 1);
	return;                                             
}                            

/* Compare two positive numbers (in Word32) with shift sh  */
static Word16 cmp_num_sh(Word32 L_num1, Word16 sh_num1, Word32 L_num2, Word16 sh_num2)
{
	Word16 sh1=sh_num1,sh2=sh_num2;
	Word32 L_tmp1,L_tmp2;	
	Word16 tmp;
	
	Norm_shl_r(L_num1, &sh1, &L_tmp1, &tmp);
	
	Norm_shl_r(L_num2, &sh2, &L_tmp2, &tmp);
	
	IF (sub(sh1, sh2) < 0) /* L_num1 > L_num2 */
		return 1;
	ELSE IF (sub(sh1, sh2) >0) /* L_num1 < L_num2 */
		return -1;
	ELSE	/* sh1 == sh2 */
	{
		IF (L_sub(L_tmp1, L_tmp2) < 0)
			return -1;
		ELSE IF (L_sub(L_tmp1, L_tmp2) > 0)
			return 1;
		ELSE
			return 0;
	}
	
}                                                   

static Word16 adjust_level(Word16 *ptr1, Word16 *ptr2, Word16 count, Word32 *L_acc)
{
  Word16 i, sh;
  Word16 temp1, temp2;
  extern Flag Overflow;
  
  sh=0;
  DO{
	  Overflow = 0;
#if(WMOPS)
  move16();
#endif
	  *L_acc = 0L;
      FOR(i = 0; i <= count; i++)
	  {
		temp1 = shr(ptr1[i], sh);
        temp2 = temp1;
#if(WMOPS)
  move16();
#endif
		if(ptr1 != ptr2)
			temp2 = shr(ptr2[i], sh);
        *L_acc = L_mac(*L_acc, temp1, temp2);
	  }
	  if(Overflow)
		  sh=add(sh, 1);
  }
  WHILE(Overflow);

  return sh;
}

static Word16 compute_change_flag(G729EV_G729_CODSTAT * pCodStat, 
						 Word16 *curAcf, Word16 sh_curAcf, Word16 energyq2)
{
	Word16 chang_flag=0;
	if(cmp_filt(pCodStat->RCoeff, pCodStat->sh_RCoeff, curAcf, sh_curAcf, pCodStat->ener[0], pCodStat->sh_ener[0], FRAC_THRESH1) != 0) 
	{
#if(WMOPS)
  move16();
#endif
		chang_flag = 1;
	}
	
	/* compute the stationary of energy */
	/* compare energy difference between current frame and last frame */
	/* pCodStat->prev_energy -> Q2 */
	if(sub(abs_s(sub(pCodStat->prev_energy ,energyq2)) , 12) > 0)
	{
#if(WMOPS)
  move16();
#endif
		chang_flag = 1;
	}
	return chang_flag;
}
