/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#ifndef __G729EV_G729_LD8K_H__
#define __G729EV_G729_LD8K_H__

/*--------------------------------------------------------------*
 * LD8K.H                                                       *
 * ~~~~~~                                                       *
 * Function prototypes and constants use in G.729               *
 *                                                              *
 *--------------------------------------------------------------*/

#include <stdio.h>
#include "stl.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729_codstat.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_defines.h"


/*--------------------------------------------------------------------------*
 * LPC analysis and filtering                                               *
 *--------------------------------------------------------------------------*/

void G729EV_G729_AutocorrLPC(Word16 x[],	/* (i)    : Input signal                      */
                             Word16 m,		/* (i)    : LPC order                         */
                             Word16 r_h[],	/* (o)	  : Autocorrelations  (msb)           */
                             Word16 r_l[],	/* (o)	  : Autocorrelations  (lsb)           */
							 Word16 *exp_R0 /* (o)    : right shift count of r[0]               */
    );

void      G729EV_G729_Lag_window(Word16 m,      /* (i)     : LPC order                                  */
                                 Word16 r_h[],  /* (i/o)   : autocorrelations  (msb)                    */
                                 Word16 r_l[]   /* (i/o)   : autocorrelations  (lsb)                    */
    );

Word16      G729EV_G729_Levinson(Word16 Rh[], /* (i)     : Rh[m+1] autocorrelation coefficients (msb) */
                               Word16 Rl[], /* (i)     : Rl[m+1] autocorrelation coefficients (lsb) */
                               Word16 A[],  /* (o) Q12 : A[m]    LPC coefficients  (m = 10)         */
                               Word16 rc[], /* (o) Q15 : rc[M]   Reflection coefficients.           */
                               Word16 old_A[], Word16 old_rc[]);

void      G729EV_G729_Az_lsp(Word16 a[],      /* (i) Q12 : predictor coefficients                     */
                             Word16 lsp[],    /* (o) Q15 : line spectral pairs                        */
                             Word16 old_lsp[] /* (i)     : old lsp[] (in case not found 10 roots)     */
    );

void      G729EV_G729_Lsp_Az(Word16 lsp[],  /* (i) Q15 : line spectral frequencies                  */
                             Word16 a[]     /* (o) Q12 : predictor coefficients (order = 10)        */
    );

void G729EV_G729_Lsf_lsp(
  Word16 lsf[],    /* (i) Q15 : lsf[m] normalized (range: 0.0<=val<=0.5) */
  Word16 lsp[],    /* (o) Q15 : lsp[m] (range: -1<=val<1)                */
  Word16 m         /* (i)     : LPC order                                */
    );
void      G729EV_G729_Lsp_lsf(Word16 lsp[], /* (i) Q15 : lsp[m] (range: -1<=val<1)                  */
                              Word16 lsf[], /* (o) Q15 : lsf[m] normalized (range: 0.0<=val<=0.5)   */
                              Word16 m      /* (i)     : LPC order                                  */
    );

void      G729EV_G729_Int_lpc(Word16 lsp_old[], /* (i)    : LSP vector of past frame                   */
                              Word16 lsp_new[], /* (i)    : LSP vector of present frame                */
                              Word16 lsf_int[], /* (o)    : interpolated lsf coefficients              */
                              Word16 lsf_new[], /* (o)    : new lsf coefficients                       */
                              Word16 Az[]       /* (o)    : interpolated Az() for the 2 subframes      */
    );

void      G729EV_G729_Int_qlpc(Word16 lsp_old[],  /* (i)    : LSP vector of past frame                   */
                               Word16 lsp_new[],  /* (i)    : LSP vector of present frame                */
                               Word16 Az[]        /* (o)    : interpolated Az() for the 2 subframes      */
    );

/*--------------------------------------------------------------------------*
 *       PWF functions                                                  *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_perc_var(Word16 * gamma1, /* bandwidth expansion parameter                        */
                               Word16 * gamma2, /* bandwidth expansion parameter                        */
                               Word16 * lsfint, /* Interpolated LSP vector : 1st subframe               */
                               Word16 * lsfnew, /* New LSP vector : 2nd subframe                        */
                               Word16 * r_c,    /* Reflection coefficients                              */
                               Word16 * smooth, Word16 LarOld[2]);

void      G729EV_G729_Weight_Az(Word16 a[],   /* (i) Q12 : a[m+1]  LPC coefficients                   */
                                Word16 gamma, /* (i) Q15 : Spectral expansion factor.                 */
                                Word16 m,     /* (i)     : LPC order.                                 */
                                Word16 ap[]   /* (o) Q12 : Spectral expanded LPC coefficients         */
    );

void      G729EV_G729_Residu(Word16 a[],  /* (i) Q12 : prediction coefficients                    */
                             Word16 x[],  /* (i) Q0  : speech (values x[-m..-1] are needed (m=10) */
                             Word16 y[],  /* (o) Q0  : residual signal                            */
                             Word16 lg    /* (i)     : frame size                                 */
    );

/* Same as G729EV_G729_Residu except the ouput is set to Q1 instead of Q0 */

void      G729EV_G729_Residu2(Word16 a[], /* (i) Q12 : prediction coefficients                    */
                              Word16 x[], /* (i)  Q0  : speech (values x[-m..-1] are needed (m=10) */
                              Word16 y[], /* (o)  Q1  : residual signal                            */
                              Word16 lg   /* (i)     : frame size                                 */
    );

void      G729EV_G729_Syn_filt(Word16 a[],    /* (i) Q12 : a[m+1] prediction coefficients   (m=10)    */
                               Word16 x[],    /* (i) Q0  : input signal                               */
                               Word16 y[],    /* (o) Q0  : output signal                              */
                               Word16 lg,     /* (i)     : size of filtering                          */
                               Word16 mem[],  /* (i/o)   : memory associated with this filtering.     */
                               Word16 update  /* (i)     : 0=no update, 1=update of memory.           */
    );

/* Same as G729EV_G729_Syn_filt except the input x is in Q1 instead of Q0 */
void      G729EV_G729_Syn_filt2(Word16 a[],   /* (i) Q12 : a[m+1] prediction coefficients   (m=10)    */
                                Word16 x[],   /* (i)  Q1  : input signal                               */
                                Word16 y[],   /* (o)  Q0  : output signal                              */
                                Word16 lg,    /* (i)     : size of filtering                          */
                                Word16 mem[], /* (i/o)   : memory associated with this filtering.     */
                                Word16 update /* (i)     : 0=no update, 1=update of memory.           */
    );

void      G729EV_G729_Convolve(Word16 x[],  /* (i)     : input vector                               */
                               Word16 h[],  /* (i) Q12 : impulse response                           */
                               Word16 y[],  /* (o)     : output vector                              */
                               Word16 L     /* (i)     : vector size                                */
    );

/*--------------------------------------------------------------------------*
 * Pitch functions.                                                         *
 *--------------------------------------------------------------------------*/

Word16    G729EV_G729_Pitch_ol( /* (o)     : open loop pitch lag                        */
                                Word16 signal[],  /* (i)     : signal used to compute the open loop pitch */
                                                  /*       signal[-pit_max] to signal[-1] should be known */
                                Word16 pit_min,   /* (i)     : minimum pitch lag                          */
                                Word16 pit_max,   /* (i)     : maximum pitch lag                          */
                                Word16 L_frame,   /* (i)     : length of frame to compute pitch           */
                                Word16 * voicing, Word16 * pit_old);

Word16    G729EV_G729_Pitch_fr3(  /* (o)     : pitch period.                              */
                                 Word16 exc[],  /* (i)     : excitation buffer                          */
                                 Word16 xn[],   /* (i)     : target vector                              */
                                 Word16 h[],    /* (i) Q12 : impulse response of filters.               */
                                 Word16 L_subfr,/* (i)     : length of subframe                         */
                                 Word16 t0_min, /* (i)     : minimum value in the searched range.       */
                                 Word16 t0_max, /* (i)     : maximum value in the searched range.       */
                                 Word16 i_subfr,/* (i)     : indicator for first subframe.              */
                                 Word16 * pit_frac  /* (o)     : chosen fraction.                           */
    );

Word16    G729EV_G729_G_pitch(  /* (o) Q14 : Gain of pitch lag saturated to 1.2         */
                               Word16 xn[],      /* (i)     : Pitch target.                              */
                               Word16 y1[],      /* (i)     : Filtered adaptive codebook.                */
                               Word16 g_coeff[], /* (i)     : Correlations need for gain quantization.   */
                               Word16 L_subfr    /* (i)     : Length of subframe.                        */
    );

Word16    G729EV_G729_Enc_lag3( /* (o)     : Return index of encoding                   */
                                Word16 T0,      /* (i)     : Pitch delay                                */
                                Word16 T0_frac, /* (i)     : Fractional pitch delay                     */
                                Word16 * T0_min,/* (i/o)   : Minimum search delay                       */
                                Word16 * T0_max,/* (i/o)   : Maximum search delay                       */
                                Word16 pit_min, /* (i)     : Minimum pitch delay                        */
                                Word16 pit_max, /* (i)     : Maximum pitch delay                        */
                                Word16 pit_flag /* (i)     : Flag for 1st subframe                      */
    );

void      G729EV_G729_Dec_lag3( /* (o)     : return integer pitch lag                   */
                                Word16 index,    /* (i)     : received pitch index                       */
                                Word16 pit_min,  /* (i)     : minimum pitch lag                          */
                                Word16 pit_max,  /* (i)     : maximum pitch lag                          */
                                Word16 i_subfr,  /* (i)     : subframe flag                              */
                                Word16 * T0,     /* (o)     : integer part of pitch lag                  */
                                Word16 * T0_frac /* (o)     : fractional part of pitch lag               */
    );

Word16    G729EV_G729_Interpol_3( /* (o)     : interpolated value                         */
                                  Word16 * x, /* (i)     : input vector                               */
                                  Word16 frac /* (i)     : fraction                                   */
    );

void      G729EV_G729_Pred_lt_3(Word16 exc[], /* (i/o)   : excitation buffer                          */
                                Word16 T0,    /* (i)     : integer pitch lag                          */
                                Word16 frac,  /* (i)     : fraction of lag                            */
                                Word16 L_subfr/* (i)     : subframe size                              */
    );

Word16    G729EV_G729_Parity_Pitch( /* (o)    : parity bit (XOR of 6 MSB bits)             */
                                    Word16 pitch_index  /* (i)    : index for which parity to compute          */
    );

Word16    G729EV_G729_Check_Parity_Pitch( /* (o) : 0 = no error, 1= error                  */
                                          Word16 pitch_index, /* (i)   : index of parameter                         */
                                          Word16 parity       /* (i)   : parity bit                                 */
    );

/*--------------------------------------------------------------------------*
 * fixed codebook excitation.                                               *
 *--------------------------------------------------------------------------*/


/*--------------------------------------------------------------------------*
 * FCB functions.                                                           *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_Cor_h(Word16 * H, /* (i) Q12 :Impulse response of filters */
                            Word16 * rr /* (o)     :Correlations of H[]         */
    );
void      G729EV_G729_Cor_h_X(Word16 h[], /* (i) Q12 :Impulse response of filters      */
                              Word16 X[], /* (i) Q12 :Target vector                    */
                              Word16 D[], /* (o)     :Correlations between h[] and D[] */
                              /*          Normalized to 13 bits            */
                              Word16 stp);


void      G729EV_G729_Decod_ACELP(Word16 sign,  /* (i)     : signs of 4 pulses.                         */
                                  Word16 index, /* (i)     : Positions of the 4 pulses.                 */
                                  Word16 cod[]  /* (o) Q13 : algebraic (fixed) codebook excitation      */
    );


/*--------------------------------------------------------------------------*
 * LSP VQ functions.                                                        *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_Lsf_lsp2(Word16 lsf[],  /* (i) Q13 : lsf[m] (range: 0.0<=val<PI)                */
                               Word16 lsp[],  /* (o) Q15 : lsp[m] (range: -1<=val<1)                  */
                               Word16 m       /* (i)     : LPC order                                  */
    );

void      G729EV_G729_Lsp_lsf2(Word16 lsp[],  /* (i) Q15 : lsp[m] (range: -1<=val<1)                  */
                               Word16 lsf[],  /* (o) Q13 : lsf[m] (range: 0.0<=val<PI)                */
                               Word16 m       /* (i)     : LPC order                                  */
    );

void      G729EV_G729_Qua_lsp(Word16 lsp[],   /* (i) Q15 : Unquantized LSP                            */
                              Word16 lsp_q[], /* (o) Q15 : Quantized LSP                              */
                              Word16 ana[],   /* (o)     : indexes                  */
                              Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729_Get_wegt(Word16 flsp[], /* (i) Q13 :                                            */
                               Word16 wegt[]  /* (o) Q11 :  normalized                                */
    );

void      G729EV_G729_Lsp_encw_reset(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729_Lsp_qua_cs(Word16 flsp_in[G729EV_G729_M], /* Q13 */
                                 Word16 lspq_out[G729EV_G729_M],  /* Q13 */
                                 Word16 * code, Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729_Lsp_expand_1(Word16 buf[],  /* Q13 */
                                   Word16 gap     /* Q13 */
    );

void      G729EV_G729_Lsp_expand_2(Word16 buf[],  /* Q13 */
                                   Word16 gap     /* Q13 */
    );

void      G729EV_G729_Lsp_expand_1_2(Word16 buf[],  /* Q13 */
                                     Word16 gap     /* Q13 */
    );

void      G729EV_G729_Lsp_get_quant(Word16 lspcb1[][G729EV_G729_M], /* Q13 */
                                    Word16 lspcb2[][G729EV_G729_M], /* Q13 */
                                    Word16 code0, Word16 code1, Word16 code2, Word16 fg[][G729EV_G729_M], /* Q15 */
                                    Word16 freq_prev[][G729EV_G729_M],  /* Q13 */
                                    Word16 lspq[],  /* Q13 */
                                    Word16 fg_sum[] /* Q15 */
    );

void      G729EV_G729_Lsp_get_tdist(Word16 wegt[],    /* normalized */
                                    Word16 buf[],     /* Q13 */
                                    Word32 * L_tdist, /* Q27 */
                                    Word16 rbuf[],    /* Q13 */
                                    Word16 fg_sum[]   /* Q15 */
    );

void      G729EV_G729_Lsp_last_select(Word32 L_tdist[], /* Q27 */
                                      Word16 * mode_index);

void      G729EV_G729_Lsp_pre_select(Word16 rbuf[], /* Q13 */
                                     Word16 lspcb1[][G729EV_G729_M],  /* Q13 */
                                     Word16 * cand);

void      G729EV_G729_Lsp_select_1(Word16 rbuf[],   /* Q13 */
                                   Word16 lspcb1[], /* Q13 */
                                   Word16 wegt[],   /* normalized */
                                   Word16 lspcb2[][G729EV_G729_M],  /* Q13 */
                                   Word16 * index);

void      G729EV_G729_Lsp_select_2(Word16 rbuf[],   /* Q13 */
                                   Word16 lspcb1[], /* Q13 */
                                   Word16 wegt[],   /* normalized */
                                   Word16 lspcb2[][G729EV_G729_M],  /* Q13 */
                                   Word16 * index);

void      G729EV_G729_Lsp_stability(Word16 buf[]  /* Q13 */
    );

void      G729EV_G729_Relspwed(Word16 lsp[],  /* Q13 */
                               Word16 wegt[], /* normalized */
                               Word16 lspq[], /* Q13 */
                               Word16 lspcb1[][G729EV_G729_M],  /* Q13 */
                               Word16 lspcb2[][G729EV_G729_M],  /* Q13 */
                               Word16 fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M], /* Q15 */
                               Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* Q13 */
                               Word16 fg_sum[G729EV_G729_MODE][G729EV_G729_M],      /* Q15 */
                               Word16 fg_sum_inv[G729EV_G729_MODE][G729EV_G729_M],  /* Q12 */
                               Word16 code_ana[]);

Word16    G729EV_G729_D_lsp(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], Word16 prev_lsp[G729EV_G729_M], Word16 * prev_ma, Word16 prm[], /* (i)     : indexes of the selected LSP */
                            Word16 lsp_q[], /* (o) Q15 : Quantized LSP parameters    */
                            Word16 erase    /* (i)     : frame erase information     */
    );

void      G729EV_G729_Lsp_decw_reset(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                     Word16 prev_lsp[G729EV_G729_M], Word16 * prev_ma);

Word16    G729EV_G729_Lsp_iqua_cs(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], Word16 prev_lsp[G729EV_G729_M], Word16 * prev_ma, Word16 prm[], /* (i)     : indexes of the selected LSP */
                                  Word16 lsp_q[], /* (o) Q13 : Quantized LSP parameters    */
                                  Word16 erase    /* (i)     : frame erase information     */
    );

void      G729EV_G729_Lsp_prev_compose(Word16 lsp_ele[],  /* Q13 */
                                       Word16 lsp[],      /* Q13 */
                                       Word16 fg[][G729EV_G729_M],        /* Q15 */
                                       Word16 freq_prev[][G729EV_G729_M], /* Q13 */
                                       Word16 fg_sum[]    /* Q15 */
    );

void      G729EV_G729_Lsp_prev_extract(Word16 lsp[G729EV_G729_M],     /* Q13 */
                                       Word16 lsp_ele[G729EV_G729_M], /* Q13 */
                                       Word16 fg[G729EV_G729_MA_NP][G729EV_G729_M], /* Q15 */
                                       Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* Q13 */
                                       Word16 fg_sum_inv[G729EV_G729_M] /* Q12 */
    );

void      G729EV_G729_Lsp_prev_update(Word16 lsp_ele[G729EV_G729_M],  /* Q13 */
                                      Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]  /* Q13 */
    );


/*--------------------------------------------------------------------------*
 * gain VQ functions.                                                       *
 *--------------------------------------------------------------------------*/

Word16    G729EV_G729_Qua_gain(Word16 code[],     /* (i) Q13 : Innovative vector.                         */
                               Word16 g_coeff[],  /* (i)     : Correlations <xn y1> -2<y1 y1>             */
                               /*                              <y2,y2>, -2<xn,y2>, 2<y1,y2> */
                               Word16 exp_coeff[],/* (i)    : Q-Format g_coeff[]                         */
                               Word16 L_subfr,    /* (i)     : Subframe length.                           */
                               Word16 * gain_pit, /* (o) Q14 : Pitch gain.                                */
                               Word16 * gain_cod, /* (o) Q1  : Code gain.                                 */
                               Word16 tameflag,   /* (i)     : flag set to 1 if taming is needed          */
                               Word16 past_qua_en[]);

void      G729EV_G729_Dec_gain(Word16 index,  /* (i)     :Index of quantization.         */
                               Word16 code[], /* (i) Q13 :Innovative vector.             */
                               Word16 L_subfr,/* (i)     :Subframe length.               */
                               Word16 bfi,    /* (i)     :Bad frame indicator            */
                               Word16 * gain_pit, /* (o) Q14 :Pitch gain.                    */
                               Word16 * gain_cod, /* (o) Q1  :Code gain.                     */
                               Word16 past_qua_en[4]);

void      G729EV_G729_Gain_predict(Word16 past_qua_en[],  /* (i) Q10 :Past quantized energies                  */
                                   Word16 code[],         /* (i) Q13 : Innovative vector.                         */
                                   Word16 L_subfr,        /* (i)     : Subframe length.                           */
                                   Word16 * gcode0,       /* (o) Qxx : Predicted codebook gain                    */
                                   Word16 * exp_gcode0    /* (o)    : Q-Format(gcode0)                           */
    );

void      G729EV_G729_Gain_update(Word16 past_qua_en[], /* (i) Q10 :Past quantized energies                  */
                                  Word32 L_gbk12        /* (i) Q13 : gbk1[indice1][1]+gbk2[indice2][1]          */
    );

void      Corr_xy2(Word16 xn[], /* (i) Q0  :Target vector.                              */
                   Word16 y1[], /* (i) Q0  :Adaptive codebook.                          */
                   Word16 y2[], /* (i) Q12 :Filtered innovative vector.                 */
                   Word16 g_coeff[],    /* (o) Q[exp]:Correlations between xn,y1,y2             */
                   Word16 exp_g_coeff[] /* (o)  :Q-format of g_coeff[]                      */
    );

/*--------------------------------------------------------------------------*
 * Postfilter functions                                                *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_pst_ltp(Word16 t0, Word16 * ptr_sig_in, Word16 * ptr_sig_pst0);

void      G729EV_G729_search_del(Word16 t0, Word16 * ptr_sig_in, Word16 * ltpdel,
                                 Word16 * phase, Word16 * num_gltp, Word16 * den_gltp, Word16 * sh_num_gltp,
                                 Word16 * sh_den_gltp, Word16 * y_up, Word16 * off_yup);

void      G729EV_G729_filt_plt(Word16 * s_in, Word16 * s_ltp, Word16 * s_out, Word16 gain_plt);

void      G729EV_G729_compute_ltp_l(Word16 * s_in, Word16 ltpdel, Word16 phase,
                                    Word16 * y_up, Word16 * num, Word16 * den, Word16 * sh_num, Word16 * sh_den);

Word16    G729EV_G729_select_ltp(Word16 num1, Word16 den1, Word16 sh_num1,
                                 Word16 sh_den1, Word16 num2, Word16 den2, Word16 sh_num2, Word16 sh_den2);
void      G729EV_G729_calc_st_filt(Word16 * apond2,     /* input : coefficients of numerator */
                                   Word16 * apond1,     /* input : coefficients of denominator */
                                   Word16 * parcor0,    /* output: 1st parcor calcul. on composed filter */
                                   Word16 * sig_ltp_ptr,/* in/out: input of 1/A(gamma1) : scaled by 1/g0 */
                                   Word16 * mem_zero);

void      G729EV_G729_filt_mu(Word16 * sig_in, Word16 * sig_out, Word16 parcor0);

void      G729EV_G729_calc_rc0_h(Word16 * h, Word16 * rc0);

void G729EV_G729_scale_st(Word16 * sig_in,    /* input : postfilter input signal */
							Word16 * sig_out,   /* in/out: postfilter output signal */
							Word16 * gain_prec, /* in/out: last value of gain for subframe */
							Word16 parcor0, 
							Word16 PostNB, 
							Word32 * Level_in_sm,
							Word16 indication   /*input: indicatate for noise or not*/
							);
/*--------------------------------------------------------------------------*
 * Bitstream functions                                                      *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_Corr_xy2(Word16 xn[], /* (i) Q0  :Target vector.                  */
                               Word16 y1[], /* (i) Q0  :Adaptive codebook.              */
                               Word16 y2[], /* (i) Q12 :Filtered innovative vector.     */
                               Word16 g_coeff[],    /* (o) Q[exp]:Correlations between xn,y1,y2 */
                               Word16 exp_g_coeff[] /* (o)       :Q-format of g_coeff[]         */
    );

Word16    G729EV_G729_test_err( /* (o) flag set to 1 if taming is necessary  */
                                G729EV_G729_CODSTAT * pCodStat, Word16 T0,  /* (i) integer part of pitch delay           */
                                Word16 T0_frac  /* (i) fractional part of pitch delay        */
    );

void      G729EV_G729_update_exc_err(Word32 * L_exc_err, Word16 gain_pit, /* (i) pitch gain */
                                     Word16 T0  /* (i) integer part of pitch delay */
    );


/*--------------------------------------------------------------------------*
 * Prototypes for auxiliary functions.                                      *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_Copy(Word16 x[],  /* (i)     : input vector                               */
                           Word16 y[],  /* (o)     : output vector                              */
                           Word16 L     /* (i)     : vector length                              */
    );

void      G729EV_G729_Set_zero(Word16 x[],  /* (o)     : vector to clear                            */
                               Word16 L     /* (i)     : length of vector                           */
    );
void G729EV_G729_Shl (Word16 x[], /* (i)   : input vector   */
                      Word16 y[], /* (o)   : output vector  */
                      Word16 L,   /* (i)   : vector length  */
					  Word16 sh   /* (i)   : shift length   */
    ); 

Word16    G729EV_G729_Random(Word16 * seed);

void      G729EV_G729_UpdateMemTam(G729EV_G729_DECSTAT * pDecStat, Word16 CoefLtp, Word16 Pitch);

Word16    G729EV_G729_TamFer(G729EV_G729_DECSTAT * pDecStat, Word16 CoefLtp, Word16 Pitch);

Word16    G729EV_G729_Chebps_11(Word16 x, Word16 f[], Word16 n);
Word16    G729EV_G729_Chebps_10(Word16 x, Word16 f[], Word16 n);

#endif /* __G729EV_G729_LD8K_H__ */
