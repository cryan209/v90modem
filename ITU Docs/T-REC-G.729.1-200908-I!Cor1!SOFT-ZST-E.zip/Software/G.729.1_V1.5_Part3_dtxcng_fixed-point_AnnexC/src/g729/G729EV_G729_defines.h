/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* Version:       1.3                                                            */
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

/*------------------------------------------------------------------------*/
/* From Original Version :                                                */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B Floating point ANSI C source code      */
/*   Copyright (C) 1999, AT&T, France Telecom, NTT, University of         */
/*   Sherbrooke, Conexant, Ericsson.                                      */
/*                                                                        */
/*   ITU-T G.729 Annex A + Annex B - Reference C code for Floating point  */
/*                         implementation of G.729 Annex AB               */
/*                                                                        */
/*========================================================================*/



#ifndef __G729EV_G729_DEFINES_H__
#define __G729EV_G729_DEFINES_H__

/*--------------------------------------------------------------------------*
 *       Codec constant parameters (coder, decoder, and postfilter)         *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_L_TOTAL     240 /* Total size of speech buffer.              */
#define G729EV_G729_L_WINDOW    240 /* Window size in LP analysis.               */
#define G729EV_G729_L_NEXT      40  /* Lookahead in LP analysis.                 */
#define G729EV_G729_L_FRAME     80  /* Frame size.                               */
#define G729EV_G729_L_SUBFR     40  /* Subframe size.                            */
#define G729EV_G729_M           10  /* Order of LP filter.                       */
#define G729EV_G729_MP1         (G729EV_G729_M+1) /* Order of LP filter + 1        */
#define G729EV_G729_PIT_MIN     20  /* Minimum pitch lag.                        */
#define G729EV_G729_PIT_MAX     143 /* Maximum pitch lag.                        */
#define G729EV_G729_L_INTERPOL  (10+1)  /* Length of filter for interpolation.       */

#define G729EV_G729_PRM_SIZE    11  /* Size of vector of analysis parameters.    */

#define G729EV_G729_SHARPMAX    13017 /* Maximum value of pitch sharpening 0.8 Q14 */
#define G729EV_G729_SHARPMIN    3277  /* Minimum value of pitch sharpening 0.2 Q14 */

#define G729EV_G729_L_SUBFRP1  (G729EV_G729_L_SUBFR + 1)

#define G729EV_G729_GPCLIP      15564 /* Maximum pitch gain if taming is needed Q14 */
#define G729EV_G729_GPCLIP2     481 /* Maximum pitch gain if taming is needed Q9 */
#define G729EV_G729_GP0999      16383 /* Maximum pitch gain if taming is needed Q14 */
#define G729EV_G729_L_THRESH_ERR 983040000L /* Error threshold taming 16384. * 60000.   */

#define G729EV_G729_MEM_SPEECH  (G729EV_G729_L_TOTAL - G729EV_G729_L_FRAME)
#define G729EV_G729_M_LPC       G729EV_G729_M
#define G729EV_G729_M_LPC1      (G729EV_G729_M_LPC+1)

/*--------------------------------------------------------------------------*
 *       PWF constant parameters                                            *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_A1          4567  /*  2.23   in Q11                            */
#define G729EV_G729_L_B1        3271557L  /*  0.78   in Q22                            */
#define G729EV_G729_A2          11776 /*  5.75   in Q11                            */
#define G729EV_G729_L_B2        16357786L /*  3.90   in Q22                            */
#define G729EV_G729_A3          27443 /* 13.40   in Q11                            */
#define G729EV_G729_L_B3        46808433L /* 11.16   in Q22                            */
#define G729EV_G729_SEG1        1299  /*  0.6341 in Q11                            */
#define G729EV_G729_SEG2        1815  /*  0.8864 in Q11                            */
#define G729EV_G729_SEG3        1944  /*  0.9490 in Q11                            */

#define G729EV_G729_THRESH_L1   -3562 /* -1.74   in Q11                            */
#define G729EV_G729_THRESH_L2   -3116 /* -1.52   in Q11                            */
#define G729EV_G729_THRESH_H1   1336  /*  0.65   in Q11                            */
#define G729EV_G729_THRESH_H2   890 /*  0.43   in Q11                            */

#define G729EV_G729_GAMMA1_0    32113 /*  0.98   in Q15                            */
#define G729EV_G729_GAMMA1_1    30802 /*  0.94   in Q15                            */
#define G729EV_G729_GAMMA2_0_L  13107 /*  0.40   in Q15                            */
#define G729EV_G729_GAMMA2_0_H  22938 /*  0.70   in Q15                            */
#define G729EV_G729_GAMMA2_1    19661 /*  0.60   in Q15                            */

#define G729EV_G729_ALPHA       19302 /*  6*pi   in Q10                            */
#define G729EV_G729_BETA        1024  /*     1   in Q10                            */


/*--------------------------------------------------------------------------*
 *       LTP constant parameters                                            *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_UP_SAMP     3 /* upsampling factor for fractional pitch    */
#define G729EV_G729_L_INTER4    4 /* length/2 for interpolation filter         */

#define G729EV_G729_FIR_SIZE_ANA (G729EV_G729_UP_SAMP*G729EV_G729_L_INTER4+1)

#define G729EV_G729_L_INTER10   10  /* length/2 for interpolation filter         */

#define G729EV_G729_FIR_SIZE_SYN (G729EV_G729_UP_SAMP*G729EV_G729_L_INTER10+1)

/*--------------------------------------------------------------------------*
 *       FCB constant parameters                                            *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_DIM_RR      616 /* size of correlation matrix                */
#define G729EV_G729_NB_POS      8 /*                                           */
#define G729EV_G729_STEP        5 /* spacing for individual pulse              */
#define G729EV_G729_MSIZE       64

/*--------------------------------------------------------------------------*
 *       LSP quantizer constant parameters                                  *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_NC          5 /*  NC = M/2                                 */
#define G729EV_G729_MA_NP       4 /* MA prediction order for LSP               */
#define G729EV_G729_MODE        2 /* number of modes for MA prediction         */
#define G729EV_G729_NC0_B       7 /* number of first stage bits                */
#define G729EV_G729_NC1_B       5 /* number of second stage bits               */
#define G729EV_G729_NC0         (1<<G729EV_G729_NC0_B)  /* number of entries in first stage          */
#define G729EV_G729_NC1         (1<<G729EV_G729_NC1_B)  /* number of entries in second stage         */

#define G729EV_G729_L_LIMIT     40  /* minimum lsf value Q13:0.005               */
#define G729EV_G729_M_LIMIT     25681 /* maximum lsf value Q13:3.135               */

#define G729EV_G729_GAP1        10  /* bandwidth expansion factor Q13            */
#define G729EV_G729_GAP2        5 /* bandwidth expansion factor Q13            */
#define G729EV_G729_GAP3        321 /* bandwidth expansion factor Q13            */
#define G729EV_G729_GRID_POINTS 60  /* search grid                               */

#define G729EV_G729_PI04        ((Word16)1029)  /* Q13  pi*0.04                    */
#define G729EV_G729_PI92        ((Word16)23677) /* Q13  pi*0.92                    */
#define G729EV_G729_CONST10     ((Word16)10*(1<<11))  /* Q11  10.0                       */
#define G729EV_G729_CONST12     ((Word16)19661) /* Q14  1.2                        */

/*--------------------------------------------------------------------------*
 * gain VQ constants.                                                       *
 *--------------------------------------------------------------------------*/

#define G729EV_G729_NCODE1_B  3 /* number of Codebook-bit                */
#define G729EV_G729_NCODE2_B  4 /* number of Codebook-bit                */
#define G729EV_G729_NCODE1    (1<<G729EV_G729_NCODE1_B) /* Codebook 1 size           */
#define G729EV_G729_NCODE2    (1<<G729EV_G729_NCODE2_B) /* Codebook 2 size           */
#define G729EV_G729_NCAN1     4 /* Pre-selecting order for #1            */
#define G729EV_G729_NCAN2     8 /* Pre-selecting order for #2            */
#define G729EV_G729_INV_COEF  -17103  /* Q19                                   */

/*--------------------------------------------------------------------------*
 * Postfilter constants                                                *
 *--------------------------------------------------------------------------*/

/* short term pst parameters :                                              */
#define G729EV_G729_GAMMA1_PST  22938 /* denominator weighting factor   (Q15)      */
#define G729EV_G729_GAMMA2_PST  18022 /* numerator  weighting factor (Q15)         */
#define G729EV_G729_GAMMA1_PST12K   24576 /* denominator weighting factor 14K (Q15) */
#define G729EV_G729_GAMMA2_PST12K   22938 /* numerator  weighting factor  14K (Q15) */
#define G729EV_G729_LONG_H_ST   20  /* impulse response length                   */
#define G729EV_G729_GAMMA3_PLUS 6554  /* tilt weighting factor when k1>0 (Q15)     */
#define G729EV_G729_GAMMA3_MINUS 29491  /* tilt weighting factor when k1<0 (Q15)     */

/* long term pst parameters :                                               */
#define G729EV_G729_F_UP_PST    8 /* resolution for fractional delay           */
#define G729EV_G729_LH2_S       4 /* length of short interp. subfilters        */
#define G729EV_G729_L2_LH2_L    4 /* log2(LH2_L)                               */
#define G729EV_G729_LH2_L       (1 << G729EV_G729_L2_LH2_L)
#define G729EV_G729_MIN_GPLT    21845 /* LT gain minimum (Q15)                     */

#define G729EV_G729_LH_UP_S     (G729EV_G729_LH2_S/2)
#define G729EV_G729_LH_UP_SM1   (G729EV_G729_LH_UP_S-1)
#define G729EV_G729_LH_UP_L     (G729EV_G729_LH2_L/2)
#define G729EV_G729_LH2_L_P1    (G729EV_G729_LH2_L + 1)

/* gain adjustment parameters                                               */
#define G729EV_G729_AGC_FAC     32358 /* gain adjustment factor  0.9875 (Q15)       */
#define G729EV_G729_AGC_FAC1    (Word16)(32768L - G729EV_G729_AGC_FAC)

/* Array sizes */
#define G729EV_G729_MEM_RES2    (G729EV_G729_PIT_MAX + 1 + G729EV_G729_LH_UP_L)
#define G729EV_G729_SIZ_RES2    (G729EV_G729_MEM_RES2 + G729EV_G729_L_SUBFR)
#define G729EV_G729_SIZ_Y_UP    ((G729EV_G729_F_UP_PST-1) * G729EV_G729_L_SUBFRP1)
#define G729EV_G729_SIZ_TAB_HUP_L ((G729EV_G729_F_UP_PST-1) * G729EV_G729_LH2_L)
#define G729EV_G729_SIZ_TAB_HUP_S ((G729EV_G729_F_UP_PST-1) * G729EV_G729_LH2_S)

/***************************************************************************************** */

#define G729EV_G729_PRM_SIZE_MAX    17  /* number of parameters per 10 ms frame      */

#define G729EV_G729_MEM_LEN_TAM         150 /* Maximum pitch is not enough, 2nd subframe can be biger then 143 */
#define G729EV_G729_LEN_MEMTAM_UPDATE_UPDATE (G729EV_G729_MEM_LEN_TAM-G729EV_G729_L_FRAME)
#define G729EV_G729_LEN_MEMTAM_UPDATE_TAM (G729EV_G729_MEM_LEN_TAM-G729EV_G729_L_SUBFR)
#define G729EV_G729_MAXTAMLIM 15360 /* 3*40*128 */
#define G729EV_G729_MINTAMLIM 10240 /* 2*40*128 */
#define G729EV_G729_DIFF_MAXMINTAMLIM   5120  /* 40*128 */

#define G729EV_G729_FLT_MAX_G729    0X7FFFFFFF//(REAL)1.e38                 /* largest floating point number */
#define G729EV_G729_FLT_MIN_G729    -G729EV_G729_FLT_MAX_G729   /* largest floating point number */

#define  FILTERORDER  6

#endif  /*__G729EV_G729_DEFINES_H__ */
