README file for the root directory - ITU-T G.729.1 (2006) Amd.8 (2013/03)
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

ITU-T G.729.1 (2006) Amd.8 (2013) introduced new Annex G with a 
floating point implementation of the fixed point superwideband 
mono extension in ITU-T G.729.1 in Annex E.

For completeness, this software distribution includes not only the
ANSI-C code for Annex G, but also that for the whole of ITU-T G.729.1. 
This distribution is labelled as "Release 1.8".

The ANSI-C code of G.729.1 main body (MB) and its Annexes B, C, D, 
and E is the same as published previously, *except* that the Release 
number has been changed to 1.8 within the .c and .h files.

The folders contain the various elements of the ITU-T G.729.1
(self-evident):

- G.729.1_V1.8_Part1_fixed_point_MB
- G.729.1_V1.8_Part2_floating_point_AnnexB
- G.729.1_V1.8_Part3_dtxcng_fixed-point_AnnexC
- G.729.1_V1.8_Part4_dtxcng_floating-point_AnnexD
- G.729.1_V1.8_Part5_swb_mono_AnnexE
- G.729.1_V1.8_Part6_G.720.1_VAD_AnnexF
- G.729.1_V1.8_Part7_swb_mono_float_AnnexG

Test vectors can be downloaded from the ITU-T Test Signal Database, see:
http://itu.int/net/ITU-T/sigdb/speaudio/Gseries.htm#G.729.1

Copyright_Notice_Gen. txt applies to ITU-T G.729.1 and its Amendments 1 to 8
Copyright_Notice_SWB-float.txt also applies to implementations of SWB-float 

-- TSB/SCN - 2013-04-05

