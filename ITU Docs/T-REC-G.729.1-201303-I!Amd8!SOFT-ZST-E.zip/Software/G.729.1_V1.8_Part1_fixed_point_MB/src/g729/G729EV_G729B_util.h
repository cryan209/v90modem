/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729_UTIL_H__
#define __G729EV_G729_UTIL_H__

void      G729EV_G729B_Get_decfreq_prev(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                        Word16 x[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729B_Update_decfreq_prev(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                           Word16 x[G729EV_G729_MA_NP][G729EV_G729_M]);

#endif
