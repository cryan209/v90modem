/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_FEC_H__
#define __G729EV_FEC_H__

#include "G729EV_MAIN_defines.h"
#include "stl.h"

extern const Word16 G729EV_table_isqrt[49];


/* fer prototype */
void      G729EV_FEC_encod(const Word16 old_clas,   /* i:   signal classification result from previous frames  */
                           const Word16 * voicing,  /* i:   normalized correlation for 3 half-frames           Q15 */
                           const Word16 * speech,   /* i:   pointer to denoised speech signal                  Q_new */
                           const Word16 * synth,    /* i:   pointer to synthesized speech for E computation    Q_new */
                           const Word16 * T_op,     /* i:   close loop pitch values for 3 half-frames           */
                           const Word16 * ee,       /* i:   lf/hf E ration for 2 half-frames                   Q14 */
                           const Word16 * sync_sp,  /* i:   time syncronised input speech                      Q_new */
                           Word16 * clas,           /* o:   signal clas for current frame                      */
                           Word16 * coder_parameters, /* o:   coder_parameters                                   */
                           const Word16 T0,         /* i:   close loop integer pitch                           */
                           const Word16 T0_frac,    /* i:   close loop fractional part of the pitch            */
                           const Word16 * res,      /* i:   LP residual signal frame                           Q_new */
                           Word16 * lp_speech,      /* i/o: LP speech energu                                 Q8 */
                           Word16 * rel_hist,       /* i/o: relative energy memory                            */
                           Word16 * rel_var,        /* i/o: relative erergy variation                         */
                           Word16 * old_pos         /* i/o: Position of the last pulse                        */
    );
Word16    G729EV_FEC_dec(       /* o:   frame class information           */
                          Word16 * last_good,    /* i:   last good received frame class    */
                          Word16 plast_good,     /* i:  previous last good received frame class    */
                          const Word16 prev_bfi, /* i:   BFI of the previous frame         */
                          Word16 * indice,       /* i/o: Q indices (parameter vector)       */
                          Word32 * enr_q,        /* o:   E information for FER protection   */
                          Word16 Rate            /* i:   Bitrate decoded                    */
    );

Word16    G729EV_FEC_energy(const Word16 clas,    /* i:   frame classification                           */
                            const Word16 * synth, /* i:   synthesized speech at                    Q_new */
                            const Word16 pitch,   /* i:   pitch period                             Q0    */
                            Word32 * enr_q,       /* o:   pitch-synchronous or half_frame energy   Q0    */
                            const Word16 offset   /* i:   speech pointer offset (0 or L_FRAME)           */
    );
void      G729EV_FEC_clas_dec(Word16 * clas,          /* i/o: frame classification                    */
                              const Word16 * pitch,   /* i:   pitch values for each subframe          QPIT */
                              const Word16 last_good, /* i:   type of the last correctly received fr. */
                              Word16 * frame_synth,   /* i/o: synthesis buffer                        Q_new */
                              Word16 * st_old_synth,  /* i/o: synthesis memory                        Q_new */
                              Word16 * lp_speech      /* i/o: long term active speech energy average Q1 */
    );
void      G729EV_FEC_pit_updt(Word16 clas,          /* i:   frame classification              */
                              Word16 * pitch_buf,   /* i:   fractionnal pitch buffer QPIT     */
                              Word16 last_good,     /* i:   Last good frame classification    */
                              Word16 * upd_cnt,     /* i/o: update counter                    */
                              Word16 * old_fpitch,  /* i/o: old fractionnal pitch buffer QPIT */
                              Word16 * fpitch       /* i/o: fractionnal pitch            QPIT */
    );
void      G729EV_FEC_scale_syn(Word16 extrate,         /* i: indicate decoded bit rate                 */
                               Word16 clas,            /* i/o: frame classification                    */
                               const Word16 last_good, /* i:   last good frame classification          */
                               Word16 * synth,         /* i/o: synthesized speech                      */
                               const Word16 * pitch,   /* i:   pitch values for each subframe          */
                               Word32 Lenr_q,          /* i:   transmitted energy for current frame    */
                               const Word16 prev_bfi,  /* i:   previous frame BFI                      */
                               Word16 Aq[],            /* i/o: LP filter coefs (can be modified if BR) */
                               Word16 * old_enr_LP,    /* i/o: LP filter E of last good G729EV_FEC_VOICED frame   Q4 */
                               Word16 * mem_tmp,       /* i/o: temporary synthesis memory              */
                               Word16 * exc_tmp,       /* i/o: temporary excitation                    */
                               Word32 Lenr_old,        /* i  : energy at the end of the last frame     */
                               Word16 * old_exc,       /* i/o: excitation buffer                       */
                               Word16 * mem_syn,       /* i/o: synthesis memory                        */
                               Word16 bfi_cnt          /* i  : Number of bad frame                     */
    );
Word16    G729EV_FEC_findpulse( /* o:   pulse position        */
                                const Word16 res[], /* i:   residual signal       */
                                Word16 T0,          /* i:   integer pitch         */
                                const Word16 enc    /* i:  enc = 1 -> encoder side; enc = 0 -> decoder side */
    );
void      G729EV_FEC_mod_adapt_codebook(Word16 * exc,       /* i/o : exc vector to modify                                               */
                                        Word16 puls_pos,    /* i   : Last pulse position desired                                        */
                                        Word16 * pitch_buf, /* i   : containt pitch modified in function of bfi_pitch and new pitch   Q6 */
                                        Word32 enr_q,       /* i   : energy provide by the encoder                                    Q0 */
                                        Word16 * Aq         /* i   : Lsp coefficient                                                     */
    );
void      G729EV_FEC_pitch_pred(Word16 bfi,       /* i: Bad frame ?                     */
                                Word16 * T,       /* i/o: Pitch                         */
                                Word16 * T_fr,    /* i/o: fractionnal pitch             */
                                Word16 * pit_mem, /* i/o: Pitch memories                */
                                Word16 * bfi_mem  /* i/o: Memory of bad frame indicator */
    );
#endif /* __G729EV_FEC_H__ */
