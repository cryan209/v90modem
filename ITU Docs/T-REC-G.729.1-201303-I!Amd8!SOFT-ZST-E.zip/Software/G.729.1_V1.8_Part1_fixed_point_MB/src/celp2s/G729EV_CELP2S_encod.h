/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/



#ifndef __G729EV_CELP2S_ENCODE_H__
#define __G729EV_CELP2S_ENCODE_H__

#include "G729EV_CELP2S.h"

#include "G729EV_G729_ld8k.h"
#include "G729EV_CELP2S_acelp_ca.h"
#include "G729EV_CELP2S_qua_gain.h"

/* Functions */
void      G729EV_CELP2S_InitEncoder(G729EV_G729_CODSTAT * pCodStat, Word16 rate);

void G729EV_CELP2S_encoder(G729EV_G729_CODSTAT * pCodStat,  /* (i)  core coder states vaiables  */ 
                           Word16 * DataIn,                 /* (i)  data to encode              */
                           Word16 * coder_parameters,       /* (o)  coder parameters            */
                           Word16 synth[],                  /* (o)  Synthesis signal            */
                           Word16 SubFrNum,                 /* (i)  Subframe number             */
                           Word16 * celp_Az,                /* (i)  Az buffer                   */
                           Word16 * sync_speech,            /* (o)  weighted synthesis          */
                           Word16 * resBF8k,                /* (o)  residual signal frame       */
                           Word16 * pit,                    /* (o)  open loop pitch             */
                           Word16 * t0_out,                 /* (o)  close loop integer pitch    */
                           Word16 * t0_fout,                /* (o)  close loop fract. pitch     */
                           Word16 * voicing,                /* (o)  frame voicing               */
                           Word16 * ee,                     /* (o)  spectral tilt info.         */
                           Word16 * diff                    /* (o)  difference signal between 
                                                                    input and local synthesis at 
                                                                    12 kbit/s */
);


#endif  /*__G729EV_CELP2S_ENCODE_H__ */
