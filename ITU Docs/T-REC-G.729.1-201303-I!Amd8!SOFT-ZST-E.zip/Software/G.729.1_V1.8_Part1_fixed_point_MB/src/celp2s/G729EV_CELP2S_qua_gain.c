/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_CELP2S_qua_gain.h"


/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_qua_gain_Stage2()                *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                *
 *  gain codebook index                                      *
 *-----------------------------------------------------------*/

Word16 G729EV_CELP2S_qua_gain_Stage2(Word16 gain_code,  /* (i)  code gain of 1st stage                      */
                                      Word16 xn[],      /* (i)  target vector for 2nd stage                 */
                                      Word16 y1[],      /* (i)  filtered fixed codeword for 2nd stage  (Q12)*/
                                      Word16 l_subfr,   /* (i)  vector dimension                            */
                                      Word16 i_subfr)   /* (i)  subframe number                             */
{
  Word32    ACC0, ACC1;
  Word32    L_dist, L_min_dist;
  Word16    i, index;
  Word16    gain, yy, tmp;
  Word16    exp_gain, exp_yy, exp_tmp;



  /* compute correlations */
  /* Compute < y1 (Q12) , y1 (Q12) > , result in Q23 (12+12+1-2) */
#if (WMOPS)
  move32();
  move32();
#endif
  ACC1 = (Word32) 0;
  ACC0 = (Word32) 0;
  FOR(i = 0; i < l_subfr; i++)
  {
    ACC0 = L_mult(y1[i], y1[i]);
    ACC0 = L_shr(ACC0, 2);
    ACC1 = L_add(ACC1, ACC0);
  }

  /* Normalize y1y1 Q(7 + exp_yy) */
  exp_yy = norm_l(ACC1);
  ACC1 = L_shl(ACC1, exp_yy);
  yy = extract_h(ACC1);

  /* Compute - 2 * < xn (Q0) , y1 (Q12) > , Result in Q11 (12 - 1) */
#if (WMOPS)
  move32();
#endif
  ACC0 = (Word32) 0;
  FOR(i = 0; i < l_subfr; i++)
  {
    ACC0 = L_msu0(ACC0, xn[i], y1[i]);
  }



  /* quantize cb gain (relative value w.r.t gain_code) - 3 bits */

#if (WMOPS)
  move16();
  test();
#endif
  index = (Word16) 0;
  IF((sub(i_subfr, 1) == 0) || (sub(i_subfr, 3) == 0))
  {
    Word16    hi, lo, exp_num, exp_den, num, den, gain, tmp16;
    Word32    L_tmp;

    /*gain_code_enh = xy/yy; */
    /* normalise xy */
    exp_num = sub(norm_l(ACC0), 1);
    num = extract_h(L_shl(L_abs(ACC0), exp_num));

    /* normalise gain_code */
    tmp16 = norm_s(gain_code);
    gain_code = shl(gain_code, tmp16);
    /* yy already normalised */
    /* den (yy)= yy*gain_code */
    ACC1 = L_mult(yy, gain_code);
    exp_den = norm_l(ACC1);
    den = extract_h(L_shl(ACC1, exp_den));
    exp_den = add(exp_den, tmp16);
    /* do xy/yy */
    gain = div_s(num, den);
    /* Find right exponent */
    exp_num = sub(exp_num, add(add(exp_den, exp_yy), -18));

    Log2(L_deposit_l(gain), &hi, &lo);
    /* remove exponent */
    hi = sub(hi, exp_num);
    /* Log2 @ 20*Log10 +6.0f */
    L_tmp = L_add(L_shl(Mpy_32_16(hi, lo, G729EV_FEC_LG10), 3), 393216);  /*Q13 -> Q16 */
    L_tmp = L_mls(L_tmp, 10923);
    /* Find index */
    index = round(L_tmp);
    if (sub(index, 3) > 0)
    {
#if (WMOPS)
      move16();
#endif
      index = (Word16) 3;
    }
    if (index < 0)
    {
#if (WMOPS)
      move16();
#endif
      index = (Word16) 0;
    }

  }
  ELSE
  {
    /* Compute gain  = G729EV_MAIN_tab_gain_enha[0]  * gain_code  */
    /*      Qexp_gain                Q14                  Q1      */

    ACC1 = L_mult(G729EV_MAIN_tab_gain_enha[0], gain_code);
    exp_gain = norm_l(ACC1);
    ACC1 = L_shl(ACC1, exp_gain);
    gain = extract_h(ACC1);


    /*    ACC1    =      ( gain    *      yy ) << ( 3 + 1 - exp_gain - exp_yy) */
    /*     Q11         Qexp_gain       Q(exp_yy+7)                             */
    ACC1 = L_mult(yy, gain);
    ACC1 = L_shr(ACC1, sub(add(exp_gain, exp_yy), 3));

    /* ACC1 = - 2 * < xn, y1 > + gain * < y1, y1 >  (Q11) */
    ACC1 = L_add(ACC0, ACC1);

    /* Normalize ACC1 -> tmp in Q(exp_tmp+11-16) */
    exp_tmp = norm_l(ACC1);
    ACC1 = L_shl(ACC1, exp_tmp);
    tmp = extract_h(ACC1);

    /* Compute L_min_dist = gain * (- 2 * < xn, y1 > + gain * < y1, y1 >) , Result in Q0 */
    ACC1 = L_mult(tmp, gain);
    L_min_dist = L_shr(ACC1, sub(add(exp_gain, exp_tmp), 16 - 12 + 2));


#if (WMOPS)
    move16();
#endif
    index = (Word16) 0;
    FOR(i = 1; i < 8; i++)
    {


      /* Compute gain  = G729EV_MAIN_tab_gain_enha[i]  * gain_code  */
      /*      Qexp_gain                Q14                  Q1      */
      ACC1 = L_mult(G729EV_MAIN_tab_gain_enha[i], gain_code); /* Q14 * Q1 -> Q16 */
      exp_gain = norm_l(ACC1);
      ACC1 = L_shl(ACC1, exp_gain);
      gain = extract_h(ACC1);

      /*    ACC1    =      ( gain    *      yy ) << ( 3 + 1 - exp_gain - exp_yy) */
      /*     Q11         Qexp_gain       Q(exp_yy+7)                             */
      ACC1 = L_mult(yy, gain);
      ACC1 = L_shr(ACC1, sub(add(exp_gain, exp_yy), 3));

      /* ACC1 = - 2 * < xn, y1 > + gain * < y1, y1 >  (Q11) */
      ACC1 = L_add(ACC0, ACC1);

      /* Normalize ACC1 -> tmp in Q(exp_tmp+11-16) */
      exp_tmp = norm_l(ACC1);
      ACC1 = L_shl(ACC1, exp_tmp);
      tmp = extract_h(ACC1);

      /* Compute L_dist = gain * (- 2 * < xn, y1 > + gain * < y1, y1 >) , Result in Q0 */
      ACC1 = L_mult(tmp, gain);
      L_dist = L_shr(ACC1, sub(add(exp_gain, exp_tmp), 16 - 12 + 2));

      IF(L_sub(L_dist, L_min_dist) < 0)
      {
        L_min_dist = L_dist;
        index = i;
#if (WMOPS)
        move32();
        move16();
#endif
      }
    }
  }

  return index;
}


/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_dec_gain_Stage2()                *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                *
 *  decode quantized gain                                    *
 *-----------------------------------------------------------*/

Word16 G729EV_CELP2S_dec_gain_Stage2(Word16 gain_code, /* (i)   1 St stage code gain         */
                                      Word16 index,    /* (i)   2 nd stage code gain index   */
                                      Word16 i_subfr)  /* (i)   subframe number              */
{
  Word32    ACC0;
  Word16    gain;

  /*  decode quantized gain value from index */
#if (WMOPS)
  test();
#endif
  IF((sub(i_subfr, 1) == 0) || (sub(i_subfr, 3) == 0))
  {

    index = s_and(index, 0x03); /* Ensure there is no more than 2 bits read #### Should not be needed when TDAC will be present ### TV */
    ACC0 = L_mult(gain_code, G729EV_MAIN_tab_gain_enha2bits[index]);  /* Q1 * Q14 -> Q16 */
  }
  ELSE
  {
    ACC0 = L_mult(gain_code, G729EV_MAIN_tab_gain_enha[index]); /* Q1 * Q14 -> Q16 */
  }
  ACC0 = L_shl(ACC0, 1);
  gain = round(ACC0);           /* Q1 */


  return (gain);
}
