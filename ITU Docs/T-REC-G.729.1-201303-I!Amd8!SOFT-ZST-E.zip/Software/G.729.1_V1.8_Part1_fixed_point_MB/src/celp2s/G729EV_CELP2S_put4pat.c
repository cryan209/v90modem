/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "stl.h"
#include "G729EV_G729_defines.h"


/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_Put4Patterns()                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *   Arranging the 4 tri-pulse patterns                      *
 *-----------------------------------------------------------*/

void G729EV_CELP2S_Put4Patterns(Word16 pos[], /* (i) : positions of the 4 patterns */
                                Word16 si[],  /* (i) : signs of the 4 patterns */
                                Word16 sp,    /* (i) : amplitude of the side pulses */
                                Word16 cod[]  /* (o) : decoded FCB vector */
    )
{
  Word16    i;
  Word16   *p_cod, sp_p, sp_m;

  p_cod = cod;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    *p_cod++ = (Word16) 0;
#ifdef WMOPS
    move16();
#endif
  }

  sp_m = mult_r(sp, 32766);     /* Q15 */
  sp_p = negate(sp);

  {
    IF(si[0] != 0)
    {
      if (pos[0] != 0)
      {
        cod[pos[0] - 1] = sp_m;
#ifdef WMOPS
        move16();
#endif
      }
      cod[pos[0] + 1] = sp_m;
#ifdef WMOPS
      move16();
#endif
    }
    ELSE
    {
      if (pos[0] != 0)
      {
        cod[pos[0] - 1] = sp_p;
#ifdef WMOPS
        move16();
#endif
      }
      cod[pos[0] + 1] = sp_p;
#ifdef WMOPS
      move16();
#endif
    }
  }

  FOR(i = 1; i < 3; i++)
  {
    IF(si[i] != 0)
    {
      cod[pos[i] - 1] = add(cod[pos[i] - 1], sp_m);
      cod[pos[i] + 1] = add(cod[pos[i] + 1], sp_m);
#ifdef WMOPS
      move16();
      move16();
#endif
    }
    ELSE
    {
      cod[pos[i] - 1] = add(cod[pos[i] - 1], sp_p);
      cod[pos[i] + 1] = add(cod[pos[i] + 1], sp_p);
#ifdef WMOPS
      move16();
      move16();
#endif
    }
  }

  {
    IF(si[3] != 0)
    {
      cod[pos[3] - 1] = add(cod[pos[3] - 1], sp_m);
#ifdef WMOPS
      move16();
#endif
      if (sub(pos[3], 39) != 0)
      {
        cod[pos[3] + 1] = add(cod[pos[3] + 1], sp_m);
#ifdef WMOPS
        move16();
#endif
      }
    }
    ELSE
    {
      cod[pos[3] - 1] = add(cod[pos[3] - 1], sp_p);
#ifdef WMOPS
      move16();
#endif
      if (sub(pos[3], 39) != 0)
      {
        cod[pos[3] + 1] = add(cod[pos[3] + 1], sp_p);
#ifdef WMOPS
        move16();
#endif
      }
    }
  }

  p_cod = cod;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    *p_cod++ = shr_r(cod[i], 2);  /* Q15 -> Q13 */
#ifdef WMOPS
    move16();
#endif
  }

  FOR(i = 0; i < 4; i++)
  {
    IF(si[i] != 0)
    {
      cod[pos[i]] = add(cod[pos[i]], 8191);
    }
    ELSE
    {
      cod[pos[i]] = add(cod[pos[i]], -8192);
    }
#ifdef WMOPS
    move16();
#endif
  }

  return;
}
