/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_fir.h"

#include "G729EV_G729_ld8k.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_fir_initialize()                                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                 *
 *  TDBWE FIR filter initialization                                         *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_fir_initialize(G729EV_TDBWE_fir_state * state,  /* (o) */
                                 Word16 * filter_coeffs)          /* (i) coefficient vector for FIR fiter */
{
  state->filter_coeffs = filter_coeffs;

  G729EV_G729_Set_zero(state->state, G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_fir()                                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                            *
 *  TDBWE FIR filter                                                        *
 *                                                                          *
 *  direct form (non-transposed) implementation                             *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_fir(G729EV_TDBWE_fir_state * state, /* (i/o) */
                      Word16 * input,                 /* (i)   input signal */
                      Word16 * output,                /* (o)   filtered signal */
                      Word16 vector_size)             /* (i)   number of elements in input[] and output[] */
{


  Word16    i, k;
  Word16   *buf_ptr, *state_ptr, *coeffs_ptr, *coeffs_ptr_start;
  Word32    acc;

  Word16    buf[G729EV_TDBWE_BUFLEN_FIR];


  G729EV_G729_Copy(state->state, buf, G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1);
  G729EV_G729_Copy(input, &buf[G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1], vector_size);

  buf_ptr = buf;
  coeffs_ptr_start = &state->filter_coeffs[G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1];

  FOR(i = 0; i < vector_size; i++)
  {
    /* filtering ... */
    state_ptr = buf_ptr++;
    coeffs_ptr = coeffs_ptr_start;
    acc = 0x000004000;          /* rounding value */
#ifdef WMOPS
    move32();
#endif

    FOR(k = 0; k < G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH; k++)
    {
      acc = L_mac0(acc, *coeffs_ptr--, *state_ptr++);
    }
    output[i] = extract_h(L_shl(acc, 1));
#ifdef WMOPS
    move16();
#endif
  }

  /* save filter state */
  G729EV_G729_Copy(&buf[vector_size], state->state, G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1);
}
