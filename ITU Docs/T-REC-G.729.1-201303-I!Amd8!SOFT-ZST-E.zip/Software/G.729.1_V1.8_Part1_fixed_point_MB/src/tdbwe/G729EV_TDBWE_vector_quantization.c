/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_vector_quantization.h"

#include "G729EV_G729_ld8k.h"



/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_vector_quantization()                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                            *
 *  TDBWE vector quantization,                                              *
 *  find entry in codebook[] closest to vector input[] and output           *
 *  its respective index                                                    *
 *                                                                          *
 *  input, codebook and output must have the same format Q.max              *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_vector_quantization(Word16 * input,             /* (i) Q.max */
                                      const Word16 * codebook,    /* (i) Q.max, pointer to quantization table */
                                      UWord16 * index,            /* (o) codebook index */
                                      const Word16 vector_size,   /* (i) length of input[] */
                                      const Word16 codebook_size) /* (i) number of entries in codebook[] */
{
  const Word16 *codebook_ptr;
  UWord16   i, j;
  Word16    error;
  Word32    distortion;
  Word32    min_distortion;


  codebook_ptr = codebook;
  min_distortion = 0x7fffffff;
#ifdef WMOPS
  move16();
  move32();
#endif

  /* loop through codebook */
  FOR(i = 0; i < codebook_size; i++)
  {

    /* start with min_distortion */
    distortion = min_distortion;
#ifdef WMOPS
    move32();
#endif

    /* compute Euclidean distance */
    FOR(j = 0; j < vector_size; j++)
    {
      error = sub(input[j], codebook_ptr[j]);
      distortion = L_msu0(distortion, error, error);
    }

    /* select best codevector */
    if (distortion > 0)
    {
      *index = i;
#ifdef WMOPS
      move16();
#endif
    }
    if (distortion > 0)
    {
      min_distortion = L_sub(min_distortion, distortion);
    }

    /* advance in codebook */
    codebook_ptr = &codebook_ptr[vector_size];

  }
}
