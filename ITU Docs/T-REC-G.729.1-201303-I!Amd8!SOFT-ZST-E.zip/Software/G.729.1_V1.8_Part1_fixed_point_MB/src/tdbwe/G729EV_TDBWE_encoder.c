/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_encoder.h"

#include "G729EV_TDBWE_extract_time_envelope.h"
#include "G729EV_TDBWE_extract_frequency_envelope.h"
#include "G729EV_TDBWE_vector_quantization.h"
#include "G729EV_G729_ld8k.h"



/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_quantization()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Quantization of the TDBWE parameter set by "mean removed VQ"            *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_quantization(Word16 * parameters_tdbwe, /* (i) Q.10, the unquantized parameter set */
                               Word16 * coder_parameters) /* (o) codebook indices */
{
  Word16    i;
  UWord16   vq_index;
  Word16    mu, mu_q;
  Word16   *parameters;
  Word16   *coder_param_ptr;

  /* initialize pointer to TDBWE parameters */
  coder_param_ptr = coder_parameters;

  /* compute mean time envelope */
  mu = (Word16) 0;
#ifdef WMOPS
  move16();
#endif
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++)
  {
    mu = add(mu, shr(parameters[i], 3));
  }
  mu = shr(mu, 1);

  /* quantize mean */
  G729EV_TDBWE_vector_quantization(&mu,
                                   G729EV_TDBWE_MEAN_TIME_ENV_cb,
                                   &vq_index, 1, G729EV_TDBWE_MEAN_TIME_ENV_NUMBER_ENTRIES);

  /* write vq_index to coder_parameters */
  *coder_param_ptr++ = vq_index;
#ifdef WMOPS
  move16();
#endif

  /* reconstruct quantized mean (table look-up) */
  mu_q = G729EV_TDBWE_MEAN_TIME_ENV_cb[vq_index];
#ifdef WMOPS
  move16();
#endif

  /* remove quantized mean from time envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;  /* parameters_tdbwe + 0 */
  FOR(i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++)
  {
    parameters[i] = sub(parameters[i], mu_q);
#ifdef WMOPS
    move16();
#endif
  }

  /* quantize mean-removed time envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_TIME_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {

    G729EV_TDBWE_vector_quantization(&parameters[i * 8],
                                     G729EV_TDBWE_TIME_ENV_cb, &vq_index, 8, G729EV_TDBWE_TIME_ENV_NUMBER_ENTRIES);

    /* write vq_index to coder_parameters */
    *coder_param_ptr++ = vq_index;
#ifdef WMOPS
    move16();
#endif

  }

  /* remove quantized mean from frequency envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
  {
    parameters[i] = sub(parameters[i], mu_q);
#ifdef WMOPS
    move16();
#endif
  }

  /* quantize mean-removed frequency envelope */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_FREQ_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {

    G729EV_TDBWE_vector_quantization(&parameters[i * 4],
                                     G729EV_TDBWE_FREQ_ENV_cb[i],
                                     &vq_index, 4, G729EV_TDBWE_FREQ_ENV_NUMBER_ENTRIES[i]);

    /* write vq_index to coder_parameters */
    *coder_param_ptr++ = vq_index;
#ifdef WMOPS
    move16();
#endif
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_encoder_init()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Initialization of the TDBWE encoder                                     *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_encoder_init(G729EV_TDBWE_CODSTAT * state)  /* (o) */
{
  G729EV_G729_Set_zero(state->old_speech, G729EV_TDBWE_MEM_SPEECH);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_encoder()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 *  TDBWE encoder (parameter extraction),                                   *
 *  computes and quantize time/frequency envelopes                          *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_encoder(G729EV_TDBWE_CODSTAT * state, /* (i/o)  */
                          Word16 * input_hi,            /* (i)    Q.0, high band input signal @ 8kHz */
                          Word16 * coder_parameters,    /* (o)    quantized parameter set (codebook indices) */
                          Word16 * input_hi_delay)      /* (o)    delayed input */
{
  Word16    parameters[G729EV_TDBWE_NB_PARAMETERS]; /* Q10 */
  Word16   *new_speech;
  Word16   *speech;
  Word16    old_speech[G729EV_TDBWE_L_TOTAL];

  /*-------------*
  * set pointers *
  *--------------*/

  new_speech = old_speech + G729EV_TDBWE_MEM_SPEECH;  /* New speech     */
  speech = new_speech - G729EV_TDBWE_L_NEXT;  /* Present frame  */
#if (WMOPS)
  move16();
  move16();
#endif

  /*--------------*
  * update buffer *
  *---------------*/

  G729EV_G729_Copy(state->old_speech, old_speech, G729EV_TDBWE_MEM_SPEECH);
  G729EV_G729_Copy(input_hi, new_speech, G729EV_TDBWE_L_FRAME);

  /*--------------------------------*
  * extract and quantize envelopes  *
  *---------------------------------*/

  /* time envelope extraction */
  G729EV_TDBWE_extract_time_envelope(speech + G729EV_TDBWE_DELTA_TIME_ENV, 0, /* nls */
                                     &parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE], G729EV_TDBWE_NB_SUBFRAMES);

  /* extraction of the frequency envelope for the 2nd 10ms frame */
  G729EV_TDBWE_extract_frequency_envelope(speech + (G729EV_TDBWE_L_FRAME2 + G729EV_TDBWE_DELTA_FREQ_ENV), 0,  /* nls */
                                          &parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE]);

  /* quantize the parameter set and write bitstream */
  G729EV_TDBWE_quantization(parameters, coder_parameters);

  /*--------------*
  * update memory *
  *---------------*/
  G729EV_G729_Copy(&old_speech[G729EV_TDBWE_L_FRAME], state->old_speech, G729EV_TDBWE_MEM_SPEECH);
  G729EV_G729_Copy(speech, input_hi_delay, G729EV_TDBWE_L_FRAME);
}
