/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_decoder.h"

#include "G729EV_TDBWE_compression.h"
#include "G729EV_TDBWE_time_envelope_shaping.h"
#include "G729EV_TDBWE_frequency_envelope_shaping.h"
#include "G729EV_G729_ld8k.h"



/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_dequantization()                                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                 *
 *  TDBWE parameter lookup and mean value reconstruction                    *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_dequantization(Word16 * coder_parameters, Word16 * parameters_tdbwe)  /* Q.10 */
{
  Word16    i;
  Word16    mu_q;               /* Q.10 */
  UWord16   vq_index;
  Word16   *parameters;         /* Q.10 */
  Word16   *param_ptr;
  const Word16 *tab_ptr;

  param_ptr = coder_parameters;

  /* retrieve the time envelope's mean from the bitstream */
  mu_q = G729EV_TDBWE_MEAN_TIME_ENV_cb[*param_ptr++];
#ifdef WMOPS
  move16();
#endif

  /* retrieve the time envelope from the bitstream and de-normalize */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_TIME_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {
    vq_index = *param_ptr++;
#ifdef WMOPS
    move16();
#endif

    G729EV_G729_Copy((Word16 *) & G729EV_TDBWE_TIME_ENV_cb[vq_index * 8], &parameters[i * 8], 8);
  }

  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_TIME_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_NB_SUBFRAMES; i++)
  {
    parameters[i] = add(parameters[i], mu_q);
#ifdef WMOPS
    move16();
#endif
  }

  /* retrieve the frequency envelope from the bitstream and de-normalize */
  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_FREQ_ENV_SPLIT_VQ_NUMBER_SPLITS; i++)
  {
    tab_ptr = G729EV_TDBWE_FREQ_ENV_cb[i];

    vq_index = *param_ptr++;
#ifdef WMOPS
    move16();
#endif

    G729EV_G729_Copy((Word16 *) & tab_ptr[vq_index * 4], &parameters[i * 4], 4);
  }

  parameters = parameters_tdbwe + G729EV_TDBWE_PAROFS_FREQ_ENVELOPE;
  FOR(i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
  {
    parameters[i] = add(parameters[i], mu_q);
#ifdef WMOPS
    move16();
#endif
  }
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_decoder_init()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Initialization of TDBWE decoder                                         *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_decoder_init(G729EV_TDBWE_DECSTAT * state)  /* (o) */
{

  state->prev_gain_time_envelope_shaping = (Word16) 0;
  state->prev_norm_time_envelope_shaping = (Word16) 0;
#ifdef WMOPS
  move16();
  move16();
#endif

  G729EV_TDBWE_generate_excitation_initialize(&state->generate_excitation);
  G729EV_TDBWE_frequency_envelope_shaping_initialize(&state->frequency_envelope_shaping);

  G729EV_G729_Set_zero(state->old_excitation_1, G729EV_TDBWE_MEM_EXC);

  G729EV_G729_Set_zero(state->mem_freq_env, G729EV_TDBWE_NB_SUBBANDS);

  state->mem_time_env[0] = (Word16) 0;
  state->mem_time_env[1] = (Word16) 0;
#ifdef WMOPS
  move16();
  move16();
#endif
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_decoder()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 *  TDBWE decoder (highband synthesis),                                     *
 *  generates the exication signal, shape time & frequency envelope and     *
 *  invokes postprocessing                                                  *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_decoder(G729EV_TDBWE_DECSTAT * state,         /* (i/o) */
                          G729EV_CELP2S_PARAM * nb_celp_param,  /* (i)   information from narrowband G.729A+ codec (8k/12k layers) */
                          Word16 * signal_highband,             /* (o)   Q.2, synthesized output signal  */
                          Word16 * parameters)                  /* (i)   Q.10, the quantized TDBWE parameter set */
{
  Word16    i, j;
  G729EV_TDBWE_g729_info excparam[2];
  Word16    jm2pi;
  Word16    excitation[G729EV_TDBWE_L_FRAME2];  /* Q.12 */
  Word16   *excitation_1;       /* Q.4 */
  Word16    interp[G729EV_TDBWE_NB_SUBBANDS];
  Word16   *tenv, *out;
  Word16   *fenv;
  Word16    old_excitation_1[G729EV_TDBWE_L_TOTAL_EXC];

  /* rearrange information on G729 NB excitation */
  FOR(j = 0; j < 2; j++)
  {
    FOR(i = 0; i < 2; i++)
    {
      jm2pi = add(add(j, j), i);  /* 2*j+i */

      excparam[j].lag[i] = nb_celp_param->t0[jm2pi];
      excparam[j].frac_lag[i] = nb_celp_param->t0_frac[jm2pi];
      excparam[j].power_ltp[i] = nb_celp_param->power_ltp[jm2pi];
      excparam[j].power_fix[i] = nb_celp_param->power_fix[jm2pi];

#ifdef WMOPS
      move16();
      move16();
      move16();
      move16();
#endif
    }
  }

  /* set pointers */
  excitation_1 = old_excitation_1 + G729EV_TDBWE_MEM_EXC;
  G729EV_G729_Copy(state->old_excitation_1, old_excitation_1, G729EV_TDBWE_MEM_EXC);

  fenv = &parameters[G729EV_TDBWE_PAROFS_FREQ_ENVELOPE];
  tenv = &parameters[G729EV_TDBWE_PAROFS_TIME_ENVELOPE];

  /* Interpolate frequency envelope for the first 10ms frame */
  FOR(i = 0; i < G729EV_TDBWE_NB_SUBBANDS; i++)
  {
    interp[i] = shr(add(state->mem_freq_env[i], fenv[i]), 1);
#ifdef WMOPS
    move16();
#endif
  }

  /* generate and shape synthetic excitation */
  out = signal_highband;
  FOR(i = 0; i < 2; i++)
  {
    /* excitation Q.12 */
    G729EV_TDBWE_generate_excitation(&state->generate_excitation, &excparam[i], excitation);

    /* time envelope Q.10 */
    G729EV_TDBWE_time_envelope_shaping(excitation,
                                       tenv,
                                       excitation_1,
                                       &(state->
                                         prev_gain_time_envelope_shaping), &(state->prev_norm_time_envelope_shaping));
    /* excitation_1 Q.0 */
    IF(i == 0) G729EV_TDBWE_frequency_envelope_shaping(&state->frequency_envelope_shaping, excitation_1, out, interp);
    ELSE G729EV_TDBWE_frequency_envelope_shaping(&state->frequency_envelope_shaping, excitation_1, out, fenv);
    /* output Q.0 */

    /* invoke post-processing */
    G729EV_TDBWE_compression(state->mem_time_env, out, tenv);

    out += G729EV_TDBWE_L_FRAME2;
    tenv += G729EV_TDBWE_NB_SUBFRAMES_2;
    excitation_1 += G729EV_TDBWE_L_FRAME2;
  }

  /* memory update */
  G729EV_G729_Copy(fenv, state->mem_freq_env, G729EV_TDBWE_NB_SUBBANDS);
  G729EV_G729_Copy(&old_excitation_1[G729EV_TDBWE_L_FRAME], state->old_excitation_1, G729EV_TDBWE_MEM_EXC);
}
