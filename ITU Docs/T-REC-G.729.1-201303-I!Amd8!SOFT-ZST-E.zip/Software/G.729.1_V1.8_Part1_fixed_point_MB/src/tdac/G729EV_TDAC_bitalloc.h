/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_BITALLOC_H__
#define __G729EV_TDAC_BITALLOC_H__

#include <stdio.h>
#include "stl.h"


/*********************************************************************/
/* words for bitstream packing*/
/*********************************************************************/

/* Functions : */
void      G729EV_TDAC_sort_ip(Word16 * ip, Word16 nb_ssb, Word16 * pos);
void      G729EV_TDAC_calc_nbit_total(Word16 nb_sb, const Word16 * nb_coef, Word16 * ip, Word16 lam,
                                      Word16 * nbit_total, Word16 * bit_alloc);

void      G729EV_TDAC_allocbit(Word16 * bit_alloc,
                               Word16 nbit_max, Word16 * ip, Word16 nb_sb, const Word16 * nb_coef, Word16 * ord_b);
/* Tables : */

extern const Word16 G729EV_TDAC_nb_coef_div[G729EV_TDAC_NB_SB];
extern const Word16 G729EV_TDAC_nb_coef[G729EV_TDAC_NB_SB];


#endif  /*__G729EV_TDAC_BITALLOC_H__ */
