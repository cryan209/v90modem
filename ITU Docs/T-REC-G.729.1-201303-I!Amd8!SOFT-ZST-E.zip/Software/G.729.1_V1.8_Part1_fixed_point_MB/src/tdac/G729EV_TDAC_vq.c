/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_bitalloc.h"
#include "G729EV_TDAC_lib_vq.h"
#include "G729EV_TDAC_vq.h"
#include "G729EV_TDAC_util.h"

#include "stl.h"
#include "G729EV_MAIN_oper_32b.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_quantif()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                         *
 *  Split spherical vector quantization                                     *
 *--------------------------------------------------------------------------*/

void G729EV_TDAC_quantif(Word16 * ykr,    /* (i)      MDCT coefficients to encode             */
                         Word16 ** bit,   /* (i/o)    pointer on adress of next bit           */
                         Word16 * nb_niv, /* (i)      number of bits allocated per subbands   */
                         Word16 nb_ssb)   /* (i)      number of subbands                      */
{
  UWord32   cod32;

  const Word16 *ptr1, *ptr0;

  Word16    j, k, nbit, pos;


  /* quantize - normalized - spectrum (loop over subbands) */
  /* because spherical VQ is used, there is no need for per-band normalization by the spectral enveloppe */
  ptr0 = G729EV_TDAC_sb_bound;
  ptr1 = ptr0 + 1;

  FOR(j = 0; j < nb_ssb; j++)
  {
    /* get the bit allocation */
    nbit = nb_niv[j];
#if(WMOPS)
    move16();
#endif

    /* if the j-th subband has a non-zero bit allocation 'nbit' */
    IF(nbit != 0)
    {
      /* compute dimension 'k' of subband */
      k = sub((*ptr1), (*ptr0));

      /* get position of first coefficient in the subband */
      pos = *ptr0;
#if(WMOPS)
      move16();
#endif

      /* apply spherical VQ */
      G729EV_TDAC_VQ_quant(&ykr[pos], k, nbit, &cod32);

      /* write index in bitstream */
      G729EV_TDAC_pushBitL(cod32, bit, nbit);
    }
    ptr0++;
    ptr1++;
  }
  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_dec_VQcoef()                                      *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                      *
 *  Codevector definition                                                   *
 *--------------------------------------------------------------------------*/

void G729EV_TDAC_dec_VQcoef(UWord32 code, /* (i)  Index read from bitstream                   */
                            Word16 dim,   /* (i)  Number of MDCT coefficients per subbands    */
                            Word16 * yq)  /* (o)  Codeword                                    */
{
  UWord32   rank, tmp_ul, diff;

  const UWord32 *ptr_offset, *ptr;

  UWord16   sgn;

  Word16    nb_lead, i, ilead;
  Word16    tmp, t;


  /* initialize the pointer to cardinality offset */
  ptr_offset = G729EV_MAIN_adOffsetLead[dim]; /* pointer init */
  ptr = ptr_offset;

  /* find the absolute leader which has a permutation of index 'code' (parse table of cardinality offsets) */
  tmp = G729EV_MAIN_NbDic[dim];
  t = sub(tmp, 1);
  nb_lead = *(G729EV_MAIN_adNbLeadpRat[dim] + t);
#if(WMOPS)
  move16();
  move16();
#endif

  ilead = sub(nb_lead, 1);
  FOR(i = 0; i < nb_lead; i++)
  {
    UL_sub(code, *ptr++, &diff, &sgn);
    IF(sub(sgn,1) == 0)
    {                           /* negative sign : code < ptr_offset[i] */
      ilead = sub(i, 1);
      BREAK;
    }
  }

  UL_sub(code, ptr_offset[add(ilead, 1)], &diff, &sgn);
  IF(sgn == 0)                  /*if(code >= ptr_offset[ilead+1])*/
  { /*invalid code for the last band, non valid vq code due to bst error*/
    IF(sub(dim,16) == 0)
    {
      ilead = 10; /*leader AAAAAAAAAAAAAAAA*/
      rank = 21845; /*signs +-+-+-+-+-+-+-+-*/
    }
    ELSE /*if(dim == 8)*/
    {
      ilead = 8; /*leader AAAAAAAA*/
      rank = 85; /*signs +-+-+-+-*/
    }
#if(WMOPS)
    move16();
    move32();
#endif
  }
  ELSE
  {
  /* compute rank of permutation: rank = index - cardinality offset */

  tmp_ul = ptr_offset[ilead];
#if(WMOPS)
  move32();
#endif

  UL_sub(code, tmp_ul, &rank, &sgn);
  }
  /* decode rank of permutation (as a side product, get also the inverse L2 norm of the leader)     */
  G729EV_TDAC_inv_schalk(rank, dim, ilead, yq);

  return;
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_decod_VQ()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 *  Inverse split spherical vector quantization                             *
 *--------------------------------------------------------------------------*/

void G729EV_TDAC_decod_VQ(Word16 ** bit,    /* (i/o)    Pointer on address of next bit          */
                          Word16 * ykr,     /* (o)      Decoded MDCT coefficients               */
                          Word16 * nb_niv,  /* (i)      number of bits allocated per subbands   */
                          Word16 * rmsq,    /* (i)      rms                                     */
                          Word16 nb_ssb)    /* (i)      number of subbands                      */
{
  Word32    L_tmp;
  UWord32   cod32;

  Word16    y[G729EV_TDAC_N_NBC];

  const Word16 *ptr1, *ptr0;

  Word16    i, j, k, n, nbit;
  Word16    w16_hi, w16_lo;


  ptr0 = G729EV_TDAC_sb_bound;
  ptr1 = ptr0 + 1;

  FOR(j = 0; j < nb_ssb; j++)
  {
    /* if the j-th subband is uncoded or if the bit allocation to the j-th subband is zero, reconstruct a zero subband */
    nbit = nb_niv[j];           /* bit allocation */
    n = G729EV_TDAC_nb_coef[j]; /* no masking in G729EV */
#if(WMOPS)
    move16();
    move16();
#endif
    IF(nbit == 0)
    {
      FOR(i = *ptr0; i < *ptr1; i++)
      {
        ykr[i] = (Word16) 0;
#if(WMOPS)
        move16();
#endif
      }
    }
    ELSE
    {
      /* read index (cod32) and decode it into a codevector (y) */
      /* get also the inverse L2 norm of y */
      cod32 = G729EV_TDAC_getBitL(bit, nbit);
      k = sub(*ptr1, *ptr0);
      G729EV_TDAC_dec_VQcoef(cod32, k, y);

      /* shape codevector (y) : ykr = y  *  rmsq * sqrt(j) */
#if(WMOPS)
      move16();
#endif

      L_tmp = L_mult(rmsq[j], G729EV_TDAC_nb_coef_sqrt[j]);
      L_Extract(L_tmp, &w16_hi, &w16_lo);
      k = (Word16) 0;
      FOR(i = *ptr0; i < *ptr1; i++)
      {
        L_tmp = Mpy_32_16(w16_hi, w16_lo, y[k]);
        L_tmp = L_shr(L_tmp, 13);
        ykr[i] = extract_l(L_tmp);  /* -> 13Q2 */
#if(WMOPS)
        move16();
#endif
        k = add(k, 1);
      }
    }
    ptr0++;
    ptr1++;
  }

  /* fill the last uncoded subband (>7.x kHz) */
  FOR(i = *ptr0; i < G729EV_MAIN_L_FRAME; i++)
  {
    ykr[i] = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }
  return;
}
