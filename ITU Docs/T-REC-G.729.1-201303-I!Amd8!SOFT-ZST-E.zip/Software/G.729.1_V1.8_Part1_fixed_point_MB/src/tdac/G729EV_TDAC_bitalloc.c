/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_TDAC_bitalloc.h"
#include "G729EV_TDAC_lib_vq.h"
#include "stl.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_calc_nbit_total()                                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Compute bit_alloc(j)=SelectCbk(nb_coef(j)*(ip(j)-lam)) and              *
 *          nbit_total = sum_j bit_alloc(j)                                 *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_calc_nbit_total(Word16 nb_sb,            /* (i)     number of subbands */
                                 const Word16 * nb_coef,  /* (i)     number of coefficients per subband */
                                 Word16 * ip,             /* (i) Q1  perceptual importance per subband */
                                 Word16 lam,              /* (i) Q6  water level */
                                 Word16 * nbit_total,     /* (o)     total number of bits */
                                 Word16 * bit_alloc       /* (o)     number of bits per subband */
    )
{
  Word16    j;
  Word16    n;
  Word16    nbit_estim;

  /* compute bit allocation for each subband */
  *nbit_total = (Word16) 0;
#if(WMOPS)
  move16();
#endif
  FOR(j = 0; j < nb_sb; j++)
  {
    /* compute estimated bit allocation = estimed rate per sample * dimension */
    nbit_estim = sub(shl(ip[j], 5), lam);
    nbit_estim = shl(nbit_estim, G729EV_TDAC_nb_coef_div[j]);

    /* find codebook rate which is closest to target rate */
    n = shr(add(nbit_estim, 0x20), 6);
    n = G729EV_TDAC_SelectCbk(n, nb_coef[j]);

    /* save bit allocation */
    bit_alloc[j] = n;
#if(WMOPS)
    move16();
#endif

    /* accumulate bit counter */
    *nbit_total = add(*nbit_total, n);
#if(WMOPS)
    move16();
#endif
  }
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_allocbit()                                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                          *
 *  Compute bit_alloc(j)=SelectCbk(nb_coef(j)*(ip(j)-lam)) and              *
 *          nbit_total = sum_j bit_alloc(j)                                 *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_allocbit(Word16 * bit_alloc,     /* (o)     number of bits per subband */
                          Word16 nbit_max,        /* (i)     bit budget to TDAC vq */
                          Word16 * ip,            /* (i) Q1  perceptual importance per subband */
                          Word16 nb_sb,           /* (i)     number of subbands */
                          const Word16 * nb_coef, /* (i)     number of coefficients per subband */
                          Word16 * ord_b          /* (i)     ordering of subbands */
    )
{
  Word16    new_bit_alloc[G729EV_TDAC_NB_SB];

  Word16    i, j, n;
  Word16    tmp16;
  Word16    bit_cnt0;
  Word16    lam, lam0, lam1;
  Word16    max_ip, min_ip;
  Word16    bit_cnt1;
  Word16    iter;
  Word16    bit_cnt;
  Word16    add_b;
  Word16    add_b_max;
  Word16    new_bi;
  Word16    diff;

  /* initialize bit allocation to subbands */
  FOR(j = 0; j < nb_sb; j++)
  {
    bit_alloc[j] = (Word16) 0;
#if(WMOPS)
    move16();
#endif
  }

  /* find min and max */
  max_ip = ip[ord_b[0]];
  tmp16 = sub(G729EV_TDAC_NB_SB, 1);
  min_ip = ip[ord_b[tmp16]];
#if(WMOPS)
  move16();
  move16();
#endif

  /* set range for bisection search */
  lam0 = shl(max_ip, 5);        /* Q6 */
  bit_cnt0 = (Word16) 0;
#if(WMOPS)
  move16();
#endif

  lam1 = shl(sub(min_ip, 8), 5);  /* min_ip - 4; *//* Q6 */
  G729EV_TDAC_calc_nbit_total(nb_sb, nb_coef, ip, lam1, &bit_cnt1, new_bit_alloc);

  iter = (Word16) 0;
#if(WMOPS)
  move16();
#endif
  WHILE(sub(iter, 10) < 0)
  {
    iter = add(iter, 1);

    /* try middle value */
    lam = shr(add(lam0, lam1), 1);
    G729EV_TDAC_calc_nbit_total(nb_sb, nb_coef, ip, lam, &bit_cnt, new_bit_alloc);

    /* update solution if total bit allocation is inferior and closer to bit budget */
    IF(sub(bit_cnt, nbit_max) <= 0)
    {
      lam0 = lam;
#if(WMOPS)
      move16();
#endif
      FOR(j = 0; j < nb_sb; j++)
      {
        bit_alloc[j] = new_bit_alloc[j];
#if(WMOPS)
        move16();
#endif
      }
      bit_cnt0 = bit_cnt;
#if(WMOPS)
      move16();
#endif
    }
    ELSE
    {
      lam1 = lam;
      bit_cnt1 = bit_cnt;
#if(WMOPS)
      move16();
      move16();
#endif
    }
  }

  /* add bits if needed */
  FOR(j = 0; (sub(j, G729EV_TDAC_NB_SB) < 0) && (sub(bit_cnt0, nbit_max) < 0); j++)
  {
    i = ord_b[j];
    n = G729EV_TDAC_nb_coef[i];
#if(WMOPS)
    move16();
    move16();
#endif

    /* add bits to subband i (try to sature bit allocation) */
    add_b = sub(G729EV_MAIN_NbDic[n], 1);
    add_b = *(G729EV_MAIN_adRate[n] + add_b);
    add_b = sub(add_b, bit_alloc[i]);
    add_b_max = sub(nbit_max, bit_cnt0);

    if (sub(add_b, add_b_max) > 0)
    {
      add_b = add_b_max;
#if(WMOPS)
      move16();
#endif
    }

    tmp16 = add(bit_alloc[i], add_b);
    new_bi = G729EV_TDAC_SelectCbk(tmp16, n);
    diff = sub(new_bi, bit_alloc[i]);

    tmp16 = add(bit_cnt0, diff);
    tmp16 = sub(tmp16, nbit_max);

    IF(tmp16 > 0)
    {
      new_bi = G729EV_TDAC_SearchPrev(new_bi, n);
      diff = sub(new_bi, bit_alloc[i]);
    }

    bit_cnt0 = add(bit_cnt0, diff);
    bit_alloc[i] = add(bit_alloc[i], diff);
#if(WMOPS)
    move16();
#endif
  }
}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_sort_ip()                                         *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *  Order subbands by decreasing perceptual importance                      *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_sort_ip(Word16 * ip,   /* (i) Q1  perceptual importance per subband */
                         Word16 nb_ssb, /* (i)     number of subband */
                         Word16 * pos   /* (o)     subband order */
    )
{
  Word16    tab_ip[G729EV_TDAC_NB_SB], max;
  Word16    i, j, jmax, k;

  /* copy ip */
  FOR(i = 0; i < G729EV_TDAC_NB_SB; i++)
  {
    tab_ip[i] = ip[i];
#if (WMOPS)
    move16();
#endif
  }

  /* sort ip in decreasing order and save positions */
  k = (Word16) 0;
#if (WMOPS)
  move16();
#endif
  FOR(i = 0; i < G729EV_TDAC_NB_SB; i++)
  {
    jmax = (Word16) 0;          /* to avoid warning */
    max = (Word16) G729EV_TDAC_SORTED_IP;
#if (WMOPS)
    move16();
    move16();
#endif
    FOR(j = 0; j < G729EV_TDAC_NB_SB; j++)
    {
      IF(sub(tab_ip[j], max) > 0)
      {
        jmax = j;
        max = tab_ip[j];
#if (WMOPS)
        move16();
        move16();
#endif
      }
    }

    pos[k] = jmax;
    tab_ip[jmax] = (Word16) G729EV_TDAC_SORTED_IP;
#if (WMOPS)
    move16();
    move16();
#endif
    k = add(k, 1);
  }
}
