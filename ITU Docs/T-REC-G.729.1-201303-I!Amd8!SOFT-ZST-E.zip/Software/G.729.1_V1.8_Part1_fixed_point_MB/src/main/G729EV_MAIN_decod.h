/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_DECOD_H__
#define __G729EV_MAIN_DECOD_H__

#include "stl.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_TDBWE_decoder.h"


/* Types : */
typedef struct
{
  /* filter states */
  G729EV_MAIN_QMFDECSTAT qmf_syn;
  G729EV_MAIN_IIR2STAT mem_postpro;
  G729EV_MAIN_IIRN_STAT mem_lp3k;

  /* state variables of G.729 and TDBWE decoders */
  G729EV_G729_DECSTAT decStG729;
  G729EV_TDBWE_DECSTAT tdbwe;

  /* previous G.729 parameters (for FEC) */
  G729EV_CELP2S_PARAM prev_nb_celp_param;

  /* lower-band postfiltering */
  G729EV_MAIN_PFSTAT mem_pf;
  Word16    mem_pf_in[G729EV_G729_M_LPC];
  Word16    mem_Az[G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1];
  Word16    mem_t0[G729EV_MAIN_NB_SUBFR];

  /* states for inverse perceptual weighting filtering of lower-band difference signal */
  Word16    mem_invWz_in[G729EV_G729_M];
  Word16    mem_invwsp[G729EV_G729_M];

  /* MDCT memories */
  Word16    mem_mdct_hi[G729EV_MAIN_L_FRAME2];
  Word16    mem_inv_mdct_lo[G729EV_MAIN_L_FRAME2];
  Word16    mem_inv_mdct_hi[G729EV_MAIN_L_FRAME2];

  /* gamma adaptation memory for lower-band postfilter */
  Word16    tab_Th[G729EV_MAIN_NMAX];

  /* state variables for FEC */
  Word16    prev_parameters_tdbwe[G729EV_TDBWE_NB_PARAMETERS];
  Word16    old_celp_output[G729EV_MAIN_L_FRAME2];
  Word16    sTdbweOld[G729EV_MAIN_L_FRAME2];
  Word16    synth_buf[G729EV_G729_PIT_MAX];
  Word16    vmhold;
  Word16    vmlold;
  Word16    first_frame;
  Word16    prev_nRcv_hi;
  Word16    prev_rate;
  Word16    lp_ener_FER;
  Word16    lastgood;
  Word16    old_enrLP;
  Word16    plast_good;
  Word32    max_prev_lo;
  Word32    max_prev_hi;

  /* variables for bit-rate switching */
  Word16    count_rcv;
  Word16    mem_postflag;

  /* decoder flags (8kHz sampled input, G.729 bistream mode, low-delay mode) */
  Word16    f8;
  Word16    g729b_bst;
  Word16    low_delay;

  /* bfi of previous frame */
  Word16    prev_bfi;

} DECSTATMAIN;


/* Functions : */
void      G729EV_MAIN_InitDecoder(DECSTATMAIN * pDecStatH, Word16 f8, Word16 g729b_bst, Word16 low_delay);
void      G729EV_MAIN_Decode(DECSTATMAIN * pDecStatH, Word16 * itu_192_bitstream,
                             Word16 * samplesOut, Word16 rate, Word16 bfi, Word16 g729ftyp[2]);

void      G729EV_FEC_dec_bf(Word16 parm[],  /* (i)   : vector of synthesis parameters */
                            Word16 synth[], /* (i/o) : synthesis speech                     */
                            Word16 Az_dec[],/* (o)   : decoded LP filter in 2 subframes     */
                            Word16 bfi,     /* (i)   : Bad Frame Indicator                  */
                            Word16 * last_good, /* (i)   : last good frame classification       */
                            Word16 * pitch_buf, /* (i/o) : Pitch memory                         */
                            Word16 old_enr,     /* (i)   : Energy at the end of the last frame  */
                            Word16 * old_exc, G729EV_G729_DECSTAT * st, /* (i)   : Decoder structure                    */
                            Word16 new_clas, Word16 puls_pos);

extern const Word16 G729EV_MAIN_switching_gain[G729EV_MAIN_COUNT_RCV_MAX + 1];

#endif  /*__G729EV_MAIN_DECOD_H__ */
