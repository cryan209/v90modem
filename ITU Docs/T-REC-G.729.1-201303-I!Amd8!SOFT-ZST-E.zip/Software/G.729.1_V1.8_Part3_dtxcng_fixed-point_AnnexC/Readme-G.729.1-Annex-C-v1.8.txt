===============================================================================
  ITU-T G.729.1 Annex C (ex G.729.1-DTX-CNG)
  Version:       1.8
  Revision Date: 2013-03-16
  Note: upgraded from 1.6 to 1.8 without any changes.
===============================================================================

These files represent the ITU-T G.729.1 Annex C fixed-point bit-exact C 
simulation. All code is written in ANSI-C.  The coder is implemented as 
two separate programs:

        encoder [options] input bistream
        decoder [options] bitstream output 
	
                            FILE FORMATS:
                            =============

The file format of the supplied binary data is 16-bit binary data which is
read and written in 16 bit little-endian words.  
The data is therefore platform DEPENDENT.  

The bitstream follows the ITU-T G.192 format. For every 20 ms input speech frame,
the bitstream contains the following data:

	Word16 SyncWord
	Word16 DataLen
	Word16 1st Databit
	Word16 2nd DataBit
	.
	.
	.
	Word16 Nth DataBit

Each bit is presented as follows: Bit 0 = 0x007f, Bit 1 = 0x0081.

The SyncWord from the encoder is always 0x6b21. The SyncWord 0x6b20, on decoder side, 
indicates that the current frame was received in error (bad frame).

The DataLen parameter gives the number of speech data bits in the frame. 

			INSTALLING THE SOFTWARE
			=======================

Installing the software on the PC:

The package includes makefile for gcc and workspace for Visual C++ 6.0. 
The makefile can be used as follows:

  make -f makefile.gcc

assuming you have gcc installed

The codec has been successfully compiled on Linux using gcc and Windows using gcc and
Visual C++ 6.0.

                       RUNNING THE SOFTWARE
                       ====================

The usage of the "encoder" program is as follows:

  encoder [options] <inputfile> <bitstream>

Options:
  -quiet     
  -rXXXXX    run encoder at bit rate XXXXX bit/s (32000 by default)
  -f8        input sampled at 8 kHz
  -g729_bst  write G.729 bitstream (maximal bit rate must be set to 8 kbit/s)
  -dtx       encoder runs with DTX/CNG scheme, scalable bitstream for silence with three layers can be generated

By default, the encoder input is sampled at 16 kHz.


The usage of the "decoder" program is as follows:

  decoder [options] <bitstream> <outputfile>

Options:
  -quiet     
  -rXXXXX    run decoder at maximal bit rate XXXXX bit/s (32000 by default)
  -f8        output sampled at 8 kHz
  -g729b_bst read and decode G.729 or G.729B bitstream
  -ld        low-delay mode
   
By default, the decoder output is sampled at 16 kHz.

-- End