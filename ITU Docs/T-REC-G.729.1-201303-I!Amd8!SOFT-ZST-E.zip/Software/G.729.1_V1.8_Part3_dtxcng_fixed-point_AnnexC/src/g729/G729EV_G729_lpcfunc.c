/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*-------------------------------------------------------------*
 *  Procedure G729EV_G729_Lsp_Az:                              *
 *            ~~~~~~                                           *
 *   Compute the LPC coefficients from lsp (order=10)          *
 *-------------------------------------------------------------*/

#include "stl.h"
#include "G729EV_MAIN_oper_32b.h"

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

#ifdef WMOPS
#include "count.h"
#endif

/* local function */

static void G729EV_G729_Get_lsp_pol(Word16 * lsp, Word32 * f);

void G729EV_G729_Lsp_Az(Word16 lsp[],  /* (i) Q15 : line spectral frequencies            */
                        Word16 a[]     /* (o) Q12 : predictor coefficients (order = 10)  */
    )
{
  Word32    f1[6], f2[6];

  Word32    t0;

  Word16    i, j;


  G729EV_G729_Get_lsp_pol(&lsp[0], f1);
  G729EV_G729_Get_lsp_pol(&lsp[1], f2);

  FOR(i = 5; i > 0; i--)
  {
    f1[i] = L_add(f1[i], f1[i - 1]);  /* f1[i] += f1[i-1]; */
    f2[i] = L_sub(f2[i], f2[i - 1]);  /* f2[i] -= f2[i-1]; */
#ifdef WMOPS
    move16();
    move16();
#endif
  }

  a[0] = 4096;
#ifdef WMOPS
  move16();
#endif

#ifdef WMOPS
  move16();
#endif
  j = 10;
  FOR(i = 1; i <= 5; i++)
  {
    t0 = L_add(f1[i], f2[i]);   /* f1[i] + f2[i]             */
    a[i] = extract_l(L_shr_r(t0, 13));  /* from Q24 to Q12 and * 0.5 */

    t0 = L_sub(f1[i], f2[i]);   /* f1[i] - f2[i]             */
    a[j] = extract_l(L_shr_r(t0, 13));  /* from Q24 to Q12 and * 0.5 */

#ifdef WMOPS
    move16();
    move16();
#endif

    j--;
  }

  return;
}

/*-----------------------------------------------------------*
 * procedure G729EV_G729_Get_lsp_pol:                                    *
 *           ~~~~~~~~~~~                                     *
 *   Find the polynomial F1(z) or F2(z) from the LSPs        *
 *-----------------------------------------------------------*
 *                                                           *
 * Parameters:                                               *
 *  lsp[]   : line spectral freq. (cosine domain)    in Q15  *
 *  f[]     : the coefficients of F1 or F2           in Q24  *
 *-----------------------------------------------------------*/

static void G729EV_G729_Get_lsp_pol(Word16 * lsp, Word32 * f)
{
  Word32    t0;

  Word16    i, j, hi, lo;


  /* All computation in Q24 */

  *f = 16777216;      /* f[0] = 1.0;             in Q24  */
  f++;
  *f = L_msu((Word32) 0, *lsp, 512);  /* f[1] =  -2.0 * lsp[0];  in Q24  */
#ifdef WMOPS
  move32();
  move32();
#endif

  f++;
  lsp += 2;                     /* Advance lsp pointer             */

  FOR(i = 2; i <= 5; i++)
  {
    *f = f[-2];
#ifdef WMOPS
    move32();
#endif

    FOR(j = 1; j < i; j++)
    {
      L_Extract(f[-1], &hi, &lo);
      t0 = Mpy_32_16(hi, lo, *lsp); /* t0 = f[-1] * lsp    */
      t0 = L_shl(t0, 1);
      *f = L_add(*f, f[-2]);    /* *f += f[-2]         */
      *f = L_sub(*f, t0);       /* *f -= t0            */
#ifdef WMOPS
      move32();
      move32();
#endif

      f--;
    }

#ifdef WMOPS
    move32();
#endif
    *f = L_msu(*f, *lsp, 512);  /* *f -= lsp<<9        */
    f += i;                     /* Advance f pointer   */
    lsp += 2;                   /* Advance lsp pointer */
  }

  return;
}

/*___________________________________________________________________________
 |                                                                           |
 |   Functions : G729EV_G729_Lsp_lsf and G729EV_G729_Lsf_lsp                 |
 |                                                                           |
 |      G729EV_G729_Lsp_lsf   Transformation lsp to lsf                      |
 |      G729EV_G729_Lsf_lsp   Transformation lsf to lsp                      |
 |---------------------------------------------------------------------------|
 |  Algorithm:                                                               |
 |                                                                           |
 |   The transformation from lsp[i] to lsf[i] and lsf[i] to lsp[i] are       |
 |   approximated by a look-up table and interpolation.                      |
 |___________________________________________________________________________|
*/

void G729EV_G729_Lsf_lsp(
  Word16 lsf[],    /* (i) Q15 : lsf[m] normalized (range: 0.0<=val<=0.5) */
  Word16 lsp[],    /* (o) Q15 : lsp[m] (range: -1<=val<1)                */
  Word16 m         /* (i)     : LPC order                                */
)
{
  Word16 i, ind, offset;

  for(i=0; i<m; i++)
  {
    ind    = shr(lsf[i], 8);               /* ind    = b8-b15 of lsf[i] */
    offset = lsf[i] & (Word16)0x00ff;      /* offset = b0-b7  of lsf[i] */
    lsp[i] = add(table[ind], extract_l(L_shr(L_mult(sub(table[ind+1], table[ind]), offset), 9)));
  }
  return;
}


void G729EV_G729_Lsp_lsf(Word16 lsp[],  /* (i) Q15 : lsp[m] (range: -1<=val<1)                */
                         Word16 lsf[],  /* (o) Q15 : lsf[m] normalized (range: 0.0<=val<=0.5) */
                         Word16 m       /* (i)     : LPC order                                */
    )
{
  Word32    L_tmp;

  Word16    i, ind, tmp;


  ind = 63;                     /* begin at end of table -1 */
#ifdef WMOPS
  move16();
#endif

  FOR(i = m - (Word16) 1; i >= 0; i--)
  {
    /* find value in table that is just greater than lsp[i] */
    WHILE(sub(table[ind], lsp[i]) < 0)
    {
      ind = sub(ind, 1);
    }

    /* acos(lsp[i])= ind*256 + ( ( lsp[i]-table[ind] ) * slope[ind] )/4096 */

    L_tmp = L_mult(sub(lsp[i], table[ind]), slope[ind]);
    tmp = round(L_shl(L_tmp, 3)); /*(lsp[i]-table[ind])*slope[ind])>>12 */
    lsf[i] = add(tmp, shl(ind, 8));
#ifdef WMOPS
    move16();
#endif
  }
  return;
}

/*___________________________________________________________________________
 |                                                                           |
 |   Functions : G729EV_G729_Lsp_lsf and G729EV_G729_Lsf_lsp                                         |
 |                                                                           |
 |      G729EV_G729_Lsp_lsf   Transformation lsp to lsf                                  |
 |      G729EV_G729_Lsf_lsp   Transformation lsf to lsp                                  |
 |---------------------------------------------------------------------------|
 |  Algorithm:                                                               |
 |                                                                           |
 |   The transformation from lsp[i] to lsf[i] and lsf[i] to lsp[i] are       |
 |   approximated by a look-up table and interpolation.                      |
 |___________________________________________________________________________|
*/

void G729EV_G729_Lsf_lsp2(Word16 lsf[], /* (i) Q13 : lsf[m] (range: 0.0<=val<PI) */
                          Word16 lsp[], /* (o) Q15 : lsp[m] (range: -1<=val<1)   */
                          Word16 m      /* (i)     : LPC order                   */
    )
{
  Word32    L_tmp;

  Word16    i, ind;
  Word16    offset;             /* in Q8 */
  Word16    freq;               /* normalized frequency in Q15 */


  FOR(i = 0; i < m; i++)
  {
/*    freq = abs_s(freq);*/
    freq = mult(lsf[i], 20861); /* 20861: 1.0/(2.0*PI) in Q17 */
    ind = shr(freq, 8);         /* ind    = b8-b15 of freq */
    offset = s_and(freq, (Word16) 0x00ff);  /* offset = b0-b7  of freq */

    if (sub(ind, 63) > 0)
    {
#ifdef WMOPS
      move16();
#endif
      ind = 63;                 /* 0 <= ind <= 63 */
    }

    /* lsp[i] = table[ind]+ (slope_cos[ind]*offset >> 12) */

    L_tmp = L_mult(slope_cos[ind], offset); /* L_tmp in Q28 */
    lsp[i] = add(table[ind], extract_l(L_shr(L_tmp, 13)));
#ifdef WMOPS
    move16();
#endif

  }
  return;
}



void G729EV_G729_Lsp_lsf2(Word16 lsp[], /* (i) Q15 : lsp[m] (range: -1<=val<1)   */
                          Word16 lsf[], /* (o) Q13 : lsf[m] (range: 0.0<=val<PI) */
                          Word16 m      /* (i)     : LPC order                   */
    )
{
  Word32    L_tmp;

  Word16    i, ind;
  Word16    offset;             /* in Q15 */
  Word16    freq;               /* normalized frequency in Q16 */


  ind = 63;                     /* begin at end of table - 2 */
#ifdef WMOPS
  move16();
#endif

  FOR(i = m - (Word16) 1; i >= 0; i--)
  {
    /* find value in table2 that is just greater than lsp[i] */
    WHILE(sub(table[ind], lsp[i]) < 0)
    {
      ind = sub(ind, 1);
      if (ind <= 0)
      {
        BREAK;
      }
    }

    offset = sub(lsp[i], table[ind]);

    /* acos(lsp[i])= ind*512 + (slope_acos[ind]*offset >> 11) */

    L_tmp = L_mult(slope[ind], offset); /* L_tmp in Q28 */
    freq = add(shl(ind, 9), extract_l(L_shr(L_tmp, 12)));
    lsf[i] = mult(freq, 25736); /* 25736: 2.0*PI in Q12 */
#ifdef WMOPS
    move16();
#endif

  }
  return;
}

/*-------------------------------------------------------------*
 *  procedure G729EV_G729_Weight_Az                                        *
 *            ~~~~~~~~~                                        *
 * Weighting of LPC coefficients.                              *
 *   ap[i]  =  a[i] * (gamma ** i)                             *
 *                                                             *
 *-------------------------------------------------------------*/


void G729EV_G729_Weight_Az(Word16 a[],    /* (i) Q12 : a[m+1]  LPC coefficients             */
                           Word16 gamma,  /* (i) Q15 : Spectral expansion factor.           */
                           Word16 m,      /* (i)     : LPC order.                           */
                           Word16 ap[]    /* (o) Q12 : Spectral expanded LPC coefficients   */
    )
{
  Word16    i, fac;

  ap[0] = a[0];
  fac = gamma;
#ifdef WMOPS
  move16();
  move16();
#endif

  FOR(i = 1; i < m; i++)
  {
#ifdef WMOPS
    move16();
#endif
    ap[i] = round(L_mult(a[i], fac));
    fac = round(L_mult(fac, gamma));
  }
  ap[m] = round(L_mult(a[m], fac));
#ifdef WMOPS
  move16();
#endif

  return;
}

/*----------------------------------------------------------------------*
 * Function G729EV_G729_Int_qlpc() and Int_lpc()                                    *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                    *
 * Interpolation of the LPC parameters.                                 *
 *----------------------------------------------------------------------*/

/* Interpolation of the quantized LSP's */

void G729EV_G729_Int_qlpc(Word16 lsp_old[], /* input : LSP vector of past frame              */
                          Word16 lsp_new[], /* input : LSP vector of present frame           */
                          Word16 Az[]       /* output: interpolated Az() for the 2 subframes */
    )
{
  Word16    i;
  Word16    lsp[G729EV_G729_M];

  /*  lsp[i] = lsp_new[i] * 0.5 + lsp_old[i] * 0.5 */

  FOR(i = 0; i < G729EV_G729_M; i++)
  {
    lsp[i] = add(shr(lsp_new[i], 1), shr(lsp_old[i], 1));
#ifdef WMOPS
    move16();
#endif

  }

  G729EV_G729_Lsp_Az(lsp, Az);  /* Subframe 1 */

  G729EV_G729_Lsp_Az(lsp_new, &Az[G729EV_G729_MP1]);  /* Subframe 2 */

  return;
}

void G729EV_G729_Int_qlpc_bfi(Word16 lsp_old[], /* input : LSP vector of past frame              */
                              Word16 lsp_new[], /* input : LSP vector of present frame           */
                              Word16 Az[],  /* output: interpolated Az() for the 2 subframes */
                              Word16 * interpol_frac1)
{
  Word16    isp[G729EV_G729_M], fnew, fold, *p_a;
  Word16    i, k;

  p_a = Az;
  FOR(k = 0; k < G729EV_MAIN_NB_SUBFR; k++)
  {
    fnew = interpol_frac1[k];
#ifdef WMOPS
    move16();
#endif
    fold = sub(32767, fnew);

    FOR(i = 0; i < G729EV_G729_M; i++)
    {
      isp[i] = mac_r(L_mult(lsp_old[i], fold), lsp_new[i], fnew);
#ifdef WMOPS
      move16();
#endif
    }
    G729EV_G729_Lsp_Az(isp, p_a);
    p_a += (G729EV_G729_MP1);
  }
  return;
}

/*----------------------------------------------------------------------*
 * Function G729EV_G729_Int_lpc()                                                   *
 * ~~~~~~~~~~~~~~~~~~                                                   *
 * Interpolation of the unquantized LPC parameters.                     *
 * Same as the previous function but we do not recompute Az() for       *
 * subframe 2  because it is already available.                         *
 * We also compute the interpolate LSF (frequency domain).               *
 *----------------------------------------------------------------------*/

void G729EV_G729_Int_lpc(Word16 lsp_old[],  /* input : LSP vector of past frame              */
                         Word16 lsp_new[],  /* input : LSP vector of present frame           */
                         Word16 lsf_int[],  /* output: interpolated lsf coefficients         */
                         Word16 lsf_new[], Word16 Az[]  /* output: interpolated Az() for the 2 subframes */
    )
{
  Word16    i;
  Word16    lsp[G729EV_G729_M];

  /*  lsp[i] = lsp_new[i] * 0.5 + lsp_old[i] * 0.5 */

  FOR(i = 0; i < G729EV_G729_M; i++)
  {
    lsp[i] = add(shr(lsp_new[i], 1), shr(lsp_old[i], 1));
#ifdef WMOPS
    move16();
#endif

  }

  G729EV_G729_Lsp_Az(lsp, Az);

  G729EV_G729_Lsp_lsf(lsp, lsf_int, G729EV_G729_M); /* transformation from LSP to LSF (freq.domain) */
  G729EV_G729_Lsp_lsf(lsp_new, lsf_new, G729EV_G729_M); /* transformation from LSP to LSF (freq.domain) */

  return;
}
