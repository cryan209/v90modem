/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*-------------------------------------------------------------------*
 * Function  G729EV_G729_Convolve:                                   *
 *           ~~~~~~~~~                                               *
 *-------------------------------------------------------------------*
 * Perform the convolution between two vectors x[] and h[] and       *
 * write the result in the vector y[].                               *
 * All vectors are of length N.                                      *
 *-------------------------------------------------------------------*/

#include "stl.h"
#include "G729EV_G729_ld8k.h"

#ifdef WMOPS
#include "count.h"
#endif

/* Caution, The same function is the original ITU-T G.729 fixed point code 
   used x in Q0, the function was modified to support Q1 x inputs */

void G729EV_G729_Convolve(Word16 x[], /* (i) Q1  : input vector                           */
                          Word16 h[], /* (i) Q12 : impulse response                       */
                          Word16 y[], /* (o)     : output vector                          */
                          Word16 L    /* (i)     : vector size                            */
    )
{
  Word32    s;

  Word16    i, n;


  FOR(n = 0; n < L; n++)
  {
    s = 0;
#ifdef WMOPS
    move32();
#endif
    FOR(i = 0; i <= n; i++)
      s = L_mac(s, x[i], h[n - i]);

    /* This is different from the original G.729 fixe point code
       s = L_shl(s, 3); was replaced by s = L_shl(s, 2);
       to account for the fact that thi input x is in Q1 format (used to be Q0) */
    s = L_shl(s, 2);            /* h is in Q12 and saturation */
    y[n] = extract_h(s);
#ifdef WMOPS
    move16();
#endif
  }

  return;
}

/*-----------------------------------------------------*
 * procedure G729EV_G729_Syn_filt:                                 *
 *           ~~~~~~~~                                  *
 * Do the synthesis filtering 1/A(z).                  *
 *-----------------------------------------------------*/


void G729EV_G729_Syn_filt(Word16 a[],   /* (i) Q12 : a[m+1] prediction coefficients   (m=10)  */
                          Word16 x[],   /* (i)     : input signal                             */
                          Word16 y[],   /* (o)     : output signal                            */
                          Word16 lg,    /* (i)     : size of filtering                        */
                          Word16 mem[], /* (i/o)   : memory associated with this filtering.   */
                          Word16 update /* (i)     : 0=no update, 1=update of memory.         */
    )
{
  Word32    s;

  Word16    tmp[80];            /* This is usually done by memory allocation (lg+M) */

  Word16   *yy;

  Word16    i, j;

  /* Copy mem[] to yy[] */

  yy = tmp;
#ifdef WMOPS
  move16();
#endif

  FOR(i = 0; i < G729EV_G729_M; i++)
  {
    *yy++ = mem[i];
#ifdef WMOPS
    move16();
#endif
  }

  /* Do the filtering. */

  FOR(i = 0; i < lg; i++)
  {
    s = L_mult(x[i], a[0]);
    FOR(j = 1; j <= G729EV_G729_M; j++)
      s = L_msu(s, a[j], yy[-j]);

    s = L_shl(s, 3);
    *yy++ = round(s);
#ifdef WMOPS
    move16();
#endif
  }

  FOR(i = 0; i < lg; i++)
  {
    y[i] = tmp[i + G729EV_G729_M];
#ifdef WMOPS
    move16();
#endif
  }

  /* Update of memory if update==1 */

  IF(update != 0)
  {
    FOR(i = 0; i < G729EV_G729_M; i++)
    {
      mem[i] = y[lg - G729EV_G729_M + i];
#ifdef WMOPS
      move16();
#endif
    }
  }

  return;
}

/* same as G729EV_G729_Syn_filt except that the input x is in Q1 as the output remains in Q0 */

void G729EV_G729_Syn_filt2(Word16 a[],    /* (i) Q12 : a[m+1] prediction coefficients   (m=10)  */
                           Word16 x[],    /* (i)     : input signal                             */
                           Word16 y[],    /* (o)     : output signal                            */
                           Word16 lg,     /* (i)     : size of filtering                        */
                           Word16 mem[],  /* (i/o)   : memory associated with this filtering.   */
                           Word16 update  /* (i)     : 0=no update, 1=update of memory.         */
    )
{
  Word32    s;

  Word16    tmp[80];            /* This is usually done by memory allocation (lg+M) */

  Word16   *yy;

  Word16    i, j;

  /* Copy mem[] to yy[] */

  yy = tmp;

  FOR(i = 0; i < G729EV_G729_M; i++)
  {
    *yy++ = mem[i];
#ifdef WMOPS
    move16();
#endif
  }

  /* Do the filtering. */

  FOR(i = 0; i < lg; i++)
  {
    s = L_mult0(x[i], a[0]);
    FOR(j = 1; j <= G729EV_G729_M; j++)
      s = L_msu(s, a[j], yy[-j]);

    s = L_shl(s, 3);
    *yy++ = round(s);
#ifdef WMOPS
    move16();
#endif
  }

  FOR(i = 0; i < lg; i++)
  {
    y[i] = tmp[i + G729EV_G729_M];
#ifdef WMOPS
    move16();
#endif
  }

  /* Update of memory if update==1 */

  IF(update != 0)
  {
    FOR(i = 0; i < G729EV_G729_M; i++)
    {
      mem[i] = y[lg - G729EV_G729_M + i];
#ifdef WMOPS
      move16();
#endif
    }
  }

  return;
}


/*-----------------------------------------------------------------------*
 * procedure G729EV_G729_Residu:                                                     *
 *           ~~~~~~                                                      *
 * Compute the LPC residual  by filtering the input speech through A(z)  *
 *-----------------------------------------------------------------------*/

void      G729EV_G729_Residu(Word16 a[],  /* (i) Q12 : prediction coefficients                     */
                             Word16 x[],  /* (i)     : speech (values x[-m..-1] are needed         */
                             Word16 y[],  /* (o)     : residual signal                             */
                             Word16 lg    /* (i)     : size of filtering                           */
    )
{
  Word32    s;

  Word16    i, j;


  FOR(i = 0; i < lg; i++)
  {
    s = L_mult(x[i], a[0]);
    FOR(j = 1; j <= G729EV_G729_M; j++)
      s = L_mac(s, a[j], x[i - j]);

    s = L_shl(s, 3);
#ifdef WMOPS
    move16();
#endif
    y[i] = round(s);
  }

  return;
}

/* Same as G729EV_G729_Residu except the ouput is set to Q1 instead of Q0 */

void      G729EV_G729_Residu2(Word16 a[], /* (i) Q12 : prediction coefficients                     */
                              Word16 x[], /* (i)  Q0  : speech (values x[-m..-1] are needed         */
                              Word16 y[], /* (o)  Q1  : residual signal                             */
                              Word16 lg   /* (i)     : size of filtering                           */
    )
{
  Word32    s;

  Word16    i, j;


  FOR(i = 0; i < lg; i++)
  {
    s = L_mult(x[i], a[0]);
    FOR(j = 1; j <= G729EV_G729_M; j++)
      s = L_mac(s, a[j], x[i - j]);

    s = L_shl(s, 4);
#ifdef WMOPS
    move16();
#endif
    y[i] = round(s);
  }

  return;
}
