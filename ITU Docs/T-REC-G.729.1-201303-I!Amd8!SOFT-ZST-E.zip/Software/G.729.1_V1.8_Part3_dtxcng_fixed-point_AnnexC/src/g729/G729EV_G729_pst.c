/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

/************************************************************************/
/*      Post - filtering : short term + long term                       */
/************************************************************************/

#include "stl.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_MAIN_oper_32b.h"


/*----------------------------------------------------------------------------
 *  G729EV_G729_pst_ltp - harmonic postfilter
 *----------------------------------------------------------------------------
 */
void G729EV_G729_pst_ltp(Word16 t0,             /* input : pitch delay given by coder */
                         Word16 * ptr_sig_in,   /* input : postfilter input filter (residu2) */
                         Word16 * ptr_sig_pst0  /* output: harmonic postfilter output */
    )
{

/**** Declare variables                                 */
  Word32    L_temp;

  Word16    y_up[G729EV_G729_SIZ_Y_UP];
  Word16    sig_cadr[G729EV_G729_SIZ_RES2];

  Word16   *ptr_y_up;
  Word16   *ptr_sig;
  Word16   *ptr_sig_cadr;

  Word16    i;
  Word16    temp;
  Word16    ltpdel, phase;
  Word16    num_gltp, den_gltp;
  Word16    num2_gltp, den2_gltp;
  Word16    sh_num, sh_den;
  Word16    sh_num2, sh_den2;
  Word16    gain_plt;
  Word16    off_yup;
  Word16    nb_sh_sig;


  /* input signal justified on 13 bits */
#if (WMOPS)
  move16();
#endif
  ptr_sig = ptr_sig_in - G729EV_G729_MEM_RES2;

  temp = 0;
  FOR(i = 0; i < G729EV_G729_SIZ_RES2; i++)
  {
    temp = s_or(temp, abs_s(ptr_sig[i]));
  }
  nb_sh_sig = sub(3, norm_s(temp));

  FOR(i = 0; i < G729EV_G729_SIZ_RES2; i++)
  {                             /* nb_sh_sig may be >0, <0 or =0 */
#if (WMOPS)
    move16();
#endif
    sig_cadr[i] = shr(ptr_sig[i], nb_sh_sig);
  }
  ptr_sig_cadr = sig_cadr + G729EV_G729_MEM_RES2;

  /* Sub optimal delay search */
  G729EV_G729_search_del(t0, ptr_sig_cadr, &ltpdel, &phase, &num_gltp, &den_gltp, &sh_num, &sh_den, y_up, &off_yup);

  IF(num_gltp == 0)
  {
    G729EV_G729_Copy(ptr_sig_in, ptr_sig_pst0, G729EV_G729_L_SUBFR);
  }

  ELSE
  {
    IF(phase == 0)
    {
      ptr_y_up = ptr_sig_in - ltpdel;
    }

    ELSE
    {

      /* Filtering with long filter */
      G729EV_G729_compute_ltp_l(ptr_sig_cadr, ltpdel, phase, ptr_sig_pst0, &num2_gltp, &den2_gltp, &sh_num2, &sh_den2);

      IF(sub(G729EV_G729_select_ltp(num_gltp, den_gltp, sh_num, sh_den, num2_gltp, den2_gltp, sh_num2, sh_den2), 1) ==
         0)
      {

        /* select short filter */
        temp = sub(phase, 1);
        L_temp = L_mult(temp, G729EV_G729_L_SUBFRP1);
        L_temp = L_shr(L_temp, 1);
        temp = extract_l(L_temp);
        temp = add(temp, off_yup);

        /* ptr_y_up = y_up + (phase-1) * G729EV_G729_L_SUBFRP1 + off_yup */
        ptr_y_up = y_up + temp;
      }
      ELSE
      {
#if (WMOPS)
        move16();
        move16();
        move16();
        move16();
#endif
        /* select long filter */
        num_gltp = num2_gltp;
        den_gltp = den2_gltp;
        sh_num = sh_num2;
        sh_den = sh_den2;
        ptr_y_up = ptr_sig_pst0;
      }

      /* rescale y_up */
      FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
      {                         /* nb_sh_sig may be >0, <0 or =0 */
#if (WMOPS)
        move16();
#endif
        ptr_y_up[i] = shl(ptr_y_up[i], nb_sh_sig);
      }
    }

    temp = sub(sh_num, sh_den);
    IF(temp >= 0)
    {
      den_gltp = shr(den_gltp, temp);
    }
    ELSE
    {
      num_gltp = shl(num_gltp, temp); /*  >> (-temp) */
    }
    IF(sub(num_gltp, den_gltp) >= 0)
    {
#if (WMOPS)
      move16();
#endif
      /* beta bounded to 1 */
      gain_plt = G729EV_G729_MIN_GPLT;
    }
    ELSE
    {

      /* GAMMA_G = 0.5                                            */
      /* gain_plt = den_gltp x 2**15 / (den_gltp + 0.5 num_gltp)  */
      /* shift 1 bit to avoid overflows in add                    */
      num_gltp = shr(num_gltp, 2);
      den_gltp = shr(den_gltp, 1);
      temp = add(den_gltp, num_gltp);
      gain_plt = div_s(den_gltp, temp); /* Q15 */
    }

        /** filtering by H0(z) = harmonic filter **/
    G729EV_G729_filt_plt(ptr_sig_in, ptr_y_up, ptr_sig_pst0, gain_plt);

  }

  return;
}

/*----------------------------------------------------------------------------
 *  search_del: computes best (shortest) integer LTP delay + fine search
 *----------------------------------------------------------------------------
 */
void G729EV_G729_search_del(Word16 t0,            /* input : pitch delay given by coder */
                            Word16 * ptr_sig_in,  /* input : input signal (with delay line) */
                            Word16 * ltpdel,      /* output: delay = *ltpdel - *phase / f_up */
                            Word16 * phase,       /* output: phase */
                            Word16 * num_gltp,    /* output: 16 bits numerator of LTP gain */
                            Word16 * den_gltp,    /* output: 16 bits denominator of LTP gain */
                            Word16 * sh_num_gltp, /* output: justification for num_gltp */
                            Word16 * sh_den_gltp, /* output: justification for den_gltp */
                            Word16 * y_up,        /* output: LT delayed signal if fract. delay */
                            Word16 * off_yup      /* output: offset in y_up */
    )
{



  Word32    L_den0[G729EV_G729_F_UP_PST - 1];
  Word32    L_den1[G729EV_G729_F_UP_PST - 1];

  Word32   *ptr_L_den0, *ptr_L_den1;

  Word32    L_num_int, L_den_int, L_den_max;
  Word32    L_temp0, L_temp1;
  Word32    L_acc;
  Word32    L_temp;

  extern Word16 tab_hup_s[G729EV_G729_SIZ_TAB_HUP_S];

  Word16   *ptr_h;
  Word16   *ptr_sig_past, *ptr_sig_past0;
  Word16   *ptr1, *ptr_y_up;

  Word16    i, n;
  Word16    num, den0, den1;
  Word16    den_max, num_max;
  Word16    hi_numsq, hi_numsq_max;
  Word16    lo_numsq, lo_numsq_max;
  Word16    ener;
  Word16    sh_num, sh_den, sh_ener;
  Word16    i_max, lambda, phi, phi_max, ioff;
  Word16    temp;


  /*************************************/
  /* Computes energy of current signal */
    /*************************************/

#if (WMOPS)
  move32();
#endif
  L_acc = 0L;

  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    L_acc = L_mac(L_acc, ptr_sig_in[i], ptr_sig_in[i]);
  }
  if (L_acc == 0)
  {
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif
    *num_gltp = 0;
    *den_gltp = 1;
    *ltpdel = 0;
    *phase = 0;
    return;
  }
  sh_ener = sub(16, norm_l(L_acc));
  /* save energy for final decision */
  IF(sh_ener > 0)
  {
    ener = extract_l(L_shr(L_acc, sh_ener));
  }
  ELSE
  {
#if (WMOPS)
    move16();
#endif
    sh_ener = 0;
    ener = extract_l(L_acc);
  }

    /*************************************/
  /* Selects best of 3 integer delays  */
  /* Maximum of 3 numerators around t0 */
    /*************************************/
#if (WMOPS)
  move16();
  move32();
#endif
  lambda = sub(t0, 1);
  ptr_sig_past = ptr_sig_in - lambda;
  L_num_int = -1L;

  /* initialization used only to suppress Microsoft Visual C++ warnings */
#if (WMOPS)
  move16();
#endif
  i_max = (Word16) 0;

  FOR(i = 0; i < 3; i++)
  {
#if (WMOPS)
    move32();
#endif
    L_acc = 0L;
    FOR(n = 0; n < G729EV_G729_L_SUBFR; n++)
    {
      L_acc = L_mac(L_acc, ptr_sig_in[n], ptr_sig_past[n]);
    }
    if (L_acc < 0)
    {
#if (WMOPS)
      move32();
#endif
      L_acc = 0L;
    }
    L_temp = L_sub(L_acc, L_num_int);
    if (L_temp > 0L)
    {
#if (WMOPS)
      move16();
      move32();
#endif
      L_num_int = L_acc;
      i_max = (Word16) i;
    }
    ptr_sig_past--;
  }

  if (L_num_int == 0)
  {
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif
    *num_gltp = 0;
    *den_gltp = 1;
    *ltpdel = 0;
    *phase = 0;
    return;
  }

  /* Compute den for i_max */
  lambda = add(lambda, (Word16) i_max);
#if (WMOPS)
  move32();
#endif
  ptr_sig_past = ptr_sig_in - lambda;
  L_acc = 0L;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
#if (WMOPS)
    move16();
#endif
    temp = *ptr_sig_past++;
    L_acc = L_mac(L_acc, temp, temp);
  }
  if (L_acc == 0L)
  {
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif
    *num_gltp = 0;
    *den_gltp = 1;
    *ltpdel = 0;
    *phase = 0;
    return;
  }
#if (WMOPS)
  move32();
#endif
  L_den_int = L_acc;


    /***********************************/
  /* Select best phase around lambda */
    /***********************************/

  /* Compute y_up & denominators */
    /*******************************/

#if (WMOPS)
  move32();
#endif
  ptr_y_up = y_up;
  L_den_max = L_den_int;
  ptr_L_den0 = L_den0;
  ptr_L_den1 = L_den1;
  ptr_h = tab_hup_s;
  temp = sub(lambda, G729EV_G729_LH_UP_SM1);
  ptr_sig_past0 = ptr_sig_in - temp;

  /* Loop on phase */
  FOR(phi = 1; phi < G729EV_G729_F_UP_PST; phi++)
  {

    /* Compute y_up for lambda+1 - phi/F_UP_PST */
    /* and lambda - phi/F_UP_PST                */

    ptr_sig_past = ptr_sig_past0;
    FOR(n = 0; n <= G729EV_G729_L_SUBFR; n++)
    {
#if (WMOPS)
      move16();
      move32();
#endif
      ptr1 = ptr_sig_past++;
      L_acc = 0L;

      FOR(i = 0; i < G729EV_G729_LH2_S; i++)
      {
        L_acc = L_mac(L_acc, ptr_h[i], ptr1[-i]);
      }
#if (WMOPS)
      move16();
#endif
      ptr_y_up[n] = round(L_acc);
    }

    /* compute den0 (lambda+1) and den1 (lambda) */

    /* part common to den0 and den1 */
#if (WMOPS)
    move32();
#endif
    L_acc = 0L;
    FOR(n = 1; n < G729EV_G729_L_SUBFR; n++)
    {
      L_acc = L_mac(L_acc, ptr_y_up[n], ptr_y_up[n]);
    }
#if (WMOPS)
    move32();
#endif
    L_temp0 = L_acc;            /* saved for den1 */

    /* den0 */
    L_acc = L_mac(L_acc, ptr_y_up[0], ptr_y_up[0]);
#if (WMOPS)
    move32();
#endif
    *ptr_L_den0 = L_acc;

    /* den1 */
    L_acc = L_mac(L_temp0, ptr_y_up[G729EV_G729_L_SUBFR], ptr_y_up[G729EV_G729_L_SUBFR]);
#if (WMOPS)
    move32();
#endif
    *ptr_L_den1 = L_acc;

    IF(sub(abs_s(ptr_y_up[0]), abs_s(ptr_y_up[G729EV_G729_L_SUBFR])) > 0)
    {
      L_temp = L_sub(*ptr_L_den0, L_den_max);
      if (L_temp > 0L)
      {
#if (WMOPS)
        move32();
#endif
        L_den_max = *ptr_L_den0;
      }
    }
    ELSE
    {
      L_temp = L_sub(*ptr_L_den1, L_den_max);
      if (L_temp > 0L)
      {
#if (WMOPS)
        move32();
#endif
        L_den_max = *ptr_L_den1;
      }
    }
    ptr_L_den0++;
    ptr_L_den1++;
    ptr_y_up += G729EV_G729_L_SUBFRP1;
    ptr_h += G729EV_G729_LH2_S;
  }

  if (L_den_max == 0)
  {
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif
    *num_gltp = 0;
    *den_gltp = 1;
    *ltpdel = 0;
    *phase = 0;

    return;
  }

  sh_den = sub(16, norm_l(L_den_max));
  /* if sh_den <= 0 :  dynamic between current frame */
  /* and delay line too high                         */
  if (sh_den <= 0)
  {
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif
    *num_gltp = 0;
    *den_gltp = 1;
    *ltpdel = 0;
    *phase = 0;
    return;
  }

  /* search sh_num to justify correlations   */
  /* sh_num = Max(sh_den, sh_ener)           */
  IF(sub(sh_den, sh_ener) >= 0)
  {
    sh_num = sh_den;
  }
  ELSE
  {
    sh_num = sh_ener;
  }
#if (WMOPS)
  move16();
#endif

  /* Computation of the numerators                */
  /* and selection of best num*num/den            */
  /* for non null phases                          */

  /* Initialize with null phase */
  L_acc = L_shr(L_den_int, sh_den); /* sh_den > 0 */
  den_max = extract_l(L_acc);
  L_acc = L_shr(L_num_int, sh_num); /* sh_num > 0 */
  num_max = extract_l(L_acc);
  L_acc = L_mult(num_max, num_max);
  L_Extract(L_acc, &hi_numsq_max, &lo_numsq_max);
#if (WMOPS)
  move16();
  move16();
#endif
  phi_max = 0;
  ioff = 1;

  ptr_L_den0 = L_den0;
  ptr_L_den1 = L_den1;
  ptr_y_up = y_up;


  /* if den_max = 0 : will be selected and declared unvoiced */
  /* if num!=0 & den=0 : will be selected and declared unvoiced */
  /* degenerated seldom cases, switch off LT is OK */

  /* Loop on phase */
  FOR(phi = 1; phi < G729EV_G729_F_UP_PST; phi++)
  {

#if (WMOPS)
    move32();
#endif
    /* compute num for lambda+1 - phi/F_UP_PST */
    L_acc = 0L;
    FOR(n = 0; n < G729EV_G729_L_SUBFR; n++)
    {
      L_acc = L_mac(L_acc, ptr_sig_in[n], ptr_y_up[n]);
    }
    L_acc = L_shr(L_acc, sh_num); /* sh_num > 0 */
    IF(L_acc < 0L)
    {
#if (WMOPS)
      move16();
#endif
      num = 0;
    }
    ELSE
    {
      num = extract_l(L_acc);
    }

    /* selection if num**2/den0 max */
    L_acc = L_mult(num, num);
    L_Extract(L_acc, &hi_numsq, &lo_numsq);
    L_temp0 = Mpy_32_16(hi_numsq, lo_numsq, den_max);
#if (WMOPS)
    move32();
#endif
    L_acc = *ptr_L_den0++;
    L_acc = L_shr(L_acc, sh_den); /* sh_den > 0 */
    den0 = extract_l(L_acc);
    L_temp1 = Mpy_32_16(hi_numsq_max, lo_numsq_max, den0);
    L_temp = L_sub(L_temp0, L_temp1);
    if (L_temp > 0L)
    {
#if (WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
#endif
      num_max = num;
      hi_numsq_max = hi_numsq;
      lo_numsq_max = lo_numsq;
      den_max = den0;
      ioff = 0;
      phi_max = phi;
    }

    /* compute num for lambda - phi/F_UP_PST */
    ptr_y_up++;
#if (WMOPS)
    move32();
#endif
    L_acc = 0L;

    FOR(n = 0; n < G729EV_G729_L_SUBFR; n++)
    {
      L_acc = L_mac(L_acc, ptr_sig_in[n], ptr_y_up[n]);
    }
    L_acc = L_shr(L_acc, sh_num); /* sh_num > 0 */
    IF(L_acc < 0L)
    {
#if (WMOPS)
      move16();
#endif
      num = 0;
    }
    ELSE
    {
      num = extract_l(L_acc);
    }

    /* selection if num**2/den1 max */
    L_acc = L_mult(num, num);
    L_Extract(L_acc, &hi_numsq, &lo_numsq);
    L_temp0 = Mpy_32_16(hi_numsq, lo_numsq, den_max);
#if (WMOPS)
    move32();
#endif
    L_acc = *ptr_L_den1++;
    L_acc = L_shr(L_acc, sh_den); /* sh_den > 0 */
    den1 = extract_l(L_acc);
    L_temp1 = Mpy_32_16(hi_numsq_max, lo_numsq_max, den1);
    L_temp = L_sub(L_temp0, L_temp1);
    if (L_temp > 0L)
    {
#if (WMOPS)
      move16();
      move16();
      move16();
      move16();
      move16();
      move16();
#endif
      num_max = num;
      hi_numsq_max = hi_numsq;
      lo_numsq_max = lo_numsq;
      den_max = den1;
      ioff = 1;
      phi_max = phi;
    }

    ptr_y_up += G729EV_G729_L_SUBFR;
  }

    /***************************************************/
    /*** test if normalized crit0[iopt] > THRESHCRIT ***/
    /***************************************************/
#if (WMOPS)
  test();
#endif
  if ((num_max == 0) || (sub(den_max, 1) <= 0))
  {
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif
    *num_gltp = 0;
    *den_gltp = 1;
    *ltpdel = 0;
    *phase = 0;
    return;
  }

  /* compare num**2               */
  /* to ener * den * 0.5          */
  /* (THRESHCRIT = 0.5)           */
  L_temp1 = L_mult(den_max, ener);
  L_temp0 = L_Comp(hi_numsq_max, lo_numsq_max);

  /* temp = 2 * sh_num - sh_den - sh_ener + 1 */
  /* 16 bits with no overflows  */
  temp = shl(sh_num, 1);
  temp = sub(temp, sh_den);
  temp = sub(temp, sh_ener);
  temp = add(temp, 1);
  IF(temp < 0)
  {
    temp = negate(temp);        /* no overflow */
    L_temp0 = L_shr(L_temp0, temp);
  }
  ELSE
  {
    if (temp > 0)
      L_temp1 = L_shr(L_temp1, temp);
  }
  L_temp = L_sub(L_temp0, L_temp1);
  IF(L_temp >= 0L)
  {
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
    move16();
    move16();
#endif
    temp = add(lambda, 1);
    *ltpdel = sub(temp, ioff);
    *off_yup = ioff;
    *phase = phi_max;
    *num_gltp = num_max;
    *den_gltp = den_max;
    *sh_den_gltp = sh_den;
    *sh_num_gltp = sh_num;
  }
  ELSE
  {
#if (WMOPS)
    move16();
    move16();
    move16();
    move16();
#endif
    *num_gltp = 0;
    *den_gltp = 1;
    *ltpdel = 0;
    *phase = 0;
  }
  return;

}

/*----------------------------------------------------------------------------
 *  filt_plt -  ltp  postfilter
 *----------------------------------------------------------------------------
 */
void G729EV_G729_filt_plt(Word16 * s_in,  /* input : input signal with past */
                          Word16 * s_ltp, /* input : filtered signal with gain 1 */
                          Word16 * s_out, /* output: output signal */
                          Word16 gain_plt /* input : filter gain  */
    )
{

  /* Local variables */
  Word32    L_acc;

  Word16    n;
  Word16    gain_plt_1;

  gain_plt_1 = sub(32767, gain_plt);
  gain_plt_1 = add(gain_plt_1, 1);  /* 2**15 (1 - g) */

  FOR(n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
    /* s_out(n) = gain_plt x s_in(n) + gain_plt_1 x s_ltp(n)        */
    L_acc = L_mult(gain_plt, s_in[n]);
    L_acc = L_mac(L_acc, gain_plt_1, s_ltp[n]); /* no overflow      */
#if (WMOPS)
    move16();
#endif
    s_out[n] = round(L_acc);
  }

  return;
}


/*----------------------------------------------------------------------------
 *  G729EV_G729_compute_ltp_l : compute delayed signal,
                    num & den of gain for fractional delay
 *                  with long interpolation filter
 *----------------------------------------------------------------------------
 */
void G729EV_G729_compute_ltp_l(Word16 * s_in, /* input signal with past */
                               Word16 ltpdel, /* delay factor */
                               Word16 phase,  /* phase factor */
                               Word16 * y_up, /* delayed signal */
                               Word16 * num,  /* numerator of LTP gain */
                               Word16 * den,  /* denominator of LTP gain */
                               Word16 * sh_num, /* justification factor of num */
                               Word16 * sh_den  /* justification factor of den */
    )
{

  Word32    L_acc;

  extern Word16 tab_hup_l[G729EV_G729_SIZ_TAB_HUP_L];

  Word16   *ptr2;
  Word16   *ptr_h;

  Word16    n, i;
  Word16    temp;

  temp = sub(phase, 1);
  temp = shl(temp, G729EV_G729_L2_LH2_L);
  ptr_h = tab_hup_l + temp;     /* tab_hup_l + G729EV_G729_LH2_L * (phase-1) */

  temp = sub(G729EV_G729_LH_UP_L, ltpdel);
  ptr2 = s_in + temp;;

  /* Compute y_up */
  FOR(n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
#if (WMOPS)
    move32();
    move16();
#endif
    L_acc = 0L;
    FOR(i = 0; i < G729EV_G729_LH2_L; i++)
    {
      L_acc = L_mac(L_acc, ptr_h[i], (*ptr2--));
    }
    y_up[n] = round(L_acc);
    ptr2 += G729EV_G729_LH2_L_P1;
  }


  /* Compute num */
#if (WMOPS)
  move32();
#endif
  L_acc = 0L;
  FOR(n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
    L_acc = L_mac(L_acc, y_up[n], s_in[n]);
  }
  IF(L_acc < 0L)
  {
#if (WMOPS)
    move16();
    move16();
#endif
    *num = 0;
    *sh_num = 0;
  }
  ELSE
  {
    temp = sub(16, norm_l(L_acc));
    if (temp < 0)
    {
#if (WMOPS)
      move16();
#endif
      temp = 0;
    }
    L_acc = L_shr(L_acc, temp); /* with temp >= 0 */
    *num = extract_l(L_acc);
    *sh_num = temp;
#if (WMOPS)
    move16();
    move16();
#endif
  }

  /* Compute den */
#if (WMOPS)
  move32();
#endif
  L_acc = 0L;
  FOR(n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
    L_acc = L_mac(L_acc, y_up[n], y_up[n]);
  }
  temp = sub(16, norm_l(L_acc));
  if (temp < 0)
  {
#if (WMOPS)
    move16();
#endif
    temp = 0;
  }
  L_acc = L_shr(L_acc, temp);   /* with temp >= 0 */
  *den = extract_l(L_acc);
  *sh_den = temp;
#if (WMOPS)
  move16();
  move16();
#endif

  return;
}

/*----------------------------------------------------------------------------
 *  G729EV_G729_select_ltp : selects best of (gain1, gain2)
 *  with gain1 = num1 * 2** sh_num1 / den1 * 2** sh_den1
 *  and  gain2 = num2 * 2** sh_num2 / den2 * 2** sh_den2
 *----------------------------------------------------------------------------
 */
Word16 G729EV_G729_select_ltp(  /* output : 1 = 1st gain, 2 = 2nd gain */
                               Word16 num1, /* input : numerator of gain1 */
                               Word16 den1, /* input : denominator of gain1 */
                               Word16 sh_num1,  /* input : just. factor for num1 */
                               Word16 sh_den1,  /* input : just. factor for den1 */
                               Word16 num2, /* input : numerator of gain2 */
                               Word16 den2, /* input : denominator of gain2 */
                               Word16 sh_num2,  /* input : just. factor for num2 */
                               Word16 sh_den2)  /* input : just. factor for den2 */
{
  Word32    L_temp1, L_temp2;
  Word32    L_temp;

  Word16    temp1, temp2;
  Word16    hi, lo;


  if (den2 == 0)
  {

    return (1);
  }

  /* compares criteria = num**2/den */
  L_temp1 = L_mult(num1, num1);
  L_Extract(L_temp1, &hi, &lo);
  L_temp1 = Mpy_32_16(hi, lo, den2);

  L_temp2 = L_mult(num2, num2);
  L_Extract(L_temp2, &hi, &lo);
  L_temp2 = Mpy_32_16(hi, lo, den1);

  /* temp1 = sh_den2 + 2 * sh_num1 */
  temp1 = shl(sh_num1, 1);
  temp1 = add(temp1, sh_den2);
  /* temp2 = sh_den1 + 2 * sh_num2; */
  temp2 = shl(sh_num2, 1);
  temp2 = add(temp2, sh_den1);

  IF(sub(temp2, temp1) > 0)
  {
    temp2 = sub(temp2, temp1);
    L_temp1 = L_shr(L_temp1, temp2);  /* temp2 > 0 */
  }
  ELSE
  {
    IF(sub(temp1, temp2) > 0)
    {
      temp1 = sub(temp1, temp2);
      L_temp2 = L_shr(L_temp2, temp1);  /* temp1 > 0 */
    }
  }

  L_temp = L_sub(L_temp2, L_temp1);
  IF(L_temp > 0L)
  {

    return (2);
  }
  ELSE
  {

    return (1);
  }
}

/*----------------------------------------------------------------------------
 *   G729EV_G729_calc_st_filt -  computes impulse response of A(gamma2) / A(gamma1)
 *   controls gain : computation of energy impulse response as
 *                    SUMn  (abs (h[n])) and computes parcor0
 *----------------------------------------------------------------------------
 */
void G729EV_G729_calc_st_filt(Word16 * apond2,  /* input : coefficients of numerator */
                              Word16 * apond1,  /* input : coefficients of denominator */
                              Word16 * parcor0, /* output: 1st parcor calcul. on composed filter */
                              Word16 * sig_ltp_ptr, /* in/out: input of 1/A(gamma1) : scaled by 1/g0 */
                              Word16 * mem_zero)
{
  Word32    L_temp, L_g0;

  Word16    h[G729EV_G729_LONG_H_ST];

  Word16    g0, temp;
  Word16    i;

  /* compute i.r. of composed filter apond2 / apond1 */
  G729EV_G729_Syn_filt(apond1, apond2, h, G729EV_G729_LONG_H_ST, mem_zero, 0);

  /* compute 1st parcor */
  G729EV_G729_calc_rc0_h(h, parcor0);

  /* compute g0 */
#if (WMOPS)
  move32();
#endif
  L_g0 = 0L;
  FOR(i = 0; i < G729EV_G729_LONG_H_ST; i++)
  {
    L_temp = L_deposit_l(abs_s(h[i]));
    L_g0 = L_add(L_g0, L_temp);
  }
  g0 = extract_h(L_shl(L_g0, 14));

  /* Scale signal input of 1/A(gamma1) */
  IF(sub(g0, 1024) > 0)
  {
    temp = div_s(1024, g0);     /* temp = 2**15 / gain0 */
    FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
#if (WMOPS)
      move16();
#endif
      sig_ltp_ptr[i] = mult_r(sig_ltp_ptr[i], temp);
    }
  }

  return;
}

/*----------------------------------------------------------------------------
 * G729EV_G729_calc_rc0_h - computes 1st parcor from composed filter impulse response
 *----------------------------------------------------------------------------
 */
void G729EV_G729_calc_rc0_h(Word16 * h, /* input : impulse response of composed filter */
                            Word16 * rc0  /* output: 1st parcor */
    )
{
  Word32    L_acc;

  Word16   *ptrs;

  Word16    acf0, acf1;
  Word16    temp, sh_acf;
  Word16    i;


  /* computation of the autocorrelation function acf */
#if (WMOPS)
  move32();
#endif
  L_acc = 0L;
  FOR(i = 0; i < G729EV_G729_LONG_H_ST; i++)
  {
    L_acc = L_mac(L_acc, h[i], h[i]);
  }
  sh_acf = norm_l(L_acc);
  L_acc = L_shl(L_acc, sh_acf);
  acf0 = extract_h(L_acc);

#if (WMOPS)
  move32();
#endif
  L_acc = 0L;
  ptrs = h;

  FOR(i = 0; i < G729EV_G729_LONG_H_ST - 1; i++)
  {
#if (WMOPS)
    move16();
#endif
    temp = *ptrs++;
    L_acc = L_mac(L_acc, temp, *ptrs);
  }
  L_acc = L_shl(L_acc, sh_acf);
  acf1 = extract_h(L_acc);

  /* Compute 1st parcor */
    /**********************/
  if (sub(acf0, abs_s(acf1)) < 0)
  {
#if (WMOPS)
    move16();
#endif
    *rc0 = 0;
    return;
  }
#if (WMOPS)
  move16();
#endif
  *rc0 = div_s(abs_s(acf1), acf0);
  if (acf1 > 0)
  {
    *rc0 = negate(*rc0);
#if (WMOPS)
    move16();
#endif
  }

  return;
}


/*----------------------------------------------------------------------------
 * G729EV_G729_filt_mu - tilt filtering with : (1 + mu z-1) * (1/1-|mu|)
 *   computes y[n] = (1/1-|mu|) (x[n]+mu*x[n-1])
 *----------------------------------------------------------------------------
 */
extern Word16 saturate(Word32 L_var1);
void G729EV_G729_filt_mu(Word16 * sig_in, /* input : input signal (beginning at sample -1) */
                         Word16 * sig_out,  /* output: output signal */
                         Word16 parcor0 /* input : parcor0 (mu = parcor0 * gamma3) */
    )
{
  Word32    L_acc, L_temp, L_fact;

  Word16   *ptrs;

  Word16    n;
  Word16    mu, mu2, ga, temp;
  Word16    fact, sh_fact;
  Word16    temp_hi, temp_lo;


#if (WMOPS)
  move16();
  move16();
  move32();
#endif
  IF(parcor0 > 0)
  {
    mu = mult_r(parcor0, G729EV_G729_GAMMA3_PLUS);
    /* G729EV_G729_GAMMA3_PLUS < 0.5 */
    sh_fact = 14;               /* sh_fact */
    fact = (Word16) 0x4000;     /* 2**sh_fact */
    L_fact = (Word32) 0x00002000L;  /* fact >> 1 */
  }
  ELSE
  {
    mu = mult_r(parcor0, G729EV_G729_GAMMA3_MINUS);
    /* G729EV_G729_GAMMA3_MINUS < 0.9375 */
    sh_fact = 11;               /* sh_fact */
    fact = (Word16) 0x0800;     /* 2**sh_fact */
    L_fact = (Word32) 0x00000400L;  /* fact >> 1 */
  }

  temp = sub(1, abs_s(mu));
  mu2 = add(32767, temp);       /* 2**15 (1 - |mu|) */
  ga = div_s(fact, mu2);        /* 2**sh_fact / (1 - |mu|) */

  ptrs = sig_in;                /* points on sig_in(-1) */

  FOR(n = 0; n < G729EV_G729_L_SUBFR; n++)
  {
#if (WMOPS)
    move16();
#endif
    temp = *ptrs++;
    L_temp = L_deposit_l(*ptrs);
    L_acc = L_shl(L_temp, 15);  /* sig_in(n) * 2**15 */
    L_temp = L_mac0(L_acc, mu, temp);

    L_Extract(L_temp, &temp_hi, &temp_lo);
    L_temp = L_add(Mpy_32_16(temp_hi, temp_lo, ga), L_fact);
    L_temp = L_shr(L_temp, sh_fact);  /* mult. temp x ga */

#if (WMOPS)
    move16();
#endif
    sig_out[n] = saturate(L_temp);
  }
  return;
}

/*----------------------------------------------------------------------------
 *   G729EV_G729_scale_st  - control of the subframe gain
 *   gain[n] = G729EV_G729_AGC_FAC * gain[n-1] + (1 - AGC_FAC) g_in/g_out
 *----------------------------------------------------------------------------
 */
void G729EV_G729_scale_st(Word16 * sig_in,    /* input : postfilter input signal */
                          Word16 * sig_out,     /* in/out: postfilter output signal */
                          Word16 * gain_prec,   /* in/out: last value of gain for subframe */
                          Word16 parcor0, 
                          Word16 PostNB, 
                          Word32 * Level_in_sm,
                          Word16 indication     /*input: indicatate for noise or not*/
                          )
{
  Word32    L_acc, L_temp;
  Word16    hi, lo;
  Word16    i, k;
  Word16    scal_in, scal_out;
  Word16    s_g_in, s_g_out, temp, sh_g0, g0;
  Word16    gain = 0;
  Word16    Cond;

  /* compute input gain */
#if (WMOPS)
  move32();
#endif
  L_acc = 0L;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    L_temp = L_abs(L_deposit_l(sig_in[i]));
    L_acc = L_add(L_acc, L_temp);
  }

  /* Smooth level */
#if (WMOPS)
  move32();
  move32();
#endif
  temp = shl(indication, 1);
    *Level_in_sm = L_add(L_shr(L_add(*Level_in_sm, (Word32) indication), 1), L_shr(L_add(*Level_in_sm, (Word32) temp), 2));
    *Level_in_sm = L_add(*Level_in_sm, L_shr(L_add(L_acc, (Word32) temp), 2));
     
#if (WMOPS)
  test();
  test();
  test();
#endif
  /* Detect silence */
  IF(indication == 0)
    Cond = (L_sub(*Level_in_sm, 1024) < 0) && (L_sub(L_acc, L_shl(*Level_in_sm, 1)) < 0) && (sub(parcor0, 512) < 0);
  ELSE
  {
    L_Extract(*Level_in_sm, &hi, &lo);
    L_temp=L_add(L_shr_r(Mpy_32_16(hi, lo, 26214), 3), *Level_in_sm);
    Cond = (L_sub(*Level_in_sm, 256) < 0) && (L_sub(L_acc, L_temp) < 0) && (sub(parcor0, 512) < 0);  
  }
    
  /* If silence is detected, replace the original level with smoothed level */
  IF ((sub(Cond, 1) == 0) && (L_sub(*Level_in_sm,L_acc)<0))
  {
#if (WMOPS)
    move32();
#endif
    L_acc = *Level_in_sm;
  }

  IF(L_acc == 0L)
  {
#if (WMOPS)
    move16();
#endif
    g0 = 0;
  }
  ELSE
  {
    scal_in = norm_l(L_acc);
    L_acc = L_shl(L_acc, scal_in);
    s_g_in = extract_h(L_acc);  /* normalized */

    /* Compute output gain */
#if (WMOPS)
    move32();
#endif
    L_acc = 0L;
    FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      L_temp = L_abs(L_deposit_l(sig_out[i]));
      L_acc = L_add(L_acc, L_temp);
    }
    if (L_acc == 0L)
    {
#if (WMOPS)
      move16();
#endif
      *gain_prec = 0;
      return;
    }
    scal_out = norm_l(L_acc);
    L_acc = L_shl(L_acc, scal_out);
    s_g_out = extract_h(L_acc); /* normalized */

    sh_g0 = add(scal_in, 1);
    sh_g0 = sub(sh_g0, scal_out); /* scal_in - scal_out + 1 */
    IF(sub(s_g_in, s_g_out) < 0)
    {
      g0 = div_s(s_g_in, s_g_out);  /* s_g_in/s_g_out in Q15 */
    }
    ELSE
    {
      temp = sub(s_g_in, s_g_out);  /* sufficient since normalized */
      g0 = shr(div_s(temp, s_g_out), 1);
      g0 = add(g0, (Word16) 0x4000);  /* s_g_in/s_g_out in Q14 */
      sh_g0 = sub(sh_g0, 1);
    }
    /* L_gain_in/L_gain_out in Q14              */
    /* overflows if L_gain_in > 2 * L_gain_out  */
    g0 = shr(g0, sh_g0);        /* sh_g0 may be >0, <0, or =0 */

	indication = shl(indication, 1);
    IF(sub(Cond, 1) == 0)
    {                           /* Apply a gain reduction for silence; the gain is defined as
                                   gain = (Level_in_sm/MAX_SILENCE_LEVEL)*k1  +  (1-k1);
                                   k1 (0=<k1<=1) is a function of PARCOR0 */
      /* k1 in Q15 */
      temp = sub(512, parcor0);
	  k = sub(shr(2048, indication), 1);
	  if (L_sub(temp, k) > 0)
		  temp = k;
#if (WMOPS)
          move16();
#endif
	  temp = shl(temp, add(indication, 4));

      /* gain = (Level_in_sm/MAX_SILENCE_LEVEL) in Q15 */
	  k = sub(shr(1024, indication), 1);
	  IF (L_sub(*Level_in_sm, k) > 0)
	  {
		  gain = k;
#if (WMOPS)
          move16();
#endif
	  }
	  ELSE
		  gain = extract_l(*Level_in_sm);
	  gain = shl(gain, add(indication, 5));

      /* gain = gain*k1 + 1-k1 */
      gain = mult_r(gain, temp);
      gain = add(gain, sub(32767, temp));

      gain = mult_r(gain, sub(32767, PostNB));
      gain = add(gain, PostNB);

      g0 = mult_r(g0, gain);
    }

    g0 = mult_r(g0, G729EV_G729_AGC_FAC1);  /* L_gain_in/L_gain_out * AGC_FAC1 */

  }

  /* gain(n) = G729EV_G729_AGC_FAC gain(n-1) + G729EV_G729_AGC_FAC1 gain_in/gain_out          */
  /* sig_out(n) = gain(n) sig_out(n)                                  */
#if (WMOPS)
  move16();
#endif
  gain = *gain_prec;
  FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    temp = mult_r(G729EV_G729_AGC_FAC, gain);
    gain = add(temp, g0);       /* in Q14 */
    L_temp = L_mult(gain, sig_out[i]);
    L_temp = L_shl(L_temp, 1);
#if (WMOPS)
    move16();
#endif
    sig_out[i] = round(L_temp);
  }
#if (WMOPS)
  move16();
#endif
  *gain_prec = gain;

  return;
}
