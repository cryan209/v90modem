/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "stl.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_FEC_tools.h"

#ifdef WMOPS
#include "count.h"
#endif


/*----------------------------------------------------------------------------
 * G729EV_G729_Lsp_decw_reset -   set the previous LSP vectors
 *----------------------------------------------------------------------------
 */
void G729EV_G729_Lsp_decw_reset(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                Word16 prev_lsp[G729EV_G729_M], Word16 * prev_ma)
{
  Word16    i;

  FOR(i = 0; i < G729EV_G729_MA_NP; i++)
    G729EV_G729_Copy(&freq_prev_reset[0], &freq_prev[i][0], G729EV_G729_M);

  *prev_ma = 0;
#ifdef WMOPS
  move16();
#endif

  G729EV_G729_Copy(freq_prev_reset, prev_lsp, G729EV_G729_M);
}



/*----------------------------------------------------------------------------
 * G729EV_G729_Lsp_iqua_cs -  LSP main quantization routine
 *----------------------------------------------------------------------------
 */
Word16 G729EV_G729_Lsp_iqua_cs(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], Word16 prev_lsp[G729EV_G729_M], Word16 * prev_ma, Word16 prm[],  /* (i)     : indexes of the selected LSP */
                               Word16 lsp_q[],  /* (o) Q13 : Quantized LSP parameters    */
                               Word16 erase     /* (i)     : frame erase information     */
    )
{
  Word16    buf[G729EV_G729_M]; /* Q13 */

  Word16    mode_index;
  Word16    code0;
  Word16    code1;
  Word16    code2;
  Word16    tmp16 = 0;


  IF(erase == 0)
  {                             /* Not frame erasure */
    mode_index = s_and(shr(prm[0], G729EV_G729_NC0_B), (Word16) 1);
    code0 = s_and(prm[0], (Word16) (G729EV_G729_NC0 - 1));
    code1 = s_and(shr(prm[1], G729EV_G729_NC1_B), (Word16) (G729EV_G729_NC1 - 1));
    code2 = s_and(prm[1], (Word16) (G729EV_G729_NC1 - 1));

    /* compose quantized LSP (lsp_q) from indexes */
    G729EV_G729_Lsp_get_quant(lspcb1, lspcb2, code0, code1, code2,
                              fg[mode_index], freq_prev, lsp_q, fg_sum[mode_index]);

    tmp16 = G729EV_FEC_Lsf_stab(lsp_q, prev_lsp);

    /* save parameters to use in case of the frame erased situation */
    G729EV_G729_Copy(lsp_q, prev_lsp, G729EV_G729_M);
    *prev_ma = mode_index;
#ifdef WMOPS
    move16();
#endif
  }
  ELSE      IF(sub(erase, -1) == 0) /* Frame erased but look for next filter */
  {
    Word16    j;

    mode_index = s_and(shr(prm[0], G729EV_G729_NC0_B), (Word16) 1);
    code0 = s_and(prm[0], (Word16) (G729EV_G729_NC0 - 1));
    code1 = s_and(shr(prm[1], G729EV_G729_NC1_B), (Word16) (G729EV_G729_NC1 - 1));
    code2 = s_and(prm[1], (Word16) (G729EV_G729_NC1 - 1));

    FOR(j = 0; j < G729EV_G729_NC; j++)
    {
      buf[j] = add(lspcb1[code0][j], lspcb2[code1][j]);
#ifdef WMOPS
      move16();
#endif
    }

    FOR(j = G729EV_G729_NC; j < G729EV_G729_M; j++)
    {
      buf[j] = add(lspcb1[code0][j], lspcb2[code2][j]);
#ifdef WMOPS
      move16();
#endif
    }

    /* interpol old and new filter */
    FOR(j = 0; j < G729EV_G729_M; j++)
    {
      buf[j] = mac_r(L_mult(buf[j], 6554), freq_prev[0][j], 26214);
#ifdef WMOPS
      move16();
#endif
    }

    /* check */
    G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP1);
    G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP2);


    /* reconstruct quantized LSP parameters */
    G729EV_G729_Lsp_prev_compose(buf, lsp_q, fg[mode_index], freq_prev, fg_sum[mode_index]);

    G729EV_G729_Lsp_prev_update(buf, freq_prev);

    G729EV_G729_Lsp_stability(lsp_q);

    G729EV_G729_Copy(lsp_q, prev_lsp, G729EV_G729_M);
    *prev_ma = mode_index;
#ifdef WMOPS
    move16();
#endif
  }
  ELSE
  {                             /* Frame erased */
    /* use revious LSP */
    G729EV_G729_Copy(prev_lsp, lsp_q, G729EV_G729_M);

    /* update freq_prev */
    G729EV_G729_Lsp_prev_extract(prev_lsp, buf, fg[*prev_ma], freq_prev, fg_sum_inv[*prev_ma]);
    G729EV_G729_Lsp_prev_update(buf, freq_prev);
  }

  return tmp16;
}



/*-------------------------------------------------------------------*
 * Function  G729EV_G729_D_lsp:                                                  *
 *           ~~~~~~                                                  *
 *-------------------------------------------------------------------*/
Word16 G729EV_G729_D_lsp(Word16 freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], Word16 prev_lsp[G729EV_G729_M], Word16 * prev_ma, Word16 prm[],  /* (i)     : indexes of the selected LSP */
                         Word16 lsp_q[],  /* (o) Q15 : Quantized LSP parameters    */
                         Word16 erase     /* (i)     : frame erase information     */
    )
{
  Word16    lsf_q[G729EV_G729_M]; /* domain 0.0<= lsf_q <PI in Q13 */

  Word16    tmp16 = G729EV_G729_Lsp_iqua_cs(freq_prev, prev_lsp, prev_ma, prm, lsf_q, erase);

  /* Convert LSFs to LSPs */
  G729EV_G729_Lsf_lsp2(lsf_q, lsp_q, G729EV_G729_M);

  return tmp16;
}
