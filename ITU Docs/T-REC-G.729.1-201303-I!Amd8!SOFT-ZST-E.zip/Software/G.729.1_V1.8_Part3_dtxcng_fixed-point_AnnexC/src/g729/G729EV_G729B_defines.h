/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#ifndef __G729EV_G729B_DEFINES_H__
#define __G729EV_G729B_DEFINES_H__


/*--------------------------------------------------------------------------*
 * Constants for DTX/CNG                                                    *
 *--------------------------------------------------------------------------*/

#define G729EV_G729B_RATE_8000       80 /* Full rate  (8000 bit/s)       */
#define G729EV_G729B_RATE_SID        15 /* SID                           */
#define G729EV_RATE_SID_WB			 19 /* SID                           */
#define G729EV_RATE_SID_NB			 9
#define G729EV_G729B_RATE_0           0 /* 0 bit/s rate                  */

/* DTX constants */
#define INIT_SEED       11111
#define NB_GAIN         4
#define A_GAIN0         28672
#define A_GAIN1         4096    /* 32768L - A_GAIN0 */
#define FLAG_DEC        (Flag)0

/* Bitrate switching constants */
#define AGC_FAC         ((Word16) 0x7e66)       /* gain adjustment factor  Q15: 0.9875 */
#define AGC_FAC1        ((Word16) 0x019a)       /* 1 - gain adjustment factor Q15      */
#define G729EV_MAIN_COUNT_RCV_DTX_MAX 5
#define WB_STAT_COEFF	((Word16) 0x2000)       /* Q14: 0.5 */
/* CNG excitation generation constant */
                                /* alpha = 0.5 */
#define FRAC1           19043   /* (sqrt(40)xalpha/2 - 1) * 32768 */
#define K0              24576   /* (1 - alpha ** 2) in Q15        */
#define G_MAX           5000
#define G729EV_G729B_ATTEN_COEFF 32735
#define G729EV_G729B_3rdCB_LEN    64
#define G729EV_G729B_3rdRAT_LEN   8

/*--------------------------------------------------------------------------*
 * Constants for DTX/CNG                                                    *
 *--------------------------------------------------------------------------*/

/* DTX constants */
#define FLAG_COD        1
#define FLAG_DEC        (Flag)0


#define FR_SID_MIN      6
#define FR_SID_MAX      25 // default maximum distance between SID frames = 25 G.729.1 frames
#define NB_CURACF       4

#define NB_SUMACF       5
#define NB_GAIN         4


#define DTX_HANG_CONST 6 /* Hangover Period */ 

#define NB_ACCACF       2

#define FRAC_THRESH1        21998  //1.342676  Q14
#define FRAC_THRESH2        17967 //1.0966466 Q14
#define A_GAIN0				28672


#define SIZ_SUMACF      (NB_SUMACF * G729EV_G729_MP1)
#define SIZ_ACF         (NB_CURACF * G729EV_G729_MP1)
#define A_GAIN1         4096    /* 32768L - A_GAIN0 */

#define GAIN_SHAPING_FILTER           32670 //(REAL)0.997 
#endif  /*__G729EV_G729_DEFINES_H__ */
