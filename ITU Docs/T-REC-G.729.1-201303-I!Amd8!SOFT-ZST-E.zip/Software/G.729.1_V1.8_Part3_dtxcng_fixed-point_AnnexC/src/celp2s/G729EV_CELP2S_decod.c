/* 
      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008-09

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: August 29, 2009
	  
	                     
*/

/* From code version:                                                            */

/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include "G729EV_CELP2S_decod.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

#include "G729EV_FEC_fer.h"

#include "G729EV_G729B_defines.h"
#include "G729EV_G729B_util.h"
#include "G729EV_G729B_tab_dtx.h"
#include "G729EV_G729B_sid.h"
#include "G729EV_G729EVDTX_sp2no_trans.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_CELP2S_InitDecoder()                                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Variables initialisation for the CELP2S                                 *
 *--------------------------------------------------------------------------*/

void G729EV_CELP2S_InitDecoder(G729EV_G729_DECSTAT * pDecStat,  /* (i/o)    Core decoder parameters     */ 
                               Word16 g729b_bst)                /* (i)      G.729 bitstream mode flag   */
{


  /* initialize lsp_old */
  G729EV_G729_Copy(G729EV_DTX_LSP_INIT, pDecStat->lsp_old, G729EV_G729_M);

  /* vectors to zero */
  G729EV_G729_Set_zero(pDecStat->old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  G729EV_G729_Set_zero(pDecStat->mem_syn, G729EV_G729_M_LPC);

  pDecStat->seed_fer = (Word16) 21845;
#if (WMOPS)
  move16();
#endif

  pDecStat->sharp = G729EV_G729_SHARPMIN;
  pDecStat->gain_code = 0;
  pDecStat->gain_pitch = 0;
#if (WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
#endif

  pDecStat->past_qua_en[0] = (Word16) (-14336);
  pDecStat->past_qua_en[1] = (Word16) (-14336);
  pDecStat->past_qua_en[2] = (Word16) (-14336);
  pDecStat->past_qua_en[3] = (Word16) (-14336);
#if (WMOPS)
  move16();
  move16();
  move16();
  move16();
#endif

  G729EV_G729_Lsp_decw_reset(pDecStat->freq_prev, pDecStat->prev_lsp, &(pDecStat->prev_ma));

  G729EV_G729_Set_zero(pDecStat->MemTam, G729EV_G729_MEM_LEN_TAM);

  pDecStat->lp_gainp = (Word16) 0;  /*Q14 */
  pDecStat->lp_gainc = (Word16) 0;  /*Q3 */
  pDecStat->i_subfr_cnt = (Word16) 0;
  pDecStat->stab_fac = (Word16) 0;  /*Q15 */
  pDecStat->tilt_code = (Word16) 0; /*Q15 */
  pDecStat->upd_cnt = G729EV_FEC_MAX_UPD_CNT;
  pDecStat->Lenr_old = (Word16) 0;  /*Q0 */
  pDecStat->fpitch[0] = (Word16) (G729EV_FEC_QPIT * G729EV_G729_PIT_MIN);
  pDecStat->fpitch[1] = (Word16) (G729EV_FEC_QPIT * G729EV_G729_PIT_MIN);
  pDecStat->old_fpitch = (Word16) (G729EV_FEC_QPIT * 40);
  pDecStat->pit_mem[0] = (Word16) (G729EV_FEC_QPIT * 20);
  pDecStat->pit_mem[1] = (Word16) (G729EV_FEC_QPIT * 20);
  pDecStat->pit_mem[2] = (Word16) (G729EV_FEC_QPIT * 20);
  pDecStat->pit_mem[3] = (Word16) (G729EV_FEC_QPIT * 20);
  pDecStat->pit_mem[4] = (Word16) (G729EV_FEC_QPIT * 20);
  pDecStat->bfi_mem = (Word16) 0;
#if (WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
#endif

  /* G.729B mode */
  pDecStat->g729b_bst = g729b_bst;
  pDecStat->ftyp[0] = 1;
  pDecStat->ftyp[1] = 1;
  pDecStat->sid_sav = 0;
  pDecStat->sh_sid_sav = 1;
  pDecStat->sid_gain = tab_Sidgain[0];
  pDecStat->past_ftyp = 1;
  pDecStat->seed = INIT_SEED;
  pDecStat->seed2 = INIT_SEED;
  pDecStat->old_pitch = 40;
  pDecStat->old_gp = 8192; //Q14
  pDecStat->lsp_mean[0] = 31441;
  pDecStat->lsp_mean[1] = 27566;
  pDecStat->lsp_mean[2] = 21458;
  pDecStat->lsp_mean[3] = 13612;
  pDecStat->lsp_mean[4] = 4663;
  pDecStat->lsp_mean[5] = -4663;
  pDecStat->lsp_mean[6] = -13612;
  pDecStat->lsp_mean[7] = -21458;
  pDecStat->lsp_mean[8] = -27566;
  pDecStat->lsp_mean[9] = -31441;
#if (WMOPS)
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
  move16();
#endif
  return;
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_CELP2S_decoder()                                       *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                   *
 *  Core Codec decoder                                                      *
 *--------------------------------------------------------------------------*/

void G729EV_CELP2S_decoder(G729EV_G729_DECSTAT * pDecStat,      /* (i/o)    Core decoder parameters     */
                           Word16 * coder_parameters,           /* (i)      decoder parameters          */
                           Word16 rate,                         /* (i)      decoder rate                */
                           Word16 SubFrNum,                     /* (i)      subframe number             */
                           G729EV_CELP2S_PARAM * nb_celp_param, /* (i/o)    celp parameters             */
                           Word16 * BfAq,                       /* (i)      A_t_fwd parameters          */ 
                           Word16 * coreExc,                    /* (o)      8k excitation               */
                           Word16 * extExc,                     /* (o)      12k excitation              */
                           Word16 * pitch_buf,                  /* (o)      pitch buffer                */
                           Word16 clas,                         /* (i)      FEC information             */
                           Word16 bfi)                          /* (i)      Bad frame information       */						    					
{
  Word32    L_temp;
  Word32    L_temp2;

  Word16    temp;

  /* Array of the coded parameters */
  Word16    old_exc[G729EV_G729_L_FRAME + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];			/* Q1 */
  Word16    A_t_fwd[2 * G729EV_G729_MP1]; /* LPC Forward filter  */
  Word16    synth_buf[G729EV_G729_L_FRAME + G729EV_G729_M_LPC]; /* synthesis signal buffer  */
  Word16    lsp_new[G729EV_G729_M]; 		/* LSPs ->Q15 ;           */
  Word16    code[G729EV_G729_L_SUBFR];  /* ACELP codevector ->Q13; */
  Word16    t2[2];

  Word16   *prm;                /* Pointer on analysis parameters   */
  Word16   *exc;                /* Pointer on exitation vector [Q1]*/
  Word16   *synth;
  Word16   *pA_t;               /* Pointer on A_t */
  Word16   *ptr_t2;             /* Pointer on t2 */

  Word16    i, i_subfr, j;
  Word16    t0, t0_frac, index; /* TO -> Q0; */
  Word16    g_p, g_c;           /* fixed and adaptive codebook gain, g_p ->Q14, g_c->Q1;  */
  Word16    t0_first;           /* Pitch lag in 1st subframe, t0_first -> Q0;          */

  Word16    g_c_enha = 0;  						  /* g_c_enha -> Q1;  */
  Word16    code_enha[G729EV_G729_L_SUBFR];   /* code_enha ->Q13; */
  Word16    exc2[G729EV_G729_L_FRAME];        /* exc2[] -> Q1;    */
  Word16   *prm2;
  Word16    sp;
  Word16    voice_fac, tmp16;                /* voice_fac ->Q15;  */

  Word16   *ptr, i0_2sub;

  /* for G.729B */
  Word16    ftyp;
  Word16    lsfq_mem[G729EV_G729_MA_NP][G729EV_G729_M];		/*lsfq_mem[] ->Q15; */
  /*Test if Decoder Initialized */
  IF(pDecStat == NULL)
  {
    return;
  }


#if (WMOPS)
  move16();
#endif
  pDecStat->rate = rate;
  IF(sub(rate, 12000) >= 0)
  {
    coder_parameters[3] = G729EV_G729_Check_Parity_Pitch(coder_parameters[2], coder_parameters[3]);
#if (WMOPS)
    move16();
#endif
  }

  /* initialize pointers and restore memory */
  G729EV_G729_Copy(pDecStat->old_exc, old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  exc = old_exc + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL;
  prm = coder_parameters;
  prm2 = &coder_parameters[G729EV_G729_PRM_SIZE];
  synth = synth_buf + G729EV_G729_M_LPC;

  G729EV_G729_Copy(pDecStat->mem_syn, synth_buf, G729EV_G729_M_LPC);

  ftyp = pDecStat->ftyp[SubFrNum];
#if(WMOPS)
  move16();
#endif

  /* Processing non active frames (SID & not transmitted) */
  IF(sub(ftyp, (Word16) 1) != 0)
  { /* Processing non active frames (SID & not transmitted) */
	Word16 prev_exc[G729EV_MAIN_L_FRAME2];
	pDecStat->bfi_factor = add(pDecStat->bfi_factor, 1); 
	if(sub(pDecStat->bfi_factor, 255) > 0)	pDecStat->bfi_factor = 255;	/*pDecStat->bfi_factor -> Q8 */

#if (WMOPS)
  test();
#endif
	if(pDecStat->transition_flag != 0)
		G729EV_Pitch_copy(pDecStat->old_exc, prev_exc, pDecStat->old_pitch);
    G729EV_G729B_Get_decfreq_prev(pDecStat->freq_prev, lsfq_mem);
    G729EV_G729B_Dec_cng(pDecStat, pDecStat->past_ftyp, pDecStat->sid_sav,pDecStat->sh_sid_sav, prm, exc, pDecStat->lsp_old,
                         A_t_fwd, &pDecStat->seed, lsfq_mem, ftyp, bfi);
	G729EV_post_cng(pDecStat->transition_flag, prev_exc, exc, &(pDecStat->subfr_num));
	G729EV_G729B_Update_decfreq_prev(pDecStat->freq_prev, lsfq_mem);

    G729EV_G729_Copy(A_t_fwd, &nb_celp_param->Az[2 * SubFrNum * G729EV_G729_MP1], 2 * G729EV_G729_MP1);

    pDecStat->sharp = G729EV_G729_SHARPMIN;	/* Q14 */
  }
  ELSE
  {
	  pDecStat->bfi_factor = 255;        /* pDecStat->bfi_factor->Q8; */
	  pDecStat->seed2 = INIT_SEED;
#if(WMOPS)
    move16();
    move16();
#endif
    pDecStat->seed = INIT_SEED;
#if(WMOPS)
    move16();
#endif
    /* ------------- */
    /* LPC decoding  */
    /* ------------- */

    /* Decode the LSPs */
    pDecStat->stab_fac =
        G729EV_G729_D_lsp(pDecStat->freq_prev, pDecStat->prev_lsp, &pDecStat->prev_ma, prm, lsp_new, 0);
    prm += 2;

	/* long term spectrum parameters*/
	FOR(i = 0; i < G729EV_G729_M; i++)
		pDecStat->lsp_mean[i] = extract_l(L_shr(L_add(pDecStat->lsp_mean[i], lsp_new[i]), 1)); /* pDecStat->lsp_mean[i] -> Q15,lsp_new[i] -> Q15, 0.5[Q15]-> 16384;*/ 
      
    /* Interpolation of LPC for the 2 subframes */
    G729EV_G729_Int_qlpc(pDecStat->lsp_old, lsp_new, A_t_fwd);

    G729EV_G729_Copy(A_t_fwd, &nb_celp_param->Az[2 * SubFrNum * G729EV_G729_MP1], 2 * G729EV_G729_MP1);

    /* update the LSFs for the next frame */
    G729EV_G729_Copy(lsp_new, pDecStat->lsp_old, G729EV_G729_M);

    pA_t = A_t_fwd;
     /*------------------------------------------------------------------------*
      *          Loop for every subframe in the analysis frame                 *
      *------------------------------------------------------------------------*
      * The subframe size is L_SUBFR and the loop is repeated L_FRAME/L_SUBFR  *
      *  times                                                                 *
      *     - decode the pitch delay                                           *
      *     - decode algebraic code                                            *
      *     - decode pitch and codebook gains                                  *
      *     - find the excitation and compute synthesis speech                 *
      *------------------------------------------------------------------------*/

    ptr_t2 = t2;                /* pointer to interpolated LPC parameters */

    i0_2sub = shl(SubFrNum, 1); /* i0_2sub = 2*SubFrNum + i0 */
#if (WMOPS)
    move16();
#endif
    FOR(i_subfr = 0; i_subfr < G729EV_G729_L_FRAME; i_subfr += G729EV_G729_L_SUBFR)
    {

      index = *prm++;           /* pitch index */
#if (WMOPS)
      move16();
#endif

      IF(i_subfr == 0)
      {
        /* get parity check result */
        i = *prm++;
#if (WMOPS)
        move16();
#endif

        G729EV_G729_Dec_lag3(index, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX, i_subfr, &t0, &t0_frac);

        t0_first = t0;          /* If first frame */
#if (WMOPS)
        move16();
#endif
      }
      ELSE                      /* second subframe */
      {
        G729EV_G729_Dec_lag3(index, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX, i_subfr, &t0, &t0_frac);
      }
      G729EV_FEC_pitch_pred(0, &t0, &t0_frac, pDecStat->pit_mem, &(pDecStat->bfi_mem));
      if (i_subfr == 0)
      {
        t0_first = t0;
#if (WMOPS)
        move16();
#endif
      }
      *ptr_t2++ = t0;
#if (WMOPS)
      move16();
#endif
      pitch_buf[pDecStat->i_subfr_cnt] = shl(t0, G729EV_FEC_SQPIT);
#if (WMOPS)
      move16();
#endif
      IF(sub(clas, G729EV_FEC_UV_TRANSITION) >= 0)
      {
        pDecStat->fpitch[0] = pDecStat->fpitch[1];
        pDecStat->fpitch[1] = add(shl(t0, G729EV_FEC_SQPIT), mult_r(shl(t0_frac, G729EV_FEC_SQPIT), 10922));
#if (WMOPS)
        move16();
        move16();
#endif
      }

          /*-------------------------------------------------*
           * - Find the adaptive codebook vector.            *
           *-------------------------------------------------*/
  pDecStat->old_pitch = t0;
#if (WMOPS)
      move16();
#endif
      G729EV_G729_Pred_lt_3(&exc[i_subfr], t0, t0_frac, G729EV_G729_L_SUBFR);

          /*-------------------------------------------------------*
           * - Decode innovative codebook.                         *
           *-------------------------------------------------------*/
      G729EV_G729_Decod_ACELP(prm[1], prm[0], code);
      prm += 2;


      j = shl(pDecStat->sharp, 1);  /* From Q14 to Q15 */
      IF(sub(t0, G729EV_G729_L_SUBFR) < 0)
      {
        ptr = code + t0;
        FOR(i = t0; i < G729EV_G729_L_SUBFR; i++)
        {
          *ptr++ = add(code[i], mult(code[sub(i, t0)], j));
#if (WMOPS)
          move16();
#endif
        }
      }

          /*-------------------------------------------------*
           * - Decode pitch and codebook gains.              *
           *-------------------------------------------------*/
      index = *prm++;           /* index of energy VQ */

#if (WMOPS)
      move16();
#endif



      G729EV_G729_Dec_gain(index, code, G729EV_G729_L_SUBFR, 0, &pDecStat->gain_pitch, &pDecStat->gain_code,
                           pDecStat->past_qua_en);

      voice_fac = G729EV_FEC_voice_factor(exc + i_subfr, pDecStat->gain_pitch, code, pDecStat->gain_code);
      sp = extract_l(L_shr(L_add(voice_fac, 32768), 1));
      sp = mult_r(sp, G729EV_CELP2S_SP);

  /*-------------------------------------------------------*
  * - Decode Second innovative codebook.                  *
  *-------------------------------------------------------*/
      IF(sub(pDecStat->rate, 12000) >= 0)
      {
        G729EV_CELP2S_Decod_ACELP(prm2[1], prm2[0], sp, code_enha);
        prm2 += 2;
      }

  /*-------------------------------------------------------------*
    * - Update pitch sharpening "sharp" with quantized gain_pitch *
    *-------------------------------------------------------------*/

      pDecStat->sharp = pDecStat->gain_pitch;
#if (WMOPS)
      move16();
#endif

      if (sub(pDecStat->sharp, G729EV_G729_SHARPMAX) > 0)
      {
        pDecStat->sharp = G729EV_G729_SHARPMAX;
#if (WMOPS)
        move16();
#endif
      }
      if (sub(pDecStat->sharp, G729EV_G729_SHARPMIN) < 0)
      {
        pDecStat->sharp = G729EV_G729_SHARPMIN;
#if (WMOPS)
        move16();
#endif
      }

   /*-------------------------------------------------------*
    * - Find the total excitation.                          *
    * - Find synthesis speech corresponding to exc[].       *
    *-------------------------------------------------------*/
      g_p = G729EV_G729_TamFer(pDecStat, pDecStat->gain_pitch,  /*gain */
                               t0); /*integer part of the pitch */
  pDecStat->old_gp = g_p; /* Q14 */
      g_c = pDecStat->gain_code;
#if (WMOPS)
      move16();
#endif

      /* i0_2sub = 2*SubFrNum + i0 */
/* long term adaptive codebook gain and fix codebook gain */
      nb_celp_param->t0[i0_2sub] = t0;
      nb_celp_param->t0_frac[i0_2sub] = t0_frac;
#if (WMOPS)
      move16();
      move16();
#endif


      nb_celp_param->power_ltp[i0_2sub] = 0;
#if (WMOPS)
      move16();
#endif

      ptr = exc + i_subfr;
      L_temp2 = nb_celp_param->power_ltp[i0_2sub];
#if (WMOPS)
      move16();
      move32();
#endif
      FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
      {
        temp = mult(g_p, exc[i + i_subfr]);
        L_temp2 = L_mac0(L_temp2, temp, temp);

        /* exc[i] = g_p*exc[i] + g_c*code[i]; */
        /* exc[i]  in Q1   g_p in Q14         */
        /* code[i] in Q13  g_code in Q1       */


        L_temp = L_mult(code[i], g_c);  /* Q13 * Q1 -> Q15 */
        L_temp = L_shl(L_temp, 1);  /* Q15 -> Q_N+15  */
        L_temp = L_mac(L_temp, exc[i + i_subfr], g_p);  /* Q_N * Q14 -> Q_N+15 */
        L_temp = L_shl(L_temp, 1);  /* Q_N+15 -> Q_N+16  */
        *ptr++ = round(L_temp);
#if (WMOPS)
        move16();
#endif

      }

      nb_celp_param->power_ltp[i0_2sub] = L_temp2;
#if (WMOPS)
      move32();
#endif



      IF(sub(pDecStat->rate, 12000) >= 0)
      {
#if (WMOPS)
        move16();
#endif
        index = *prm2++;


        nb_celp_param->power_fix[i0_2sub] = 0;
#if (WMOPS)
        move16();
#endif


        /* decode gain (optimized version: table lookup) */
        g_c_enha = G729EV_CELP2S_dec_gain_Stage2(g_c, index, i0_2sub);

        /* Compute excitation for with two inovative codebook         */
        /* exc2[i+i_subfr] = g_c_enha * code_enha[i] + exc[i+i_subfr] */
        /* exc[i]  in Q1                                              */
        /* code_enha[i] in Q13  gain_code_enha in Q1                  */

        ptr = exc2 + i_subfr;
        L_temp2 = nb_celp_param->power_fix[i0_2sub];
#if (WMOPS)
        move32();
#endif
        FOR(i = 0; i < G729EV_G729_L_SUBFR; i++)
        {

          temp = add(mult(g_c, code[i]), mult(g_c_enha, code_enha[i]));
          L_temp2 = L_mac0(L_temp2, temp, temp);

          L_temp = L_mult(code_enha[i], g_c_enha);  /* Q13 * Q1 -> Q15 */
          L_temp = L_shl(L_temp, 1);  /* Q15 -> Q_N+15   */
          L_temp = L_mac(L_temp, exc[i + i_subfr], 16384);  /* Q_N * Q_14 -> Q_N+15 */
          L_temp = L_shl(L_temp, 1);  /* Q_N+15 -> Q_N+16 */
          *ptr++ = round(L_temp);
#if (WMOPS)
          move16();
#endif
        }

        nb_celp_param->power_fix[i0_2sub] = L_shl(L_temp2, 2);
#if (WMOPS)
        move32();
#endif

      }

	G729EV_adjust_gain(&pDecStat->Ga_gain_mean, &pDecStat->Gf_gain_mean, g_p, g_c, g_c_enha);

    tmp16 = add(pDecStat->i_subfr_cnt, 1);
    tmp16 = i_mult(tmp16, 3277);
    pDecStat->lp_gainp = add(pDecStat->lp_gainp, mult_r(tmp16, g_p));
    pDecStat->lp_gainc = add(pDecStat->lp_gainc, mult_r(tmp16, shl(g_c, 2)));
    pDecStat->tilt_code = extract_l(L_shr(L_add(voice_fac, 32767), 2));
    pDecStat->i_subfr_cnt = add(pDecStat->i_subfr_cnt, 1);

    pA_t += G729EV_G729_MP1;  /* interpolated LPC parameters for next subframe */

    i0_2sub = add(i0_2sub, 1);  /* i0++ */
    }
  }

  /*------------*
   *  For G729b
   *-----------*/
  IF(bfi == 0)
  {
    L_temp = 0L;
    FOR(i = 0; i < G729EV_G729_L_FRAME; i++)
    {
      L_temp = L_mac(L_temp, exc[i], exc[i]);
    }                           /* may overflow => last level of SID quantizer */
	pDecStat->sh_sid_sav = 0;
#ifdef WMOPS
  move16();
#endif
	Norm_shl_r(L_temp, &pDecStat->sh_sid_sav, &L_temp, &pDecStat->sid_sav);
    pDecStat->sh_sid_sav = sub(16, pDecStat->sh_sid_sav);
  }


 /*--------------------------------------------------*
  * Update signal for next frame.                    *
  * -> shift to the left by L_FRAME  exc[]           *
  *--------------------------------------------------*/

  G729EV_G729_Copy(&old_exc[G729EV_G729_L_FRAME], &pDecStat->old_exc[0], G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);


  G729EV_G729_Copy(exc, coreExc, G729EV_G729_L_FRAME);
  G729EV_G729_Copy(exc2, extExc, G729EV_G729_L_FRAME);
  G729EV_G729_Copy(A_t_fwd, BfAq, 2 * G729EV_G729_MP1);

  /* for G729b */
  pDecStat->past_ftyp = ftyp;
#if (WMOPS)
  move16();
#endif
  return;
}





/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_Decod_pos_sig()                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *   Decode positions and signs of the 4 tri-pulse patterns  *
 *-----------------------------------------------------------*/
void G729EV_CELP2S_Decod_pos_sig(Word16 index,  /* (i) : Positions of the 4 pattern */
                                 Word16 sign,   /* (i) : Signs of the 4 pattern */
                                 Word16 pos[],  /* (o) : Decoded positions */
                                 Word16 si[]    /* (o) : Decoded signs */
    )
{
  Word16    i, j;

  /* Decode the positions */

#ifdef WMOPS
  logic16();
  move16();
#endif
  i = index & (Word16) 7;
  pos[0] = add(i, shl(i, 2));   /* pos0 =i*5 */
  index = shr(index, 3);

#ifdef WMOPS
  logic16();
  move16();
#endif
  i = index & (Word16) 7;
  i = add(i, shl(i, 2));        /* pos1 =i*5+1 */
  pos[1] = add(i, 1);
  index = shr(index, 3);

#ifdef WMOPS
  logic16();
  move16();
#endif
  i = index & (Word16) 7;
  i = add(i, shl(i, 2));        /* pos2 =i*5+1 */
  pos[2] = add(i, 2);
  index = shr(index, 3);

#ifdef WMOPS
  logic16();
  logic16();
  move16();
#endif
  j = index & (Word16) 1;
  index = shr(index, 1);
  i = index & (Word16) 7;
  i = add(i, shl(i, 2));        /* pos3 =i*5+3+j */
  i = add(i, 3);
  pos[3] = add(i, j);


  /* Decode the signs */

  FOR(j = 0; j < 4; j++)
  {
#ifdef WMOPS
    logic16();
    move16();
#endif
    i = sign & (Word16) 1;
    si[j] = i;
    sign = shr(sign, 1);
  }

  return;
}



/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_Decod_ACELP()                    *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *   Algebraic codebook decoder.                             *
 *-----------------------------------------------------------*/

void G729EV_CELP2S_Decod_ACELP(Word16 sign,   /* (i)     : Signs of 4 patterns                       */
                               Word16 index,  /* (i)     : Positions of the 4 pattern centres        */
                               Word16 sp,     /* (i)     : Amplitude of the side pulses.             */
                               Word16 cod[]   /* (o) Q13 : algebraic (fixed) codebook excitation     */
    )
{
  Word16    pos[4];
  Word16    si[4];

  /* Decode the positions and signs */
  G729EV_CELP2S_Decod_pos_sig(index, sign, pos, si);

  /* Put the tri-pulse patterns */
  G729EV_CELP2S_Put4Patterns(pos, si, sp, cod);

  return;
}
