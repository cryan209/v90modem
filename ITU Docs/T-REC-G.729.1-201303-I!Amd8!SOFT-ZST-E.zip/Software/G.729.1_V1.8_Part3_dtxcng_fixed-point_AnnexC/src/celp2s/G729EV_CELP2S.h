/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_CELP2S_H__
#define __G729EV_CELP2S_H__

#include "stl.h"

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"

typedef struct
{
  Word16    Az[G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1]; /* Q12 */

  Word16    t0[G729EV_MAIN_NB_SUBFR];	/* Q0 */
  Word16    t0_frac[G729EV_MAIN_NB_SUBFR]; /* Q0 */

  Word32    power_fix[G729EV_MAIN_NB_SUBFR];
  Word32    power_ltp[G729EV_MAIN_NB_SUBFR];

} G729EV_CELP2S_PARAM;

#endif  /*__G729EV_CELP2S_H__ */
