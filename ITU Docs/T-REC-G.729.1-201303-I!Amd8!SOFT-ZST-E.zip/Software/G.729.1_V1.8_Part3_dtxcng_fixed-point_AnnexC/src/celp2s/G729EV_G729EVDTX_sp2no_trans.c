/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/
#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_G729_ld8k.h"
#include "G729EV_G729EVDTX_sp2no_trans.h"
#include "G729EV_MAIN_dspfunc.h"
#include "G729EV_G729B_tab_dtx.h"


/* last pitch cycle of the previous frame is repeatedly copied up to an extra superframe */    
void G729EV_Pitch_copy(Word16* old_exc,	/*excitation in the previous frame*/
 		  Word16* new_exc,	        /*new excitation in the current superframe*/ 
 		  Word16 Tc)	            /*pitch of the last subframe in previous frame*/
{
	Word16 *pt_exc, *pt1_exc;
	Word16 i;
		
	pt_exc = &old_exc[G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL];
	pt_exc = &pt_exc[-Tc];
	pt1_exc = new_exc;
	FOR(i = 0; i < Tc; i++)
    {
    	*pt1_exc = *pt_exc;
    	pt1_exc++;
    	pt_exc++;
    }
    
    pt_exc = new_exc;
    
    FOR(i = Tc; i < G729EV_MAIN_L_FRAME2; i++)
    {
        *pt1_exc = *pt_exc;
    	pt1_exc++;
    	pt_exc++;
    }
}    

/* excitation smoothing in the subframe*/ 
void G729EV_Exc_tans_sub(Word16* prev_exc,	/*excitation in the previous superframe*/
		 Word16* curr_exc,			/*excitation in the current superframe*/
		 Word16* new_exc,			/*excitation in the new superframe*/
		 Word16 subfr_num)			/*subframe number in the superframe*/
		
{
	Word16 step,gain1,gain2;
	Word16 *pt_exc,*pt1_exc,*pt2_exc;
	Word16 i;
	Word32 L_acc;
	Word16 energy_tmp1, energy_tmp2, sh;
	Word16 sh_energy_tmp1=0, sh_energy_tmp2=0;

	step = (Word16)205;	/* Q15 */
#if (WMOPS)
  move16();
#endif
	gain1 = shl(subfr_num, (Word16)14);	/* gain1 = subfr_num * G729EV_MAIN_L_FRAME4 * step, in Q15 */
	gain2 = sub((Word16)32767, gain1); 	/* Q15 */
	
	pt_exc = new_exc;               
	pt1_exc  = curr_exc; 
	pt2_exc = &prev_exc[i_mult(subfr_num, G729EV_MAIN_L_FRAME4)]; 
	
	L_acc = 1;
#if (WMOPS)
  move32();
#endif
	FOR (i = 0; i < G729EV_MAIN_L_FRAME4; i ++)
		L_acc = L_mac(L_acc, pt1_exc[i], pt1_exc[i]);
	Norm_shl_r(L_acc, &sh_energy_tmp1, &L_acc, &energy_tmp1);

	FOR(i = 0; i < G729EV_MAIN_L_FRAME4; i++)
	{
		L_acc = L_mac(L_mult(gain1, *pt1_exc), gain2, *pt2_exc);
		*pt_exc = extract_h(L_acc);
		
		pt_exc++;
		pt1_exc++;
		pt2_exc++;
		
		gain1 = add(gain1, step);
		gain2 = sub(gain2, step);
	}
	
	L_acc = 1;
#if (WMOPS)
  move32();
#endif
	FOR (i = 0; i < G729EV_MAIN_L_FRAME4; i ++)
		L_acc = L_mac(L_acc, new_exc[i], new_exc[i]);
	Norm_shl_r(L_acc, &sh_energy_tmp2, &L_acc, &energy_tmp2);
	
	energy_tmp2=div_s(16384, energy_tmp2);
	sh=sub(45, sh_energy_tmp2);	
	L_acc = L_mult(energy_tmp1, energy_tmp2);
	sh=add(sh, sub(sh_energy_tmp1, 16));
	IF((sh&1)!=0) L_acc = L_shr(L_acc, 1);
	energy_tmp1 = Sqrt(L_acc);
    sh=shr(sh, 1);
	sh=add(sh, 1);

	// Gain control for excitation transition
	FOR (i = 0; i < G729EV_MAIN_L_FRAME4; i ++)
		new_exc[i] = (Word16)L_shr_r(L_mult(new_exc[i], energy_tmp1), sh);
}
/* complete excitation transition */
void G729EV_post_cng(Word16 transition_flag,/*excitation transition flag*/
			  Word16 *prev_exc,      /*excitation of the previous superframe*/
			  Word16 *exc,           /*excitation of the current superframe*/
			  Word16 *subfr_num)     /*subframe number in the superframe*/
{		
	Word16 new_exc[G729EV_G729_L_FRAME];	
	IF(sub(transition_flag, 1) == 0)
	{
		G729EV_Exc_tans_sub(prev_exc, exc, new_exc, *subfr_num);
		G729EV_G729_Copy(new_exc, exc, G729EV_G729_L_FRAME);
		*subfr_num = add(*subfr_num, 1);
	}
}
/* accumulation with weighting */
void G729EV_linear_compose(Word16 *num1, /* input num1 */
					Word16 *sh1,  /* scalar of num1 */
					Word16 *num2, /* input num2 */
					Word16 *sh2,  /* scalar of num1 */ 
					Word16 fact1, /* weight 1*/
					Word16 fact2) /* weight 2*/
{
	Word16 temp;
	Word32 L_temp;	
	
	temp = ((*sh1) < (*sh2)) ? (*sh1) : (*sh2);
	L_temp = L_mult(shr(*num2, sub(*sh2, temp)), fact1);
	L_temp = L_mac(L_temp, shr(*num1, sub(*sh1, temp)), fact2);
			 
	Norm_shl_r(L_temp, &temp, &L_temp, num2);
	*sh1 = temp;
	*sh2 = *sh1;
}
/* estimate initial energy of inactive */
void G729EV_adjust_gain(Word16 *Ga, Word16 *Gf, Word16 g_p, Word16 g_c, Word16 g_a)
{
	Word16 temp16;
	Word32 L_temp;

	*Ga = extract_l(L_shr(L_add((Word32)(*Ga), g_p), 1));	
	L_temp = L_mac(L_mult(g_c, g_c), g_a, g_a);
	temp16 = ful_Sqrt_r(L_temp);
	*Gf = extract_l(L_shr_r(L_add((Word32)(*Gf), L_shl((Word32)temp16, 1)), 1));	/* pDecStat->fx_Gf_gain_mean in Q1, tmp16c in Q0 */
}   
/* excitation re-shaping filter */
void G729EV_fir_filt(Word16 x[], Word16 i_frame, Word16 filt[], Word16 count)
{
	Word16 i, j;
	Word32 s;
	FOR (i = 0; i < count; i++)
	{
		s = L_mult(round(L_mult(x[i_frame+i], Shaping_filter[0])), (Word16)GAIN_SHAPING_FILTER);

		FOR (j = 0; j < FILTERORDER; j++)
			s = L_mac(s, round(L_mult(Shaping_filter[j+1], filt[FILTERORDER-1-j])), (Word16)GAIN_SHAPING_FILTER);
		
		FOR(j = 0; j < FILTERORDER-1; j++)
		{
			filt[j] = filt[j+1];
#if(WMOPS)
			move16();
#endif
		}
		filt[j] = x[i_frame+i];
#if(WMOPS)
		move16();
#endif
		x[i_frame+i] = round(s);
	} 
}
/* attenuation factor computing */
Word16 G729EV_calc_alpha(Word16 last_good, Word16 bfi_cnt, Word16 stab_fac)
{
	Word16 alpha;
#if(WMOPS)
		move16();
#endif
	IF(sub(last_good, G729EV_FEC_UNVOICED) == 0)
	{
		IF(sub(bfi_cnt, 3) > 0)
		{                           /* If stable, do not decrease the energy */
			/*alpha = (stab_fac * (0.9f - G729EV_FEC_ALPHA_U) + G729EV_FEC_ALPHA_U); */
			alpha = G729EV_FEC_ALPHA_VT;
		}
		ELSE      IF(sub(bfi_cnt, 1) > 0)
		{                           /* If stable, do not decrease the energy */
			/*alpha = (stab_fac * (0.9f - G729EV_FEC_ALPHA_U) + G729EV_FEC_ALPHA_U); */
			alpha = add(stab_fac, G729EV_FEC_ALPHA_U);
		}
		ELSE
		{
			alpha = G729EV_FEC_ALPHA_U2;
		}
	}
	ELSE IF   (sub(last_good, G729EV_FEC_UV_TRANSITION) == 0)
	{
		alpha = G729EV_FEC_ALPHA_UT;
	}
	ELSE IF   ((sub(last_good, G729EV_FEC_ONSET) == 0))
	{
	    alpha = 26214;              /* mild convergence to 0 for the first 3 erased frames */
	}
	ELSE IF (sub(last_good, G729EV_FEC_VOICED) == 0)
	{
	    alpha = G729EV_FEC_ALPHA_V; /* constant for the first 3 erased frames */
	}
	ELSE IF   (sub(last_good, G729EV_FEC_SIN_ONSET) == 0)
	{
	    alpha = G729EV_FEC_ALPHA_S;
	}
	ELSE                          /* G729EV_FEC_V_TRANSITION */
	{
	    IF((sub(bfi_cnt, 2) <= 0))
	    {
			alpha = 2 * G729EV_FEC_ALPHA_VT;  /* medium convergence to 0  */
		}
		ELSE
		{
			alpha = (Word16) 6654;    /* very fast convergence to 0  */
		}
	}

	return alpha;

}
