/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include "G729EV_TDBWE_time_envelope_shaping.h"

#include "G729EV_TDBWE_extract_time_envelope.h"
#include "G729EV_MAIN_dspfunc.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_time_envelope_shaping()                          *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                          *
 *  TDBWE time envelope shaping module,                                     *
 *  shape time envelope of input[] according to envelope[]                  *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_time_envelope_shaping(Word16 * input,     /* (i) Q.12, excitation input signal */
                                        Word16 * envelope,  /* (i) Q.10, desired time envelope */
                                        Word16 * output,    /* (o) Q.4, shaped output signal */
                                        Word16 * prev_gain, /* (i/o) Q.0, memory */
                                        Word16 * prev_norm) /* (i/o) memory  */
{
  Word16    l;
  Word16    gain16;             /* Q.2  */
  Word16    ratio;              /* Q.15 */
  Word16    smoothed_gain;      /* Q.2  */
  Word16    idx, start, end;
  Word16    actual_envelope[G729EV_TDBWE_NB_SUBFRAMES_2]; /* Q.10 */
  Word16    exp, expf;
  Word32    tmp32;
  Word32    tmp32_2;
  Word16    m16;


  /* get the subframe energies of the excitation signal */
  G729EV_TDBWE_extract_time_envelope(input, 12, /* nls */
                                     actual_envelope, G729EV_TDBWE_NB_SUBFRAMES_2);

  /* start with first subframe */
  start = 0;
#ifdef WMOPS
  move16();
#endif

  /* iterate over 8 subframes */
  FOR(l = 0; l < G729EV_TDBWE_NB_SUBFRAMES_2; l++)
  {

    /* gain =  pow ( 2.0, envelope[l] - actual_envelope[l] ); */
    m16 = sub(envelope[l], actual_envelope[l]);
    exp = shr(m16, 10);         /* Q0 */
    expf = shl(s_and(m16, 0x03ff), 5);
    gain16 = extract_l(Pow2(0, expf));  /* Q0 */

    end = add(start, G729EV_TDBWE_SUBFRAME_SIZE_2);

    /* iterate over 1st half of current subframe */
    FOR(idx = start; idx < end; idx++)
    {
      /* smoothed_gain = ratio * gain + (1.0f - ratio) * *prev_gain; */
      ratio = G729EV_TDBWE_TIME_ENVELOPE_SHAPING_WINDOW[idx - start];
#ifdef WMOPS
      move16();
#endif
      tmp32 = L_shl(L_mult(ratio, gain16), exp);  /* Q.16 */
      tmp32_2 = L_shl(L_mult(sub(ratio, 8192), *prev_gain), *prev_norm);
      tmp32 = L_sub(tmp32, tmp32_2);  /* Q.16 */
      smoothed_gain = round(tmp32); /* Q.0  */

      /* apply gain */
      tmp32 = L_shl(L_mult(smoothed_gain, input[idx]), 5);  /* Q.x-1 -> Q.16 */
      output[idx] = round(tmp32);
#ifdef WMOPS
      move16();
#endif
    }

    end = add(start, G729EV_TDBWE_SUBFRAME_SIZE);
    start = add(start, G729EV_TDBWE_SUBFRAME_SIZE_2);

    /* iterate over 2nd half of current subframe, no smoothing here (flat-top window)! */
    FOR(idx = start; idx < end; idx++)
    {
      /* apply gain */
      tmp32 = L_shl(L_mult(gain16, input[idx]), add(3, exp)); /* Q.x+1 -> Q.16 */
      output[idx] = round(tmp32);
#ifdef WMOPS
      move16();
#endif
    }

    /* start with next subframe */
    start = end;
#ifdef WMOPS
    move16();
#endif

    /* memory update */
    *prev_gain = gain16;
    *prev_norm = exp;
#ifdef WMOPS
    move16();
    move16();
#endif

  }
}
