/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDBWE_EXTRACT_TIME_ENVELOPE_H__
#define __G729EV_TDBWE_EXTRACT_TIME_ENVELOPE_H__

#include "stl.h"


/* prototype for exported function */

void      G729EV_TDBWE_extract_time_envelope(Word16 * signal, Word16 nls, Word16 * envelope, Word16 number_subframes);

#endif
