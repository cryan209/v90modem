/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
/* 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          

      Copyright (c) 2008

      Huawei Technologies, Siemens AG

      Version 1.5

      Revision Date: Jun 03, 2009
	  
	                     
*/

#ifndef __G729EV_MAIN_DEFINES_H__
#define __G729EV_MAIN_DEFINES_H__

#include "stl.h"


/*************************
 * Constants for framing
 *************************/

#define G729EV_MAIN_L_FRAME         320
#define G729EV_MAIN_L_FRAME2        160
#define G729EV_MAIN_L_FRAME4         80
#define G729EV_MAIN_NB_SUBFR  4

/***********************************
 * Constants for DTX
 ***********************************/
#define PRM_SIZE_SID    4        /* Size of vector of analysis parameters.    */
#define RATE_SID        15      /* SID                           */
#define	RATE_SID_NB		9
#define	RATE_SID_WB		19
#define SIDRATE			(RATE_SID + RATE_SID_WB)*50
#define RATE_0          0       /* 0 bit/s rate                  */
/* TD-BWE DTX thresholds */
/* threshold-constant[Q10] = threshold[dB] * 2^10 / (20 * log(2) / log(10)) */
#define G729EV_TDBWE_THR_TD  ((Word16) 0x00ee)            /* st change of signal energy (1.4dB) */
#define G729EV_TDBWE_THR_TD_INV        23406              /* st change of signal energy (1.4dB) */
#define G729EV_TDBWE_THR_SD  ((Word16) 0x00ee)
#define G729EV_TDBWE_THR_TC  ((Word16) 0x0220)            /* lt change of signal energy (3.2dB) */
#define G729EV_TDBWE_THR_SC  ((Word16) 0x0220)
#define ALPHA_TENV           ((Word16) 0x2000)            /* time envelope filter 0.25 in Q15 */
#define ONE_M_ALPHA_TENV     ((Word16) 0x6000)            /* time envelope filter 0.75 in Q15 */
#define ALPHA_FENV           ((Word16) 0x2000)            /* frequency envelope filter 0.25 in Q15 */
#define ONE_M_ALPHA_FENV     ((Word16) 0x6000)            /* frequency envelope filter 0.75 in Q15 */

/***********************************
 * Constants for bitstream packing
 ***********************************/

#define ITU_G192_SYNCWORD 0x6b21
#define ITU_G192_SYNCWORD_ERASURE 0x6b20
#define ITU_G192_BIT_0 0x007f
#define ITU_G192_BIT_1 0x0081

#define G729EV_MAX_BITRATE  32000
#define G729EV_MAX_BITS_BST 640
#define G729EV_MAIN_COUNT_RCV_MAX 50

/*****************************
 * constants for TDAC module  
 ******************************/

/* constants for MDCT and inverse MDCT */
#define G729EV_TDAC_L_WIN   320
#define G729EV_TDAC_L_WIN2  160
#define G729EV_TDAC_L_WIN4   80
#define G729EV_TDAC_NP        5
#define G729EV_TDAC_EXP_NPP   4
#define G729EV_TDAC_NB_REV    6
#define G729EV_TDAC_NPP     (1<<G729EV_TDAC_EXP_NPP)

/* constants for spectral envelope coding */
#define G729EV_TDAC_NB_SB          18
#define G729EV_TDAC_NB_SB_NB       10
#define G729EV_TDAC_NB_SB_WB        8
#define G729EV_TDAC_MAX_VQBITS    800

/* Constants for spectrum envelope quantization */
#define G729EV_TDAC_MAX_LONG_HUFF   16  /* longueur max code d'Huffman */
#define G729EV_TDAC_MAX_NB_PRM_FACT 6
#define G729EV_TDAC_MIN_RMS      -11
#define G729EV_TDAC_MAX_RMS      20
#define G729EV_TDAC_RMS_OFFSET    6
#define G729EV_TDAC_Q3db_INV     16384  /* 1 / 3dB in Q14 */
#define G729EV_TDAC_Q3db        16384   /* 3dB in Q15 */
#define G729EV_TDAC_N_NBC      16       /* Maximum number of coeff. (dim. of vectors)    */
#define G729EV_TDAC_NB_LEAD_H    84
#define G729EV_TDAC_NORM_MDCT_TRESH  4


/* Constants for bit allocation */
#define G729EV_TDAC_SORTED_IP    -2000  /* Q1 */

#define  G729EV_TDAC_NB_SB_LEN     16
#define  G729EV_TDAC_NB_SB_PST     (Word16)((G729EV_MAIN_L_FRAME/G729EV_TDAC_NB_SB_LEN)/2)

/***************************
 * Constants for delay
 ***************************/
#define G729EV_MAIN_DELAY         143

/***************************
 * Constants for filtering
 ***************************/

/* number of taps for median filter (used to adapt postfilter's gammas) */
#define G729EV_MAIN_NMAX 5

/* QMF filterbank */
#define G729EV_MAIN_S_QMF    32
#define G729EV_MAIN_S_QMF_FS (G729EV_MAIN_S_QMF/2)

/* preprocessing of higher band signal */
#define G729EV_MAIN_LP_ORD   4


/* perceptual weighting filtering of lower-band difference signal */
#define  G729EV_MAIN_GAMMA1     (Word16) 30802  /* Q15 */
#define  G729EV_MAIN_GAMMA2     (Word16) 19661  /* Q15 */

/****************************************
 * Constants for pre/post-echo reduction
 ****************************************/
#define G729EV_MAIN_PRE_SUBFRAME 40 /* block for energy comparison in 8khz-samples: 5msec */

/* constants for SID postfilter */
#define G729EV_PP_ATT_SID_HI    ((Word16) 0x6666)  /* Q15: 0.8   */
#define G729EV_PF_BETA          ((Word16) 0x1687)  /* Q15: 0.176 */
#define G729EV_PF_BETAM1        ((Word16) 0x6979)  /* Q15: 0.824 */

/******************************
 * constants for CELP2S module
 ******************************/

#define G729EV_CELP2S_SP          (Word16)   -11141
#define G729EV_CELP2S_HP_FACT     (Word16)    -4915

#define G729EV_CELP2S_FCB_REPEAT  4
#define G729EV_CELP2S_FCB_THRES   0
#define G729EV_CELP2S_FCB_1_4    (Word16)(8192)
#define G729EV_CELP2S_FCB_1_8    (Word16)(4096)

/******************************
 * constants for TDBWE module  
 ******************************/

/* TD-BWE frame size constants */

#define G729EV_TDBWE_L_FRAME    160
#define G729EV_TDBWE_L_FRAME2    80
#define G729EV_TDBWE_L_FRAME4    40

/* TDBWE buffering and pointer address constants */
#define G729EV_TDBWE_L_TOTAL                             232
#define G729EV_TDBWE_L_NEXT                              40
#define G729EV_TDBWE_MEM_SPEECH                          72
#define G729EV_TDBWE_DELTA_TIME_ENV                      16
#define G729EV_TDBWE_DELTA_FREQ_ENV                      -32
#define G729EV_TDBWE_L_TOTAL_EXC                         208
#define G729EV_TDBWE_MEM_EXC                             48

/* TDBWE time envelope computation, shaping & postprocessing */

#define G729EV_TDBWE_NB_SUBFRAMES         16
#define G729EV_TDBWE_NB_SUBFRAMES_2       8
#define G729EV_TDBWE_NB_SUBFRAMES_2_M_1   7
#define G729EV_TDBWE_NB_SUBFRAMES_2_M_2   6
#define G729EV_TDBWE_SUBFRAME_SIZE        10
#define G729EV_TDBWE_SUBFRAME_SIZE_2      5

/* TDBWE frequency envelope computation, shaping & postprocessing */

#define G729EV_TDBWE_FFT_NUM_STAGE     5
#define G729EV_TDBWE_FFT_SIZE2         (2 << (G729EV_TDBWE_FFT_NUM_STAGE+1))   /* 128 */
#define G729EV_TDBWE_FFT_SIZE          (2 << G729EV_TDBWE_FFT_NUM_STAGE)       /* 64  */
#define G729EV_TDBWE_FFT_SIZE_M_2      ((2 << G729EV_TDBWE_FFT_NUM_STAGE) - 2) /* 62  */
#define G729EV_TDBWE_FFT_SIZE_BY_TWO   (2 << (G729EV_TDBWE_FFT_NUM_STAGE-1))   /* 32  */

#define G729EV_TDBWE_NB_SUBBANDS                         12
#define G729EV_TDBWE_FREQUENCY_ENVELOPE_WINDOW_SIZE      (G729EV_TDBWE_FFT_SIZE<<1) /* 128 */
#define G729EV_TDBWE_FREQUENCY_ENVELOPE_WINDOW_SIZE_M_FS ((G729EV_TDBWE_FFT_SIZE<<1)-G729EV_TDBWE_L_FRAME2)
#define G729EV_TDBWE_BINS_PER_SUBBAND                    3  /* 375 Hz */
#define G729EV_TDBWE_BINS_BTW_CENTER_BINS                1

#define G729EV_TDBWE_BUFLEN_FIR (80+32)
#define G729EV_TDBWE_FREQ_ENV_SHAPING_STORAGE_LENGTH      17
#define G729EV_TDBWE_FREQ_ENV_SHAPING_GAIN_HIGHPASS       26
#define G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH       33
#define G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1   32

/* TD-BWE parameter array offsets */

#define G729EV_TDBWE_PAROFS_TIME_ENVELOPE 0
#define G729EV_TDBWE_PAROFS_FREQ_ENVELOPE (G729EV_TDBWE_PAROFS_TIME_ENVELOPE+G729EV_TDBWE_NB_SUBFRAMES)
#define G729EV_TDBWE_NB_PARAMETERS (G729EV_TDBWE_PAROFS_FREQ_ENVELOPE+G729EV_TDBWE_NB_SUBBANDS)

/* TD-BWE excitation generation */

#define G729EV_TDBWE_LENGTH_PULSE_SHAPE   57
#define G729EV_TDBWE_NUMBER_PULSE_SHAPES   6

/* TD-BWE quantization table constants */

#define G729EV_TDBWE_MEAN_TIME_ENV_BITS                5
#define G729EV_TDBWE_MEAN_TIME_ENV_NUMBER_ENTRIES     32
#define G729EV_TDBWE_TIME_ENV_BITS                     7
#define G729EV_TDBWE_TIME_ENV_NUMBER_ENTRIES         128
#define G729EV_TDBWE_TIME_ENV_SPLIT_VQ_NUMBER_SPLITS   2
#define G729EV_TDBWE_FREQ_ENV_SPLIT_VQ_NUMBER_SPLITS   3

/******************************
 * constants for FEC module  
 ******************************/

#define G729EV_FEC_SINGLE_FRAME    (-1)

/* attenuation strategy in case of FER */
#define G729EV_FEC_ALPHA_S         19661
#define G729EV_FEC_ALPHA_V         32767
#define G729EV_FEC_ALPHA_VT        13107
#define G729EV_FEC_ALPHA_UT        28836
#define G729EV_FEC_ALPHA_U         13107
#define G729EV_FEC_ALPHA_U2        31130
#define G729EV_FEC_L_FIR_FER       5  /* impulse response length for low- & high-pass filters   */

#define G729EV_FEC_MAX_UPD_CNT     30
#define G729EV_FEC_L_EXC_MEM       (G729EV_G729_PIT_MAX+G729EV_G729_L_INTERPOL)
#define G729EV_FEC_QPIT            32
#define G729EV_FEC_QPIT2           16
#define G729EV_FEC_SQPIT           5

/* signal classification for FER protection */
#define G729EV_FEC_UNVOICED          0  /* G729EV_FEC_UNVOICED, silence, noise, G729EV_FEC_VOICED offset   */
#define G729EV_FEC_UV_TRANSITION     1  /* Transition from G729EV_FEC_UNVOICED to G729EV_FEC_VOICED components - possible onset, but too small */
#define G729EV_FEC_V_TRANSITION      2  /* Transition from G729EV_FEC_VOICED - still G729EV_FEC_VOICED, but with very weak G729EV_FEC_VOICED characteristics     */
#define G729EV_FEC_VOICED            3  /* G729EV_FEC_VOICED frame, previous frame was also G729EV_FEC_VOICED or ONSET                   */
#define G729EV_FEC_ONSET             4  /* G729EV_FEC_VOICED onset sufficiently well built to follow with a G729EV_FEC_VOICED concealments    */
#define G729EV_FEC_SIN_ONSET         5  /* artificial harmonic+noise onset (used only in decoder)                       */

#define G729EV_FEC_GOOD_FRAME      0  /* Correct frame                   */
#define G729EV_FEC_BAD_FRAME       1  /* Bad frame                       */

#define G729EV_FEC_LG10             24660   /* 10*log10(2)          in Q13 */
#define G729EV_FEC_LG10_LFRAME      361123  /* 10*log10(160)        in Q14 */
#define G729EV_FEC_LG10_LFRAME_155  465965  /* 5.0*log10(160)/1.55  in Q16 */
#define G729EV_FEC_LG10_s1_55       31820   /* 5*log10(2)/1.55      in Q15 */

#define G729EV_FEC_K_COR            23405       /* Q13      2.8547f                       */
#define G729EV_FEC_C_COR            -690415993  /* Q13+16   -1.286f                       */
#define G729EV_FEC_K_TILT           13653       /*Q14       0.8333f     <-0.35, 0.85>     */
#define G729EV_FEC_C_TILT           313210491   /*Q14+16    0.2917f                       */
#define G729EV_FEC_K_ZC_DEC         -2195       /*Q15       -0.067f     <63, 38>          */
#define G729EV_FEC_C_ZC_DEC         171246      /*Q0+16     2.613       <63, 38>          */
#define G729EV_FEC_K_ENR            18725       /*Q15       0.57143     <-14, 11>         */
#define G729EV_FEC_C_ENR            14384953    /*Q8+16     0.85741f                      */
#define G729EV_FEC_K_PC_DEC         -1927       /*Q15       -0.0588f    <45, 17>          */
#define G729EV_FEC_C_PC_DEC         107925      /*Q0+16     1.6071f                       */
#define G729EV_FEC_UNS6             10923/2

#define G729EV_FEC_AGC              31470

#define G729EV_FEC_L_FRAME_FER      G729EV_MAIN_L_FRAME2
#define G729EV_FEC_L_FRAME2_FER     (G729EV_FEC_L_FRAME_FER/2)
#define G729EV_FEC_L_SUBFR          (G729EV_MAIN_L_FRAME2/G729EV_MAIN_NB_SUBFR)
#define G729EV_FEC_L_MEM            (G729EV_MAIN_L_FRAME2+G729EV_FEC_L_FIR_FER)
#define G729EV_FEC_PIT_MAX32        (Word16)(G729EV_G729_PIT_MAX*32)
#define G729EV_FEC_PIT_MIN32        (Word16)(G729EV_G729_PIT_MIN*32)

#define G729EV_FEC_K_EE             20480 /*Q13 */
#define G729EV_FEC_C_EE             -41943040
#define G729EV_FEC_K_RELE           1638  /*Q15 */
#define G729EV_FEC_C_RELE           14746 /*Q15 */
#define G729EV_FEC_K_SNR            3151  /*Q15 */
#define G729EV_FEC_C_SNR            -8192 /*Q15 */
#define G729EV_FEC_K_PC_ENC         -3854 /*Q15 */
#define G729EV_FEC_C_PC_ENC         131072/*Q16 */
#define G729EV_FEC_K_ZC_ENC         -3277 /*Q15 */
#define G729EV_FEC_C_ZC_ENC         16384 /*Q13 */


#define G729EV_TDBWE_FADE_OUT_LENGTH 50
#define ATTENUATION_CONST 150
#endif /*__G729EV_MAIN_DEFINES_H__ */
