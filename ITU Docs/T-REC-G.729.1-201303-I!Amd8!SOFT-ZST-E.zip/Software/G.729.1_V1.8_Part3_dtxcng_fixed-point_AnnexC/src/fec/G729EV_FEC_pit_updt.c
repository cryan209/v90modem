/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdio.h>
#include <stdlib.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "stl.h"

/************************************************************************************/
/* G729EV_FEC_pit_updt :  Update last reliable pitch                                */
/************************************************************************************/

void G729EV_FEC_pit_updt(Word16 clas,        /* i:   frame classification              */
                         Word16 * pitch_buf, /* i:   fractionnal pitch buffer    Q5    */
                         Word16 last_good,   /* i:   Last good frame classification    */
                         Word16 * upd_cnt,   /* i/o: update counter                    */
                         Word16 * old_fpitch,/* i/o: old fractionnal pitch buffer Q5   */
                         Word16 * fpitch     /* i/o: fractionnal pitch            Q5   */
    )
{
  Word16    tmp1, tmp_old;

#if (WMOPS)
  test();
#endif
  IF((sub(clas, G729EV_FEC_VOICED) == 0) && (sub(last_good, G729EV_FEC_V_TRANSITION) >= 0))
  {
    tmp1 = mult(22938, pitch_buf[1]);
    tmp_old = mult(22938, *old_fpitch);
#if (WMOPS)
    test();
    test();
    test();
#endif
    if ((sub(shr(pitch_buf[3], 1), tmp1) < 0) && (sub(pitch_buf[3], tmp1) > 0) && /* Check for pitch coherence */
        (sub(shr(pitch_buf[1], 1), tmp_old) < 0) && (sub(pitch_buf[3], tmp_old) > 0))
    {
      *upd_cnt = 0;
#if(WMOPS)
      move16();
#endif
    }
  }

  IF(sub(clas, G729EV_FEC_UNVOICED) == 0)
  {
    *old_fpitch = shr(add(fpitch[0], fpitch[1]), 1);
  }
  ELSE
  {
    *old_fpitch = pitch_buf[3];
  }
#if(WMOPS)
  move16();
  move16();
#endif
  *upd_cnt = add(*upd_cnt, 1);  /* counter of the age of the last update */

  if (sub(*upd_cnt, G729EV_FEC_MAX_UPD_CNT) > 0)
  {
    *upd_cnt = G729EV_FEC_MAX_UPD_CNT;
#if(WMOPS)
    move16();
#endif
  }

}
