/* ITU-T G.729.1 - Reference C code for fixed-point implementation               */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Apr 24, 2008                                                   */

/*
   ITU-T G.729.1    ANSI-C Source Code
   Copyright (c) 2006-08 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_TDAC_ENCOD_H__
#define __G729EV_TDAC_ENCOD_H__

#include <stdio.h>
#include "stl.h"

/* Functions : */

void      G729EV_TDAC_encoder(Word16 * y_lo, Word16 * y_hi, Word16 * bitstream, Word16 nbit, Word16 nbit_max,
                              Word16 norm_lo, Word16 norm_hi, Word16 norm_MDCT);


/* Tables : */

#endif /* __G729EV_TDAC_ENCOD_H__ */
