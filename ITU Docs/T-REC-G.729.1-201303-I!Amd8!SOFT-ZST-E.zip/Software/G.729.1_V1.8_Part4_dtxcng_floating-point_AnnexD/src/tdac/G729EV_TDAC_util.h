/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#ifndef __G729EV_TDAC_UTIL_H__
#define __G729EV_TDAC_UTIL_H__

#include <stdio.h>
#include "CodecTypedef.h"

/* Functions : */

INT16     G729EV_MAIN_c_REAL_INT16(REAL round_var);
void      G729EV_TDAC_pushBit(UINT16 code, INT16 ** pBit, int nbit);
void      G729EV_TDAC_pushBitL(UINT32 code, INT16 ** pBit, int nbit);
UINT16    G729EV_TDAC_getBit(INT16 ** pBit, int nbit);
UINT32    G729EV_TDAC_getBitL(INT16 ** pBit, int nbit);
void      G729EV_MAIN_copyRealToInt(REAL * src, INT16 * dest, int n);


/* Tables : */


#endif  /*__G729EV_TDAC_UTIL_H__ */
