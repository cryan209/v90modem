/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <assert.h>
#include <stdlib.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_PostModify()                                      *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                        *
 *  Modify envelope for post-processing of MDCT coefficients                *
*--------------------------------------------------------------------------*/
void G729EV_TDAC_PostModify(REAL * yq,  /* (i)     envelope per subbands */
                            int n_yq,   /* (i)     number of subbands */
                            REAL alfa   /* (i)     tuning factor */
    )
{
  REAL      Max, alfa0, alfa1;
  int       j;

  Max = (REAL) 1.0;
  for (j = 0; j < n_yq; j++)
  {
    if (yq[j] > Max)
      Max = yq[j];
  }

  alfa1 = 1 - alfa;
  alfa0 = alfa / Max;
  for (j = 0; j < n_yq; j++)
  {
    if (yq[j] < Max)
      yq[j] *= (yq[j] * alfa0 + alfa1);
  }

}

/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDAC_PostProcess()                                     *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                       *
 *  Post-processing of higher-band MDCT coefficients                        *
 *--------------------------------------------------------------------------*/
void G729EV_TDAC_PostProcess(REAL * ykr,  /* (i)     reconstructed higher-band MDCT coefficients */
                             int nbits    /* (i)     number of bits to decode in TDAC */
    )
{

  REAL      EnvelopQ[G729EV_TDAC_NB_SB_PST], EnvelopQ_P[G729EV_TDAC_NB_SB_PST];
  int       sign[G729EV_MAIN_L_FRAME2];
  REAL      Mag0, Mag1, g, alfa, beta;
  int       i, j, i_s, rate_flag;

  alfa = (REAL) 0.25;
  beta = (REAL) 0.3;
  rate_flag = (nbits / 8 - 35) / 5; /* 0:14kbps;  1:16kbps;...;  9:32kbps */
  alfa -= rate_flag / (REAL) 64.;
  beta -= rate_flag / (REAL) 64.;

  /* ----------------- Record sign ----------------- */
  for (j = 0; j < G729EV_MAIN_L_FRAME2; j++)
  {
    sign[j] = 1;
    if (ykr[j] < 0)
    {
      sign[j] = -1;
      ykr[j] = -ykr[j];
    }
  }

  /* ----------------------------------------------- */
  /* Envelope estimate  and Post-processing         */
  /* ----------------------------------------------- */

  /* Envelope */
  i_s = 0;
  for (j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    /* Envelope estimate */
    EnvelopQ[j] = (REAL) 1.0;
    for (i = i_s; i < i_s + G729EV_TDAC_NB_SB_LEN; i++)
      EnvelopQ[j] += ykr[i];
    i_s += G729EV_TDAC_NB_SB_LEN;
  }

  /* Post-processing */
  Mag0 = (REAL) 1.;
  for (j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
    Mag0 += EnvelopQ[j];

  for (j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
    EnvelopQ_P[j] = EnvelopQ[j];
  G729EV_TDAC_PostModify(EnvelopQ_P, G729EV_TDAC_NB_SB_PST, alfa);

  /* Energy compensation */
  Mag1 = (REAL) 1.;
  for (j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
    Mag1 += EnvelopQ_P[j];

  g = Mag0 / Mag1;
  for (j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
    EnvelopQ_P[j] *= g;

  /* Normalize */
  for (j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
    EnvelopQ_P[j] /= EnvelopQ[j];

  /* ----------------------------------------------- */
  /*  Fine structure post-processing                */
  /* ----------------------------------------------- */

  i_s = 0;
  for (j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    G729EV_TDAC_PostModify(&ykr[i_s], G729EV_TDAC_NB_SB_LEN, beta);
    i_s += G729EV_TDAC_NB_SB_LEN;
  }

  /* ----------------------------------------------- */
  /*      Reconstruction                            */
  /* ----------------------------------------------- */
  i_s = 0;
  for (j = 0; j < G729EV_TDAC_NB_SB_PST; j++)
  {
    for (i = i_s; i < i_s + G729EV_TDAC_NB_SB_LEN; i++)
      ykr[i] *= sign[i] * EnvelopQ_P[j];
    i_s += G729EV_TDAC_NB_SB_LEN;
  }

  /* ----------------------------------------------- */
  return;
}
