/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/



#ifndef __G729EV_TDAC_COEF_VQ_H__
#define __G729EV_TDAC_COEF_VQ_H__

#include <stdio.h>
#include "CodecTypedef.h"

/* Functions : */
    /* Prototypes */

void      G729EV_TDAC_VQ_quant(REAL * x, int dim, int nbit, UINT32 * cod);
UINT32    G729EV_TDAC_schalk(int dim, int ilead, int *tab_pos, int *tab_sgn);
void      G729EV_TDAC_SrchDic(int dim, int nbit, int *IdicSel);
void      G729EV_TDAC_SrchLead(REAL * x, int dim, int *tab_pos, int *tab_sgn, REAL * xn);
INT16     G729EV_TDAC_getNbLead(int dim, int idic);
void      G729EV_TDAC_VQLead(REAL * xn, int dim, int *ILead, int ivq1);
INT16     G729EV_TDAC_getInfoLead(int dim, int ilead, INT16 ** ptr_nb_val,
                                  INT16 ** ptr_val, UINT32 * offset, INT16 * nb_sgn, REAL * inv_norm_l2);
INT32     G729EV_TDAC_prod_prm_fact(INT16 * exp);
void      G729EV_TDAC_inv_schalk(UINT32 UL_rank, int n, int ind_lead, INT16 * y, REAL * inv_norm_l2);
int       G729EV_TDAC_SearchPrev(int n, int dim);
int       G729EV_TDAC_SelectCbk(int nbit, int dim);

/* Tables : */
extern const INT16 G729EV_TDAC_tab_nb_prm_fact[17];
extern const INT16 G729EV_TDAC_delta_decomp_val[17];
extern const INT16 G729EV_TDAC_tab_decomp_val[17 * 6];
extern const INT16 G729EV_TDAC_tab_decomp_fact[17 * 6];
extern const INT16 *G729EV_MAIN_adRate[G729EV_TDAC_N_NBC + 1];
extern const INT16 G729EV_MAIN_NbDic[G729EV_TDAC_N_NBC + 1];
extern const INT16 *G729EV_MAIN_adNbLeadpRat[G729EV_TDAC_N_NBC + 1];
extern const INT16 *G729EV_MAIN_adListLead[G729EV_TDAC_N_NBC + 1];
extern const UINT16 G729EV_MAIN_maskBit[G729EV_TDAC_MAX_LONG_HUFF + 1];
extern const REAL G729EV_MAIN_InvNormL2Lead[G729EV_TDAC_NB_LEAD_H];
extern const INT16 G729EV_MAIN_dim_leader[G729EV_TDAC_NB_LEAD_H];
extern const INT16 G729EV_MAIN_delta_leader[G729EV_TDAC_NB_LEAD_H];
extern const INT16 *G729EV_MAIN_adLeader[G729EV_TDAC_N_NBC + 1];
extern const UINT32 *G729EV_MAIN_adOffsetLead[G729EV_TDAC_N_NBC + 1];

extern const INT16 G729EV_TDAC_tab_pow3[8];
extern const INT16 G729EV_TDAC_tab_pow5[5];
extern const INT16 G729EV_TDAC_tab_pow7[4];
extern const INT16 G729EV_TDAC_tab_pow11[3];
extern const INT16 G729EV_TDAC_tab_pow13[3];

#endif  /*__G729EV_TDAC_COEF_VQ_H__ */
