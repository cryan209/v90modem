/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"


/*---------------------------------------------------------------------------*
 * Function  G729EV_G729_Dec_gain                                            *
 * ~~~~~~~~~~~~~~~~~~                                                        *
 * Decode the pitch and codebook gains                                       *
 *                                                                           *
 *---------------------------------------------------------------------------*
 * input arguments:                                                          *
 *                                                                           *
 *   index      :Quantization index                                          *
 *   code[]     :Innovative code vector                                      *
 *   l_subfr    :Subframe size                                               *
 *   bfi        :Bad frame indicator                                         *
 *                                                                           *
 * output arguments:                                                         *
 *                                                                           *
 *   gain_pit   :Quantized pitch gain                                        *
 *   gain_cod   :Quantized codebook gain                                     *
 *                                                                           *
 *---------------------------------------------------------------------------*/
void G729EV_G729_Dec_gain(int index,        /*(i) : Index of quantization              */
                          REAL code[],      /*(i) : Innovative vector                  */
                          int l_subfr,      /*(i) : subframe length                    */
                          int bfi,          /*(i) : bad frame indicator good = 0       */
                          REAL * gain_pit,  /*(o) : pitch gain                         */
                          REAL * gain_code, /*(o) : code gain                          */
                          REAL * past_qua_en)
{


  int       index1, index2;
  REAL      gcode0, g_code;

  /*-------------- Decode pitch gain ---------------*/
  index1 = imap1[index >> G729EV_G729_NCODE2_B];
  index2 = imap2[index & (G729EV_G729_NCODE2 - 1)];
  *gain_pit = gbk1[index1][0] + gbk2[index2][0];

  /*-------------- Decode codebook gain ---------------*/
  /*---------------------------------------------------*
  *-  energy due to innovation                       -*
  *-  predicted energy                               -*
  *-  predicted codebook gain => gcode0[exp_gcode0]  -*
  *---------------------------------------------------*/
  G729EV_G729_Gain_predict(past_qua_en, code, l_subfr, &gcode0);

  /*-----------------------------------------------------------------*
  * *gain_code = (gbk1[indice1][1]+gbk2[indice2][1]) * gcode0;      *
  *-----------------------------------------------------------------*/
  g_code = gbk1[index1][1] + gbk2[index2][1];
  *gain_code = g_code * gcode0;

  /*----------------------------------------------*
  * update table of past quantized energies      *
  *----------------------------------------------*/
  G729EV_G729_Gain_update(past_qua_en, g_code);

  return;
}
