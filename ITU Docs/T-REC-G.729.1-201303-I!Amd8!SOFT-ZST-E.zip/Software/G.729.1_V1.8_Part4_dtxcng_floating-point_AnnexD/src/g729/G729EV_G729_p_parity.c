/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"



/*--------------------------------------------------------------------------*
 * Function G729EV_G729_Parity_Pitch - compute parity bit for first 6 MSBs  *
 *--------------------------------------------------------------------------*/

int G729EV_G729_Parity_Pitch(                 /* (o) : parity bit (XOR of 6 MSB bits)     */
                              int pitch_index /* (i) : index for which parity to compute */
    )
{
  int       temp, sum, i, bit;

  temp = pitch_index >> 1;

  sum = 1;
  for (i = 0; i <= 5; i++)
  {
    temp >>= 1;
    bit = temp & 1;
    sum = sum + bit;
  }
  sum = sum & 1;

  return (sum);
}

/*-----------------------------------------------------------------------------------------*
 * Function G729EV_G729_Check_Parity_Pitch - check parity of index with transmitted parity *
 *-----------------------------------------------------------------------------------------*/

int G729EV_G729_Check_Parity_Pitch(                   /*  (o) : 0 = no error, 1= error */
                                    int pitch_index,  /*  (i) : index of parameter     */
                                    int parity        /*  (i) : parity bit             */
    )
{
  int       temp, sum, i, bit;

  temp = pitch_index >> 1;

  sum = 1;
  for (i = 0; i <= 5; i++)
  {
    temp >>= 1;
    bit = temp & 1;
    sum = sum + bit;
  }
  sum += parity;
  sum = sum & 1;

  return (sum);
}
