/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.8                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729_SID_H__
#define __G729EV_G729_SID_H__

#include "CodecTypedef.h"

#define         TRUE 1
#define         FALSE 0
#define         sqr(a)  ((a)*(a))
#define         R_LSFQ 10

void lsfq_noise(REAL noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M],
				REAL *lsp_new, REAL *lspq,
                REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], int *idx);
void      G729EV_G729B_Dec_cng(G729EV_G729_DECSTAT * pDecStat, int past_ftyp,     /* (i)   : past frame type                      */
                               REAL sid_sav,                                      /* (i)   : energy to recover SID gain           */
                               int *parm,                                         /* (i)   : coded SID parameters                 */
                               REAL * exc,                                        /* (i/o) : excitation array                     */
                               REAL * lsp_old,                                    /* (i/o) : previous lsp                         */
                               REAL * A_t,                                        /* (o)   : set of interpolated LPC coefficients */
                               INT16 * seed,                                      /* (i/o) : random generator seed                */
                               REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],  /* (i/o) : previous LPS for quantization        */
                          		INT16 ftyp, int bfi
								);

void      sid_lsfq_decode(int *index,                                       /* (i) : quantized indices    */
                          REAL * lspq,                                      /* (o) : quantized lsp vector */
                          REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i) : memory of predictor  */
						  REAL noise_fg[G729EV_G729_MODE][G729EV_G729_MA_NP][G729EV_G729_M],
						  INT16 sid_nb,
						  int Ratio_3rd_idx
						  );
                     
#endif
