/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

static void G729EV_G729_Gbk_presel(REAL best_gain[],  /* (i) [0]    : unquantized pitch gain     */
                                                      /* (i) [1]    : unquantized code gain      */
                                   int *cand1,        /* (o)        : index of best 1st stage vector */
                                   int *cand2,        /* (o)        : index of best 2nd stage vector */
                                   REAL gcode0        /* (i)        : presearch for gain codebook    */
    );

/*****************************************************************************/
/* gain quantizer routines                                                   */
/*****************************************************************************/

/*---------------------------------------------------------------------------*
 * Function  G729EV_G729_Qua_gain                                            *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                            *
 * Inputs:                                                                   *
 *   code[]     :Innovative codebook.                                        *
 *   g_coeff[]  :Correlations compute for pitch.                             *
 *   l_subfr    :Subframe length.                                            *
 *                                                                           *
 * Outputs:                                                                  *
 *   gain_pit   :Quantized pitch gain.                                       *
 *   gain_code  :Quantized code gain.                                        *
 *                                                                           *
 * Return:                                                                   *
 *   Index of quantization.                                                  *
 *                                                                           *
 *---------------------------------------------------------------------------*/
int G729EV_G729_Qua_gain(                   /* (o)  : quantizer index                   */
                          REAL code[],      /* (i) : Innovative vector               */
                          REAL * g_coeff,   /* (i) : Correlations <xn y1> -2<y1 y1>  */
                                            /*         <y2,y2>, -2<xn,y2>, 2<y1,y2>  */
                          int l_subfr,      /* (i) : Subframe length                 */
                          REAL * gain_pit,  /* (o): Pitch gain                       */
                          REAL * gain_code, /* (o): Code gain                        */
                          int tameflag,     /* (i) : set to 1 if taming is needed    */
                          REAL * past_qua_en)
{
  int       i, j, index1, index2;
  int       cand1, cand2;
  REAL      gcode0;
  REAL      dist, dist_min, G729EV_G729_g_pitch, g_code;
  REAL      best_gain[2], tmp;

  /*---------------------------------------------------*
  *-  energy due to innovation                       -*
  *-  predicted energy                               -*
  *-  predicted codebook gain => gcode0[exp_gcode0]  -*
  *---------------------------------------------------*/
  G729EV_G729_Gain_predict(past_qua_en, code, l_subfr, &gcode0);

  /*-----------------------------------------------------------------*
  *  pre-selection                                                  *
  *-----------------------------------------------------------------*/
  /*-----------------------------------------------------------------*
  *  calculate best gain                                            *
  *-----------------------------------------------------------------*/

  tmp = (REAL) - 1. / ((REAL) 4. * g_coeff[0] * g_coeff[2] - g_coeff[4] * g_coeff[4]);
  best_gain[0] = ((REAL) 2. * g_coeff[2] * g_coeff[1] - g_coeff[3] * g_coeff[4]) * tmp;
  best_gain[1] = ((REAL) 2. * g_coeff[0] * g_coeff[3] - g_coeff[1] * g_coeff[4]) * tmp;

  if (tameflag == 1)
  {
    if (best_gain[0] > G729EV_G729_GPCLIP2)
      best_gain[0] = G729EV_G729_GPCLIP2;
  }
  /*----------------------------------------------*
  *   - presearch for gain codebook -            *
  *----------------------------------------------*/

  G729EV_G729_Gbk_presel(best_gain, &cand1, &cand2, gcode0);

  /*---------------------------------------------------------------------------*
  * Find the best quantizer.                                                  *
  *---------------------------------------------------------------------------*/

  dist_min = G729EV_G729_FLT_MAX_G729;

  /* initialization used only to suppress Microsoft Visual C++  warnings */
  index1 = cand1;
  index2 = cand2;
  if (tameflag == 1)
  {
    for (i = 0; i < G729EV_G729_NCAN1; i++)
    {
      for (j = 0; j < G729EV_G729_NCAN2; j++)
      {
        G729EV_G729_g_pitch = gbk1[cand1 + i][0] + gbk2[cand2 + j][0];
        if (G729EV_G729_g_pitch < G729EV_G729_GP0999)
        {
          g_code = gcode0 * (gbk1[cand1 + i][1] + gbk2[cand2 + j][1]);
          dist =
              G729EV_G729_g_pitch * G729EV_G729_g_pitch * g_coeff[0] +
              G729EV_G729_g_pitch * g_coeff[1] +
              g_code * g_code * g_coeff[2] + g_code * g_coeff[3] + G729EV_G729_g_pitch * g_code * g_coeff[4];
          if (dist < dist_min)
          {
            dist_min = dist;
            index1 = cand1 + i;
            index2 = cand2 + j;
          }
        }
      }
    }
  }
  else
  {
    for (i = 0; i < G729EV_G729_NCAN1; i++)
    {
      for (j = 0; j < G729EV_G729_NCAN2; j++)
      {
        G729EV_G729_g_pitch = gbk1[cand1 + i][0] + gbk2[cand2 + j][0];
        g_code = gcode0 * (gbk1[cand1 + i][1] + gbk2[cand2 + j][1]);
        dist =
            G729EV_G729_g_pitch * G729EV_G729_g_pitch * g_coeff[0] +
            G729EV_G729_g_pitch * g_coeff[1] +
            g_code * g_code * g_coeff[2] + g_code * g_coeff[3] + G729EV_G729_g_pitch * g_code * g_coeff[4];
        if (dist < dist_min)
        {
          dist_min = dist;
          index1 = cand1 + i;
          index2 = cand2 + j;
        }
      }
    }
  }
  /* Read the quantized gain */

  *gain_pit = gbk1[index1][0] + gbk2[index2][0];
  g_code = gbk1[index1][1] + gbk2[index2][1];
  *gain_code = g_code * gcode0;

  /*----------------------------------------------*
  * update table of past quantized energies      *
  *----------------------------------------------*/
  G729EV_G729_Gain_update(past_qua_en, g_code);

  return (map1[index1] * G729EV_G729_NCODE2 + map2[index2]);
}

/*---------------------------------------------------------------------------*
 * Function G729EV_G729_Gbk_presel                                           *
 * ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                           *
 *   - presearch for gain codebook -                                         *
 *---------------------------------------------------------------------------*/
static void G729EV_G729_Gbk_presel(REAL best_gain[],  /* (i) : [0] unquantized pitch gain     */
                                                      /*       [1] unquantized code gain      */
                                   int *cand1,        /* (o) : index of best 1st stage vector */
                                   int *cand2,        /* (o) : index of best 2nd stage vector */
                                   REAL gcode0        /* (i) : presearch for gain codebook    */
    )
{
  REAL      x, y;

  x = (best_gain[1] - (coef[0][0] * best_gain[0] + coef[1][1]) * gcode0) * G729EV_G729_INV_COEF;
  y = (coef[1][0] *
       (-coef[0][1] + best_gain[0] * coef[0][0]) * gcode0 - coef[0][0] * best_gain[1]) * G729EV_G729_INV_COEF;

  if (gcode0 > (REAL) 0.0)
  {
    /* pre select codebook #1 */
    *cand1 = 0;
    do
    {
      if (y > thr1[*cand1] * gcode0)
        (*cand1)++;
      else
        break;
    }
    while ((*cand1) < (G729EV_G729_NCODE1 - G729EV_G729_NCAN1));

    /* pre select codebook #2 */
    *cand2 = 0;
    do
    {
      if (x > thr2[*cand2] * gcode0)
        (*cand2)++;
      else
        break;
    }
    while ((*cand2) < (G729EV_G729_NCODE2 - G729EV_G729_NCAN2));
  }
  else
  {
    /* pre select codebook #1 */
    *cand1 = 0;
    do
    {
      if (y < thr1[*cand1] * gcode0)
        (*cand1)++;
      else
        break;
    }
    while ((*cand1) < (G729EV_G729_NCODE1 - G729EV_G729_NCAN1));

    /* pre select codebook #2 */
    *cand2 = 0;
    do
    {
      if (x < thr2[*cand2] * gcode0)
        (*cand2)++;
      else
        break;
    }
    while ((*cand2) < (G729EV_G729_NCODE2 - G729EV_G729_NCAN2));
  }

  return;
}
