/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.8                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_G729_DTX_H__
#define __G729EV_G729_DTX_H__

#include "G729EV_G729_decstat.h"

/* quantize the energy */
void G729EV_Qua_Sidgain_quant_Energy(
    REAL *enerq,    /* (o)   first stage decoded energies in dB              */
    int *idx,       /* (o)   first stage SID gain quantization index         */
	REAL *enerq2,   /* (o)   second stage decoded energies in dB              */
    int *idx2,      /* (o)   second stage SID gain quantization index         */
    REAL frame_energy     /* (i)   energy                   */
);

/* SID gain Quantization */
void      G729EV_Qua_Sidgain(REAL * ener,  /* (i)   array of energies                   */
                      int nb_ener,  /* (i)   number of energies or               */
                      REAL * enerq, /* (o)   decoded energies in dB              */
                      int *idx,      /* (o)   SID gain quantization index         */
					  REAL *enerq2,    /* (o)   decoded energies in dB              */
					  int *idx2,       /* (o)   SID gain quantization index         */
					  REAL *frame_energy     /* (i)   energy                */
					  );


/* CNG excitation generation */
void G729EV_calc_exc_rand(
    REAL cur_gain,       /* (i)   :   target sample gain                 */
    REAL * exc,          /* (i/o) :   excitation array                   */
    INT16 * seed,        /* (i)   :   current Vad decision               */
    int flag_cod,        /* (i)   :   encoder/decoder flag               */
	REAL *exc_err,
	INT16 pastVad,
	INT16 *old_pitch,
	REAL *old_gp,
	REAL *pre_gain,
	INT16 *i_subfr_cnt,
	REAL *lp_gainp,
	REAL *lp_gainc,
	REAL *tilt_code
    );

/* Encoder DTX/CNG functions */
void init_cod_cng(G729EV_G729_CODSTAT * pCodStat);
void G729EV_cod_cng(
    G729EV_G729_CODSTAT * pCodStat,
	int   ftyp_j,         /* (i) : number of 10 ms frame */
    REAL *exc,          /* (i/o) : excitation array                     */
    REAL *Aq,           /* (o)   : set of interpolated LPC coefficients */
    int *ana,            /* (o)   : coded SID parameters                 */
    REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* (i/o) : previous LPS for quantization        */
    REAL *SID_tdbwe_parameters,
	REAL *tdbwe_parameters
);
void update_cng(
  G729EV_G729_CODSTAT * pCodStat,
  REAL *r,         /* (i) :   frame autocorrelation               */
  int Vad           /* (i) :   current Vad decision                */
);

#endif
