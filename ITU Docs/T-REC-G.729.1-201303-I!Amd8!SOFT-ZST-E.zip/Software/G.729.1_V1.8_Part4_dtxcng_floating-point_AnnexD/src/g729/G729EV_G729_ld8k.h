/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.8                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/
#ifndef __G729EV_G729_LD8K_H__
#define __G729EV_G729_LD8K_H__

/*--------------------------------------------------------------*
 * LD8K.H                                                       *
 * ~~~~~~                                                       *
 * Function prototypes and constants use in G.729               *
 *                                                              *
 *--------------------------------------------------------------*/

#include <stdio.h>
#include "G729EV_G729_defines.h"
#include "G729EV_G729_codstat.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_defines.h"
#include "G729EV_FEC_tools.h"

/*--------------------------------------------------------------------------*
 * LPC analysis and filtering                                               *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_AutocorrLPC(REAL * x, /* (i)     : input signal                               */
                                  int m,    /* (i)     : LPC order                                  */
                                  REAL * r  /* (o)     : autocorrelations                           */
    );

void      G729EV_G729_Lag_window(int m,   /* (i)     : LPC order                                  */
                                 REAL r[] /* (i/o)   : autocorrelations                           */
    );

/*--------------------------------------------------------------------------*
 * G729D gain  phase dispersion                                             *
 *--------------------------------------------------------------------------*/
void Update_PhDisp(
    REAL ltpGain,   /* (i)  : pitch gain                  */
    REAL cbGain     /* (i)  : codebook gain               */
);
void PhDisp(
    REAL x[],       /* input : excitation signal                */
    REAL x_phdisp[],/* output : excitation signal after phase dispersion */
    REAL cbGain,
    REAL ltpGainQ,
    REAL inno[]
);
REAL	  G729EV_G729_Levinson (REAL * r,     /* (i)     : Rh[m+1] autocorrelation coefficients       */
                                REAL * a,     /* (o)     : A[m]    LPC coefficients  (m = 10)         */
                                REAL * rc,    /* (o)     : rc[M]   Reflection coefficients.           */
                                REAL * old_A, REAL * old_rc 
    );

void      G729EV_G729_Az_lsp(REAL * a,      /* (i)     : predictor coefficients                     */
                             REAL * lsp,    /* (o)     : line spectral pairs                        */
                             REAL * old_lsp /* (i)     : old lsp[] (in case not found 10 roots)     */
    );

void      G729EV_G729_Lsp_Az(REAL * lsp,  /* (i)     : line spectral frequencies                  */
                             REAL * a     /* (o)     : predictor coefficients (order = 10)        */
    );

void      G729EV_G729_Lsp_lsf(REAL lsp[], /* (i)      :  lsp coefficients                         */
                              REAL lsf[], /* (o)      :  lsf (normalized frequencies)             */
                              int m       /* (i)      :  LPC order                                */
    );

void      G729EV_G729_Lsf_lsp(REAL lsf[], /* (i)      :  lsf coefficients                         */
                              REAL lsp[], /* (o)      :  lsp coefficients                         */
                              int m       /* (i)      :  LPC order                                */
    );

void      G729EV_G729_Int_lpc(REAL lsp_old[], /* (i)    : LSP vector of past frame                   */
                              REAL lsp_new[], /* (i)    : LSP vector of present frame                */
                              REAL lsf_int[], /* (o)    : interpolated lsf coefficients              */
                              REAL lsf_new[], /* (o)    : new lsf coefficients                       */
                              REAL az[]       /* (o)    : interpolated Az() for the 2 subframes      */
    );

void      G729EV_G729_Int_qlpc(REAL lsp_old[],  /* (i)    : LSP vector of past frame                   */
                               REAL lsp_new[],  /* (i)    : LSP vector of present frame                */
                               REAL az[]        /* (o)    : interpolated Az() for the 2 subframes      */
    );

/*--------------------------------------------------------------------------*
 *       PWF functions                                                      *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_perc_var(REAL * gamma1, /*(o)     : gamma1 value                              */
                               REAL * gamma2, /*(o)     : gamma2 value                              */
                               REAL * lsfint, /*(i)     : Interpolated LSP vector : 1st subframe    */
                               REAL * lsfnew, /*(i)     : New LSP vector : 2nd subframe             */
                               REAL * r_c,    /*(i)     : Reflection coefficients                   */
                               REAL lar_old[2], INT16 * smooth);

void      G729EV_G729_Weight_Az(REAL a[],   /* (i)     : a[m+1]  LPC coefficients                   */
                                REAL gamma, /* (i)     : Spectral expansion factor.                 */
                                int m,      /* (i)     : LPC order.                                 */
                                REAL ap[]   /* (o)     : Spectral expanded LPC coefficients         */
    );

void      G729EV_G729_Convolve(REAL x[],  /* (i)     : input vector                               */
                               REAL h[],  /* (i)     : impulse response                           */
                               REAL y[],  /* (o)     : output vector                              */
                               int l      /* (i)     : vector size                                */
    );

void      G729EV_G729_Syn_filt(REAL a[],    /* (i)     : a[m+1] prediction coefficients   (m=10)  */
                               REAL x[],    /* (i)     : input signal                             */
                               REAL y[],    /* (i)     : output signal                            */
                               int lg,      /* (i)     : size of filtering                        */
                               REAL mem[],  /* (i/o)   : memory associated with this filtering.   */
                               int update   /* (i)     : 0=no update, 1=update of memory.         */
    );

void      G729EV_G729_Residu(REAL * a,  /* (i)     : prediction coefficients                    */
                             REAL * x,  /* (i)     : speech (values x[-m..-1] are needed (m=10) */
                             REAL * y,  /* (o)     : residual signal                            */
                             int lg     /* (i)     : frame size                                 */
    );

/*--------------------------------------------------------------------------*
 * Pitch functions.                                                         *
 *--------------------------------------------------------------------------*/

int       G729EV_G729_Pitch_ol(                 /* (o)     : open loop pitch lag                        */
                                REAL signal[],  /* (i)     : signal used to compute the open loop pitch */
                                                /*       signal[-pit_max] to signal[-1] should be known */
                                int pit_min,    /* (i)     : minimum pitch lag                          */
                                int pit_max,    /* (i)     : maximum pitch lag                          */
                                int l_frame,    /* (i)     : length of frame to compute pitch           */
                                REAL * voicing, INT16 * pit_old);

int       G729EV_G729_Pitch_fr3(                /* (o)     : pitch period.                              */
                                 REAL exc[],    /* (i)     : excitation buffer                          */
                                 REAL xn[],     /* (i)     : target vector                              */
                                 REAL h[],      /* (i)     : impulse response of filters.               */
                                 int l_subfr,   /* (i)     : length of subframe                         */
                                 int t0_min,    /* (i)     : minimum value in the searched range.       */
                                 int t0_max,    /* (i)     : maximum value in the searched range.       */
                                 int i_subfr,   /* (i)     : indicator for first subframe.              */
                                 int *pit_frac  /* (o)     : chosen fraction.                           */
    );

REAL      G729EV_G729_G_pitch(                  /* (o)     : Gain of pitch lag saturated to 1.2         */
                               REAL xn[],       /* (i)     : Pitch target.                              */
                               REAL y1[],       /* (i)     : Filtered adaptive codebook.                */
                               REAL g_coeff[],  /* (i)     : Correlations need for gain quantization.   */
                               int l_subfr      /* (i)     : Length of subframe.                        */
    );

int       G729EV_G729_Enc_lag3(               /* (o)     : Return index of encoding                   */
                                int T0,       /* (i)     : Pitch delay                                */
                                int T0_frac,  /* (i)     : Fractional pitch delay                     */
                                int *T0_min,  /* (i/o)   : Minimum search delay                       */
                                int *T0_max,  /* (i/o)   : Maximum search delay                       */
                                int pit_min,  /* (i)     : Minimum pitch delay                        */
                                int pit_max,  /* (i)     : Maximum pitch delay                        */
                                int pit_flag  /* (i)     : Flag for 1st subframe                      */
    );

void      G729EV_G729_Dec_lag3(               /* (o)     : return integer pitch lag                   */
                                int index,    /* (i)     : received pitch index                       */
                                int pit_min,  /* (i)     : minimum pitch lag                          */
                                int pit_max,  /* (i)     : maximum pitch lag                          */
                                int i_subfr,  /* (i)     : subframe flag                              */
                                int *T0,      /* (o)     : integer part of pitch lag                  */
                                int *T0_frac  /* (o)     : integer part of pitch lag                  */
    );

REAL      G729EV_G729_Interpol_3(           /* (o)     : interpolated value                         */
                                  REAL * x, /* (i)     : input vector                               */
                                  int frac  /* (i)     : fraction                                   */
    );

void      G729EV_G729_Pred_lt_3(REAL exc[], /* (i/o)   : excitation buffer                          */
                                int t0,     /* (i)     : integer pitch lag                          */
                                int frac,   /* (i)     : fraction of lag                            */
                                int l_subfr /* (i)     : subframe size                              */
    );

int       G729EV_G729_Parity_Pitch(                 /* (o)    : parity bit (XOR of 6 MSB bits)             */
                                    int pitch_index /* (i)    : index for which parity to compute          */
    );

int       G729EV_G729_Check_Parity_Pitch(                   /* (o) : 0 = no error, 1= error                  */
                                          int pitch_index,  /* (i)    : index for which parity to compute          */
                                          int parity        /* (i)   : parity bit                                 */
    );

/*--------------------------------------------------------------------------*
 * fixed codebook excitation.                                               *
 *--------------------------------------------------------------------------*/

/*--------------------------------------------------------------------------*
 * FCB functions.                                                           *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_Cor_h(REAL * H, /* (i)     :Impulse response of filters */
                            REAL * rr /* (o)     :Correlations of H[]         */
    );

void      G729EV_G729_Cor_h_X(REAL h[], /* (i)     :Impulse response of filters      */
                              REAL X[], /* (i)     :Target vector                    */
                              REAL D[], /* (o)     :Correlations between h[] and D[] */
                              short stp);

void      G729EV_G729_Corr_xy2(REAL xn[],     /* (i)     :Target vector.                  */
                               REAL y1[],     /* (i)     :Adaptive codebook.              */
                               REAL y2[],     /* (i)     :Filtered innovative vector.     */
                               REAL g_coeff[] /* (o)     :Correlations between xn,y1,y2   */
    );

void      G729EV_G729_Decod_ACELP(int sign,   /* (i)     : signs of 4 pulses.                         */
                                  int index,  /* (i)     : Positions of the 4 pulses.                 */
                                  REAL cod[]  /* (o)     : algebraic (fixed) codebook excitation      */
    );

/*--------------------------------------------------------------------------*
 * LSP VQ functions.                                                        *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_Qua_lsp(REAL lsp[],   /* (i)     : Unquantized LSP                            */
                              REAL lsp_q[], /* (i)     : Quantized LSP                              */
                              int ana[],    /* (o)     : indexes                                    */
                              REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729_Get_wegt(REAL flsp[], REAL wegt[]);

void      G729EV_G729_Lsp_encw_reset(REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729_Lsp_qua_cs(REAL * flsp_in,
                                 REAL * lspq_out, int *code, REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729_Lsp_decw_reset(REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                     REAL prev_lsp[G729EV_G729_M], INT16 * prev_ma);

REAL      G729EV_G729_Lsp_iqua_cs(int prm[],    /* (i)     : indexes of the selected LSP */
                                  REAL lsp_q[], /* (o)     : Quantized LSP parameters    */
                                  int erase,    /* (i)     : frame erase information     */
                                  REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                  REAL prev_lsp[G729EV_G729_M], INT16 * prev_ma);

REAL      G729EV_G729_D_lsp(int prm[],    /* (i)     : indexes of the selected LSP */
                            REAL lsp_q[], /* (o)     : Quantized LSP parameters    */
                            int erase,    /* (i)     : frame erase information     */
                            REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], REAL prev_lsp[], INT16 * prev_ma);

void      G729EV_G729_Lsp_get_quant(REAL lspcb1[][G729EV_G729_M],
                                    REAL lspcb2[][G729EV_G729_M],
                                    int code0, int code1, int code2, REAL fg[][G729EV_G729_M],
                                    REAL freq_prev[][G729EV_G729_M], REAL lspq[], REAL fg_sum[]);

void      G729EV_G729_Lsp_expand_1(REAL buf[], REAL gap);

void      G729EV_G729_Lsp_expand_2(REAL buf[], REAL gap);

void      G729EV_G729_Lsp_expand_1_2(REAL buf[], REAL gap);

void      G729EV_G729_Lsp_get_tdist(REAL wegt[], REAL buf[], REAL * tdist, REAL rbuf[], const REAL fg_sum[]);

void      G729EV_G729_Lsp_last_select(REAL tdist[], int *mode_index);

void      G729EV_G729_Lsp_pre_select(REAL rbuf[], int *cand);

void      G729EV_G729_Lsp_select_1(REAL rbuf[], const REAL lspcb1[], REAL wegt[], int *index);

void      G729EV_G729_Lsp_select_2(REAL rbuf[], const REAL lspcb1[], REAL wegt[], int *index);

void      G729EV_G729_Lsp_prev_compose(REAL lsp_ele[],
                                       REAL lsp[],
                                       REAL fg[][G729EV_G729_M], REAL freq_prev[][G729EV_G729_M], REAL fg_sum[]);

void      G729EV_G729_Lsp_prev_extract(REAL lsp[G729EV_G729_M],
                                       REAL lsp_ele[G729EV_G729_M],
                                       REAL fg[G729EV_G729_MA_NP][G729EV_G729_M],
                                       REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M],
                                       REAL fg_sum_inv[G729EV_G729_M]);

void      G729EV_G729_Lsp_prev_update(REAL lsp_ele[G729EV_G729_M], REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]);

void      G729EV_G729_Lsp_stability(REAL buf[]);

void      G729EV_G729_Relspwed(REAL lsp[],
                               REAL wegt[],
                               REAL lspq[], REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], int code_ana[]);

/*--------------------------------------------------------------------------*
 * gain VQ functions.                                                       *
 *--------------------------------------------------------------------------*/

int       G729EV_G729_Qua_gain(REAL code[],       /* (i)     : Innovative vector.                         */
                               REAL * g_coeff,    /* (i)     : Correlations <xn y1> -2<y1 y1>             */
                                                  /*                        <y2,y2>, -2<xn,y2>, 2<y1,y2>  */
                               int l_subfr,       /* (i)     : Subframe length.                           */
                               REAL * gain_pit,   /* (o)     : Pitch gain.                                */
                               REAL * gain_code,  /* (o)     : Code gain.                                 */
                               int tameflag,      /* (i)     : flag set to 1 if taming is needed          */
                               REAL * past_qua_en);

void      G729EV_G729_Dec_gain(int index,         /* (i)     :Index of quantization.         */
                               REAL code[],       /* (i)     :Innovative vector.             */
                               int l_subfr,       /* (i)     :Subframe length.               */
                               int bfi,           /* (i)     :Bad frame indicator            */
                               REAL * gain_pit,   /* (o)     :Pitch gain.                    */
                               REAL * gain_code,  /* (o)     :Code gain.                     */
                               REAL * past_qua_en);

void      G729EV_G729_Gain_predict(REAL past_qua_en[],  /* (i)     : Past quantized energies                    */
                                   REAL code[],         /* (i)     : Innovative vector.                         */
                                   int l_subfr,         /* (i)     : Subframe length.                           */
                                   REAL * gcode0        /* (o)     : Predicted codebook gain                    */
    );

void      G729EV_G729_Gain_update(REAL past_qua_en[], /* (i)     : Past quantized energies                    */
                                  REAL g_code         /* (i)     : Code Gain                                  */
    );

/*--------------------------------------------------------------------------*
 * Postfilter functions                                                *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_pst_ltp(int t0, REAL * ptr_sig_in, REAL * ptr_sig_pst0);

void      G729EV_G729_search_del(int t0, REAL * ptr_sig_in, int *ltpdel,
                                 int *phase, REAL * num_gltp, REAL * den_gltp, REAL * y_up, int *off_yup);

void      G729EV_G729_filt_plt(REAL * s_in, REAL * s_ltp, REAL * s_out, REAL gain_plt);

void      G729EV_G729_compute_ltp_l(REAL * s_in, int ltpdel, int phase, REAL * y_up, REAL * num, REAL * den);

int       G729EV_G729_select_ltp(REAL num1, REAL den1, REAL num2, REAL den2);

void      G729EV_G729_calc_st_filt(REAL * apond2,       /* input : coefficients of numerator */
                                   REAL * apond1,       /* input : coefficients of denominator */
                                   REAL * parcor0,      /* output: 1st parcor calcul. on composed filter */
                                   REAL * sig_ltp_ptr,  /* in/out: input of 1/A(gamma1) : scaled by 1/g0 */
                                   REAL * mem_zero);

void      G729EV_G729_filt_mu(REAL * sig_in, REAL * sig_out, REAL parcor0);

void      G729EV_G729_calc_rc0_h(REAL * h, REAL * rc0);

void      G729EV_G729_scale_st(REAL * sig_in, REAL * sig_out, REAL * gain_prec,
                               REAL parcor0, REAL PostNB, REAL * Level_in_sm, INT16 indication);

/*--------------------------------------------------------------------------*
 * Prototypes for auxiliary functions.                                      *
 *--------------------------------------------------------------------------*/

void      G729EV_G729_Copy(REAL x[],  /* (i)     : input vector                               */
                           REAL y[],  /* (i)     : output vector                              */
                           int length /* (i)     : vector length                              */
    );

void      G729EV_G729_Set_zero(REAL x[],  /* (o)     : vector to clear                            */
                               int length /* (i)     : length of vector                           */
    );

INT16     G729EV_G729_Random(INT16 * seed);

int       G729EV_G729_test_err(                                         /* (o) flag set to 1 if taming is necessary  */
                                G729EV_G729_CODSTAT * pCodStat, int t0, /* (i) integer part of pitch delay           */
                                int t0_frac                             /* (i) fractional part of pitch delay        */
    );

void      G729EV_G729_update_exc_err(REAL gain_pit, /* (i) pitch gain */
                                     int t0,        /* (i) integer part of pitch delay */
                                     REAL * exc_err);

void      G729EV_G729_UpdateMemTam(G729EV_G729_DECSTAT * pDecStat, REAL CoefLtp, int Pitch);

REAL      G729EV_G729_TamFer(G729EV_G729_DECSTAT * pDecStat, REAL CoefLtp, int Pitch);

REAL      G729EV_G729_chebyshev(REAL x,   /*(i)     : value of evaluation; x=cos(freq)            */
                                REAL * f, /*(i)     : coefficients of sum or diff polynomial      */
                                int n     /*(i)     : order of polynomial                         */
    );

REAL      G729EV_G729_inv_sqrt(         /*(o)  : 1/sqrt(x) */
                                REAL x  /*(i)   : value of x */
    );

#endif /* __G729EV_G729_LD8K_H__ */
