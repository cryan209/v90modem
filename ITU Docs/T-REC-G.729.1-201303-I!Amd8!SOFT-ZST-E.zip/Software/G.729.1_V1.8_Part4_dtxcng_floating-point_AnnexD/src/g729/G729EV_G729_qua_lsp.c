/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"





/*---------------------------------------------------------*
* Functions related to the quantization of LSP's           *
*----------------------------------------------------------*/
/**---------------------------------------------------------*
* Function G729EV_G729_Qua_lsp - quantize the LSP         *
*----------------------------------------------------------*/
void G729EV_G729_Qua_lsp(REAL lsp[],    /* (i) : Unquantized LSP            */
                         REAL lsp_q[],  /* (o) : Quantized LSP              */
                         int ana[],     /* (o) : indexes                    */
                         REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M])
{
  REAL      lsf[G729EV_G729_M], lsf_q[G729EV_G729_M]; /* domain 0.0<= lsf <G729EV_G729_PI */

  /* Convert LSPs to LSFs */
  G729EV_G729_Lsp_lsf(lsp, lsf, G729EV_G729_M);

  G729EV_G729_Lsp_qua_cs(lsf, lsf_q, ana, freq_prev);

  /* Convert LSFs to LSPs */
  G729EV_G729_Lsf_lsp(lsf_q, lsp_q, G729EV_G729_M);

  return;
}

/*---------------------------------------------------------------------------
 * Function lsp_encw_reset - set the previous LSP vector
 *----------------------------------------------------------------------------
 */
void G729EV_G729_Lsp_encw_reset(REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]  /* (i) : previous LSP MA vector        */
    )
{
  int       i;

  for (i = 0; i < G729EV_G729_MA_NP; i++)
    G729EV_G729_Copy(&freq_prev_reset[0], &freq_prev[i][0], G729EV_G729_M);

  return;
}

/*---------------------------------------------------------------------------
 * Function lsp_qua_cs - lsp quantizer
 *----------------------------------------------------------------------------
 */
void G729EV_G729_Lsp_qua_cs(REAL * flsp_in,                                                                                       /*  input : Original LSP parameters      */
                            REAL * lspq_out,                                                                                      /*  output: Quantized LSP parameters     */
                            int *code,                                                                                            /*  output: codes of the selected LSP    */
                            REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M]                                                      /**< (i)  : previous LSP MA vector      */
    )
{
  REAL      wegt[G729EV_G729_M];  /* weighting coefficients */

  G729EV_G729_Get_wegt(flsp_in, wegt);

  G729EV_G729_Relspwed(flsp_in, wegt, lspq_out, freq_prev, code);

  return;
}

/*---------------------------------------------------------------------------
 * Function G729EV_G729_Relspwed -
 *----------------------------------------------------------------------------
 */
void G729EV_G729_Relspwed(REAL lsp[],                                       /* input: unquantized LSP parameters  */
                          REAL wegt[],                                      /* input: weighting coefficients      */
                          REAL lspq[],                                      /* output:quantized LSP parameters    */
                          REAL freq_prev[G729EV_G729_MA_NP][G729EV_G729_M], /* input: previous LSP vector         */
                          int code_ana[]                                    /* output:codes of the selected LSP   */
    )
{
  int       mode, j;
  int       index, mode_index;
  int       cand[G729EV_G729_MODE], cand_cur;
  int       tindex1[G729EV_G729_MODE], tindex2[G729EV_G729_MODE];
  REAL      tdist[G729EV_G729_MODE];
  REAL      rbuf[G729EV_G729_M];
  REAL      buf[G729EV_G729_M];

  for (mode = 0; mode < G729EV_G729_MODE; mode++)
  {

    G729EV_G729_Lsp_prev_extract(lsp, rbuf, fg[mode], freq_prev, fg_sum_inv[mode]);

        /*----- search the first stage lsp codebook -----*/
    G729EV_G729_Lsp_pre_select(rbuf, &cand_cur);
    cand[mode] = cand_cur;

        /*----- search the second stage lsp codebook (lower 0-4) ----- */
    G729EV_G729_Lsp_select_1(rbuf, lspcb1[cand_cur], wegt, &index);

    tindex1[mode] = index;

    for (j = 0; j < G729EV_G729_NC; j++)
      buf[j] = lspcb1[cand_cur][j] + lspcb2[index][j];

    G729EV_G729_Lsp_expand_1(buf, G729EV_G729_GAP1);  /* check */

    G729EV_G729_Lsp_select_2(rbuf, lspcb1[cand_cur], wegt, &index);

    tindex2[mode] = index;

    for (j = G729EV_G729_NC; j < G729EV_G729_M; j++)
      buf[j] = lspcb1[cand_cur][j] + lspcb2[index][j];
    G729EV_G729_Lsp_expand_2(buf, G729EV_G729_GAP1);  /* check */


    /* check */
    G729EV_G729_Lsp_expand_1_2(buf, G729EV_G729_GAP2);

    G729EV_G729_Lsp_get_tdist(wegt, buf, &tdist[mode], rbuf, fg_sum[mode]);

  }


  G729EV_G729_Lsp_last_select(tdist, &mode_index);  /* select the codes */

  /* pack codes for lsp parameters */
  code_ana[0] = (mode_index << G729EV_G729_NC0_B) | cand[mode_index];
  code_ana[1] = (tindex1[mode_index] << G729EV_G729_NC1_B) | tindex2[mode_index];

  /* reconstruct quantized LSP parameter and check the stabilty */
  G729EV_G729_Lsp_get_quant(lspcb1, lspcb2,
                            cand[mode_index],
                            tindex1[mode_index], tindex2[mode_index],
                            fg[mode_index], freq_prev, lspq, fg_sum[mode_index]);

  return;
}

/*-----------------------------------------------------------------------------------
 * Function G729EV_G729_Lsp_pre_select - select the code of first stage lsp codebook
 *-----------------------------------------------------------------------------------
 */
void G729EV_G729_Lsp_pre_select(REAL rbuf[],  /* input : target vetor             */
                                int *cand     /* output: selected code            */
    )
{
  int       i, j;
  REAL      dmin, dist, temp;

  /* calculate the distortion */
  *cand = 0;
  dmin = G729EV_G729_FLT_MAX_G729;
  for (i = 0; i < G729EV_G729_NC0; i++)
  {
    dist = (REAL) 0.;
    for (j = 0; j < G729EV_G729_M; j++)
    {
      temp = rbuf[j] - lspcb1[i][j];
      dist += temp * temp;
    }

    if (dist < dmin)
    {
      dmin = dist;
      *cand = i;
    }
  }

  return;
}

/*--------------------------------------------------------------------------------------
 * Function lsp_pre_select_1 - select the code of second stage lsp codebook (lower 0-4)
 *--------------------------------------------------------------------------------------
 */
void G729EV_G729_Lsp_select_1(REAL rbuf[],          /* input : target vector            */
                              const REAL lspcb1[],  /* input : first stage lsp codebook */
                              REAL wegt[],          /* input : weight coef.             */
                              int *index            /* output: selected codebook index  */
    )
{
  int       j, k1;
  REAL      buf[G729EV_G729_M];
  REAL      dist, dmin, tmp;

  for (j = 0; j < G729EV_G729_NC; j++)
    buf[j] = rbuf[j] - lspcb1[j];

  *index = 0;
  dmin = G729EV_G729_FLT_MAX_G729;
  for (k1 = 0; k1 < G729EV_G729_NC1; k1++)
  {
    /* calculate the distortion */
    dist = (REAL) 0.;
    for (j = 0; j < G729EV_G729_NC; j++)
    {
      tmp = buf[j] - lspcb2[k1][j];
      dist += wegt[j] * tmp * tmp;
    }

    if (dist < dmin)
    {
      dmin = dist;
      *index = k1;
    }
  }
  return;
}

/*---------------------------------------------------------------------------
 * Function lsp_pre_select_2 - select the code of second stage lsp codebook (higher 5-9)
 *----------------------------------------------------------------------------
 */
void G729EV_G729_Lsp_select_2(REAL rbuf[],          /* input : target vector            */
                              const REAL lspcb1[],  /* input : first stage lsp codebook */
                              REAL wegt[],          /* input : weighting coef.          */
                              int *index            /* output: selected codebook index  */
    )
{
  int       j, k1;
  REAL      buf[G729EV_G729_M];
  REAL      dist, dmin, tmp;

  for (j = G729EV_G729_NC; j < G729EV_G729_M; j++)
    buf[j] = rbuf[j] - lspcb1[j];


  *index = 0;
  dmin = G729EV_G729_FLT_MAX_G729;
  for (k1 = 0; k1 < G729EV_G729_NC1; k1++)
  {
    dist = (REAL) 0.0;
    for (j = G729EV_G729_NC; j < G729EV_G729_M; j++)
    {
      tmp = buf[j] - lspcb2[k1][j];
      dist += wegt[j] * tmp * tmp;
    }

    if (dist < dmin)
    {
      dmin = dist;
      *index = k1;
    }
  }
  return;
}

/*---------------------------------------------------------------------------
 * Function G729EV_G729_Lsp_get_tdist - calculate the distortion
 *----------------------------------------------------------------------------
 */
void G729EV_G729_Lsp_get_tdist(REAL wegt[],         /* input : weight coef.          */
                               REAL buf[],          /* input : candidate LSP vector  */
                               REAL * tdist,        /* output: distortion            */
                               REAL rbuf[],         /* input : target vector         */
                               const REAL fg_sum[]  /* input : present MA prediction coef.  */
    )
{
  int       j;
  REAL      tmp;

  *tdist = (REAL) 0.0;
  for (j = 0; j < G729EV_G729_M; j++)
  {
    tmp = (buf[j] - rbuf[j]) * fg_sum[j];
    *tdist += wegt[j] * tmp * tmp;
  }
  return;
}

/*---------------------------------------------------------------------------
 * Function G729EV_G729_Lsp_last_select - select the mode
 *----------------------------------------------------------------------------
 */
void G729EV_G729_Lsp_last_select(REAL tdist[],    /* input : distortion         */
                                 int *mode_index  /* output: the selected mode  */
    )
{
  *mode_index = 0;

  if (tdist[1] < tdist[0])
    *mode_index = 1;

  return;
}

/*---------------------------------------------------------------------------
 * Function G729EV_G729_Get_wegt - compute lsp weights
 *----------------------------------------------------------------------------
 */
void G729EV_G729_Get_wegt(REAL flsp[],  /* input : G729EV_G729_M LSP parameters */
                          REAL wegt[]   /* output: G729EV_G729_M weighting coefficients */
    )
{
  int       i;
  REAL      tmp;

  tmp = flsp[1] - G729EV_G729_PI04 - (REAL) 1.0;
  if (tmp > (REAL) 0.0)
    wegt[0] = (REAL) 1.0;
  else
    wegt[0] = tmp * tmp * (REAL) 10. + (REAL) 1.0;

  for (i = 1; i < G729EV_G729_M - 1; i++)
  {
    tmp = flsp[i + 1] - flsp[i - 1] - (REAL) 1.0;
    if (tmp > (REAL) 0.0)
      wegt[i] = (REAL) 1.0;
    else
      wegt[i] = tmp * tmp * (REAL) 10. + (REAL) 1.0;
  }

  tmp = G729EV_G729_PI92 - flsp[G729EV_G729_M - 2] - (REAL) 1.0;
  if (tmp > (REAL) 0.0)
    wegt[G729EV_G729_M - 1] = (REAL) 1.0;
  else
    wegt[G729EV_G729_M - 1] = tmp * tmp * (REAL) 10. + (REAL) 1.0;

  wegt[4] *= G729EV_G729_CONST12;
  wegt[5] *= G729EV_G729_CONST12;

  return;
}
