/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.8                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_CELP2S_encod.h"

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"

#include "G729EV_FEC_tools.h"
#include "G729EV_G729B_defines.h"
#include "G729EV_G729B_dtx.h"
#include "G729EV_G729B_enc_sid.h"
#include "G729EV_G729EVDTX_sp2no_trans.h"
#include "G729EV_G729B_tab_dtx.h"
/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_InitEncoder()                    *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *   Variables initialisation for the G.729 coder            *
 *-----------------------------------------------------------*/

void G729EV_CELP2S_InitEncoder(G729EV_G729_CODSTAT * pCodStat,  /* (o)  Core coder parameters   */
                               int rate,                        /* (i)  coder rate              */
                               int dtx_max_fr                 /* (i)  maximum number of consecutive zero-frames (0 = infinite) */
    )
{
  int       i;

  pCodStat->rate = rate;

  /* Static vectors to zero */

  G729EV_G729_Set_zero(pCodStat->old_speech, G729EV_G729_MEM_SPEECH);
  G729EV_G729_Set_zero(pCodStat->old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  G729EV_G729_Set_zero(pCodStat->old_wsp, G729EV_G729_PIT_MAX);

  G729EV_G729_Set_zero(pCodStat->mem_syn, G729EV_G729_M);
  G729EV_G729_Set_zero(pCodStat->mem_w, G729EV_G729_M);
  G729EV_G729_Set_zero(pCodStat->mem_w0, G729EV_G729_M);
  G729EV_G729_Set_zero(pCodStat->mem_w0_2, G729EV_G729_M_LPC);
  G729EV_G729_Set_zero(pCodStat->mem_err2, G729EV_G729_M_LPC);
  G729EV_G729_Set_zero(pCodStat->mem_err, G729EV_G729_M);

  G729EV_G729_Set_zero(pCodStat->mem_synth, G729EV_G729_M_LPC);

  pCodStat->pit_sharp = G729EV_G729_SHARPMIN;

  /* Initialize past_qua_en */
  pCodStat->past_qua_en[0] = (REAL) - 14.0;
  pCodStat->past_qua_en[1] = (REAL) - 14.0;
  pCodStat->past_qua_en[2] = (REAL) - 14.0;
  pCodStat->past_qua_en[3] = (REAL) - 14.0;

  /* Initialize lsp_old[] */
  G729EV_G729_Copy(G729EV_DTX_LSP_INIT, pCodStat->lsp_old, G729EV_G729_M);

  /* Initialize lsp_old_q[] */
  G729EV_G729_Copy(pCodStat->lsp_old, pCodStat->lsp_old_q, G729EV_G729_M);

  G729EV_G729_Lsp_encw_reset(pCodStat->freq_prev);

  for (i = 0; i < 4; i++)
    pCodStat->exc_err[i] = (REAL) 1.;

  pCodStat->smooth = 1;

  pCodStat->lar_old[0] = (REAL) 0.0;
  pCodStat->lar_old[1] = (REAL) 0.0;

  G729EV_G729_Set_zero(pCodStat->old_A, G729EV_G729_MP1);
  pCodStat->old_A[0] = 1.0;

  G729EV_G729_Set_zero(pCodStat->old_rc, 2);

  pCodStat->pit_old = 40;
  /* For G.729B */
  /* Initialize VAD/DTX parameters */
  pCodStat->pastVad = 1;
  pCodStat->ppastVad = 1;
  G729EV_G729_Copy(G729EV_DTX_LSP_INIT, pCodStat->lsp_mean, G729EV_G729_M);

  pCodStat->Ga_gain_mean = 0.0;
  pCodStat->Gf_gain_mean = 0.0;
  pCodStat->energy_lt = 0.0;
  pCodStat->seed = INIT_SEED;
  pCodStat->dtx_max_fr = dtx_max_fr;
  init_cod_cng(pCodStat);

  pCodStat->transition_flag = 0;
  pCodStat->subfr_num = 0;
  for(i = 0; i < 4; i ++)
	  pCodStat->filt_temp[i] = 0.0;

  return;
}



/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_encoder()                        *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *  Core Codec Encoder                                       *
 *-----------------------------------------------------------*/

void G729EV_CELP2S_encoder(G729EV_G729_CODSTAT * pCodStat,  /* (i)  : core coder parameters   */
                           REAL * DataIn,                   /* (i)  : input frames            */
                           int *coder_parameters,           /* (o)  : Analysis parameters     */
                           REAL * DataSynth,                /* (o)  : Output synthesis                        */
                           int SubFrNum,                    /* (i)  : number of subframes                     */
                           REAL * celp_Az,                  /* (i)  Az buffer                                 */
                           REAL * sp_sync,                  /* (0) weighted synthesis                         */
                           REAL * resBF8k,                  /* (0) residual signal frame                      */
                           INT16 * pit,                     /* (0) open loop pitch values for 3 half-frames   */
                           INT16 * t0_out,                  /* (0) close loop integer pitch                   */
                           INT16 * t0_fout,                 /* (0) close loop fractional part of the pitch    */
                           REAL * voicing,                  /* (0) frame voicing                              */
                           REAL * ee,                       /* (o) spectral tilt information                  */
                           REAL * diff,                     /* (o) difference signal between input and local  */
						   REAL *SID_tdbwe_parameters,
						   REAL *tdbwe_parameters
                                                            /*     synthesis at 12 kbit/s                     */
                            )
{
  /* LPC analysis */
  REAL      r_fwd[G729EV_G729_M + 1];       /* Autocorrelations            */
  REAL      rc_fwd[G729EV_G729_M];          /* Reflection coefficients     */
  REAL      A_t_fwd[G729EV_G729_MP1 * 2];   /* A(z) unquantized for the 2 subframes  */
  REAL      A_t_fwd_q[G729EV_G729_MP1 * 2]; /* A(z) quantized for the 2 subframes    */
  REAL     *pAp, *pAq;
  REAL      lsp_new[G729EV_G729_M], lsp_new_q[G729EV_G729_M]; /* LSPs at 2th subframe                 */
  REAL      lsf_int[G729EV_G729_M];   /* Interpolated LSF 1st subframe.       */
  REAL      lsf_new[G729EV_G729_M];
  REAL      Ap1[G729EV_G729_M_LPC1];  /* A(z) with spectral expansion         */
  REAL      Ap2[G729EV_G729_M_LPC1];  /* A(z) with spectral expansion         */

  /* Speech buffer */
  REAL      old_speech[G729EV_G729_L_TOTAL];
  REAL     *new_speech;
  REAL     *speech, *p_window;

  /* Weighted speech vector */
  REAL      old_wsp[G729EV_G729_L_FRAME + G729EV_G729_PIT_MAX], *wsp;

  /* Excitation vector */
  REAL      old_exc[G729EV_G729_L_FRAME + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL], *exc;


  /* Zero vector */
  REAL      ai_zero[G729EV_G729_L_SUBFR + G729EV_G729_M_LPC1], *zero;
  REAL     *synth_ptr;

  /* Filter's memory */
  REAL      mem_err[G729EV_G729_M_LPC + G729EV_G729_L_SUBFR], *error;

  /* Other vectors */
  REAL      h1[G729EV_G729_L_SUBFR];  /* Impulse response h1[]              */
  REAL      xn[G729EV_G729_L_SUBFR];  /* Target vector for pitch search     */
  REAL      xn2[G729EV_G729_L_SUBFR]; /* Target vector for codebook search  */
  REAL      code[G729EV_G729_L_SUBFR];/* Fixed codebook excitation          */
  REAL      y1[G729EV_G729_L_SUBFR];  /* Filtered adaptive excitation       */
  REAL      y2[G729EV_G729_L_SUBFR];  /* Filtered fixed codebook excitation */
  REAL      g_coeff[5];         /* Correlations between xn, y1, & y2: */

  /* <y1,y1>, <xn,y1>, <y2,y2>, <xn,y2>,<y1,y2> */
  REAL      gamma1[2], gamma2[2];
  int       i_gamma;



  /* Scalars */
  int       i, j, i_subfr;
  int       T_op, t0, t0_min, t0_max, t0_frac;
  int       index, taming;
  REAL      gain_pit, gain_code;

  REAL      synth_buf[G729EV_G729_L_FRAME];

  /* Parameters  */
  int      *ana;

  int      *ana2;
  int       index_enha, ii;
  REAL      gain_code_enha = 0;
  REAL      exc2[G729EV_G729_L_FRAME];
  REAL      mem_err2[G729EV_G729_M_LPC + G729EV_G729_L_SUBFR], *error2;

  REAL      xn_enha[G729EV_G729_L_SUBFR];   /* Target vector for codebook search  */
  REAL      code_enha[G729EV_G729_L_SUBFR]; /* Fixed codebook excitation          */
  REAL      y2_enha[G729EV_G729_L_SUBFR];   /* Filtered fixed codebook excitation */
  REAL      exc_enha[G729EV_G729_L_FRAME];
  REAL      res1[G729EV_G729_L_SUBFR];
  REAL      norm_voiced_fac;
  REAL      voice_fac;

  /* for DTX purposes */
  REAL lsfq_mem[G729EV_G729_MA_NP][G729EV_G729_M];
  /* For G.729B */
  REAL r_nbe[G729EV_G729_MP1];
  REAL resid_ener;
  REAL  coreExc[G729EV_G729_L_SUBFR];
  gain_code_enha = 0.0;
  /*----------------------------------------------------------------------*
  *      Initialize pointers to speech vector.                            *
  *                                                                       *
  *                                                                       *
  *   |--------------------|-------------|-------------|------------|     *
  *     previous speech           sf1           sf2         L_NEXT        *
  *                                                                       *
  *   <----------------  Total speech vector (L_TOTAL)   ----------->     *
  *   <----------------  LPC analysis window (L_WINDOW)  ----------->     *
  *   |                   <-- present frame (L_FRAME) -->                 *
  * old_speech            |              <-- new speech (L_FRAME) -->     *
  * p_window              |              |                                *
  *                     speech           |                                *
  *                             new_speech                                *
  *-----------------------------------------------------------------------*/

  new_speech = old_speech + G729EV_G729_MEM_SPEECH; /* New speech     */
  p_window = old_speech + G729EV_G729_L_TOTAL - G729EV_G729_L_WINDOW; /* For LPC window */
  speech = new_speech - G729EV_G729_L_NEXT; /* Present frame  */
  synth_ptr = synth_buf;

  G729EV_G729_Copy(pCodStat->old_speech, old_speech, G729EV_G729_MEM_SPEECH);
  G729EV_G729_Copy(DataIn, new_speech, G729EV_G729_L_FRAME);

  wsp = old_wsp + G729EV_G729_PIT_MAX;

  G729EV_G729_Copy(pCodStat->old_wsp, old_wsp, G729EV_G729_PIT_MAX);

  exc = old_exc + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL;

  G729EV_G729_Copy(pCodStat->old_exc, old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);

  error = mem_err + G729EV_G729_M;
  error2 = mem_err2 + G729EV_G729_M_LPC;

  G729EV_G729_Copy(pCodStat->mem_err, mem_err, G729EV_G729_M_LPC);
  G729EV_G729_Copy(pCodStat->mem_err2, mem_err2, G729EV_G729_M_LPC);

  zero = ai_zero + G729EV_G729_M_LPC1;
  ana = coder_parameters;
  ana2 = coder_parameters + G729EV_G729_PRM_SIZE;

  G729EV_G729_Set_zero(ai_zero, (G729EV_G729_L_SUBFR + G729EV_G729_M_LPC1));

  /*------------------------------------------------------------------------*
  *  - Perform LPC analysis:                                               *
  *       * autocorrelation + lag windowing                                *
  *       * Levinson-durbin algorithm to find a[]                          *
  *       * convert a[] to lsp[]                                           *
  *       * quantize and code the LSPs                                     *
  *       * find the interpolated LSPs and convert to a[] for the 2        *
  *         subframes (both quantized and unquantized)                     *
  *------------------------------------------------------------------------*/

  /* LP analysis */

  G729EV_G729_AutocorrLPC(p_window, G729EV_G729_M, r_fwd);  /* Autocorrelations */
  G729EV_G729_Copy(r_fwd, r_nbe, G729EV_G729_MP1);
  G729EV_G729_Lag_window(G729EV_G729_M, r_fwd); /* Lag windowing    */

  /* Levinson Durbin  */
  resid_ener = G729EV_G729_Levinson(r_fwd, &A_t_fwd[G729EV_G729_MP1], rc_fwd, pCodStat->old_A, pCodStat->old_rc);

  *ee = -rc_fwd[0];

  G729EV_G729_Az_lsp(&A_t_fwd[G729EV_G729_MP1], lsp_new, pCodStat->lsp_old);  /* From A(z) to lsp */

  /* LSP quantization */

  /* For G.729B */
  /* ------ VAD ------- */
  if(pCodStat->Vad != 1) update_cng(pCodStat, r_nbe, pCodStat->Vad);

  /*--------------------------------------------------------------------*
  * Find interpolated LPC parameters in all subframes (both quantized  *
  * and unquantized).                                                  *
  * The interpolated parameters are in array A_t[] of size (M+1)*4     *
  * and the quantized interpolated parameters are in array Aq_t[]      *
  *--------------------------------------------------------------------*/

  G729EV_G729_Int_lpc(pCodStat->lsp_old, lsp_new, lsf_int, lsf_new, A_t_fwd);
  /* update the LSPs for the next frame */

  G729EV_G729_Copy(lsp_new, pCodStat->lsp_old, G729EV_G729_M);

  /*----------------------------------------------------------------------*
  * - Find the weighting factors                                         *
  *----------------------------------------------------------------------*/

  G729EV_G729_perc_var(gamma1, gamma2, lsf_int, lsf_new, rc_fwd, pCodStat->lar_old, &pCodStat->smooth);

  /*----------------------------------------------------------------------*
  * - Find the weighted input speech w_sp[] for the whole speech frame   *
  * - Find the open-loop pitch delay                                     *
  *----------------------------------------------------------------------*/

  G729EV_G729_Weight_Az(&A_t_fwd[0], gamma1[0], G729EV_G729_M, Ap1);
  G729EV_G729_Weight_Az(&A_t_fwd[0], gamma2[0], G729EV_G729_M, Ap2);
  G729EV_G729_Residu(Ap1, &speech[0], &wsp[0], G729EV_G729_L_SUBFR);
  G729EV_G729_Syn_filt(Ap2, &wsp[0], &wsp[0], G729EV_G729_L_SUBFR, pCodStat->mem_w, 1);

  G729EV_G729_Weight_Az(&A_t_fwd[G729EV_G729_MP1], gamma1[1], G729EV_G729_M, Ap1);
  G729EV_G729_Weight_Az(&A_t_fwd[G729EV_G729_MP1], gamma2[1], G729EV_G729_M, Ap2);
  G729EV_G729_Residu(Ap1, &speech[G729EV_G729_L_SUBFR], &wsp[G729EV_G729_L_SUBFR], G729EV_G729_L_SUBFR);
  G729EV_G729_Syn_filt(Ap2, &wsp[G729EV_G729_L_SUBFR], &wsp[G729EV_G729_L_SUBFR], G729EV_G729_L_SUBFR, pCodStat->mem_w,
                       1);
  /* ---------------------- */
  /* Case of Inactive frame */
  /* ---------------------- */
  /* Vad is based on AMR-WB VAD and uses 20 ms frame length */ 
  if (pCodStat->Vad == 0){
	  REAL prev_exc[G729EV_MAIN_L_FRAME2];
	  if(pCodStat->transition_flag != 0)
		  G729EV_Pitch_copy(pCodStat->old_exc, prev_exc, pCodStat->old_pitch);		
	  for (i = 0; i < G729EV_G729_MA_NP; i++) 
		  G729EV_G729_Copy(&pCodStat->freq_prev[i][0], &lsfq_mem[i][0], G729EV_G729_M);

	  G729EV_cod_cng (pCodStat, SubFrNum, exc, A_t_fwd_q,
              ana, lsfq_mem, SID_tdbwe_parameters,tdbwe_parameters
              );

	  G729EV_post_cng(pCodStat->transition_flag, prev_exc, exc, &(pCodStat->subfr_num));

	  for (i=0; i<G729EV_G729_MA_NP; i++) 
		  G729EV_G729_Copy(&lsfq_mem[i][0], &pCodStat->freq_prev[i][0], G729EV_G729_M);
	  
      pCodStat->ppastVad = pCodStat->pastVad;
	  pCodStat->pastVad = pCodStat->Vad;

	  /* UPDATE wsp, mem_w, mem_syn, mem_err, and mem_w0 */
	  pAp  = A_t_fwd;     /* pointer to interpolated LPC parameters           */
	  pAq = A_t_fwd_q;    /* pointer to interpolated quantized LPC parameters */
	  i_gamma = 0;
	  for(i_subfr=0; i_subfr < G729EV_G729_L_FRAME; i_subfr += G729EV_G729_L_SUBFR) {
		  G729EV_G729_Weight_Az(pAp, gamma1[i_gamma], G729EV_G729_M, Ap1);
		  G729EV_G729_Weight_Az(pAp, gamma2[i_gamma], G729EV_G729_M, Ap2);
		  i_gamma++;

		if(pCodStat->g729_bst == 0)
		{
	        G729EV_G729_Copy(&exc[i_subfr], coreExc, G729EV_G729_L_SUBFR);
			G729EV_fir_filt(coreExc, 0, pCodStat->filt_temp, G729EV_G729_L_SUBFR);
		}
		  /* update mem_syn */
		if(pCodStat->g729_bst == 0)
		{
		  G729EV_G729_Syn_filt(pAq, coreExc, &synth_ptr[i_subfr], G729EV_G729_L_SUBFR, 
			  pCodStat->mem_syn, 1);
		}
		else
		{
		  G729EV_G729_Syn_filt(pAq, &exc[i_subfr], &synth_ptr[i_subfr], G729EV_G729_L_SUBFR, 
			  pCodStat->mem_syn, 1);
		}
		  /* update mem_w0 */
		  for (i=0; i<G729EV_G729_L_SUBFR; i++)
			  error[i] = speech[i_subfr+i] - synth_ptr[i_subfr+i];
		  G729EV_G729_Residu(Ap1, error, xn, G729EV_G729_L_SUBFR);
		  G729EV_G729_Syn_filt(Ap2, xn, xn, G729EV_G729_L_SUBFR, pCodStat->mem_w0, 1);
		  
		  /* update mem_err */
		  for (i = G729EV_G729_L_SUBFR-G729EV_G729_M, j = 0; i < G729EV_G729_L_SUBFR; i++, j++)
			  mem_err[j] = error[i];
		  
		  
		  pAp += G729EV_G729_MP1;
		  pAq += G729EV_G729_MP1; 
	  }
	  
      pCodStat->pit_sharp = G729EV_G729_SHARPMIN;
	  
	  /* Update memories for next frames */
	  G729EV_G729_Copy(mem_err, pCodStat->mem_err, G729EV_G729_M_LPC);
	  G729EV_G729_Copy(mem_err, pCodStat->mem_err2, G729EV_G729_M_LPC);
      G729EV_G729_Copy(&old_speech[G729EV_G729_L_FRAME], &pCodStat->old_speech[0], G729EV_G729_L_TOTAL-G729EV_G729_L_FRAME);
      G729EV_G729_Copy(&old_wsp[G729EV_G729_L_FRAME], &pCodStat->old_wsp[0], G729EV_G729_PIT_MAX);
      G729EV_G729_Copy(&old_exc[G729EV_G729_L_FRAME], &pCodStat->old_exc[0], G729EV_G729_PIT_MAX+G729EV_G729_L_INTERPOL);
    G729EV_G729_Copy(synth_ptr, DataSynth, G729EV_G729_L_FRAME);
	G729EV_G729_Copy(pCodStat->mem_syn, pCodStat->mem_synth, G729EV_G729_M);
	  return;
  }  /* End of inactive frame case */

  pCodStat->seed = INIT_SEED;
  pCodStat->seed2 = INIT_SEED;
  pCodStat->ppastVad = pCodStat->pastVad;
  pCodStat->pastVad = pCodStat->Vad;
  /* LSP quantization */
  if (pCodStat->Vad == 2)
	  pCodStat->energy_lt = resid_ener * 0.5 + pCodStat->energy_lt * 0.5;
  else
      pCodStat->energy_lt = resid_ener * 0.9 + pCodStat->energy_lt * 0.1;
  
  G729EV_G729_Qua_lsp (lsp_new, lsp_new_q, ana, pCodStat->freq_prev);
  ana += 2;
  G729EV_G729_Int_qlpc (pCodStat->lsp_old_q, lsp_new_q, A_t_fwd_q);
  G729EV_G729_Copy (A_t_fwd_q, &celp_Az[2 * SubFrNum * G729EV_G729_MP1], 2*G729EV_G729_MP1);
  G729EV_G729_Copy (lsp_new_q, pCodStat->lsp_old_q, G729EV_G729_M);
/* long term spectrum parameters */
  for(i=0;i<G729EV_G729_M;i++)
  {
      pCodStat->lsp_mean[i] = 0.5*pCodStat->lsp_mean[i] + 0.5*lsp_new_q[i];
  }
  /* Find open loop pitch lag */

  T_op = G729EV_G729_Pitch_ol(wsp, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX,
                              G729EV_G729_L_FRAME, voicing, &(pCodStat->pit_old));

  /* Range for closed loop pitch search in 1st subframe */

  t0_min = T_op - 3;
  if (t0_min < G729EV_G729_PIT_MIN)
    t0_min = G729EV_G729_PIT_MIN;
  t0_max = t0_min + 6;
  if (t0_max > G729EV_G729_PIT_MAX)
  {
    t0_max = G729EV_G729_PIT_MAX;
    t0_min = t0_max - 6;
  }

   /*------------------------------------------------------------------------*
    *          Loop for every subframe in the analysis frame                 *
    *------------------------------------------------------------------------*
    *  To find the pitch and innovation parameters. The subframe size is     *
    *  G729EV_G729_L_SUBFR and the loop is repeated 2 times.                 *
    *     - find the weighted LPC coefficients                               *
    *     - find the LPC residual signal res[]                               *
    *     - compute the target signal for pitch search                       *
    *     - compute impulse response of weighted synthesis filter (h1[])     *
    *     - find the closed-loop pitch parameters                            *
    *     - encode the pitch delay                                           *
    *     - update the impulse response h1[] by including fixed-gain pitch   *
    *     - find target vector for codebook search                           *
    *     - codebook search                                                  *
    *     - encode codebook address                                          *
    *     - VQ of pitch and codebook gains                                   *
    *     - find synthesis speech                                            *
    *     - update states of weighting filter                                *
    *------------------------------------------------------------------------*/
  pAp = A_t_fwd;                /* pointer to interpolated LPC parameters */
  pAq = A_t_fwd_q;              /* pointer to interpolated quantized LPC parameters */

  i_gamma = 0;

  for (i_subfr = 0; i_subfr < G729EV_G729_L_FRAME; i_subfr += G729EV_G729_L_SUBFR)
  {

      /*---------------------------------------------------------------*
      * Find the weighted LPC coefficients for the weighting filter.  *
      *---------------------------------------------------------------*/
    G729EV_G729_Weight_Az(pAp, gamma1[i_gamma], G729EV_G729_M, Ap1);
    G729EV_G729_Weight_Az(pAp, gamma2[i_gamma], G729EV_G729_M, Ap2);
    i_gamma++;

      /*---------------------------------------------------------------*
      * Compute impulse response, h1[], of weighted synthesis filter  *
      *---------------------------------------------------------------*/

    G729EV_G729_Copy(Ap1, ai_zero, G729EV_G729_MP1);

    G729EV_G729_Syn_filt(pAq, ai_zero, h1, G729EV_G729_L_SUBFR, zero, 0);
    G729EV_G729_Syn_filt(Ap2, h1, h1, G729EV_G729_L_SUBFR, zero, 0);

     /*------------------------------------------------------------------------*
      *                                                                        *
      *          Find the target vector for pitch search:                      *
      *          ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                       *
      *                                                                        *
      *              |------|  res[n]                                          *
      *  speech[n]---| A(z) |--------                                          *
      *              |------|       |   |--------| error[n]  |------|          *
      *                    zero -- (-)--| 1/A(z) |-----------| W(z) |-- target *
      *                    exc          |--------|           |------|          *
      *                                                                        *
      * Instead of subtracting the zero-input response of filters from         *
      * the weighted input speech, the above configuration is used to          *
      * compute the target vector. This configuration gives better performance *
      * with fixed-point implementation. The memory of 1/A(z) is updated by    *
      * filtering (res[n]-exc[n]) through 1/A(z), or simply by subtracting     *
      * the synthesis speech from the input speech:                            *
      *    error[n] = speech[n] - syn[n].                                      *
      * The memory of W(z) is updated by filtering error[n] through W(z),      *
      * or more simply by subtracting the filtered adaptive and fixed          *
      * codebook excitations from the target:                                  *
      *     target[n] - gain_pit*y1[n] - gain_code*y2[n]                       *
      * as these signals are already available.                                *
      *                                                                        *
      *------------------------------------------------------------------------*/

    G729EV_G729_Residu(pAq, &speech[i_subfr], &exc[i_subfr], G729EV_G729_L_SUBFR);  /* LPC residual */

    if (pCodStat->rate >= 12000)
    {
      /* Save residual. This input will be needed to compute the error signal in the residual domain */
      G729EV_G729_Copy(&exc[i_subfr], &exc2[i_subfr], G729EV_G729_L_SUBFR);
    }

    G729EV_G729_Syn_filt(pAq, &exc[i_subfr], error, G729EV_G729_L_SUBFR, &mem_err[0], 0);

    G729EV_G729_Residu(Ap1, error, xn, G729EV_G729_L_SUBFR);

    G729EV_G729_Syn_filt(Ap2, xn, xn, G729EV_G729_L_SUBFR, &pCodStat->mem_w0[0], 0);  /* target signal xn[] */

    /* Save residual signal (will be needed to compute second second stage target */
    G729EV_G729_Copy(exc + i_subfr, res1, G729EV_G729_L_SUBFR);

     /*----------------------------------------------------------------------*
      *                 Closed-loop fractional pitch search                  *
      *----------------------------------------------------------------------*/
    t0 = G729EV_G729_Pitch_fr3(&exc[i_subfr], xn, h1, G729EV_G729_L_SUBFR, t0_min, t0_max, i_subfr, &t0_frac);

    index = G729EV_G729_Enc_lag3(t0, t0_frac, &t0_min, &t0_max, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX, i_subfr);

    *ana++ = index;

    if ((i_subfr == 0))
    {
      *ana++ = G729EV_G729_Parity_Pitch(index);
    }
    *pit++ = t0;

	pCodStat->old_pitch = t0;
     /*-----------------------------------------------------------------*
      *   - find unity gain pitch excitation (adaptive codebook entry)  *
      *     with fractional interpolation.                              *
      *   - find filtered pitch exc. y1[]=exc[] convolve with h1[])     *
      *   - compute pitch gain and limit between 0 and 1.2              *
      *   - update target vector for codebook search                    *
      *   - find LTP residual.                                          *
      *-----------------------------------------------------------------*/

    G729EV_G729_Pred_lt_3(&exc[i_subfr], t0, t0_frac, G729EV_G729_L_SUBFR);

    G729EV_G729_Convolve(&exc[i_subfr], h1, y1, G729EV_G729_L_SUBFR);

    gain_pit = G729EV_G729_G_pitch(xn, y1, g_coeff, G729EV_G729_L_SUBFR);


    /* clip pitch gain if taming is necessary */
    taming = G729EV_G729_test_err(pCodStat, t0, t0_frac);

    if (taming == 1)
    {
      if (gain_pit > G729EV_G729_GPCLIP)
      {
        gain_pit = G729EV_G729_GPCLIP;
      }
    }

    for (i = 0; i < G729EV_G729_L_SUBFR; i++)
      xn2[i] = xn[i] - y1[i] * gain_pit;

     /*-----------------------------------------------------*
      * - Innovative codebook search.                       *
      *-----------------------------------------------------*/
    {
      REAL      h[G729EV_G729_L_SUBFR];

      /* The impulse respond h1 should not be modified by the codebook search routine because           
         it will be used as an input to the second inovative codebook search. h1 is therefore                         
         duplicated into a temporary memory space before calling G729EV_G729_ACELP_code_A_OTH */

      G729EV_G729_Copy(h1, h, G729EV_G729_L_SUBFR);


      /* Compute residual after long term prediction */
      for (i = 0; i < G729EV_G729_L_SUBFR; i++)
      {
        res1[i] = res1[i] - exc[i + i_subfr] * gain_pit;
      }

      index = G729EV_CELP2S_ACELP_code_A_OTH(xn2, res1, h, t0, pCodStat->pit_sharp, code, y2, &i, y1);

      *ana++ = index;           /* Positions index */
      *ana++ = i;               /* Signs index     */

    }

     /*-----------------------------------------------------*
      * - Quantization of gains.                            *
      *-----------------------------------------------------*/
    G729EV_G729_Corr_xy2(xn, y1, y2, g_coeff);

    *ana++ = G729EV_G729_Qua_gain(code, g_coeff, G729EV_G729_L_SUBFR,
                                  &gain_pit, &gain_code, taming, pCodStat->past_qua_en);

    voice_fac = G729EV_FEC_voice_factor(exc + i_subfr, gain_pit, code, gain_code);
    norm_voiced_fac = (voice_fac + 1.0f) * 0.5f;

  pCodStat->old_gp = gain_pit;
     /*------------------------------------------------------*
      * - Find the total excitation                          *
      * - find synthesis speech corresponding to exc[]       *
      * - update filters memories for finding the target     *
      *   vector in the next subframe                        *
      *   (update error[-m..-1] and mem_w_err[])             *
      *   update error function for taming process           *
      *------------------------------------------------------*/
    for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    {
      exc[i + i_subfr] = gain_pit * exc[i + i_subfr] + gain_code * code[i];
    }

    G729EV_G729_Syn_filt(pAq, &exc[i_subfr], &synth_ptr[i_subfr], G729EV_G729_L_SUBFR, &pCodStat->mem_syn[0], 1);

    /* Addition of a second fixed codebook (12Kbit/s mode)   */
    if (pCodStat->rate >= 12000)
    {
      int       i;
      REAL      res2[G729EV_G729_L_SUBFR];


      /* Compute the error signal (input to the second stage) in the residual domain */
      /* exc  -> residual of the 1st stage output signal                             */
      /* exc2 -> residual of the input signal                                        */
      for (i = 0; i < G729EV_G729_L_SUBFR; i++)
        res2[i] = exc2[i + i_subfr] - exc[i + i_subfr];
      /* exc2 -> residual of the error signal                                        */


        /*--------------------------------------------------------*        
        * Find the target vector for the second fixed codebook   *
        *--------------------------------------------------------*/

      G729EV_G729_Syn_filt(pAq, res2, error2, G729EV_G729_L_SUBFR, &mem_err2[0], 0);
      G729EV_G729_Residu(Ap1, error2, xn_enha, G729EV_G729_L_SUBFR);
      G729EV_G729_Syn_filt(Ap2, xn_enha, xn_enha, G729EV_G729_L_SUBFR, &pCodStat->mem_w0_2[0], 0);  /* target signal xn_enha[] */

       /*-----------------------------------------------------*
        * - Innovative codebook search.                       *
        *-----------------------------------------------------*/

      /* search in fixed-codebook:  */
      index_enha = G729EV_CELP2S_ACELP_code_2NDLAYER(xn_enha, res2, h1, norm_voiced_fac, code_enha, y2_enha, &ii);


      *ana2++ = index_enha;     /* Positions index */
      *ana2++ = ii;             /* Signs index     */

      i = (int) (i_subfr / G729EV_G729_L_SUBFR);
      i = i + 2 * SubFrNum;

      /* quantize second fixed codebook gain */
      index = G729EV_CELP2S_qua_gain_Stage2(gain_code, xn_enha, y2_enha, G729EV_G729_L_SUBFR, (INT16) i);

      /* Save Gain index */
      *ana2++ = index;

      /* Get Quantized gain value */
      gain_code_enha = G729EV_CELP2S_dec_gain_Stage2(gain_code, index, (INT16) i);

       /*-----------------------------------------------------*
      *   Find final output excitation                      *
      * exc_enha =  exc[] + gain_code_enha * code_enha[]    *
      *    exc[] = gain_pit * exc[-T] + gain_code * code [] * 
      *-----------------------------------------------------*/

      for (i = 0; i < G729EV_G729_L_SUBFR; i++)
      {
        exc_enha[i + i_subfr] = gain_code_enha * code_enha[i] + exc[i + i_subfr];
      }


      /* Compute synthesis signal. exc_enha[] / A(z)    */
      G729EV_G729_Syn_filt(pAq, &exc_enha[i_subfr], &DataSynth[i_subfr], G729EV_G729_L_SUBFR, pCodStat->mem_synth, 1);

      /* compute difference signal between input and local synthesis */
      for (i = 0; i < G729EV_G729_L_SUBFR; i++)
      {
        diff[i_subfr + i] = speech[i_subfr + i] - DataSynth[i_subfr + i];
      }

    }

	/* long term energy */
	G729EV_adjust_gain(&pCodStat->Ga_gain_mean, &pCodStat->Gf_gain_mean, gain_pit, gain_code, gain_code_enha);
     /*------------------------------------------------------------*
      * - Update pitch sharpening "sharp" with quantized gain_pit  *
      *------------------------------------------------------------*/

    pCodStat->pit_sharp = gain_pit;
    if (pCodStat->pit_sharp > G729EV_G729_SHARPMAX)
      pCodStat->pit_sharp = G729EV_G729_SHARPMAX;
    if (pCodStat->pit_sharp < G729EV_G729_SHARPMIN)
      pCodStat->pit_sharp = G729EV_G729_SHARPMIN;

    G729EV_G729_update_exc_err(gain_pit, t0, pCodStat->exc_err);

    for (i = G729EV_G729_L_SUBFR - G729EV_G729_M, j = 0; i < G729EV_G729_L_SUBFR; i++, j++)
    {
      mem_err[j] = speech[i_subfr + i] - synth_ptr[i_subfr + i];
      pCodStat->mem_w0[j] = xn[i] - gain_pit * y1[i] - gain_code * y2[i];
    }

    if (pCodStat->rate >= 12000)
      for (i = G729EV_G729_L_SUBFR - G729EV_G729_M, j = 0; i < G729EV_G729_L_SUBFR; i++, j++)
      {
        pCodStat->mem_w0_2[j] = xn_enha[i] - gain_code_enha * y2_enha[i];
        mem_err2[j] = speech[i_subfr + i] - DataSynth[i_subfr + i];
      }



    pAp += G729EV_G729_MP1;     /* interpolated LPC parameters for next subframe */
    pAq += G729EV_G729_MP1;

  }


  /* at this stage DataSynth comprises the synthesis at 12k while synth_ptr comprises
     the synthesis at 8k if the rate is 8k, overwrite DataSynth */
  if (pCodStat->rate == 8000)
  {
	  G729EV_G729_Copy(synth_ptr, DataSynth, G729EV_G729_L_FRAME);
	  G729EV_G729_Copy(pCodStat->mem_syn, pCodStat->mem_synth, G729EV_G729_M);
  }

  
  if(pCodStat->g729_bst == 0)
	  G729EV_G729_Copy(&exc[G729EV_G729_L_FRAME-FILTERORDER], pCodStat->filt_temp, FILTERORDER);

    /*-------------------------------------------------*
    * Update signal for next frame.                    *
    * -> shift to the left by G729EV_G729_L_FRAME:     *
    *     speech[], wsp[], exc[] and exc2[]            *
    *--------------------------------------------------*/

  G729EV_G729_Copy(mem_err, pCodStat->mem_err, G729EV_G729_M_LPC);
  G729EV_G729_Copy(&old_wsp[G729EV_G729_L_FRAME], &pCodStat->old_wsp[0], G729EV_G729_PIT_MAX);
  G729EV_G729_Copy(&old_exc[G729EV_G729_L_FRAME], &pCodStat->old_exc[0], G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  G729EV_G729_Copy(&old_speech[G729EV_G729_L_FRAME], &pCodStat->old_speech[0], G729EV_G729_MEM_SPEECH);
  G729EV_G729_Copy(mem_err2, pCodStat->mem_err2, G729EV_G729_M_LPC);

  /* Find sp_sync */
  *t0_out = t0;
  *t0_fout = t0_frac;

  G729EV_G729_Copy(exc2, resBF8k, G729EV_G729_L_FRAME);
  G729EV_G729_Copy(speech, sp_sync, G729EV_G729_L_FRAME);

  return;

}
