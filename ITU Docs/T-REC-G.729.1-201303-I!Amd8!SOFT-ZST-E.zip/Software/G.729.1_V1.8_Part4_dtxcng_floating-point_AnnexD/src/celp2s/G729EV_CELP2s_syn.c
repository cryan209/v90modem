/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"

/*-----------------------------------------------------------*
 *  Function  G729EV_G729_syn()                              *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~                              *
 *  Synthesys of g729ev core                                 *
 *-----------------------------------------------------------*/

void G729EV_G729_syn(REAL * exc_core, /* (i)  : 8kbits core excitation              */
                     REAL * exc_ext,  /* (i)  : 12kbits  core excitation  extention */
                     REAL * BfAq,     /* (i)  : LPC coefficient filter              */
                     REAL * synth,    /* (o)  : Synthesis buffer                    */
                     REAL * mem_syn,  /* (i/o): synthesis memory buffer             */
                     INT16 extrate    /* (i)  : Extension bit rate                  */
    )
{
  INT16     i_subfr;

  /* Tables */
  REAL     *pA_t;               /* Pointer on A_t   */

  pA_t = BfAq;
  for (i_subfr = 0; i_subfr < 2 * G729EV_G729_L_FRAME; i_subfr += G729EV_G729_L_SUBFR)
  {
    if (extrate >= 12000)
      G729EV_G729_Syn_filt(pA_t, &exc_ext[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn, 0);
    else
      G729EV_G729_Syn_filt(pA_t, &exc_core[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn, 0);


    G729EV_G729_Copy(&synth[i_subfr + G729EV_G729_L_SUBFR - G729EV_G729_M], mem_syn, G729EV_G729_M);
    pA_t += G729EV_G729_MP1;    /* interpolated LPC parameters for next subframe */
  }

}
