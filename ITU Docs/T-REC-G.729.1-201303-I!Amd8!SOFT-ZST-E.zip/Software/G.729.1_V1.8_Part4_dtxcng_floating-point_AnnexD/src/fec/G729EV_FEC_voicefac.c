/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*-------------------------------------------------------------------*
 *                         VOICEFAC.C                                *
 *-------------------------------------------------------------------*
 * Find the voicing factor (1=voice to -1=unvoiced).                 *
 *-------------------------------------------------------------------*/

#include "G729EV_MAIN_defines.h"
#include "G729EV_FEC_tools.h"

REAL G729EV_FEC_voice_factor(                 /* (o) : factor (-1=unvoiced to 1=voiced) */
                              REAL exc[],     /* (i) : pitch excitation                 */
                              REAL gain_pit,  /* (i) : gain of pitch                    */
                              REAL code[],    /* (i) : Fixed codebook excitation        */
                              REAL gain_code  /* (i) : gain of code                     */
    )
{
  int       i;
  REAL      ener1, ener2, voice_fac;

  ener1 = (REAL) 0.0;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    ener1 += exc[i] * exc[i];
  }
  ener1 *= (gain_pit * gain_pit);

  ener2 = (REAL) 0.0;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    ener2 += code[i] * code[i];
  }
  ener2 *= (gain_code * gain_code);

  voice_fac = (REAL) ((ener1 - ener2) / (ener1 + ener2 + (REAL) 0.01));
  return (voice_fac);

}
