/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_FEC_tools.h"
#include "G729EV_G729_ld8k.h"

static void G729EV_FEC_synchro_exc(REAL * exc, INT16 true_puls_pos, INT16 desire_puls_pos, INT16 Old_pitch);
static REAL G729EV_FEC_enr_1_Az(            /* o:   impulse response energy */
                                 REAL Aq[], /* i:   LP filter coefs         */
                                 INT16 len  /* i:   impulse response length */
    );
static void G729EV_FEC_syn_bfi(INT16 last_good, INT16 bfi_cnt, const REAL stab_fac,
                               REAL * lp_gainp, REAL * lp_gainc, REAL * exc_mem,
                               REAL * exc2, const REAL T3, const REAL tilt_code,
                               const REAL Ts, REAL * pitch_buf, const INT16 Tcnt,
                               REAL * Aq, REAL * synth, REAL * mem_syn2,
                               REAL * enr_old, INT16 * seed, REAL * exc, INT16 pulse_pos, INT16 new_pit);

/******************************************************************************/
/* G729EV_FEC_dec_bf : Frame erasure concealment                              */
/* Find LPC coefficient, pitch and reconstruct lost synthesis                 */
/******************************************************************************/
void G729EV_FEC_dec_bf(INT32 parm[],              /* (i)   : vector of synthesis parameters       */
                       REAL synth[],              /* (i/o) : synthesis speech                     */
                       REAL Az_dec[],             /* (o)   : decoded LP filter in 2 subframes     */
                       INT16 bfi,                 /* (i)   : Bad Frame Indicator                  */
                       INT16 * last_good,         /* (i)   : last good frame classification       */
                       REAL * pitch_buf,          /* (i/o) : Pitch memory                         */
                       REAL old_enr,              /* (i)   : Energy at the end of the last frame  */
                       REAL * old_exc,            /* (i/o) : excitiation memory                   */
                       G729EV_G729_DECSTAT * st,  /* (i)   : Decoder structure                    */
                       INT16 new_clas,            /* (i)   : present frame classification         */
                       INT16 puls_pos             /* (i)   : Position of the last pulse           */
    )
{

  REAL      A[G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1];
  REAL      lsp_new[G729EV_G729_M];
  REAL     *exc, T3;
  REAL      exc2[G729EV_MAIN_L_FRAME2 + G729EV_FEC_L_FIR_FER - 1];
  REAL      exc_buf[G729EV_MAIN_L_FRAME2 + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL + G729EV_G729_L_SUBFR];
  int       T0, T0_frac;
  int       t0, t0_frac;
  INT16     index;

  T0 = 0, T0_frac = 0;
  exc = exc_buf + G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL;
  G729EV_G729_Copy(old_exc, exc_buf, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);

  /* Decode the LSPs */
  G729EV_G729_D_lsp(parm, lsp_new, bfi, st->freq_prev, st->prev_lsp, &(st->prev_ma));


  parm += 2;
  if (bfi == G729EV_FEC_SINGLE_FRAME)
  {
    index = *parm++;            /* pitch index */

    /* decode future pitch */
    G729EV_G729_Dec_lag3(index, G729EV_G729_PIT_MIN, G729EV_G729_PIT_MAX, 0, &t0, &t0_frac);

    /* Interpolation of LPC for the 4 subframes */
    G729EV_G729_Int_qlpc_bfi(st->lsp_old, lsp_new, A, interpol_frac1);
    G729EV_G729_Copy(A, Az_dec, G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1);

    /* update the LSFs for the next frame */
    G729EV_G729_Copy(lsp_new, st->lsp_old, G729EV_G729_M);

    /* Update pitch prediction, use pit_mem[3] to represent last usable pitch */
    G729EV_FEC_pitch_pred((INT16) 1, &T0, &T0_frac, st->pit_mem, &(st->bfi_mem));
    T3 = st->pit_mem[3];
    /*t0 = true future pitch */
  }
  else
  {
    /* Interpolation of LPC for the 4 subframes */
    G729EV_G729_Int_qlpc_bfi(st->lsp_old, lsp_new, A, interpol_frac1);
    G729EV_G729_Copy(A, Az_dec, G729EV_MAIN_NB_SUBFR * G729EV_G729_MP1);

    /* update the LSFs for the next frame */
    G729EV_G729_Copy(lsp_new, st->lsp_old, G729EV_G729_M);
    G729EV_FEC_pitch_pred(1, &T0, &T0_frac, st->pit_mem, &(st->bfi_mem));
    T3 = st->pit_mem[3];
    t0 = T0;                    /* t0 = predicted pitch */
  }

 /*-------------------------------------------------*
  * Find the excitation and synthesize speech
  *-------------------------------------------------*/
  G729EV_FEC_syn_bfi(*last_good, st->bfi_cnt, st->stab_fac, &st->lp_gainp,
                     &st->lp_gainc, st->old_exc, exc2, T3, st->tilt_code,
                     st->old_fpitch, pitch_buf, st->upd_cnt, A, synth,
                     st->mem_syn, &(st->enr_old), &(st->seed_fer), exc, puls_pos, (INT16) t0);
  /*--------------------------------------------------*
   * Others updates
   *--------------------------------------------------*/

  G729EV_G729_Copy(&exc[G729EV_MAIN_L_FRAME2 - G729EV_G729_PIT_MAX - G729EV_G729_L_INTERPOL],
                   st->old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);

  (st->upd_cnt)++;              /* counter of the age of the last update */
  if (st->upd_cnt > G729EV_FEC_MAX_UPD_CNT)
  {
    st->upd_cnt = G729EV_FEC_MAX_UPD_CNT;
  }
 /*----------------------------------------------------------------------*
  * Update for next frame.                           
  *----------------------------------------------------------------------*/
}

/******************************************************************************/
/* G729EV_FEC_syn_bfi : Reconstruction of erased frame                        */
/* - Find pitch                                                               */
/* - Estimate damping factor                                                  */
/* - Construct and synchronize periodic part of excitation                    */
/* - Construct random part of excitation                                      */
/* - Apply gain to excitation                                                 */
/* - Do synthesis filtering to recover lost synthesis                         */
/******************************************************************************/
static void G729EV_FEC_syn_bfi(INT16 last_good,       /* i:   last good frame clas                    */
                               INT16 bfi_cnt,         /* i:   counter of consecutive bfi frames       */
                               const REAL stab_fac,   /* i:   ISF stability measure                   */
                               REAL * lp_gainp,       /* i/o: damped pitch gain                       */
                               REAL * lp_gainc,       /* i/o: damped code gain                        */
                               REAL * exc_mem,        /* o:   excitation memory (st->old_exc)         */
                               REAL * exc2,           /* o:   excitation buffer (for synthesis)       */
                               const REAL T3,         /* i:   floating pitch                          */
                               const REAL tilt_code,  /* i:   spectral tilt                           */
                               const REAL Ts,         /* i:   previous pitch for hr G729EV_FEC_VOICED */
                               REAL * pitch_buf,      /* o:   floating pitch for every subfr          */
                               const INT16 upd_cnt,   /* i:   counter of the last bfi pitch updt.     */
                               REAL * Aq,             /* i    LP filter coefs                         */
                               REAL * synth,          /* o    synthesized speech at Fs = 12k8 Hz      */
                               REAL * mem_syn2,       /* i/o  initial synthesis filter states         */
                               REAL * enrold,         /* o    energy update at the end for next frame */
                               INT16 * seed,          /* i/o: random generator seed                   */
                               REAL * exc,            /* i/o: pointer to present exc                  */
                               INT16 puls_pos,        /* i  : Pulse position                          */
                               INT16 new_pit          /* i  : Pitch of the first future frame         */
    )
{
  REAL     *pt_exc, *pt1_exc, alpha, step, gain_inov, gain, tmp_Tc, tmp2;
  INT16     i, Tc, i_subfr, sect;
  REAL      hp_filt[5], ftmp, *p_Az;
  INT16     pit_subfr, pos;
  REAL      delta, fT0;
  INT16     Tlist[10], nb_pusles, pulse_chosen, temp;
  INT16     pit_search, diff_pit, sign = 0, Plast, Terr;
  REAL      tmp;
  INT16     total_pit_lag = (INT16) 0, P0 = (INT16) 0, dist_Plast;


 /*------------------------------------------------------------------------------------------*
  * Find secure pitch estimation for FERs
  * The new_pit is always known 
  * in single FER, we know future pitch else the pitch is predict with past pitch
  *------------------------------------------------------------------------------------------*/
  if (((Ts < (REAL) 1.8 * T3) && (Ts > (REAL) 0.6 * T3)) || /* last pitch coherent with the past  */
      (upd_cnt >= G729EV_FEC_MAX_UPD_CNT))  /* or last update too far in the past */
  {
    tmp_Tc = T3;                /* take the previous frame last pitch */
  }
  else
  {
    tmp_Tc = Ts;                /* last pitch unreliable - use the long-term pitch */
  }

  if (new_pit > 0)              /* New pitch always known (with bitstream or by predition */
  {
    fT0 = tmp_Tc;
    delta = (REAL) (new_pit - fT0) / 4; /* Interpolate over 4 sub frame */
    for (i = 0; i < 4; i++)
    {
      fT0 += delta;
      pitch_buf[i] = (INT16) (fT0 + 0.5);
    }
  }
  else                          /* Should not happen */
  {
    for (i = 0; i < 4; i++)
    {
      pitch_buf[i] = tmp_Tc;
    }
  }

 /*-------------------------------------------------*
  * hp filter random part and add to excitation   
  *-------------------------------------------------*/
  tmp2 = (REAL) 1.0 - tilt_code;
  for (i = 0; i < G729EV_FEC_L_FIR_FER; i++)
  {
    hp_filt[i] = tmp2 * G729EV_FEC_h_high[i];
  }

 /*-------------------------------------------------*
  * Estimate damping factor                         *
  *-------------------------------------------------*/
  if (last_good == G729EV_FEC_UNVOICED)
  {
    if (bfi_cnt > 3)
    {                           /* If stable, do not decrease the energy */
      alpha = G729EV_FEC_ALPHA_VT;
    }
    else if (bfi_cnt > 1)
    {                           /* If stable, do not decrease the energy */
      alpha = (stab_fac * ((REAL) 0.9 - G729EV_FEC_ALPHA_U) + G729EV_FEC_ALPHA_U);
    }
    else
    {
      alpha = G729EV_FEC_ALPHA_U2;
    }
  }
  else if (last_good == G729EV_FEC_UV_TRANSITION)
  {
    alpha = G729EV_FEC_ALPHA_UT;
  }
  else if (last_good == G729EV_FEC_ONSET)
  {
    alpha = (REAL) 0.8;         /* mild convergence to 0 for the first 3 erased frames */
  }
  else if (last_good == G729EV_FEC_VOICED)
  {
    alpha = G729EV_FEC_ALPHA_V; /* constant for the first 3 erased frames */
  }
  else if (last_good == G729EV_FEC_SIN_ONSET)
  {
    alpha = G729EV_FEC_ALPHA_S;
  }
  else                          /*G729EV_FEC_V_TRANSITION */
  {

    if (bfi_cnt <= 2)
    {
      alpha = (REAL) 2. *G729EV_FEC_ALPHA_VT; /* medium convergence to 0  */
    }
    else
    {
      alpha = (REAL) 0.2;       /* very fast convergence to 0  */
    }
  }

  if (last_good >= G729EV_FEC_VOICED)
  {

    if (bfi_cnt == 1)           /* if first erased frame in a block, reset harmonic gain */
    {
      if (*lp_gainp == (REAL) 0.)
      {
        *lp_gainp = (REAL) 1.;
      }
      gain = (REAL) sqrt(*lp_gainp);  /* move pitch gain towards 1 for G729EV_FEC_VOICED to remove energy fluctuations */
      if (gain > (REAL) 0.98)
      {
        gain = (REAL) 0.98;
      }
      else if (gain < (REAL) 0.85)
      {
        gain = (REAL) 0.85;
      }
      alpha *= gain;
    }
    else if (bfi_cnt <= 3)
    {
      alpha = *lp_gainp;
    }
    else
    {
      alpha = G729EV_FEC_ALPHA_VT;
    }

  }

  if (last_good >= G729EV_FEC_UV_TRANSITION)
  {

    Tc = (INT16) (tmp_Tc + 0.5);
    pt_exc = exc;
    pt1_exc = exc - Tc;
    pos = 0;
    if (bfi_cnt == 1)           /* if first erased frame in a block */
    {
      for (i = 0; i < Tc; i++)  /* find lp filtered pitch pulse */
      {
        *pt_exc++ = ((REAL) 0.18 * pt1_exc[-1] + (REAL) 0.64 * pt1_exc[0] + (REAL) 0.18 * pt1_exc[1]);
        pt1_exc++;
      }
      pos = Tc;
    }
    /* last pitch cycle of the previous frame is repeatedly copied up to an extra subframe */
    for (i = pos; i < G729EV_MAIN_L_FRAME2 + G729EV_G729_L_SUBFR; i++)
    {
      *pt_exc++ = *pt1_exc++;
    }

    if (new_pit > 0)
    {

      pit_subfr = 0;
      if (puls_pos == -1000)    /* Information of pulse position is not present */
      {
        /* Only possible when more than 1 frame erasure or with bitrate < 14 kbps */

        i = 1;
        ftmp = 0;
        sect = 0;
        ftmp = pitch_buf[0];
        while (ftmp < (G729EV_MAIN_L_FRAME2 - G729EV_G729_PIT_MIN))
        {
          sect = (INT16) (ftmp * 4 / G729EV_MAIN_L_FRAME2);
          ftmp += pitch_buf[sect];
          i++;
        }
   /*------------------------------------------------------------
    * Find estimated pitch lags per subframe 
    * estimation of the difference between the last concealed 
    * maximum glottal pulse in the frame and the estimated pulse  
    *------------------------------------------------------------*/
        total_pit_lag = (INT16) (i * Tc - ftmp);

        /* have to play   safe when we extrapolate a pulse position */
        if (total_pit_lag > 35)
        {
          total_pit_lag = 0;
        }
        if (total_pit_lag < -35)
        {
          total_pit_lag = 0;
        }

      }
      else
      {
   /*------------------------------------------------------------
    * Decode phase information transmitted in the bitstream
    * (The position of the absolute maximum glottal pulse from 
    * the end of the frame and its sign)
    *------------------------------------------------------------*/
        P0 = puls_pos;
        if (P0 >= 64)
        {
          sign = 1;
          P0 = (P0 & 0x3F);
        }
        if (Tc >= 128)
        {
          P0 *= 4;
          P0 += 2;
        }
        else if (Tc >= 64)
        {
          P0 *= 2;
          P0 += 1;
        }
        if (P0 > 160)
        {
          P0 = 160;             /* Should never be the case, however... */
        }
      }
      pit_search = Tc;

      if (sign)                 /* Take sign in account to find right pulse */
        pit_search = -pit_search;

      /* Find the position of the first lp_filtered pulse */
      /* |<--------------------- L_FRAME --------------------->|<----- L_SUBFR --->| */
      /* |<-------pit_search---->                              |                   | */
      Tlist[0] = G729EV_FEC_findpulse(exc, pit_search, 0);
      /* Find number of pulse */
      nb_pusles = (G729EV_MAIN_L_FRAME2 / Tc) + 1;
      /* Extrapolate the position of all the other pulses */
      /* puls_list contains realtive pulse position  P = Pulse PL = Puls_list */
      /* |<--------------------- L_FRAME --------------------->|<----- L_SUBFR --->| */
      /* |    P                 p                 p            |    p              | */
      /* |   TL[0]             TL[1]             TL[2]         |   TL[x]           | */
      for (i = 1; i < nb_pusles; i++)
      {
        Tlist[i] = Tlist[i - 1] + Tc;
      }
      if (puls_pos == -1000)    /* Information of pulse position is not present */
      {
        if (G729EV_MAIN_L_FRAME2 >= Tlist[nb_pusles - 1]) /* We try to find the right pulse pos */
        {
          P0 = G729EV_MAIN_L_FRAME2 - Tlist[nb_pusles - 1] + total_pit_lag;
        }
        else
        {
          P0 = G729EV_MAIN_L_FRAME2 - Tlist[nb_pusles - 2] + total_pit_lag;
        }
      }
      /* Choose on wich pulse to start the correction in function of pulse position sent by the encoder or estimated */
      pulse_chosen = 0;
      Terr = 200;
      Plast = G729EV_MAIN_L_FRAME2 - P0;
      for (i = 0; i < nb_pusles; i++)
      {
        temp = abs(Plast - Tlist[i]);
        if (temp < Terr)
        {
          Terr = temp;
          pulse_chosen = i;
        }
      }

      dist_Plast = G729EV_MAIN_L_FRAME2 - Tlist[pulse_chosen];
      diff_pit = abs(new_pit - Tc);

      ftmp = (REAL) (int) ((REAL) G729EV_MAIN_L_FRAME2 / (REAL) Tc + 0.5);
      if (((Terr <= ftmp * diff_pit) && (Terr != 0))  /*   If Terr = 0, no resynchronization required */
          && (Terr < G729EV_G729_L_SUBFR))  /* prevent catastrophy search */
      {
        /* performe excitation resynchronization here */
        G729EV_FEC_synchro_exc(exc, P0, dist_Plast, Tc);
      }
    }
    if ((last_good == G729EV_FEC_UV_TRANSITION))
    {
      gain = (REAL) 0.75;
      *lp_gainp = alpha / (REAL) 2.0;
    }
    else
    {
      gain = (REAL) 1.0;        /* start-of-the-frame gain */
      *lp_gainp = alpha;        /* end-of-the-frame gain, save attenuation factor for the next frame */
    }

    step = (gain - *lp_gainp) / G729EV_MAIN_L_FRAME2;

    for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
    {
      exc[i] *= gain;           /* Linearly attenuate the gain through the frame */
      gain -= step;
    }

    /* Update old_exc without random part */
    G729EV_G729_Copy(&exc[G729EV_MAIN_L_FRAME2 - G729EV_FEC_L_EXC_MEM], exc_mem, G729EV_FEC_L_EXC_MEM);

  }                             /* end of "if last_good >= G729EV_FEC_V_TRANSITION"  */

  /*-------------------------------------------------*
   * Construct the random part of excitation         *
   *-------------------------------------------------*/
  for (i = 0; i < G729EV_MAIN_L_FRAME2 + G729EV_FEC_L_FIR_FER - 1; i++)
  {
    exc2[i] = (REAL) G729EV_G729_Random(seed);
  }

  if ((last_good > G729EV_FEC_V_TRANSITION) || ((last_good > G729EV_FEC_UV_TRANSITION) && bfi_cnt > 1))
  {
    *lp_gainc *= (REAL) 0.5;
  }



  gain = *lp_gainc;             /* start-of-the-frame gain */

  *lp_gainc = alpha * *lp_gainc;


  if ((last_good == G729EV_FEC_UV_TRANSITION))
  {
    *lp_gainc = (REAL) 0.0;
  }

  pt_exc = exc2 + G729EV_FEC_L_FIR_FER / 2;
  gain_inov =
      1.0f / (REAL) sqrt(G729EV_Dot_product(pt_exc, pt_exc, G729EV_MAIN_L_FRAME2) / G729EV_MAIN_L_FRAME2 + 0.01f);
  if (last_good == G729EV_FEC_UNVOICED) /* Attenuate somewhat on unvoiced */
  {
    gain_inov *= (REAL) 0.4;
  }

  step = (gain - *lp_gainc) / (REAL) G729EV_MAIN_L_FRAME2;  /* Linearly attenuate the gain through the frame */
  pt_exc = exc2;                /* non-causal ringing of the FIR filter       */
  tmp = (gain_inov * gain);
  for (i = 0; i < G729EV_FEC_L_FIR_FER / 2; i++)
  {
    *pt_exc++ *= tmp;
  }

  for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)  /* Actual filtered random part of excitation  */
  {
    *pt_exc++ *= (gain_inov * gain);
    gain -= step;
  }
  tmp = (gain_inov * gain);
  for (i = 0; i < G729EV_FEC_L_FIR_FER / 2; i++)  /* causal ringing of the FIR filter           */
  {
    *pt_exc++ *= tmp;;
  }


  /*-------------------------------------------------*
   * Construct the total excitation         
   *-------------------------------------------------*/
  if (last_good >= G729EV_FEC_UV_TRANSITION)
  {
    pt_exc = exc2;
    for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)  /* hp filter random part and add to excitation */
    {
      exc[i] += G729EV_Dot_product(pt_exc, hp_filt, G729EV_FEC_L_FIR_FER);
      pt_exc++;
    }
  }
  else
  {
    /* For purely G729EV_FEC_UNVOICED, just G729EV_G729_Copy the random part */
    G729EV_G729_Copy(exc2 + G729EV_FEC_L_FIR_FER / 2, exc, G729EV_MAIN_L_FRAME2);
    /* Update old_exc  */
    G729EV_G729_Copy(&exc[G729EV_MAIN_L_FRAME2 - G729EV_FEC_L_EXC_MEM], exc_mem, G729EV_FEC_L_EXC_MEM);
  }

  G729EV_G729_Copy(exc, exc2, G729EV_MAIN_L_FRAME2);  /* Update exc2       */


  /*------------------------------------------------------------*
   * Speech synthesis 
   *------------------------------------------------------------*/
  p_Az = Aq;
  for (i_subfr = 0; i_subfr < G729EV_MAIN_L_FRAME2; i_subfr += G729EV_G729_L_SUBFR)
  {
    G729EV_G729_Syn_filt(p_Az, &exc2[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn2, 1);
    p_Az += (G729EV_G729_M + 1);
  }
  /*------------------------------------------------------------------*
   * estimate the pitch-synchronous speech energy per sample          *
   * to be used when normal operation recovers                        *
   *------------------------------------------------------------------*/
  G729EV_FEC_energy(last_good, synth, tmp_Tc, enrold, 1);
  return;
}

/*************************************************************************************/
/* G729EV_FEC_scale_syn : Smooth energy transition between lost frame and good frame */
/* - Find energy at frame end                                                        */
/* - Find energy at frame beginning                                                  */
/* - smooth excitation energy over all the frame                                     */
/* - redo synthesis (if needed)                                                      */
/*************************************************************************************/
void G729EV_FEC_scale_syn(INT16 extrate,          /* i: indicate decoded bit rate                 */
                          INT16 clas,             /* i/o: frame classification                    */
                          const INT16 last_good,  /* i:   last good frame classification          */
                          REAL * synth,           /* i/o: synthesized speech                      */
                          const REAL * pitch,     /* i:   pitch values for each subframe          */
                          REAL enr_q,             /* i:   transmitted energy for current frame    */
                          const INT16 prev_bfi,   /* i:   previous frame BFI                      */
                          REAL Aq[],              /* i/o: LP filter coefs (can be modified if BR) */
                          REAL * old_enr_LP,      /* i/o: LP filter E of last good G729EV_FEC_VOICED frame */
                          REAL * mem_tmp,         /* i/o: temporary synthesis memory              */
                          REAL * exc_tmp,         /* i/o: temporary excitation                    */
                          REAL enr_old,           /* i  : energy at the end of the last frame     */
                          REAL * old_exc,         /* i/o: excitation buffer                       */
                          REAL * mem_syn,         /* i/o: synthesis memory                        */
                          INT16 bfi_cnt           /* i  : Number of bad frame                     */
    )
{
  INT16     i, scale_flag;
  REAL      enr1, enr2, gain1, gain2, enr_LP, *p_Az;
  int       i_subfr;

  enr_LP = (REAL) 0.0;
  gain2 = (REAL) 0.0;
  gain1 = (REAL) 0.0;
  scale_flag = 0;

    /*-----------------------------------------------------------------*
     * Find the synthesis filter impulse response on G729EV_FEC_VOICED     
     *-----------------------------------------------------------------*/

  if (clas >= G729EV_FEC_V_TRANSITION)
  {
    enr_LP = G729EV_FEC_enr_1_Az(Aq + 3 * (G729EV_G729_M + 1), G729EV_G729_L_SUBFR);
  }


  if ((prev_bfi != G729EV_FEC_GOOD_FRAME) /* previous frame erased */
      && ((last_good < G729EV_FEC_SIN_ONSET) || (extrate > 40)) /* Do not scale if onset and energy doesnt sent by the encoder */
      )
  {
 /*-----------------------------------------------------------------*
  * Find the energy at the end of the frame 
  *-----------------------------------------------------------------*/
    G729EV_FEC_energy(clas, synth, pitch[3], &enr2, G729EV_MAIN_L_FRAME2);

    enr2 += (REAL) 0.1;

    if (extrate <= 40)          /* < 16 kbps  use the nergy estimation from the decoder */
    {
      enr_q = enr2;
      /* G729EV_FEC_VOICED-G729EV_FEC_VOICED recovery */
      if ((last_good >= G729EV_FEC_V_TRANSITION) && (clas >= G729EV_FEC_V_TRANSITION))
      {
        if (enr_LP > *old_enr_LP)
        {
          enr_q /= enr_LP;
          enr_q *= *old_enr_LP;
          if (bfi_cnt <= 1)
          {
            enr_q *= (REAL) 4.;
          }
        }

        if (enr_LP < *old_enr_LP)
        {
          if (enr_q > (REAL) 4. * enr_old)  /* Prevent energy to increase on G729EV_FEC_VOICED */
          {
            enr_q = (REAL) 4. *enr_old;
          }
        }
        else if (enr_q > enr_old) /* Prevent energy to increase on G729EV_FEC_VOICED */
        {
          enr_q = enr_old;
        }
      }
    }

    gain2 = (REAL) sqrt(enr_q / enr2);

   /*-----------------------------------------------------------------*
    * Clipping of the smoothing gain at the frame end
    *-----------------------------------------------------------------*/
    if ((enr_q < (REAL) 1.1))   /* Do not allow E increase if enr_q index==0 (lower end Q clipping) */
    {
      if (gain2 > (REAL) 1.0)
      {
        gain2 = (REAL) 1.0;     /* Gain modification clipping */
      }
    }
    else
    {
      if (gain2 > (REAL) 1.2)
      {
        gain2 = (REAL) 1.2;     /* Gain modification clipping */
      }
    }
   /*-----------------------------------------------------------------*
    * Find the energy at the beginning of the frame to ensure smooth 
    * transition after erasure     
    *-----------------------------------------------------------------*/

    if (clas == G729EV_FEC_SIN_ONSET) /* slow increase */
    {
      gain1 = (REAL) 0.5 *gain2;

      scale_flag = 1;
    }
    else if (((last_good >= G729EV_FEC_V_TRANSITION) && (clas == G729EV_FEC_UNVOICED)))
    {
      gain1 = gain2;
      scale_flag = 0;
    }
    else
    {
      G729EV_FEC_energy(clas, synth, pitch[0], &enr1, 0);

      enr1 += (REAL) 0.1;

      gain1 = (REAL) sqrt(enr_old / enr1);
      if (gain1 > (REAL) 1.2)
      {
        gain1 = (REAL) 1.2;     /* Gain modification clipping   */
      }
      /* Prevent a catastrophy in case of offset followed by G729EV_FEC_ONSET */
      if ((clas == G729EV_FEC_ONSET) && (gain1 > gain2))
      {
        gain1 = gain2;
      }
      scale_flag = 1;
    }
  }


 /*-----------------------------------------------------------------*
  * Smooth the energy evolution by exponentially evolving from 
  * gain1 to gain2        
  *-----------------------------------------------------------------*/

  if (scale_flag != 0)
  {
    gain2 *= ((REAL) 1.0 - G729EV_FEC_AGC);

    for (i = 0; i < G729EV_MAIN_L_FRAME2; i++)
    {
      gain1 = gain1 * G729EV_FEC_AGC + gain2;
      exc_tmp[i] *= gain1;
    }
    /* Update excitation memory with new excitation */
    G729EV_G729_Copy(&exc_tmp[G729EV_MAIN_L_FRAME2 - (G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL)],
                     old_exc, G729EV_G729_PIT_MAX + G729EV_G729_L_INTERPOL);
  }
 /*-----------------------------------------------------------------*
  * Update the LP filter energy for G729EV_FEC_VOICED frames
  *-----------------------------------------------------------------*/
  if (clas >= G729EV_FEC_V_TRANSITION)
  {
    *old_enr_LP = enr_LP;       /* Update */
  }
 /*-----------------------------------------------------------------*
  * smoothing is done in excitation domain, so redo synthesis
  *-----------------------------------------------------------------*/

  if ((prev_bfi != G729EV_FEC_GOOD_FRAME))
  {
 /*------------------------------------------------------------*
  * Speech synthesis at 8 kHz sampling rate                  *
  *------------------------------------------------------------*/
    G729EV_G729_Copy(mem_tmp, mem_syn, G729EV_G729_M);

    p_Az = Aq;
    for (i_subfr = 0; i_subfr < G729EV_MAIN_L_FRAME2; i_subfr += G729EV_G729_L_SUBFR)
    {
      G729EV_G729_Syn_filt(p_Az, &exc_tmp[i_subfr], &synth[i_subfr], G729EV_G729_L_SUBFR, mem_syn, 1);
      p_Az += (G729EV_G729_M + 1);
    }
  }

  return;
}

/******************************************************************************/
/* G729EV_FEC_enr_1_Az : To find impulse response energy                      */
/******************************************************************************/
static REAL G729EV_FEC_enr_1_Az(            /* o:   impulse response energy */
                                 REAL Aq[], /* i:   LP filter coefs         */
                                 INT16 len  /* i:   impulse response length */
    )
{
  REAL      enr_LP, h1[2 * G729EV_G729_L_SUBFR], mem[G729EV_G729_M];


  G729EV_G729_Set_zero(h1, len);  /* Find the impulse response        */
  G729EV_G729_Set_zero(mem, G729EV_G729_M);
  h1[0] = (REAL) 1.0;
  G729EV_G729_Syn_filt(Aq, h1, h1, len, mem, 0);

  enr_LP = G729EV_Dot_product(h1, h1, len) + (REAL) 0.01; /* Find the impulse response energy */

  return enr_LP;

}

/******************************************************************************/
/* G729EV_FEC_synchro_exc : To resynchronize concealed                        */
/* - Find number of minimum energy region                                     */
/* - Find location of minimum energy region                                   */
/* - Find number of sample to add/remove by minimum energy region             */
/* - Synchronisation (sample deletion/addition)                               */
/******************************************************************************/
static void G729EV_FEC_synchro_exc(REAL * exc,            /* i/o : exc vector to modify                      */
                                   INT16 desire_puls_pos, /* Pulse position send by the encoder              */
                                   INT16 true_puls_pos,   /* Present pulse location                          */
                                   INT16 Old_pitch        /* Pitch use to create temporary adaptive codebook */
    )
{
  REAL      exc_tmp[G729EV_MAIN_L_FRAME2 + G729EV_G729_L_SUBFR], min_energy, *pt_exc, *pt_exc1, ftmp, fact;
  INT16     i, j, k, point_to_remove, point_to_add = -1, nb_min, min_pos[10], points_by_pos[10], total_point, tmp_len;
  INT16    *pt_pos, pos, start_search, tmp16;
  int       remaining_len;
  REAL      tmp;

  point_to_add = -1;
  for (i = 0; i < 10; i++)
  {
    min_pos[i] = -10000;
    points_by_pos[i] = 0;
  }

  /* Find number of point to remove and number of minimum */
  point_to_remove = true_puls_pos - desire_puls_pos;  /* if it is negative it means remove point else it means add point */

  /* Find number of minimum energy region */
  nb_min = (G729EV_MAIN_L_FRAME2 - true_puls_pos) / Old_pitch;
  /* if Old pitch < 80, must have at least 2 min */
  if ((Old_pitch <= 80) && (nb_min < 2))
    nb_min = 2;
  /* Must have at least 1 min */
  if (nb_min == 0)
    nb_min = 1;

  pos = G729EV_MAIN_L_FRAME2 - true_puls_pos;
  pt_exc = exc + pos;

  /* Find start_search for minimum energy search */
  start_search = -3 * Old_pitch / 4;
  if (start_search + pos < 0)
  {
    start_search = -pos;
    if (abs(start_search) < Old_pitch / 8)
    {
      /* it's not safe to remove/add point inside 1/8 of the pulse position */
      return;
    }
  }

  /* Find min energy in the first pitch section */
  min_energy = 65536 * 65536.0f;

  ftmp = (pt_exc[start_search] * pt_exc[start_search]);
  ftmp += (pt_exc[start_search + 1] * pt_exc[start_search + 1]);
  ftmp += (pt_exc[start_search + 2] * pt_exc[start_search + 2]);
  ftmp += (pt_exc[start_search + 3] * pt_exc[start_search + 3]);
  ftmp += (pt_exc[start_search + 4] * pt_exc[start_search + 4]);

  if (ftmp < min_energy)
  {
    min_energy = ftmp;
    min_pos[0] = pos + start_search + 2;
  }
  for (i = start_search; i < -5; i++)
  {
    ftmp -= pt_exc[i] * pt_exc[i];
    ftmp += pt_exc[i + 5] * pt_exc[i + 5];
    if (ftmp < min_energy)
    {
      min_energy = ftmp;
      min_pos[0] = pos + i + 2;
    }
  }
  for (j = 1; j < nb_min; j++)
  {
    min_pos[j] = min_pos[j - 1] - Old_pitch;
    /* If the first minimum is in the past, forget this minimum */
    if (min_pos[j] < 0)
    {
      min_pos[j] = -10000;
      nb_min = nb_min - 1;
    }
  }
  /* --------------------------------------------------------------------
   * Determine the number of samples to be added or removed at each pitch 
   * cycle whereby less samples are added/removed at the beginning and 
   * more towards the end of the frame
   * --------------------------------------------------------------------*/
  if (nb_min == 1 || abs(point_to_remove) == 1)
  {
    nb_min = 1;
    points_by_pos[0] = abs(point_to_remove);
  }
  else
  {
    /* First position */
    /*fact = (float)fabs(point_to_remove) / sqi[nb_min-2]; (nb_min*nb_min); */
    fact = (REAL) fabs(2 * point_to_remove) / (nb_min * nb_min);
    points_by_pos[0] = (INT16) (fact / 2 + 0.5);
    total_point = points_by_pos[0];
    for (i = 2; i <= nb_min; i++)
    {
      points_by_pos[i - 1] = (INT16) (fact * (i * i) / 2 - total_point + 0.5);
      total_point += points_by_pos[i - 1];
      /* ensure a constant increase */
      if (points_by_pos[i - 1] < points_by_pos[i - 2])
      {
        tmp16 = points_by_pos[i - 2];
        points_by_pos[i - 2] = points_by_pos[i - 1];
        points_by_pos[i - 1] = tmp16;
      }
    }
  }
  /* --------------------------------------------------------------------
   * Sample deletion or insertion is performed in minimum energy regions. 
   * At the end of this section the last maximum pulse in the concealed 
   * excitation is forced to align to the actual maximum pulse position 
   * at the end of the frame which is transmitted in the future frame.
   * --------------------------------------------------------------------*/
  if (point_to_remove > 0)
    point_to_add = point_to_remove;

  pt_exc = exc_tmp;
  pt_exc1 = exc;
  i = 0;
  k = 0;
  pt_pos = min_pos + nb_min - 1;
  if (point_to_add > 0)         /* Samples insertion */
  {
    remaining_len = G729EV_MAIN_L_FRAME2;

    for (i = 0; i < nb_min; i++)
    {
      if (i == 0)
      {
        /*Compute len to copy */
        tmp_len = *pt_pos;
      }
      else
      {
        /*Compute len to copy */
        tmp_len = *pt_pos - *(pt_pos + 1) - points_by_pos[i - 1];
      }
      G729EV_G729_Copy(pt_exc1, pt_exc, tmp_len);
      remaining_len = remaining_len - tmp_len;
      pt_exc1 += tmp_len;
      pt_exc += tmp_len;

      /*Find point to add and Add points */
      tmp = -*pt_exc1 / 20;
      for (j = 0; j < points_by_pos[i]; j++)
      {
        *pt_exc++ = tmp;        /* repeat last point  */
        tmp = -(tmp);
      }
      remaining_len = remaining_len - points_by_pos[i];
      pt_pos--;
    }
    /* Copy remaining data */
    G729EV_G729_Copy(pt_exc1, pt_exc, remaining_len);
    /* Update excitation vector */
    G729EV_G729_Copy(exc_tmp, exc, G729EV_MAIN_L_FRAME2);
  }
  else                          /* Samples deletion */
  {
    remaining_len = G729EV_MAIN_L_FRAME2;

    for (i = 0; i < nb_min; i++)
    {
      if (i == 0)
      {
        /*Compute len to copy */
        tmp_len = *pt_pos;
      }
      else
      {
        /*Compute len to copy */
        tmp_len = *pt_pos - *(pt_pos + 1) - points_by_pos[i - 1];
      }
      G729EV_G729_Copy(pt_exc1, pt_exc, tmp_len);
      remaining_len = remaining_len - tmp_len;
      pt_exc1 += tmp_len;
      pt_exc += tmp_len;
      /* Remove points */
      for (j = 0; j < points_by_pos[i]; j++)
      {
        pt_exc1++;
      }
      pt_pos--;
    }
    /* Copy remaining data */
    G729EV_G729_Copy(pt_exc1, pt_exc, remaining_len);
    /* Update excitation vector */
    G729EV_G729_Copy(exc_tmp, exc, G729EV_MAIN_L_FRAME2);
  }
  return;
}
