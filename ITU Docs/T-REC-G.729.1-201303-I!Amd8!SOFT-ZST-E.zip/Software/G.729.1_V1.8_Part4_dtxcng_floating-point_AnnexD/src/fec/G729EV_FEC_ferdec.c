/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: Jul 2, 2007                                                    */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/******************************************************************************/
/* G729EV_FEC_dec :  Decode FER information                                   */
/* - Decode class information (if avalaible)                                  */
/* - Decode pulse postion and sign information (if avalaible)                 */
/* - Decode enegy information (if avalaible)                                  */
/******************************************************************************/
#include <math.h>
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_FEC_tools.h"

INT16 G729EV_FEC_dec(                       /* o:   frame class information               */
                      INT16 * last_good,    /* i:   last good received frame class        */
                      INT16 plast_good,     /* i:  previous last good received frame class*/
                      const INT16 prev_bfi, /* i:   BFI of the previous frame             */
                      int *indice,          /* i/o: Q indices (parameter vector)          */
                      REAL * enr_q,         /* o:   E information for FER protection      */
                      int Rate              /* i:   Bitrate decoded                       */
    )
{
  INT16     clas, ind;


  clas = G729EV_FEC_UNVOICED;   /* Initialization         */
  ind = (INT16) indice[0];
  if (ind == 0)
  {
    clas = G729EV_FEC_UNVOICED;
  }
  else if (ind == 1)
  {

    if (*last_good >= G729EV_FEC_V_TRANSITION)
    {
      clas = G729EV_FEC_V_TRANSITION;
    }
    else
    {
      clas = G729EV_FEC_UV_TRANSITION;
    }
  }
  else if (ind == 2)
  {
    clas = G729EV_FEC_VOICED;
  }
  else
  {
    clas = G729EV_FEC_ONSET;
  }

 /*-----------------------------------------------------------------*
  * Decide whether to model ONSET by sinusoidal model (FER) 
  * or regular ACELP  
  *-----------------------------------------------------------------*/

  if (prev_bfi != G729EV_FEC_GOOD_FRAME)  /* first good after bfi                  */
  {
    if ((clas >= G729EV_FEC_VOICED) &&  /* G729EV_FEC_VOICED                                */
        ((*last_good < G729EV_FEC_UV_TRANSITION)))  /* last good received frame was G729EV_FEC_UNVOICED */
    {
      clas = G729EV_FEC_SIN_ONSET;
      *last_good = G729EV_FEC_SIN_ONSET;  /* To prepare onset reconstruction */
    }
    if ((clas == G729EV_FEC_VOICED) &&  /* G729EV_FEC_VOICED                                */
        ((*last_good > G729EV_FEC_VOICED))  /* last good received frame was G729EV_FEC_UNVOICED */
        )
    {
      *last_good = G729EV_FEC_VOICED;
    }
    else if ((clas == G729EV_FEC_VOICED) && /* G729EV_FEC_VOICED                                */
             (plast_good >= G729EV_FEC_VOICED)) /* last good received frame was G729EV_FEC_UNVOICED */
    {
      *last_good = G729EV_FEC_VOICED;
    }
    else if ((clas == G729EV_FEC_UNVOICED) && /* G729EV_FEC_VOICED                                */
             (*last_good == G729EV_FEC_VOICED)) /* last good received frame was G729EV_FEC_UNVOICED */
    {
      *last_good = G729EV_FEC_UV_TRANSITION;
    }

  }

   /*-----------------------------------------------------------------*
    * Decode the energy for FER concealment
    *-----------------------------------------------------------------*/
  if (indice[1] != -1000)       /* if information is present */
  {
    *enr_q = (REAL) pow(10.0f, ((REAL) indice[1] * (REAL) 1.55) / (REAL) 5.0);
  }

  return clas;
}
