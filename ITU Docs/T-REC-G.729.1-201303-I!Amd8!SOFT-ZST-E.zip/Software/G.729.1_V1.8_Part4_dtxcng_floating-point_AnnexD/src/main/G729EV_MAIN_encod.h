/*                                                                                    */
/*      ITU-T G.729.1 Annex D - Reference C code for floating-point implementation    */      
/*      Copyright (c) 2008                                                            */
/*      Huawei Technologies, Siemens AG                                               */
/*      Version 1.4                                                                   */
/*      Revision Date: Sep. 16, 2008                                                  */
/*	                                                                                  */

/* This file is taken/adapted from the following distributions: 

      ITU-T G.729.1 Annex C - Reference C code for fixed-point implementation          
      Copyright (c) 2008
      Huawei Technologies, Siemens AG
      Version 1.3
      Revision Date: April 29, 2008
	                     

   ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    
   $Release:       1.8                                                            
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
   Revision Date: Jul 2, 2007                                                    

   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-07 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_ENCOD_H__
#define __G729EV_MAIN_ENCOD_H__

#include <stdio.h>
#include "CodecTypedef.h"

#include "G729EV_TDBWE_encoder.h"
#include "G729EV_G729_codstat.h"
#include "G729EV_G729_decstat.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_MAIN_defines.h"

/* Types : */

typedef struct
{
  /* filter states */
  G729EV_MAIN_QMFCODSTAT qmf_ana;
  G729EV_MAIN_IIR2STAT mem_hp50;
  G729EV_MAIN_IIRN_STAT mem_lp3k;

  /* G.729 state variables */
  G729EV_G729_CODSTAT codStG729;
  G729EV_G729_DECSTAT decStG729;
  G729EV_TDBWE_CODSTAT tdbwe;

  /* states for perceptual weighting filtering of lower-band difference signal */
  REAL      mem_Wz_in[G729EV_G729_M];
  REAL      mem_wsp[G729EV_G729_M];

  /* memory of MDCT */
  REAL      mem_mdct_lo[G729EV_MAIN_L_FRAME2];
  REAL      mem_mdct_hi[G729EV_MAIN_L_FRAME2];

  /* states variables of FER encoder */
  INT16     oldferclass;
  REAL      lp_speech;
  REAL      relE_hist;
  REAL      relE_var;
  INT16     old_pulspos;

  /* encoder flags (8kHz sampled input, G729 bitstream mode) */
  int       f8;
  INT16     g729ev_dtx;
  REAL tdbwe_parameters[13];
  int hangover_cnt;
} CODSTATMAIN;


/* Functions : */

void      G729EV_MAIN_InitEncoder(CODSTATMAIN * codstat, 
								  int rate, 
								  int dtx_max_fr, 
								  int f8, 
								  int g729_bst,
								  INT16 cng_nb,
								  INT16 cng_wb,         
								  INT16 g729ev_dtx);

void G729EV_MAIN_Encode (
#ifdef MKVAD
						 INT16 mkvad_vadflag,
#endif
						 CODSTATMAIN * codstat, INT16 *samplesIn, INT16 *bitstream, int rate);


#endif  /*__G729EV_MAIN_ENCOD_H__ */
