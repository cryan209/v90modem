/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_TDBWE_fir.h"
#include "G729EV_G729_ld8k.h"


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_fir_initialize()                                 *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                 *
 *  TDBWE FIR filter initialization                                         *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_fir_initialize(G729EV_TDBWE_fir_state * state,  /* (o) */
                                 REAL * filter_coeffs)            /* (i) coefficient vector for FIR fiter */
{
  state->filter_coeffs = filter_coeffs;

  G729EV_G729_Set_zero(state->state, G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1);
}


/*--------------------------------------------------------------------------*
 *  Function  G729EV_TDBWE_fir()                                            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~                                            *
 *  TDBWE FIR filter                                                        *
 *                                                                          *
 *  direct form (non-transposed) implementation                             *
 *--------------------------------------------------------------------------*/
void G729EV_TDBWE_fir(G729EV_TDBWE_fir_state * state, /* (i/o) */
                      REAL * input,                   /* (i)   input signal */
                      REAL * output,                  /* (o)   filtered signal */
                      int vector_size)                /* (i)   number of elements in input[] and output[] */
{

  int       i, k;
  REAL     *buf_ptr, *state_ptr, *coeffs_ptr, *coeffs_ptr_start;
  REAL      buf[G729EV_TDBWE_BUFLEN_FIR];

  G729EV_G729_Copy(state->state, buf, G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1);
  G729EV_G729_Copy(input, &buf[G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1], vector_size);

  buf_ptr = buf;
  coeffs_ptr_start = &state->filter_coeffs[G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1];

  for (i = 0; i < vector_size; i++)
  {
    /* filtering ... */
    state_ptr = buf_ptr++;
    coeffs_ptr = coeffs_ptr_start;

    output[i] = 0.0;
    for (k = 0; k < G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH; k++)
    {
      output[i] += *coeffs_ptr-- * *state_ptr++;
    }
  }
  /* save filter state */
  G729EV_G729_Copy(&buf[vector_size], state->state, G729EV_TDBWE_FREQ_ENV_SHAPING_FILTER_LENGTH_M_1);
}
