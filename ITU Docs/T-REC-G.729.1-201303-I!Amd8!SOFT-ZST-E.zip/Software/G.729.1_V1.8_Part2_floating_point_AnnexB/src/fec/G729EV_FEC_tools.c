/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/


/*-----------------------------------------------------------*
 * Tool library
 * ~~~~~~~~~~~~~~~~~~~                                             
 *-----------------------------------------------------------*/


/* Fixed-point definitions and prototypes */
#include "G729EV_MAIN_defines.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_tools.h"
#include "G729EV_FEC_fer.h"



/*----------------------------------------------------------------------------------*
 * procedure   Emaximum:                                     
 *             ~~~~~~~~                                      
 *   Find index of a maximum energy in a vector              
 *----------------------------------------------------------------------------------*/
INT16 G729EV_Emaximum2(                   /* o:   return index with energy value in vector  */
                        const REAL * vec, /* i:   input vector                              */
                        int lvec,         /* i:   length of input vector                    */
                        REAL * ener_max   /* o:   maximum energy value                      */
    )
{
  INT16     j, ind;
  REAL      temp;

  *ener_max = (REAL) 0.0;
  ind = 0;
  for (j = 0; j < lvec; j++)
  {
    temp = vec[j] * vec[j];
    if (temp > *ener_max)
    {
      ind = j;
      *ener_max = temp;
    }
  }
  return ind;
}

/*----------------------------------------------------------------------------------*
 * Function Name : Dot_product()                           
 * Compute scalar product of <x[],y[]> using accumulator.   
 *----------------------------------------------------------------------------------*/
REAL G729EV_Dot_product(                  /* o:   Sum               */
                         const REAL x[],  /* i:   x vector          */
                         const REAL y[],  /* i:   y vector          */
                         int lg           /* i:   vector length     */
    )
{
  int       i;
  REAL      sum;

  sum = x[0] * y[0];
  for (i = 1; i < lg; i++)
  {
    sum += x[i] * y[i];
  }
  return (sum);
}
