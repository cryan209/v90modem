/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*----------------------------------------------------------------------------------*
 *  Supplementary information for FER concealment                       
 *----------------------------------------------------------------------------------*/

#include <stdlib.h>
#include <stdio.h>
#include <math.h>
#include <time.h>

#include "G729EV_MAIN_defines.h"
#include "G729EV_MAIN_filt.h"
#include "G729EV_G729_defines.h"
#include "G729EV_FEC_fer.h"
#include "G729EV_TDAC_util.h"
#include "G729EV_FEC_tools.h"

/*---------------------------------------------------------------------*
 *                             Prototypes 
 *---------------------------------------------------------------------*/
static INT16 G729EV_FEC_clas_enc(const INT16 clas);
static INT16 G729EV_FEC_sig_clas(const INT16 old_clas, const REAL voicing[6], const REAL * speech,
                                 const INT16 pit[3], const REAL * ee, const REAL * sync_sp,
                                 const REAL * syn, REAL * lp_speech, REAL * rel_hist, REAL * rel_var);
/******************************************************************************/
/* G729EV_FEC_encod :  Decode FER information                                 */
/* - Find signal classification                                               */
/* - Find signal energy                                                       */
/* - Find last glotal pulse postion                                           */
/******************************************************************************/
void G729EV_FEC_encod(const INT16 old_clas,   /* i:   signal classification result from previous frames */
                      const REAL * voicing,   /* i:   normalized correlation for 3 half-frames          */
                      const REAL * speech,    /* i:   pointer to denoised speech signal                 */
                      const REAL * synth,     /* i:   pointer to synthesized speech for E computation   */
                      const INT16 * T_op,     /* i:   close loop pitch values for 3 half-frames         */
                      const REAL * ee,        /* i:   lf/hf E ration for 2 half-frames                  */
                      const REAL * sync_sp,   /* i:   time syncronised input speech                     */
                      INT16 * clas,           /* o:   signal clas for current frame                     */
                      int *coder_parameters,  /* o:   coder_parameters                                  */
                      const INT16 T0,         /* i:   close loop integer pitch                          */
                      const INT16 T0_frac,    /* i:   close loop fractional part of the pitch           */
                      const REAL * res,       /* i:   LP residual signal frame                          */
                      REAL * lp_speech,       /* i/o: LP speech energu                                  */
                      REAL * rel_hist,        /* i/o: relative energy memory                            */
                      REAL * rel_var,         /* i/o: relative erergy variation                         */
                      INT16 * old_pos         /* i/o: Position of the last pulse                        */
    )
{

  INT16     tmpS;
  INT16     maxi, FER_pitch;
  INT16     index[3];
  REAL      enr_q;
  INT16     sign;
  int      *coder_param_ptr;

  coder_param_ptr = coder_parameters;
  sign = 0;
  enr_q = (REAL) 1.0;
  FER_pitch = T_op[3];

 /*------------------------------------------------------------------------*
  *  Signal classification 
  *------------------------------------------------------------------------*/
  *clas = G729EV_FEC_sig_clas(old_clas, voicing, speech, T_op, ee, sync_sp, synth, lp_speech, rel_hist, rel_var);
 /*-----------------------------------------------------------------*
  *  Speech energy information
  *  - Maximum of energy per pitch period for G729EV_FEC_VOICED frames
  *  - mean energy per sample over 2nd half of the frame for other
  *    frames
  *-----------------------------------------------------------------*/
  G729EV_FEC_energy(*clas, synth, (REAL) (T0) + (REAL) (T0_frac) / (REAL) 3.0, &enr_q, G729EV_FEC_L_FRAME_FER);

 /*-----------------------------------------------------------------*
  * linearly quantized the energy in the range 0 : 1.55 : 96 dB
  *-----------------------------------------------------------------*/

  tmpS = (INT16) (5.0 * log10(enr_q + 0.001f) / 1.55);
  if (tmpS >= 31)
  {
    tmpS = 31;
  }
  if (tmpS < 0)
  {
    tmpS = 0;
  }
  index[1] = tmpS;

   /*-----------------------------------------------------------------*
    *  Signal classification encoding
    *-----------------------------------------------------------------*/
  index[0] = G729EV_FEC_clas_enc(*clas);

   /*-----------------------------------------------------------------*
    *  First pitch pulse position encoding
    *  - Find first pitch pulse of current frame
    *  - Encode first pitch pulse position
    *-----------------------------------------------------------------*/
  maxi = 0;
  if (*clas > G729EV_FEC_UNVOICED)
  {
    maxi = G729EV_FEC_findpulse(res, FER_pitch, 1);
  }

  if (maxi > 160)
  {
    maxi -= 256;
    sign = 1;
  }

  if (FER_pitch >= 64)
  {
    maxi /= 2;
  }

  if (FER_pitch >= 128)
  {
    maxi /= 2;
  }

  if (maxi > 64)
  {
    maxi = 63;                  /* This should never happen... */
  }
  if (sign)
    maxi += 64;

  /* delay puls pos parameter */
  tmpS = maxi;
  maxi = *old_pos;
  *old_pos = tmpS;

  index[2] = maxi;

  *coder_param_ptr++ = index[2];
  *coder_param_ptr++ = index[0];
  *coder_param_ptr++ = index[1];
}

/******************************************************************************/
/* G729EV_FEC_sig_clas :  Do signal classification                            */
/* - Find realtive signal energy                                              */
/* - Find signal to noise ratio                                               */
/* - Find average voicing                                                     */
/* - Compute the zero crossing rate                                           */
/* - Compute pitch stability                                                  */
/* - Compute function of merit                                                */
/* - Find signal classification                                               */
/******************************************************************************/
static INT16 G729EV_FEC_sig_clas(                       /* o:   classification for current frames                    */
                                  const INT16 old_clas, /* i:   signal classification result from previous frames    */
                                  const REAL voicing[], /* i:   normalized correlation for 3 half-frames             */
                                  const REAL * speech,  /* i:   pointer to speech signal for E computation           */
                                  const INT16 pit[],    /* i:   open loop pitch values for 3 half-frames             */
                                  const REAL * ee,      /* i:   lf/hf E ration for 2 half-frames                     */
                                  const REAL * wsp,     /* i:   weighted speech                                      */
                                  const REAL * wsyn,    /* i:   weighted synthesized signal                          */
                                  REAL * lp_speech,     /* i/o: LP speech energu                                     */
                                  REAL * last_relE,     /* i/o: relative energy memory                               */
                                  REAL * relE_var       /* i/o: relative erergy variation                            */
    )
{
  REAL      mean_voi2, segen, noiseen, tmp, snr_val;
  REAL      een, corn, zcn, relEn, pcn, snrn, fmerit1, fmerit_fac, tmp_mean;
  INT16     i, clas, pc, zc;

  REAL      relE, Etot, *pt_wind, ftmp;

 /*-----------------------------------------------------------------*
  * Signal classification preprocessing   
  *-----------------------------------------------------------------*/
  /* Etot is the total energy over all the bandwith in dB */
  Etot = (REAL) 0.01;
  pt_wind = (REAL *) Sqrt_han_wind8k;
  for (i = 0; i < G729EV_FEC_L_FRAME_FER / 4; i++)
  {
    ftmp = speech[i] * *pt_wind++;
    Etot += (ftmp * ftmp);
  }
  for (; i < G729EV_FEC_L_FRAME_FER / 2; i++)
  {
    ftmp = speech[i] * *pt_wind++;
    Etot += (ftmp * ftmp);
  }
  for (; i < 3 * G729EV_FEC_L_FRAME_FER / 4; i++)
  {
    ftmp = speech[i] * *pt_wind--;
    Etot += (ftmp * ftmp);
  }
  for (; i < G729EV_FEC_L_FRAME_FER; i++)
  {
    ftmp = speech[i] * *pt_wind--;
    Etot += (ftmp * ftmp);
  }


  Etot = (REAL) (10.0f * log10(Etot / G729EV_FEC_L_FRAME_FER));
  relE = Etot - *lp_speech;
 /*-----------------------------------------------------------------*
  * Signal classification preprocessing   
  *-----------------------------------------------------------------*/

  /* Compute the SNR  */
  segen = (REAL) 0.0;
  noiseen = (REAL) 0.01;

  for (i = 0; i < G729EV_FEC_L_FRAME_FER; i++)
  {
    segen += (wsp[i] * wsp[i]);
    tmp = (wsp[i] - wsyn[i]);
    noiseen += tmp * tmp;
  }
  snr_val = segen / noiseen;    /* Total SNR    */
  snr_val = (REAL) ((REAL) 10.0 * log10(snr_val + (REAL) 0.01));

  /* average voicing on second half-frame and look-ahead  */
  mean_voi2 = (REAL) 0.5f *(voicing[3] + voicing[0]);

  /* Average the spectral tilt in dB        */
  een = ee[0] * ee[1];
  een = G729EV_FEC_K_EE * een + G729EV_FEC_C_EE;
  if (een < (REAL) 0.0 || ee[0] < (REAL) 0.0f || (REAL) ee[1] < 0.0)
  {
    een = (REAL) 0.0;
  }
  if ((een > (REAL) 1.0))
  {
    een = (REAL) 1.0;
  }

  /* Compute the zero crossing rate    */
  zc = 0;
  for (i = 1; i < G729EV_FEC_L_FRAME_FER; i++)
  {
    if ((speech[i] <= (REAL) 0.0) && (speech[i - 1] > (REAL) 0.0))
    {
      zc++;
    }
  }


  /* Compute the pitch stability      */
  pc = abs(pit[2] - pit[1]) + abs(pit[3] - pit[2]);

  /* This section is needed to improve signal classification in noisy condition */
  tmp_mean = *last_relE;
  *last_relE = relE;
  fmerit_fac = (REAL) 1.0;

  if ((fabs(relE - tmp_mean) < (fabs(*relE_var) + (REAL) 6.)) && (old_clas <= G729EV_FEC_UNVOICED)) /* absolute variation */
  {
    fmerit_fac = (REAL) 0.8;
  }
  else if (((relE - tmp_mean) > (*relE_var + (REAL) 3.0)) && (old_clas <= G729EV_FEC_V_TRANSITION))
  {
    fmerit_fac = (REAL) 1.1;
  }
  else if (((relE - tmp_mean) < ((*relE_var) - (REAL) 5.0)) && (old_clas >= G729EV_FEC_V_TRANSITION))
  {
    fmerit_fac = (REAL) 0.6;
  }
  *relE_var = (REAL) 0.05 *(relE - tmp_mean) + (REAL) 0.95 *(*relE_var);

   /*-----------------------------------------------------------------*
    * transform parameters between 0 & 1    
    * find unique merit function            
    *-----------------------------------------------------------------*/
  corn = G729EV_FEC_K_COR_ENC * mean_voi2 + G729EV_FEC_C_COR_ENC;
  if (corn > (REAL) 1.0)
  {
    corn = (REAL) 1.0;
  }
  else if (corn < (REAL) 0.0)
  {
    corn = (REAL) 0.0;
  }

  zcn = G729EV_FEC_K_ZC_ENC * zc + G729EV_FEC_C_ZC_ENC;
  if (zcn > (REAL) 1.0)
  {
    zcn = (REAL) 1.0;
  }
  else if (zcn < (REAL) 0.0)
  {
    zcn = (REAL) 0.0;
  }

  relEn = G729EV_FEC_K_RELE * relE + G729EV_FEC_C_RELE;
  if (relEn > (REAL) 1.0)
  {
    relEn = (REAL) 1.0;
  }
  else if (relEn < (REAL) 0.5)
  {
    relEn = (REAL) 0.5;
  }

  pcn = G729EV_FEC_K_PC_ENC * pc + G729EV_FEC_C_PC_ENC;
  if (pcn > (REAL) 1.0)
  {
    pcn = (REAL) 1.0;
  }
  else if (pcn < (REAL) 0.0)
  {
    pcn = (REAL) 0.0;
  }
  snrn = G729EV_FEC_K_SNR * snr_val + G729EV_FEC_C_SNR;
  if (snrn > (REAL) 1.0)
  {
    snrn = (REAL) 1.0;
  }
  else if (snrn < (REAL) 0.0)
  {
    snrn = (REAL) 0.0;
  }

  fmerit1 = ((REAL) 2. * corn + een + (REAL) 1.2 * snrn + pcn + relEn + zcn) / (REAL) 7.;

  if (relEn <= (REAL) 0.5)
    fmerit1 *= (REAL) 1.05;
  if (relEn > (REAL) 0.75)
    fmerit1 *= (REAL) 1.25;

  /* Correction when noisy condition */
  fmerit1 *= fmerit_fac;

 /*-----------------------------------------------------------------*
  * frame classification                  
  *-----------------------------------------------------------------*/
  if ((relE < (REAL) - 10.0))
  {
    clas = G729EV_FEC_UNVOICED;
  }
  else
  {
    switch (old_clas)
    {
      case G729EV_FEC_VOICED:
      case G729EV_FEC_ONSET:
      case G729EV_FEC_V_TRANSITION:

        if (fmerit1 < (REAL) 0.56)
        {
          clas = G729EV_FEC_UNVOICED;
        }
        else if (fmerit1 < (REAL) 0.68)
        {
          clas = G729EV_FEC_V_TRANSITION;
        }
        else
        {
          clas = G729EV_FEC_VOICED;
        }
        break;

      case G729EV_FEC_UNVOICED:
      case G729EV_FEC_UV_TRANSITION:


        if (fmerit1 > (REAL) 0.64)
        {
          clas = G729EV_FEC_ONSET;
        }
        else if (fmerit1 > (REAL) 0.58)
        {
          clas = G729EV_FEC_UV_TRANSITION;
        }
        else
        {
          clas = G729EV_FEC_UNVOICED;
        }
        break;

      default:
        clas = G729EV_FEC_UNVOICED;
        break;
    }
  }

  if (clas > G729EV_FEC_V_TRANSITION)
  {
    *lp_speech = (REAL) 0.99 *(*lp_speech) + (REAL) 0.01 *Etot;
  }

  return clas;
}


/*---------------------------------------------------------------------*
 *  Signal classification encoding
 *---------------------------------------------------------------------*/

static INT16 G729EV_FEC_clas_enc(                   /* o: quantization index                */
                                  const INT16 clas  /* i:   signal clas for current frame   */
    )
{
  INT16     index;

  if (clas == G729EV_FEC_UNVOICED)
  {
    index = 0;
  }
  else if ((clas == G729EV_FEC_V_TRANSITION) || (clas == G729EV_FEC_UV_TRANSITION))
  {
    index = 1;
  }
  else if (clas == G729EV_FEC_VOICED)
  {
    index = 2;
  }
  else                          /* G729EV_FEC_ONSET        */
  {
    index = 3;
  }
  return index;
}
