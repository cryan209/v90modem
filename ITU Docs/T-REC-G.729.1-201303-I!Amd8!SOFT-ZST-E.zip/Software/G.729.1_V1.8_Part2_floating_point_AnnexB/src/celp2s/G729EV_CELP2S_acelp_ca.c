/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_CELP2S_acelp_ca.h"

/*--------------------------------------------------------------------------*
 * Function  G729EV_G729_cor_h_OTH()                                        *
 * Compute  correlations of h[] needed for the codebook search.             *
 *--------------------------------------------------------------------------*/

static void G729EV_CELP2S_cor_h_OTH(REAL * h,   /* (i) :  Impulse response of filters */
                                    REAL * rr,  /* (o) :  Correlations of H[]         */
                                    REAL * y1)
{
  REAL     *rri0i0, *rri1i1, *rri2i2, *rri3i3, *rri4i4;
  REAL     *rri0i1, *rri0i2, *rri0i3, *rri0i4;
  REAL     *rri1i2, *rri1i3, *rri1i4;
  REAL     *rri2i3, *rri2i4;

  REAL     *p0, *p1, *p2, *p3, *p4;

  REAL     *ptr_hd, *ptr_hf, *ptr_h1, *ptr_h2;
  REAL      cor;
  int       i, k, ldec, l_fin_sup, l_fin_inf;

  int       j, ii, jj, kk;
  REAL      r0, r1, tmp[40], rt0, rt1, rt2, rt3, rt4;

  /*------------------------------------------------------------*
  * Compute rri0i0[], rri1i1[], rri2i2[], rri3i3 and rri4i4[]  *
  *------------------------------------------------------------*/
  /* Init pointers */
  rri0i0 = rr;
  rri1i1 = rri0i0 + G729EV_G729_NB_POS; /* 8 */
  rri2i2 = rri1i1 + G729EV_G729_NB_POS;
  rri3i3 = rri2i2 + G729EV_G729_NB_POS;
  rri4i4 = rri3i3 + G729EV_G729_NB_POS;
  rri0i1 = rri4i4 + G729EV_G729_NB_POS;
  rri0i2 = rri0i1 + G729EV_G729_MSIZE;  /* 64 */
  rri0i3 = rri0i2 + G729EV_G729_MSIZE;
  rri0i4 = rri0i3 + G729EV_G729_MSIZE;
  rri1i2 = rri0i4 + G729EV_G729_MSIZE;
  rri1i3 = rri1i2 + G729EV_G729_MSIZE;
  rri1i4 = rri1i3 + G729EV_G729_MSIZE;
  rri2i3 = rri1i4 + G729EV_G729_MSIZE;
  rri2i4 = rri2i3 + G729EV_G729_MSIZE;

  p0 = rri0i0 + G729EV_G729_NB_POS - 1; /* Init pointers to last position of rrixix[] */
  p1 = rri1i1 + G729EV_G729_NB_POS - 1;
  p2 = rri2i2 + G729EV_G729_NB_POS - 1;
  p3 = rri3i3 + G729EV_G729_NB_POS - 1;
  p4 = rri4i4 + G729EV_G729_NB_POS - 1;

  ptr_h1 = h;
  cor = (REAL) 0.0;
  for (i = 0; i < G729EV_G729_NB_POS; i++)
  {
    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p4-- = cor;

    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p3-- = cor;

    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p2-- = cor;

    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p1-- = cor;

    cor += *ptr_h1 * *ptr_h1;
    ptr_h1++;
    *p0-- = cor;
  }

  /*-----------------------------------------------------------------*
   * Compute elements of: rri2i3[], rri1i2[], rri0i1[] and rri0i4[]  *
   *-----------------------------------------------------------------*/

  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;
  ldec = G729EV_G729_NB_POS + 1;

  ptr_hd = h;
  ptr_hf = ptr_hd + 1;

  for (k = 0; k < G729EV_G729_NB_POS; k++)
  {

    p3 = rri2i3 + l_fin_sup;
    p2 = rri1i2 + l_fin_sup;
    p1 = rri0i1 + l_fin_sup;
    p0 = rri0i4 + l_fin_inf;
    cor = (REAL) 0.0;
    ptr_h1 = ptr_hd;
    ptr_h2 = ptr_hf;

    for (i = k + 1; i < G729EV_G729_NB_POS; i++)
    {

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p3 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p2 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p1 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p0 = cor;

      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p3 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p2 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p1 = cor;

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

  /*---------------------------------------------------------------------*
   * Compute elements of: rri2i4[], rri1i3[], rri0i2[], rri1i4[], rri0i3 *
   *---------------------------------------------------------------------*/

  ptr_hd = h;
  ptr_hf = ptr_hd + 2;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;
  for (k = 0; k < G729EV_G729_NB_POS; k++)
  {

    p4 = rri2i4 + l_fin_sup;
    p3 = rri1i3 + l_fin_sup;
    p2 = rri0i2 + l_fin_sup;
    p1 = rri1i4 + l_fin_inf;
    p0 = rri0i3 + l_fin_inf;

    cor = (REAL) 0.0;
    ptr_h1 = ptr_hd;
    ptr_h2 = ptr_hf;
    for (i = k + 1; i < G729EV_G729_NB_POS; i++)
    {

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p4 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p3 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p2 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p1 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p0 = cor;

      p4 -= ldec;
      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p4 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p3 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p2 = cor;

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

  /*----------------------------------------------------------------------*
   * Compute elements of: rri1i4[], rri0i3[], rri2i4[], rri1i3[], rri0i2  *
   *----------------------------------------------------------------------*/

  ptr_hd = h;
  ptr_hf = ptr_hd + 3;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;
  for (k = 0; k < G729EV_G729_NB_POS; k++)
  {

    p4 = rri1i4 + l_fin_sup;
    p3 = rri0i3 + l_fin_sup;
    p2 = rri2i4 + l_fin_inf;
    p1 = rri1i3 + l_fin_inf;
    p0 = rri0i2 + l_fin_inf;

    ptr_h1 = ptr_hd;
    ptr_h2 = ptr_hf;
    cor = (REAL) 0.0;
    for (i = k + 1; i < G729EV_G729_NB_POS; i++)
    {

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p4 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p3 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p2 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p1 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p0 = cor;

      p4 -= ldec;
      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p4 = cor;

    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p3 = cor;

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }

 /*----------------------------------------------------------------------*
  * Compute elements of: rri0i4[], rri2i3[], rri1i2[], rri0i1[]          *
  *----------------------------------------------------------------------*/

  ptr_hd = h;
  ptr_hf = ptr_hd + 4;
  l_fin_sup = G729EV_G729_MSIZE - 1;
  l_fin_inf = l_fin_sup - 1;
  for (k = 0; k < G729EV_G729_NB_POS; k++)
  {

    p3 = rri0i4 + l_fin_sup;
    p2 = rri2i3 + l_fin_inf;
    p1 = rri1i2 + l_fin_inf;
    p0 = rri0i1 + l_fin_inf;

    ptr_h1 = ptr_hd;
    ptr_h2 = ptr_hf;
    cor = 0;
    for (i = k + 1; i < G729EV_G729_NB_POS; i++)
    {

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p3 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p2 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p1 = cor;

      cor += *ptr_h1 * *ptr_h2;
      ptr_h1++;
      ptr_h2++;
      *p0 = cor;

      p3 -= ldec;
      p2 -= ldec;
      p1 -= ldec;
      p0 -= ldec;
    }
    cor += *ptr_h1 * *ptr_h2;
    ptr_h1++;
    ptr_h2++;
    *p3 = cor;

    l_fin_sup -= G729EV_G729_NB_POS;
    l_fin_inf--;
    ptr_hf += G729EV_G729_STEP;
  }
 /*----------------------------------------------------------------------*
  * Compute rr for AC orthogonalizing search                             *
  *----------------------------------------------------------------------*/

  ii = 40;
  for (i = 0; i < 40; i++)
  {
    r0 = 0.;
    ii--;
    jj = ii;
    for (j = 0; j <= i; j++)
      r0 += h[j] * y1[jj++];
    tmp[ii] = r0;
  }
  r1 = 0.;
  for (i = 0; i < 40; i++)
    r1 += y1[i] * y1[i];
  if (r1 > 0.001f)
    r1 = 1.f / r1;
  else
    r1 = 0.;
  ii = kk = 0;
  for (i = 0; i < G729EV_G729_NB_POS; i++)
  {
    rt0 = tmp[ii] * r1;
    rt1 = tmp[ii + 1] * r1;
    rt2 = tmp[ii + 2] * r1;
    rt3 = tmp[ii + 3] * r1;
    rt4 = tmp[ii + 4] * r1;
    rri0i0[i] -= tmp[ii] * rt0;
    rri1i1[i] -= tmp[ii + 1] * rt1;
    rri2i2[i] -= tmp[ii + 2] * rt2;
    rri3i3[i] -= tmp[ii + 3] * rt3;
    rri4i4[i] -= tmp[ii + 4] * rt4;
    jj = 0;
    for (j = 0; j < G729EV_G729_NB_POS; j++)
    {
      rri0i1[kk + j] -= tmp[jj + 1] * rt0;
      rri0i2[kk + j] -= tmp[jj + 2] * rt0;
      rri0i3[kk + j] -= tmp[jj + 3] * rt0;
      rri0i4[kk + j] -= tmp[jj + 4] * rt0;
      rri1i2[kk + j] -= tmp[jj + 2] * rt1;
      rri1i3[kk + j] -= tmp[jj + 3] * rt1;
      rri1i4[kk + j] -= tmp[jj + 4] * rt1;
      rri2i3[kk + j] -= tmp[jj + 3] * rt2;
      rri2i4[kk + j] -= tmp[jj + 4] * rt2;
      jj += 5;
    }
    ii += 5;
    kk += 8;
  }

}

/*--------------------------------------------------------------------------*
 * Function  G729EV_CELP2S_cor_h_x_OTH()                                    *
 * Compute  correlations of input response h[] with the target vector X[].  *
 *--------------------------------------------------------------------------*/
static void G729EV_CELP2S_cor_h_x_OTH(REAL h[], /* (i) :  Impulse response of filters      */
                                      REAL x[], /* (i) :  Target vector                    */
                                      REAL d[], /* (o) :  Correlations between h[] and x[] */
                                      REAL y1[] /* (i) :  ac synthesised signal            */
    )
{
  int       i, j;
  REAL      s;

  REAL      tmp[G729EV_G729_L_SUBFR], r0, r1;

  r0 = r1 = 0.;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    r0 += x[i] * y1[i];
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    r1 += y1[i] * y1[i];
  if (r1 > 0.001)
    r0 /= r1;
  else
    r0 = 0.;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
    tmp[i] = x[i] - r0 * y1[i];

  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    s = (REAL) 0.0;
    for (j = i; j < G729EV_G729_L_SUBFR; j++)
      s += tmp[j] * h[j - i];
    d[i] = s;
  }

  return;

}



/*------------------------------------------------------------------------*
 * Function  G729EV_d4i40_17_fast                                         *
 *  -> 17 bits; 4 pulses in a frame of 40 samples                         *
 *------------------------------------------------------------------------*
 * The code length is 40, containing 4 nonzero pulses i0, i1, i2, i3.     *
 * Each pulses can have 8 possible positions (positive or negative)       *
 * except i3 that have 16 possible positions.                             *
 *                                                                        *
 * i0 (+-1) : 0, 5, 10, 15, 20, 25, 30, 35                                *
 * i1 (+-1) : 1, 6, 11, 16, 21, 26, 31, 36                                *
 * i2 (+-1) : 2, 7, 12, 17, 22, 27, 32, 37                                *
 * i3 (+-1) : 3, 8, 13, 18, 23, 28, 33, 38                                *
 *            4, 9, 14, 19, 24, 29, 34, 39                                *
 *------------------------------------------------------------------------*/

static int G729EV_CELP2S_d4i40_17_fast(             /* (o) : Index of pulses positions.                       */
                                        int layer,  /* (i): 0= 8k layer, other= 12k layer                     */
                                        REAL sp,    /* (i): amplitude of the side-pulses                      */
                                        REAL b[],   /* (i) : LTP residual & Dn                                */
                                        REAL dn[],  /* (i)    : Correlations between h[] and Xn[].            */
                                        REAL rr[],  /* (i) : Correlations of impulse response h[].            */
                                        REAL h0[],  /* (i) : Impulse response of filters for the 1st sample.  */
                                        REAL h[],   /* (i) : Impulse response of filters.                     */
                                        REAL cod[], /* (o) : Selected algebraic codeword.                     */
                                        REAL y[],   /* (o) : Filtered algebraic codeword.                     */
                                        int *sign   /* (o) : Signs of 4 pulses.                               */
    )
{
  int       i0, i1, i2, i3, ip[5];
  int       i0_offset, i1_offset, i2_offset, i3_offset;
  int       i, j;
  int       p_max, track;
  REAL      sign_dn[G729EV_G729_L_SUBFR], sign_dn_inv[G729EV_G729_L_SUBFR], *psign;
  REAL     *rri0i0, *rri1i1, *rri2i2, *rri3i3, *rri4i4;
  REAL     *rri0i1, *rri0i2, *rri0i3, *rri0i4;
  REAL     *rri1i2, *rri1i3, *rri1i4;
  REAL     *rri2i3, *rri2i4;
  REAL     *p0, *p1, *p2, *p3, *p4, *p5;
  REAL      Ck, Ek, Ck_tmp, Ek_tmp, max;
  REAL      num_max, den_max, num, tmp, prev_num_max, prev_den_max;
  REAL     *ptr_rri0i3_i4;
  REAL     *ptr_rri1i3_i4;
  REAL     *ptr_rri2i3_i4;
  REAL     *ptr_rri3i3_i4;
  int       sign_pat[4];


  /*-------------------------------------------------------------------*
   * Search the optimum positions of the four pulses which maximize    *
   * square(correlation)                                               *
   *-------------------------------------------------------------------*/

  rri0i0 = rr;
  rri1i1 = rri0i0 + G729EV_G729_NB_POS;
  rri2i2 = rri1i1 + G729EV_G729_NB_POS;
  rri3i3 = rri2i2 + G729EV_G729_NB_POS;
  rri4i4 = rri3i3 + G729EV_G729_NB_POS;
  rri0i1 = rri4i4 + G729EV_G729_NB_POS;
  rri0i2 = rri0i1 + G729EV_G729_MSIZE;
  rri0i3 = rri0i2 + G729EV_G729_MSIZE;
  rri0i4 = rri0i3 + G729EV_G729_MSIZE;
  rri1i2 = rri0i4 + G729EV_G729_MSIZE;
  rri1i3 = rri1i2 + G729EV_G729_MSIZE;
  rri1i4 = rri1i3 + G729EV_G729_MSIZE;
  rri2i3 = rri1i4 + G729EV_G729_MSIZE;
  rri2i4 = rri2i3 + G729EV_G729_MSIZE;

  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    if (dn[i] >= 0.0)
    {
      sign_dn[i] = 1.0;
      sign_dn_inv[i] = -1.0;
    }
    else
    {
      sign_dn[i] = -1.0;
      sign_dn_inv[i] = 1.0;
      b[i] = -b[i];
      dn[i] = -dn[i];
    }
  }

  p0 = rri0i1;
  p1 = rri0i2;
  p2 = rri0i3;
  p3 = rri0i4;

  for (i = 0; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
  {
    psign = sign_dn;

    if (psign[i] < 0.0)
    {
      psign = sign_dn_inv;
    }

    for (j = 1; j < G729EV_G729_L_SUBFR; j += G729EV_G729_STEP)
    {
      *p0 *= psign[j];
      p0++;
      *p1 *= psign[j + 1];
      p1++;
      *p2 *= psign[j + 2];
      p2++;
      *p3 *= psign[j + 3];
      p3++;
    }
  }

  p0 = rri1i2;
  p1 = rri1i3;
  p2 = rri1i4;

  for (i = 1; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
  {
    psign = sign_dn;

    if (psign[i] < 0.0)
    {
      psign = sign_dn_inv;
    }

    for (j = 2; j < G729EV_G729_L_SUBFR; j += G729EV_G729_STEP)
    {
      *p0 *= psign[j];
      p0++;
      *p1 *= psign[j + 1];
      p1++;
      *p2 *= psign[j + 2];
      p2++;
    }
  }

  p0 = rri2i3;
  p1 = rri2i4;

  for (i = 2; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
  {
    psign = sign_dn;

    if (psign[i] < 0.0)
    {
      psign = sign_dn_inv;
    }

    for (j = 3; j < G729EV_G729_L_SUBFR; j += G729EV_G729_STEP)
    {
      *p0 *= psign[j];
      p0++;
      *p1 *= psign[j + 1];
      p1++;
    }
  }

  for (track = 0; track < 5; track++)
  {
    max = b[track];
    ip[track] = track;

    for (i = track + G729EV_G729_STEP; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
    {
      if (b[i] > max)
      {
        max = b[i];
        ip[track] = i;
      }
    }
  }

  ptr_rri0i3_i4 = rri0i3;
  ptr_rri1i3_i4 = rri1i3;
  ptr_rri2i3_i4 = rri2i3;
  ptr_rri3i3_i4 = rri3i3;

  if (b[ip[3]] < b[ip[4]])
  {
    ip[3] = ip[4];
    ptr_rri0i3_i4 = rri0i4;
    ptr_rri1i3_i4 = rri1i4;
    ptr_rri2i3_i4 = rri2i4;
    ptr_rri3i3_i4 = rri4i4;
  }

  i0 = ip[0] / 5;
  i1 = ip[1] / 5;
  i2 = ip[2] / 5;
  i3 = ip[3] / 5;
  i0_offset = i0 << 3;
  i1_offset = i1 << 3;
  i2_offset = i2 << 3;
  i3_offset = i3 << 3;

  p0 = rri0i1 + i0_offset + i1;
  p1 = rri0i2 + i0_offset + i2;
  p2 = ptr_rri0i3_i4 + i0_offset + i3;
  p3 = rri1i2 + i1_offset + i2;
  p4 = ptr_rri1i3_i4 + i1_offset + i3;
  p5 = ptr_rri2i3_i4 + i2_offset + i3;

  Ck = dn[ip[0]] + dn[ip[1]] + dn[ip[2]] + dn[ip[3]];
  Ek = rri0i0[i0] + rri1i1[i1] + rri2i2[i2] + ptr_rri3i3_i4[i3] + 2 * (*p0 + *p1 + *p2 + *p3 + *p4 + *p5);

  num_max = Ck * Ck;
  den_max = Ek;
  prev_num_max = num_max;
  prev_den_max = den_max;
  track = 5;
  p_max = 0;

  for (j = 0; j < G729EV_CELP2S_FCB_REPEAT; j++)
  {

    if (track != 0)
    {
      p0 = rri1i1 + i1;
      p1 = rri2i2 + i2;
      p2 = ptr_rri3i3_i4 + i3;
      p3 = rri1i2 + i1_offset + i2;
      p4 = ptr_rri1i3_i4 + i1_offset + i3;
      p5 = ptr_rri2i3_i4 + i2_offset + i3;

      Ck_tmp = dn[ip[1]] + dn[ip[2]] + dn[ip[3]];
      Ek_tmp = *p0 + *p1 + *p2 + 2 * (*p3 + *p4 + *p5);

      p0 = rri0i0;
      p1 = rri0i1 + i1;
      p2 = rri0i2 + i2;
      p3 = ptr_rri0i3_i4 + i3;

      for (i = 0; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
      {
        Ck = Ck_tmp + dn[i];
        Ek = Ek_tmp + *p0 + 2 * (*p1 + *p2 + *p3);
        p0++;
        p1 += G729EV_G729_NB_POS;
        p2 += G729EV_G729_NB_POS;
        p3 += G729EV_G729_NB_POS;
        num = Ck * Ck;
        tmp = (num * den_max) - (num_max * Ek);

        if (tmp > 0)
        {
          num_max = num;
          den_max = Ek;
          p_max = i;
        }
      }
    }

    if (track != 1)
    {
      p0 = rri0i0 + i0;
      p1 = rri2i2 + i2;
      p2 = ptr_rri3i3_i4 + i3;
      p3 = rri0i2 + i0_offset + i2;
      p4 = ptr_rri0i3_i4 + i0_offset + i3;
      p5 = ptr_rri2i3_i4 + i2_offset + i3;

      Ck_tmp = dn[ip[0]] + dn[ip[2]] + dn[ip[3]];
      Ek_tmp = *p0 + *p1 + *p2 + 2 * (*p3 + *p4 + *p5);

      p0 = rri1i1;
      p1 = rri0i1 + i0_offset;
      p2 = rri1i2 + i2;
      p3 = ptr_rri1i3_i4 + i3;

      for (i = 1; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
      {
        Ck = Ck_tmp + dn[i];
        Ek = Ek_tmp + *p0 + 2 * (*p1 + *p2 + *p3);
        p0++;
        p1++;
        p2 += G729EV_G729_NB_POS;
        p3 += G729EV_G729_NB_POS;

        num = Ck * Ck;
        tmp = (num * den_max) - (num_max * Ek);

        if (tmp > 0)
        {
          num_max = num;
          den_max = Ek;
          p_max = i;
        }
      }
    }

    if (track != 2)
    {
      p0 = rri0i0 + i0;
      p1 = rri1i1 + i1;
      p2 = ptr_rri3i3_i4 + i3;
      p3 = rri0i1 + i0_offset + i1;
      p4 = ptr_rri0i3_i4 + i0_offset + i3;
      p5 = ptr_rri1i3_i4 + i1_offset + i3;

      Ck_tmp = dn[ip[0]] + dn[ip[1]] + dn[ip[3]];
      Ek_tmp = *p0 + *p1 + *p2 + 2 * (*p3 + *p4 + *p5);

      p0 = rri2i2;
      p1 = rri0i2 + i0_offset;
      p2 = rri1i2 + i1_offset;
      p3 = ptr_rri2i3_i4 + i3;

      for (i = 2; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
      {
        Ck = Ck_tmp + dn[i];
        Ek = Ek_tmp + *p0 + 2 * (*p1 + *p2 + *p3);
        p0++;
        p1++;
        p2++;
        p3 += G729EV_G729_NB_POS;
        num = Ck * Ck;
        tmp = (num * den_max) - (num_max * Ek);

        if (tmp > 0)
        {
          num_max = num;
          den_max = Ek;
          p_max = i;
        }
      }
    }

    if (track != 3)
    {
      p0 = rri0i0 + i0;
      p1 = rri1i1 + i1;
      p2 = rri2i2 + i2;
      p3 = rri0i1 + i0_offset + i1;
      p4 = rri0i2 + i0_offset + i2;
      p5 = rri1i2 + i1_offset + i2;

      Ck_tmp = dn[ip[0]] + dn[ip[1]] + dn[ip[2]];
      Ek_tmp = *p0 + *p1 + *p2 + 2 * (*p3 + *p4 + *p5);

      p0 = rri3i3;
      p1 = rri0i3 + i0_offset;
      p2 = rri1i3 + i1_offset;
      p3 = rri2i3 + i2_offset;

      for (i = 3; i < G729EV_G729_L_SUBFR; i += G729EV_G729_STEP)
      {
        Ck = Ck_tmp + dn[i];
        Ek = Ek_tmp + *p0 + 2 * (*p1 + *p2 + *p3);
        p0++;
        p1++;
        p2++;
        p3++;

        num = Ck * Ck;
        tmp = (num * den_max) - (num_max * Ek);

        if (tmp > 0)
        {
          num_max = num;
          den_max = Ek;
          p_max = i;
        }

        if (i == 38)
        {
          i = -1;
          p0 = rri4i4;
          p1 = rri0i4 + i0_offset;
          p2 = rri1i4 + i1_offset;
          p3 = rri2i4 + i2_offset;
        }
      }
    }

    tmp = (num_max * prev_den_max) - (prev_num_max * den_max);

    if (tmp > G729EV_CELP2S_FCB_THRES)
    {
      prev_num_max = num_max;
      prev_den_max = den_max;

      track = p_max % 5;
      ip[track] = p_max;

      if (track == 3)
      {
        ptr_rri0i3_i4 = rri0i3;
        ptr_rri1i3_i4 = rri1i3;
        ptr_rri2i3_i4 = rri2i3;
        ptr_rri3i3_i4 = rri3i3;
      }

      if (track == 4)
      {
        ip[3] = ip[4];
        track = 3;
        ptr_rri0i3_i4 = rri0i4;
        ptr_rri1i3_i4 = rri1i4;
        ptr_rri2i3_i4 = rri2i4;
        ptr_rri3i3_i4 = rri4i4;
      }

      i0 = ip[0] / 5;
      i1 = ip[1] / 5;
      i2 = ip[2] / 5;
      i3 = ip[3] / 5;
      i0_offset = i0 << 3;
      i1_offset = i1 << 3;
      i2_offset = i2 << 3;
      i3_offset = i3 << 3;
    }
    else
      break;
  }

  /* Set the sign of impulses */

  i0 = (int) sign_dn[ip[0]];
  i1 = (int) sign_dn[ip[1]];
  i2 = (int) sign_dn[ip[2]];
  i3 = (int) sign_dn[ip[3]];

  /* Find the codeword corresponding to the selected positions */

  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    cod[i] = 0.0;
  }

  if (layer != 0)
  {
    sign_pat[0] = (int) (((int) i0 + 1) / 2);
    sign_pat[1] = (int) (((int) i1 + 1) / 2);
    sign_pat[2] = (int) (((int) i2 + 1) / 2);
    sign_pat[3] = (int) (((int) i3 + 1) / 2);
    G729EV_CELP2S_Put4Patterns(ip, sign_pat, sp, cod);
  }
  else
  {
    cod[ip[0]] = (REAL) (i0);
    cod[ip[1]] = (REAL) (i1);
    cod[ip[2]] = (REAL) (i2);
    cod[ip[3]] = (REAL) (i3);
  }


  /* find the filtered codeword */
  for (i = 0; i < ip[0] - 1; i++)
  {
    y[i] = 0.0;
  }


  if (i0 > 0)
  {
    if (ip[0] > 0)
    {
      for (i = ip[0] - 1, j = -1; i < G729EV_G729_L_SUBFR; i++, j++)
      {
        y[i] = h[j];
      }
    }
    else
    {
      for (i = ip[0], j = 0; i < G729EV_G729_L_SUBFR; i++, j++)
      {
        y[i] = h0[j];
      }
    }
  }
  else
  {

    if (ip[0] > 0)
    {
      for (i = ip[0] - 1, j = -1; i < G729EV_G729_L_SUBFR; i++, j++)
      {
        y[i] = -h[j];
      }
    }
    else
    {
      for (i = ip[0], j = 0; i < G729EV_G729_L_SUBFR; i++, j++)
      {
        y[i] = -h0[j];
      }
    }
  }

  if (i1 > 0)
  {

    for (i = ip[1] - 1, j = -1; i < G729EV_G729_L_SUBFR; i++, j++)
    {
      y[i] = y[i] + h[j];
    }
  }
  else
  {

    for (i = ip[1] - 1, j = -1; i < G729EV_G729_L_SUBFR; i++, j++)
    {
      y[i] = y[i] - h[j];
    }
  }

  if (i2 > 0)
  {

    for (i = ip[2] - 1, j = -1; i < G729EV_G729_L_SUBFR; i++, j++)
    {
      y[i] = y[i] + h[j];
    }
  }
  else
  {

    for (i = ip[2] - 1, j = -1; i < G729EV_G729_L_SUBFR; i++, j++)
    {
      y[i] = y[i] - h[j];
    }
  }

  if (i3 > 0)
  {

    for (i = ip[3] - 1, j = -1; i < G729EV_G729_L_SUBFR; i++, j++)
    {
      y[i] = y[i] + h[j];
    }
  }
  else
  {

    for (i = ip[3] - 1, j = -1; i < G729EV_G729_L_SUBFR; i++, j++)
    {
      y[i] = y[i] - h[j];
    }
  }

  /* find codebook index;  17-bit address */

  i = 0;

  if (i0 > 0)
  {
    i += 1;
  }

  if (i1 > 0)
  {
    i += 2;
  }

  if (i2 > 0)
  {
    i += 4;
  }

  if (i3 > 0)
  {
    i += 8;
  }
  *sign = i;

  ip[0] = ip[0] / 5;
  ip[1] = ip[1] / 5;
  ip[2] = ip[2] / 5;
  i = ip[3] / 5;
  j = i * 5;
  j = ip[3] - j - 3;
  ip[3] = i * 2 + j;

  i = ip[0] + (ip[1] << 3) + (ip[2] << 6) + (ip[3] << 9);

  return i;

}



/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_ACELP_code_A_OTH()               *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~               *
 *   Index of pulses positions                               *
 *-----------------------------------------------------------*/

int G729EV_CELP2S_ACELP_code_A_OTH(                   /* (o) :index of pulses positions     */
                                    REAL x[],         /* (i) :Target vector                 */
                                    REAL res2[],      /* (i) : LTP residual                 */
                                    REAL h[],         /* (i) :Inpulse response of filters   */
                                    int T0,           /* (i) :Pitch lag                     */
                                    REAL pitch_sharp, /* (i) :Last quantized pitch gain     */
                                    REAL code[],      /* (o) :Innovative codebook           */
                                    REAL y[],         /* (o) :Filtered innovative codebook  */
                                    int *sign,        /* (o) :Signs of 4 pulses             */
                                    REAL y1[]         /* (i) :AC synthesized signal         */
    )
{
  int       i, index;
  REAL      h_buf[G729EV_G729_L_SUBFR + 1];
  REAL      Dn[G729EV_G729_L_SUBFR], bn[G729EV_G729_L_SUBFR];
  REAL      rr[G729EV_G729_DIM_RR];
  REAL      energy_res2, energy_Dn;

  G729EV_G729_Copy(h, h_buf + 1, G729EV_G729_L_SUBFR);
  h_buf[0] = 0;

    /*-----------------------------------------------------------------*
     * Include fixed-gain pitch contribution into impulse resp. h[]    *
     * Find correlations of h[] needed for the codebook search.        *
     *-----------------------------------------------------------------*/

  if (T0 < G729EV_G729_L_SUBFR)
    for (i = T0; i < G729EV_G729_L_SUBFR; i++)
      h[i] += pitch_sharp * h[i - T0];

  G729EV_CELP2S_cor_h_OTH(h, rr, y1);

    /*-----------------------------------------------------------------*
     * Compute correlation of target vector with impulse response.     *
     *-----------------------------------------------------------------*/

  G729EV_CELP2S_cor_h_x_OTH(h, x, Dn, y1);


  energy_res2 = 0.0;
  energy_Dn = 0.0;


  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    energy_res2 += (res2[i] * res2[i]);
    energy_Dn += (Dn[i] * Dn[i]);
  }

  if (energy_res2 == 0)
    energy_res2 = G729EV_G729_FLT_MAX_G729;
  else
    energy_res2 = (REAL) 1.0 / (REAL) sqrt(energy_res2);

  if (energy_Dn == 0)
    energy_Dn = G729EV_G729_FLT_MAX_G729;
  else
    energy_Dn = (REAL) 1.0 / (REAL) sqrt(energy_Dn);

  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    bn[i] = res2[i] * energy_res2 + Dn[i] * energy_Dn;
  }

    /*-----------------------------------------------------------------*
     * Find innovative codebook.                                       *
     *-----------------------------------------------------------------*/

  /* 1st layer search */
  index = G729EV_CELP2S_d4i40_17_fast(0, 0, bn, Dn, rr, h_buf + 1, h_buf + 1, code, y, sign);


    /*-----------------------------------------------------------------*
     * Compute innovation vector gain.                                 *
     * Include fixed-gain pitch contribution into code[].              *
     *-----------------------------------------------------------------*/

  if (T0 < G729EV_G729_L_SUBFR)
    for (i = T0; i < G729EV_G729_L_SUBFR; i++)
      code[i] += pitch_sharp * code[i - T0];

  return index;

}


/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_ACELP_code_2NDLAYER()            *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~            *
 *   Index of patterns centre positions                      *
 *-----------------------------------------------------------*/

int G729EV_CELP2S_ACELP_code_2NDLAYER(REAL x[],         /* (i) :Target vector                */
                                      REAL res2[],      /* (i) : LTP residual                */
                                      REAL h[],         /* (i) :Inpulse response of filters  */
                                      REAL voiced_fac,  /* (i) :voiced_fac (0..1)            */
                                      REAL code[],      /* (o) :Innovative codebook          */
                                      REAL y[],         /* (o) :Filtered innovative codebook */
                                      int *sign         /* (o) :Signs of 4 pulses            */
    )
{
  int       index;
  REAL      Dn[G729EV_G729_L_SUBFR], bn[G729EV_G729_L_SUBFR];
  REAL      rr[G729EV_G729_DIM_RR];
  REAL      energy_res2, energy_Dn;
  REAL      fac;
  REAL      h_buf[G729EV_G729_L_SUBFR + 1], x_hp[G729EV_G729_L_SUBFR + 1];
  REAL      h0_buf[G729EV_G729_L_SUBFR + 1];
  REAL      h1_buf[G729EV_G729_L_SUBFR + 1];
  REAL      h0_buf0[G729EV_G729_L_SUBFR + 1];
  int       i;

  G729EV_G729_Copy(h, h0_buf + 1, G729EV_G729_L_SUBFR);
  G729EV_G729_Copy(x, x_hp + 1, G729EV_G729_L_SUBFR);
  h0_buf[0] = 0.;
  x_hp[0] = 0.;

  /* High Pass filter the target vector and the impulse response to better focus on HFs */
  G729EV_MAIN_CONVOLVE_3Tap(h0_buf, h1_buf, G729EV_CELP2S_HP_FACT, G729EV_G729_L_SUBFR + 1);
  G729EV_MAIN_CONVOLVE_3Tap(x_hp, x_hp, G729EV_CELP2S_HP_FACT, G729EV_G729_L_SUBFR + 1);
  h1_buf[0] = 0.0;
  x_hp[0] = 0.0;

  fac = G729EV_CELP2S_SP * voiced_fac;

  /* Modify h to introduce tripulse pattern effect */
  G729EV_MAIN_CONVOLVE_3Tap(h1_buf, h_buf, fac, G729EV_G729_L_SUBFR + 1);

  /*-----------------------------------------------------------------*
   * Include fixed-gain pitch contribution into impulse resp. h[]    *
   * Find correlations of h[] needed for the codebook search.        *
   *-----------------------------------------------------------------*/

  G729EV_G729_Cor_h(h_buf + 1, rr);

  /*-----------------------------------------------------------------*
   * Compute correlation of target vector with impulse response.     *
   *-----------------------------------------------------------------*/

  G729EV_G729_Cor_h_X(h_buf + 1, x_hp + 1, Dn, 1);

  energy_res2 = 0.0;
  energy_Dn = 0.0;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    energy_res2 += (res2[i] * res2[i]);
    energy_Dn += (Dn[i] * Dn[i]);
  }

  if (energy_res2 == 0)
    energy_res2 = G729EV_G729_FLT_MAX_G729;
  else
    energy_res2 = (REAL) 1.0 / (REAL) sqrt(energy_res2);

  if (energy_Dn == 0)
    energy_Dn = G729EV_G729_FLT_MAX_G729;
  else
    energy_Dn = (REAL) 1.0 / (REAL) sqrt(energy_Dn);

  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    bn[i] = res2[i] * energy_res2 + Dn[i] * energy_Dn;
  }

  /*-----------------------------------------------------------------*
   * Find innovative codebook.                                       *
   *-----------------------------------------------------------------*/

  fac = G729EV_CELP2S_SP * voiced_fac;
  G729EV_MAIN_CONVOLVE_2Tap(h0_buf, h0_buf0, fac, G729EV_G729_L_SUBFR + 1);
  G729EV_MAIN_CONVOLVE_3Tap(h0_buf, h0_buf, fac, G729EV_G729_L_SUBFR + 1);

  /* 2nd layer search */
  index = G729EV_CELP2S_d4i40_17_fast(1, fac, bn, Dn, rr, h0_buf0 + 1, h0_buf + 1, code, y, sign);

  return index;

}
