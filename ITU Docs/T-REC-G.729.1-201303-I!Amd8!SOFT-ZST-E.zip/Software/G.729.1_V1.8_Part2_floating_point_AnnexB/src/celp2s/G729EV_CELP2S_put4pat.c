/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include "G729EV_G729_ld8k.h"

/*-----------------------------------------------------------*
 *  Function  G729EV_CELP2S_Put4Patterns()                   *
 *  ~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~                    *
 *   Arranging the 4 tri-pulse patterns                      *
 *-----------------------------------------------------------*/

void G729EV_CELP2S_Put4Patterns(int pos[],  /* (i) : positions of the 4 patterns  */
                                int si[],   /* (i) : signs of the 4 patterns      */
                                REAL sp,    /* (i) : amplitude of the side pulses */
                                REAL cod[]  /* (o) : decoded FCB vector           */
    )
{
  int       i;
  REAL     *p_cod;

  p_cod = cod;
  for (i = 0; i < G729EV_G729_L_SUBFR; i++)
  {
    *p_cod++ = 0.;
  }


  {
    if (si[0] != 0)
    {
      if (pos[0] != 0)
        cod[pos[0] - 1] = sp;
      cod[pos[0] + 1] = sp;
    }
    else
    {
      if (pos[0] != 0)
        cod[pos[0] - 1] = -sp;
      cod[pos[0] + 1] = -sp;
    }
  }

  for (i = 1; i < 3; i++)
  {
    if (si[i] != 0)
    {
      cod[pos[i] - 1] = cod[pos[i] - 1] + sp;
      cod[pos[i] + 1] = cod[pos[i] + 1] + sp;
    }
    else
    {
      cod[pos[i] - 1] = cod[pos[i] - 1] - sp;
      cod[pos[i] + 1] = cod[pos[i] + 1] - sp;
    }
  }

  {
    if (si[3] != 0)
    {
      cod[pos[3] - 1] = cod[pos[3] - 1] + sp;
      if (pos[3] != 39)
        cod[pos[3] + 1] = cod[pos[3] + 1] + sp;
    }
    else
    {
      cod[pos[3] - 1] = cod[pos[3] - 1] - sp;
      if (pos[3] != 39)
        cod[pos[3] + 1] = cod[pos[3] + 1] - sp;
    }
  }


  for (i = 0; i < 4; i++)
  {
    if (si[i] != 0)
    {
      cod[pos[i]] = cod[pos[i]] + (REAL) 1.0;
    }
    else
    {
      cod[pos[i]] = cod[pos[i]] - (REAL) 1.0;
    }
  }

  return;
}
