/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#ifndef __G729EV_MAIN_ENVADAPTATION_H__
#define __G729EV_MAIN_ENVADAPTATION_H__

void
 
 
 G729EV_MAIN_envAdapt(REAL * sOut_low,
                      REAL * sBasic_low,
                      REAL * sTdacAdd_low,
                      REAL * vmlold,
                      REAL * sOut_hi,
                      REAL * sBasic_hi,
                      REAL * sTdacInc_hi,
                      REAL * vmhold,
                      int work, int begin_index_low, int end_index_low, int begin_index_high, int end_index_high);

void      G729EV_MAIN_PreechoFalseAlarm(REAL * rec_sig,
                                        REAL * imdct_mem, REAL * max_prev, int *begin_ind, int *end_ind);

#endif /* __G729EV_MAIN_ENVADAPTATION_H__ */
