/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"
#include "G729EV_G729_tab_ld8k.h"





/*****************************************************************************/
/* lpc analysis routines                                                     */
/*****************************************************************************/

/*-----------------------------------------------------------------------------------------
 * Function G729EV_G729_autocorr - compute the auto-correlations of windowed speech signal
 *-----------------------------------------------------------------------------------------*/

void G729EV_G729_AutocorrLPC(REAL * x,  /*(i) : Input signal               */
                             int m,     /*(i) : LPC order                  */
                             REAL * r   /*(o) : Autocorrelations           */
    )
{
  REAL      y[G729EV_G729_L_WINDOW];
  REAL      sum;
  int       i, j;

  /* Windowing of signal */
  for (i = 0; i < G729EV_G729_L_WINDOW; i++)
    y[i] = x[i] * hamwindow[i];

  /* Compute r[1] to r[m] */
  for (i = 0; i <= m; i++)
  {
    sum = (REAL) 0.0;
    for (j = 0; j < G729EV_G729_L_WINDOW - i; j++)
      sum += y[j] * y[j + i];
    r[i] = sum;
  }
  if (r[0] < (REAL) 1.0)
    r[0] = (REAL) 1.0;

  return;
}

/*-------------------------------------------------------*
 * Function G729EV_G729_Lag_window()                     *
 *                                                       *
 * Lag_window on autocorrelations.                       *
 *                                                       *
 * r[i] *= lag_wind[i]                                   *
 *                                                       *
 *-------------------------------------------------------*/
void G729EV_G729_Lag_window(int m,    /*(i)   : LPC order   */
                            REAL r[]  /*(i/o) : Autocorrelations */
    )
{
  int       i;

  for (i = 1; i <= m; i++)
    r[i] *= lwindow[i - 1];

  return;
}


/*___________________________________________________________________________
 |                                                                           |
 |      LEVINSON-DURBIN algorithm                                            |
 |      ~~~~~~~~~~~~~~~~~~~~~~~~~~                                           |
 |---------------------------------------------------------------------------|
 |                                                                           |
 | Algorithm                                                                 |
 |                                                                           |
 |       R[i]    autocorrelations.                                           |
 |       A[i]    filter coefficients.                                        |
 |       rc      reflection coefficients.                                    |
 |       Alpha   prediction gain.                                            |
 |                                                                           |
 |       Initialization:                                                     |
 |               A[0] = 1                                                    |
 |               rc   = -R[1]/R[0]                                           |
 |               A[1] = rc                                                   |
 |               Alpha = R[0] * (1-rc**2]                                    |
 |                                                                           |
 |       Do for  i = 2 to M                                                  |
 |                                                                           |
 |            S =  SUM ( R[j]*A[i-j] ,j=1,i-1 ) +  R[i]                      |
 |                                                                           |
 |            rc = -S / Alpha                                                |
 |                                                                           |
 |            An[j] = A[j] + rc*A[i-j]   for j=1 to i-1                      |
 |                                      where   An[i] = new A[i]             |
 |            An[i]=rc                                                       |
 |                                                                           |
 |            Alpha=Alpha * (1-rc**2)                                        |
 |                                                                           |
 |       END                                                                 |
 |___________________________________________________________________________|
*/

void G729EV_G729_Levinson(REAL * r,   /*(i) : Vector of autocorrelations          */
                          REAL * a,   /*(o) : A[M]    LPC coefficients  (m = 10)  */
                          REAL * rc,  /*(o) : rc[M]   Reflection coefficients.    */
                          REAL * old_A, REAL * old_rc)
{
  REAL      s, at, err;
  int       i, j, l;

  if (r[1] > r[0])
    r[1] = r[0];
  rc[0] = (-r[1]) / r[0];
  a[0] = (REAL) 1.0;
  a[1] = rc[0];
  err = r[0] + r[1] * rc[0];
  for (i = 2; i <= G729EV_G729_M; i++)
  {
    s = (REAL) 0.0;
    for (j = 0; j < i; j++)
      s += r[i - j] * a[j];
    if (err != 0.)
    {
      rc[i - 1] = (-s) / (err);
    }
    else
      rc[i - 1] = (REAL) 1.;

    /* Test for unstable filter. If unstable keep old A(z) */
    if (fabs(rc[i - 1]) > (REAL) 0.999451)
    {
      for (j = 0; j <= G729EV_G729_M; j++)
      {
        a[j] = old_A[j];
      }
      rc[0] = old_rc[0];        /* only two rc coefficients are needed */
      rc[1] = old_rc[1];
      return;
    }

    /*------------------------------------------*
    *  Compute new LPC coeff.                  *
    *------------------------------------------*/

    for (j = 1; j <= (i / 2); j++)
    {
      l = i - j;
      at = a[j] + rc[i - 1] * a[l];
      a[l] += rc[i - 1] * a[j];
      a[j] = at;
    }
    a[i] = rc[i - 1];
    err += rc[i - 1] * s;
    if (err <= (REAL) 0.0)
      err = (REAL) 0.001;
  }

  G729EV_G729_Copy(a, old_A, (G729EV_G729_M + 1));
  old_rc[0] = rc[0];
  old_rc[1] = rc[1];

  return;
}


/*-------------------------------------------------------------------*
*  Function G729EV_G729_az_lsp:                                      *
*            ~~~~~~                                                  *
*   Compute the LSPs from  the LPC coefficients a[] (order=10) using *
* Chebyshev polynomials. The found LSPs are in the cosine domain     *
* with values in the range from 1 down to -1.                        *
* The table grid[] contains the points (in the cosine domain) at     *
* which the polynomials are evaluated. The table corresponds to      *
* NO_POINTS frequencies uniformly spaced between 0 and pi.           *
*--------------------------------------------------------------------*/

void G729EV_G729_Az_lsp(REAL * a,       /*(i) : predictor coefficients                   */
                        REAL * lsp,     /*(o): Line spectral pairs                       */
                        REAL * old_lsp  /*(i) : old lsp[] (in case not found 10 roots)   */
    )
{
  int       i, j, nf, ip;
  REAL      xlow, ylow, xhigh, yhigh, xmid, ymid, xint;
  REAL     *coef;

  REAL      f1[G729EV_G729_M / 2 + 1], f2[G729EV_G729_M / 2 + 1];

  /*------------------------------------------------------------*
  * find the sum and diff polynomials F1(z) and F2(z)           *
  *      F1(z) = [A(z) + z^11 A(z^-1)]/(1+z^-1)                 *
  *      F2(z) = [A(z) - z^11 A(z^-1)]/(1-z^-1)                 *
  *-------------------------------------------------------------*/
  f1[0] = (REAL) 1.0;
  f2[0] = (REAL) 1.0;
  for (i = 1, j = G729EV_G729_M; i <= G729EV_G729_NC; i++, j--)
  {
    f1[i] = a[i] + a[j] - f1[i - 1];
    f2[i] = a[i] - a[j] + f2[i - 1];
  }

  /*---------------------------------------------------------------------*
  * Find the LSPs (roots of F1(z) and F2(z) ) using the                 *
  * Chebyshev polynomial evaluation.                                    *
  * The roots of F1(z) and F2(z) are alternatively searched.            *
  * We start by finding the first root of F1(z) then we switch          *
  * to F2(z) then back to F1(z) and so on until all roots are found.    *
  *                                                                     *
  *  - Evaluate Chebyshev pol. at grid points and check for sign change.*
  *  - If sign change track the root by subdividing the interval        *
  *    NO_ITER times and ckecking sign change.                          *
  *---------------------------------------------------------------------*/
  nf = 0;                       /* number of found frequencies */
  ip = 0;                       /* flag to first polynomial   */

  coef = f1;                    /* start with F1(z) */

  xlow = grid[0];
  ylow = G729EV_G729_chebyshev(xlow, coef, G729EV_G729_NC);

  j = 0;
  while ((nf < G729EV_G729_M) && (j < G729EV_G729_GRID_POINTS))
  {
    j++;
    xhigh = xlow;
    yhigh = ylow;
    xlow = grid[j];
    ylow = G729EV_G729_chebyshev(xlow, coef, G729EV_G729_NC);

    if (ylow * yhigh <= (REAL) 0.0) /* if sign change new root exists */
    {
      j--;

      /* divide the interval of sign change by 4 */

      for (i = 0; i < 4; i++)
      {
        xmid = (REAL) 0.5 *(xlow + xhigh);

        ymid = G729EV_G729_chebyshev(xmid, coef, G729EV_G729_NC);
        if (ylow * ymid <= (REAL) 0.0)
        {
          yhigh = ymid;
          xhigh = xmid;
        }
        else
        {
          ylow = ymid;
          xlow = xmid;
        }
      }

      /* linear interpolation for evaluating the root */

      xint = xlow - ylow * (xhigh - xlow) / (yhigh - ylow);

      lsp[nf] = xint;           /* new root */
      nf++;

      ip = 1 - ip;              /* flag to other polynomial    */
      coef = ip ? f2 : f1;      /* pointer to other polynomial */

      xlow = xint;
      ylow = G729EV_G729_chebyshev(xlow, coef, G729EV_G729_NC);
    }
  }

  /* Check if G729EV_G729_M roots found */
  /* if not use the LSPs from previous frame */

  if (nf < G729EV_G729_M)
  {
    for (i = 0; i < G729EV_G729_M; i++)
      lsp[i] = old_lsp[i];
  }
  return;
}

/*--------------------------------------------------------------*
 * Function  G729EV_G729_chebyshev:                             *
 *           ~~~~~~~~~~~~~~~~~~~~~~                             *
 *    Evaluates the Chebyshev polynomial series                 *
 *--------------------------------------------------------------*
 *  The polynomial order is                                     *
 *     n = m/2   (m is the prediction order)                    *
 *  The polynomial is given by                                  *
 *    C(x) = T_n(x) + f(1)T_n-1(x) + ... +f(n-1)T_1(x) + f(n)/2 *
 * Arguments:                                                   *
 *  x:     input value of evaluation; x = cos(frequency)        *
 *  f[]:   coefficients of the pol.                             *
 *  n:     order of the pol.                                    *
 *                                                              *
 * The value of C(x) is returned.                               *
 *--------------------------------------------------------------*/

REAL G729EV_G729_chebyshev(REAL x, REAL * f, int n)
{
  REAL      b1, b2, b0, x2;
  int       i;

  x2 = (REAL) 2.0 *x;           /* x2 = 2.0*x;                        */

  b2 = (REAL) 1.0;              /* f[0]                               */
  b1 = x2 + f[1];               /* b1 = x2 + f[1];                    */
  for (i = 2; i < n; i++)
  {                             /*                                    */
    b0 = x2 * b1 - b2 + f[i];   /* b0 = x2 * b1 - 1. + f[2];          */
    b2 = b1;                    /* b2 = x2 * b0 - b1 + f[3];          */
    b1 = b0;                    /* b1 = x2 * b2 - b0 + f[4];          */
  }

  return (x * b1 - b2 + (REAL) 0.5 * f[n]); /* return (x*b1 - b2 + 0.5*f[5]);     */
}
