/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

#include <math.h>
#include <stdlib.h>

#include "G729EV_G729_ld8k.h"

/*****************************************************************************/
/* auxiliary functions                                                       */
/*****************************************************************************/
/*-------------------------------------------------------------------*
 * Function  Set zero()                                              *
 *           ~~~~~~~~~~                                              *
 * Set vector x[] to zero                                            *
 *-------------------------------------------------------------------*/
void G729EV_G729_Set_zero(REAL x[],   /* (o)    : vector to clear     */
                          int length  /* (i)    : length of vector    */
    )
{
  int       i;

  for (i = 0; i < length; i++)
    x[i] = (REAL) 0.0;

  return;
}

/*------------------------------------------------------------------*
 * Function  G729EV_G729_Copy:                                      *
 *           ~~~~~                                                  *
 * Copy vector x[] to y[]                                           *
 *------------------------------------------------------------------*/
void G729EV_G729_Copy(REAL x[],   /* (i)   : input vector   */
                      REAL y[],   /* (o)   : output vector  */
                      int length  /* (i)   : vector length  */
    )
{
  int       i;

  for (i = 0; i < length; i++)
    y[i] = x[i];

  return;
}

/* Random generator  */
INT16 G729EV_G729_Random(INT16 * seed)
{

  *seed = (INT16) ((*seed) * 31821L + 13849L);

  return (*seed);

}

/*---------------------------------------------------------------------------
 * Function G729EV_G729_inv_sqrt - compute y = 1 / sqrt(x)
 *----------------------------------------------------------------------------
 */
REAL G729EV_G729_inv_sqrt(        /* output: 1/sqrt(x) */
                           REAL x /* input : value of x */
    )
{
  return ((REAL) 1.0 / (REAL) sqrt((double) x));
}
