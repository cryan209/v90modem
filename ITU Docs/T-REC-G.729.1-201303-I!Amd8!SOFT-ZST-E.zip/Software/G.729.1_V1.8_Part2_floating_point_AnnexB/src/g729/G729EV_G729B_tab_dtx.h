/* ITU-T G.729.1 Annex B - Reference C code for floating-point implementation    */
/* $Release:       1.8                                                            */
/* Note: release number updated without change in code
         [G.729.1 (2006) Amd.6 (2010-03-29)]
/* Revision Date: August 29, 2009                                                   */

/*
   ITU-T G.729.1 Annex B   ANSI-C Source Code
   Copyright (c) 2006-2009 
   France Telecom, Matsushita Electric, Mindspeed, Siemens AG, ETRI, VoiceAge Corp.
                      
*/

/*
   ITU-T G.729 Annex C+ - Reference C code for floating point
                         implementation of G.729 Annex C+
                         (integration of Annexes B, D and E)
                         Version 2.1 of October 1999
*/

/*
 File : TAB_DTX.H
*/

#include "CodecTypedef.h"

/* Quantization of LSF vector */
extern int PtrTab_1[32];
extern int PtrTab_2[2][16];

/* Quantization of SID gain */
extern REAL fact[NB_GAIN + 1];
extern REAL tab_Sidgain[32];

/* SID LSF quantization */
extern REAL noise_fg_sum[G729EV_G729_MODE][G729EV_G729_M];
